/*****************************
Copyright 2011 Rafael Muñoz Salinas. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Rafael Muñoz Salinas ''AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Rafael Muñoz Salinas OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Rafael Muñoz Salinas.
********************************/

/**
* @file simple_double.cpp
* @author Bence Magyar
* @date June 2012
* @version 0.1
* @brief ROS version of the example named "simple" in the Aruco software package.
*/

#include <aruco/aruco.h>
#include <aruco/cvdrawingutils.h>
#include <posetracker.h>
#include <fstream>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sstream>
#include <stdexcept>
#include <Eigen/Geometry>
#include <opencv2/core/eigen.hpp>

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>

#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include "aruco_ros/aruco_ros_utils.h"

#include <markermap.h>
#include "geometry_msgs/PoseStamped.h"


using namespace cv;
using namespace aruco;

cv::Mat inImage;
aruco::CameraParameters camParam;
MarkerDetector mDetector;
MarkerMap TheMarkerMapConfig;

ros::Subscriber cam_info_sub;
bool cam_info_received;
image_transport::Publisher image_pub;
image_transport::Publisher debug_pub;
ros::Publisher pose_pub;
ros::Publisher visual_pub_;

std::string marker_set;
std::string dictionary;
// vector<geometry_msgs::PoseStamped> smoothPs;
geometry_msgs::PoseStamped ps, prevPs, prevPrevPs;

ros::Time prev_stamp; 

double marker_size;
int marker_id, count= 0;


//! Transform the pose from Rvec to quaternion
void getCameraPoseEigen( cv::Mat& tv, cv::Mat& rv, Eigen::Quaterniond &quats, Eigen::Vector3d &pos){

  // std::cout << "Rve     :[" <<rv.at<float>(0,0) << ", " << rv.at<float>(1,0) << ", " << rv.at<float>(2,0) << "]" << std::endl;  
  // std::cout << "Tve     :[" <<tv.at<float>(0,0) << ", " << tv.at<float>(1,0) << ", " << tv.at<float>(2,0) << "]" << std::endl;  

  cv::Mat M44 = cv::Mat_<double>(4,4);
  cv::Mat R   = cv::Mat_<double>(3,3);   
  cv::Rodrigues(rv, R);   
 
  M44.at<double>(0,0) = R.at<float>(0,0);
  M44.at<double>(0,1) = R.at<float>(0,1);
  M44.at<double>(0,2) = R.at<float>(0,2);
  M44.at<double>(0,3) = tv.at<float>(0,0);
  M44.at<double>(1,0) = R.at<float>(1,0);
  M44.at<double>(1,1) = R.at<float>(1,1);
  M44.at<double>(1,2) = R.at<float>(1,2);
  M44.at<double>(1,3) = tv.at<float>(1,0);
  M44.at<double>(2,0) = R.at<float>(2,0);
  M44.at<double>(2,1) = R.at<float>(2,1);
  M44.at<double>(2,2) = R.at<float>(2,2);
  M44.at<double>(2,3) = tv.at<float>(2,0);
  M44.at<double>(3,0) = 0.0;
  M44.at<double>(3,1) = 0.0;
  M44.at<double>(3,2) = 0.0;
  M44.at<double>(3,3) = 1.0;   
  M44 = M44.inv();
  pos.x() = M44.at<double>(2,3);
  pos.y() = -M44.at<double>(0,3);
  pos.z() = -M44.at<double>(1,3);

  float theta = sqrt((rv.at<float>(0,0)*rv.at<float>(0,0)) + (rv.at<float>(1,0)*rv.at<float>(1,0)) + (rv.at<float>(2,0)*rv.at<float>(2,0)));        
  quats.w() = cos(theta/2.0);
  quats.x() = rv.at<float>(2,0)*sin(theta/2.0)/theta;
  quats.y() = -rv.at<float>(0,0)*sin(theta/2.0)/theta;
  quats.z() = -rv.at<float>(1,0)*sin(theta/2.0)/theta;

  float signum = ((quats.w()>0) - (quats.w()<0))*1.0f;  
  quats.w() *= signum;
  quats.x() *= signum;
  quats.y() *= signum;
  quats.z() *= signum;
    
  // std::cout << "Attitude:[" << quats.w() << ", " << quats.x() << ", " << quats.y() << ", " << quats.z() << "]" << std::endl;   
  // auto euler = quats.toRotationMatrix().eulerAngles(0,1,2);  
  // std::cout << "RPY     :[" << euler.x()*57.2957795131 << ", " << euler.y()*57.2957795131 << ", " << euler.z()*57.2957795131 << "]"<< std::endl;  
  // std::cout << "Pos     :[" <<pos.x() << ", " << pos.y() << ", " << pos.z() << "]" << std::endl;  
  
}

void image_callback(const sensor_msgs::ImageConstPtr& msg)
{
  double ticksBefore = cv::getTickCount();
  static tf::TransformBroadcaster br;
  // ROS_DEBUG("image_time_stamp: %f", msg.header.stamp.sec+ msg.header.stamp.nsec/1000000000.0);
  if(cam_info_received)
  {
    ros::Time curr_stamp(ros::Time::now());
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::RGB8);      
      inImage = cv_ptr->image;
      // camParam.resize(inImage.size());

      std::map<uint32_t, MarkerPoseTracker> mTracker;  // use a map so that for each id, we use a different pose tracker

      // set the dictionary used
      mDetector.setDictionary(dictionary);
      
      TheMarkerMapConfig.clear();
      TheMarkerMapConfig.readFromFile(marker_set);

      // detect the markers without computing R & T      
      vector<Marker> Markers = mDetector.detect(inImage); //, camParam, marker_size); 
      vector<cv::Point2f> corners;
      vector<cv::Point3f> d3Corners;
      for (auto& marker : Markers){    
        // get the corners of each marker
        corners.push_back(marker[0]);
        corners.push_back(marker[1]);
        corners.push_back(marker[2]);
        corners.push_back(marker[3]);
        // get the relating position of in inertial frame
        for (auto p : TheMarkerMapConfig.getMarker3DInfo(marker.id).points){
          d3Corners.push_back(p);
        } 
        
        // to visualize the pose of each marker
        mTracker[marker.id].estimatePose(marker, camParam, marker_size);  // call its tracker and estimate the pose      
        marker.draw(inImage, Scalar(0, 0, 255), 2);
        // CvDrawingUtils::draw3dCube(inImage, marker, camParam);
        // CvDrawingUtils::draw3dAxis(inImage, marker, camParam);
      }


      if(Markers.size()>0){
        //RT = TheMarkerMapConfig.calculateExtrinsics( Markers, marker_size, camParam.CameraMatrix, camParam.Distorsion);
        pair <cv::Mat, cv::Mat> RT;
        Eigen::Quaterniond quat;
        Eigen::Vector3d pos;        
        
        // cout << d3Corners << endl << corners << endl << camParam.CameraMatrix << endl << camParam.Distorsion << endl << RT.first << endl << RT.second << endl << endl;
        cv::solvePnP(d3Corners, corners, camParam.CameraMatrix, camParam.Distorsion, RT.first, RT.second); 
        getCameraPoseEigen( RT.second, RT.first, quat, pos);        
        ps.header.seq = ticksBefore;
        ps.pose.position.x = pos.x()-0.12; // 0.12 is camera off set from CoG
        ps.pose.position.y = pos.y();
        ps.pose.position.z = pos.z()-0.09;
        ps.header.stamp =curr_stamp;            
        
        ps.pose.orientation.w = quat.w();
        ps.pose.orientation.x = quat.x();
        ps.pose.orientation.y = quat.y();
        ps.pose.orientation.z = quat.z();
        // std::cout << ps.pose.position.x<< " " << ps.pose.position.y<< " " << ps.pose.position.z << std::endl;   
        // std::cout << ps.pose.orientation.w<< " " << ps.pose.orientation.x<< " " << ps.pose.orientation.y << " " << ps.pose.orientation.z << std::endl;                
        visual_pub_.publish(ps);
      }     
      
      if(image_pub.getNumSubscribers() > 0)
      {
        //show input with augmented information
        cv_bridge::CvImage out_msg;
        out_msg.header.stamp = curr_stamp;
        out_msg.encoding = sensor_msgs::image_encodings::RGB8;
        out_msg.image = inImage;
        image_pub.publish(out_msg.toImageMsg());
      }

      if(debug_pub.getNumSubscribers() > 0)
      {
        //show also the internal image resulting from the threshold operation
        cv_bridge::CvImage debug_msg;
        debug_msg.header.stamp = curr_stamp;
        debug_msg.encoding = sensor_msgs::image_encodings::MONO8;
        debug_msg.image = mDetector.getThresholdedImage(0);
        debug_pub.publish(debug_msg.toImageMsg());
      }

      // ROS_DEBUG("Ticks:   runtime: %f ms", 1000*(cv::getTickCount() - ticksBefore)/cv::getTickFrequency());
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
  }
}




// wait for one camerainfo, then shut down that subscriber
void cam_info_callback(const sensor_msgs::CameraInfo &msg)
{
  camParam = aruco_ros::rosCameraInfo2ArucoCamParams(msg, false); //useRectifiedImages
  cam_info_received = true;
  cam_info_sub.shutdown();
}

int main(int argc,char **argv)
{
  ros::init(argc, argv, "aruco_simple");
  ros::NodeHandle nh("~");
  
  image_transport::ImageTransport it(nh);   
  
  image_transport::Subscriber image_sub = it.subscribe("/image_raw", 1, &image_callback);
  cam_info_sub = nh.subscribe("/camera_info", 1, &cam_info_callback);

  cam_info_received = false;
  image_pub = it.advertise("result", 1);
  debug_pub = it.advertise("debug", 1);
  // pose_pub = nh.advertise<geometry_msgs::PoseStamped>("pose", 100);  

  nh.param<double>("marker_size", marker_size, 0.1778);
  nh.param<int>("marker_id", marker_id, 582);  
  nh.param<std::string>("marker_set", marker_set, "");
  nh.param<std::string>("dictionary", dictionary, "ARUCO");
   
  visual_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose", 1);

  ROS_INFO("Aruco node started with marker size of %f meters and marker ids to track: %d",
           marker_size, marker_id);  

  ros::spin();   
}
