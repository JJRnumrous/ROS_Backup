/*****************************
Copyright 2011 Rafael Muñoz Salinas. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are
permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, this list of
      conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright notice, this list
      of conditions and the following disclaimer in the documentation and/or other materials
      provided with the distribution.

THIS SOFTWARE IS PROVIDED BY Rafael Muñoz Salinas ''AS IS'' AND ANY EXPRESS OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL Rafael Muñoz Salinas OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the
authors and should not be interpreted as representing official policies, either expressed
or implied, of Rafael Muñoz Salinas.
********************************/

/**
* @file simple_double.cpp
* @author Bence Magyar
* @date June 2012
* @version 0.1
* @brief ROS version of the example named "simple" in the Aruco software package.
*/

#include <aruco/aruco.h>
#include <aruco/cvdrawingutils.h>
#include <posetracker.h>
#include <fstream>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sstream>
#include <stdexcept>
#include <Eigen/Geometry>
#include <opencv2/core/eigen.hpp>

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>

#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include "aruco_ros/aruco_ros_utils.h"

#include <markermap.h>
#include "geometry_msgs/PoseStamped.h"
#include <opencv2/calib3d/calib3d.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/aruco.hpp>


// using namespace cv;
// using namespace aruco;

cv::Mat inImage;
aruco::CameraParameters camParam;
aruco::MarkerDetector mDetector;
aruco::MarkerMap TheMarkerMapConfig;

ros::Subscriber cam_info_sub;
bool cam_info_received;
image_transport::Publisher image_pub;
image_transport::Publisher debug_pub;
ros::Publisher pose_pub;
ros::Publisher visual_pub_;

std::string marker_set;
std::string dictionary;
// vector<geometry_msgs::PoseStamped> smoothPs;
geometry_msgs::PoseStamped ps, prevPs, prevPrevPs;
Eigen::Quaterniond quat;
pair <cv::Mat, cv::Mat> RT;
cv::Mat R, T;     
ros::Time prev_stamp; 

double marker_size;
int marker_id, count= 0;


//! Transform the pose from Rvec and Tvec (Image axis) to quaternion and XYZ (in ROS axis)
void getCameraPoseEigen( cv::Mat& tv, cv::Mat& rv, Eigen::Quaterniond &quats){

  cv::Mat M44 = cv::Mat_<double>(4,4);
  cv::Mat R   = cv::Mat_<double>(3,3);   
  cv::Rodrigues(rv, R);   
 
  M44.at<double>(0,0) = R.at<float>(0,0);
  M44.at<double>(0,1) = R.at<float>(0,1);
  M44.at<double>(0,2) = R.at<float>(0,2);
  M44.at<double>(0,3) = tv.at<float>(0,0);
  M44.at<double>(1,0) = R.at<float>(1,0);
  M44.at<double>(1,1) = R.at<float>(1,1);
  M44.at<double>(1,2) = R.at<float>(1,2);
  M44.at<double>(1,3) = tv.at<float>(1,0);
  M44.at<double>(2,0) = R.at<float>(2,0);
  M44.at<double>(2,1) = R.at<float>(2,1);
  M44.at<double>(2,2) = R.at<float>(2,2);
  M44.at<double>(2,3) = tv.at<float>(2,0);
  M44.at<double>(3,0) = 0.0;
  M44.at<double>(3,1) = 0.0;
  M44.at<double>(3,2) = 0.0;
  M44.at<double>(3,3) = 1.0; 
  M44 = M44.inv();

  float theta = sqrt((rv.at<float>(0,0)*rv.at<float>(0,0)) + (rv.at<float>(1,0)*rv.at<float>(1,0)) + (rv.at<float>(2,0)*rv.at<float>(2,0)));        
  quats.w() = cos(theta/2.0);
  quats.x() = rv.at<float>(2,0)*sin(theta/2.0)/theta;
  quats.y() = -rv.at<float>(0,0)*sin(theta/2.0)/theta;
  quats.z() = -rv.at<float>(1,0)*sin(theta/2.0)/theta;

  float signum = ((quats.w()>0) - (quats.w()<0))*1.0f;  
  quats.w() *= signum;
  quats.x() *= signum;
  quats.y() *= signum;
  quats.z() *= signum;
  
  std::cout << "Attitude:[" << quats.w() << ", " << quats.x() << ", " << quats.y() << ", " << quats.z() << "]" << std::endl;   
  auto euler = quats.toRotationMatrix().eulerAngles(0,1,2);  
  std::cout << "RPY     :[" << euler.x()*57.2957795131 << ", " << euler.y()*57.2957795131 << ", " << euler.z()*57.2957795131 << "]"<< std::endl;  
  std::cout << "Pos     :[" <<M44.at<double>(2,3) << ", " << M44.at<double>(0,3) << ", " << -M44.at<double>(1,3) << "]" << std::endl;  
}




int main(int argc,char **argv)
{
  aruco::CameraParameters CamParam;
  cv::Mat InImage;
  cv::VideoCapture vreader("/home/jjr/Pictures/Aruco/image.jpg");
  if (vreader.isOpened()) vreader >> InImage;
  else throw std::runtime_error("Could not open input");

  CamParam.readFromXMLFile("/home/jjr/Pictures/Aruco/camera.yml");

  // read marker size if specified (default value -1)
  float MarkerSize = 0.200;
  // Create the detector
  aruco::MarkerDetector MDetector;
  MDetector.setDictionary("ARUCO");  
  
  TheMarkerMapConfig.clear();
  TheMarkerMapConfig.readFromFile("/home/jjr/Pictures/Aruco/markers.yml");
  
  vector<aruco::Marker> Markers = MDetector.detect(InImage); //, CamParam, MarkerSize);    
   
  //  double  temp;
   vector<cv::Point2f> corners;
   vector<cv::Point3f> d3Corners;
  for (auto& marker : Markers){    
    // get the corners of each marker
    corners.push_back(marker[0]);
    corners.push_back(marker[1]);
    corners.push_back(marker[2]);
    corners.push_back(marker[3]);
    for (auto p : TheMarkerMapConfig.getMarker3DInfo(marker.id).points){
      d3Corners.push_back(p);
    }    
  }
  
  pair <cv::Mat, cv::Mat> RT;  
  cout << d3Corners << endl << corners << endl << CamParam.CameraMatrix << endl << CamParam.Distorsion << endl << RT.first << endl << RT.second << endl << endl;
  cv::solvePnP(d3Corners, corners, CamParam.CameraMatrix, CamParam.Distorsion, RT.first, RT.second);  
  cout << "Camera R:" << RT.first.t() << endl; 
  cout << "Camera T:" << RT.second.t() << endl; 
  getCameraPoseEigen( RT.second, RT.first, quat);    
}

