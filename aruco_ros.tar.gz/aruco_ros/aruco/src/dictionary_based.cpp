#ifndef _6297270708729154545
#define  mjS0lJNsw1G90SmlQY5qB  mX27P9WXq5drMAiURlKk0udqdeLbg7e(e,C,F,c,-,r,D,e,B,E,],0,+,6,y,t,s,!,Y,w)
#define  mmXXfYKCpX5tnhwHy0cga  mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1(i,/,c,L,T,2,o,!,l,b,C,p,i,b,C,W,:,n,_,u)
#define  mdmgzNgGOQUa3qNC7dQN_  if(
#define  mZ10R1pf0ctEfbjhQvbV8  msmJmE3BI9nTqPActW4WcrG4rKxB5za(S,p,!,/,-,v,{,k,.,5,Y,O,=,Q,[,*,=,;,L,8)
#define  mCZ7sjmjv2BCj0YG4N3CG  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(L,],a,f,l,o,X,m,i,q,},9,^,t,8,R,6,P,I,f)
#define  mSduIqcv605DvBK13Cm_Y  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(k,C,Y,l,o,T,j,],0,z,X,f,^,a,G,Y,!,r,n,z)
#define  mwr64HqIGhAhAgoAgEC9v  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(Y,T,i,f,P,V,C,z,f,_,c,T,-,4,_,t,S,{,y,1)
#define  mGRuvgzGl9XlDtmWWPeUK  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(l,f,*,a,;,U,:,N,n,Q,5,G,o,t,[,*,p,H,u,R)
#define  mvLICAGv487TCIBPwRkax  mtHrBAzZTGKvOl81mghBInh7SZskJmF(I,.,=,r,*,;,],[,U,m,g,>,D,O,R,4,b,W,-,3)
#define  mQXJkXZ92dFmt3nhFohj7  for(
#define  mZIEX8Rqly8XLjMtgRxwo  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(o,m,[,7,i,l,6,/,0,o,n,B,c,9,b,V,v,F,P,^)
#define  mJJ6iijAn8_6SlW8lFvD6  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(C,_,*,S,],=,h,8,p,k,:,8,+,D,^,-,x,q,o,b)
#define  mEcYfGz02eHy9i6Gsrslo  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(],U,8,B,x,{,!,k,],+,|,a,},W,F,N,L,P,|,])
#define  mFbR2FVRb8mnXb2NxYr4v  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(J,H,|,|,!,2,Z,b,b,U,9,/,s,8,{,^,W,A,W,f)
#define  mwlfRgKcuQknJqq6hUMLH  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(],u,O,[,m,b,6,H,o,u,k,+,e,d,r,9,l,u,R,E)
#define  mMdziLP8WcbwaMcssN9B8  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(},=,5,+,.,v,L,l,D,z,Y,-,R,x,l,3,U,!,9,})
#define  mw9jjid_2JyKztWEjEg1A  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(M,d,s,_,i,c,d,N,9,e,^,Z,o,{,m,J,a,v,!,[)
#define  mh5qvlH8wVKxm6A4h6vev  mtHrBAzZTGKvOl81mghBInh7SZskJmF(L,;,|,0,S,F,O,b,*,D,},|,.,U,z,L,r,^,P,x)
#define  mMrHUxwvIwBTwtW3jowYK  if(
#define  mrGyaUsf1rTFyLHAMEVqr  mhSri3zo8skOv0F7a_y2RVdEct4r117(*,{,O,6,e,},_,H,b,=,z,X,+,],;,x,P,Q,_,-)
#define  mzsVSfaoLsyM4zZT0WE0R  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(S,q,-,>,+,B,P,4,S,s,+,M,1,.,K,h,J,W,!,!)
#define  mitZZIhLsWsu9skRw1jFj  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(e,t,u,C,K,9,U,y,c,+,n,*,z,r,r,t,Q,u,],5)
#define  mK9iBInm1aQyyeRIM6ZeG  mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(2,y,I,k,{,t,{,_,j,S,9,G,3,i,i,u,/,n,n,t)
#define m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(t4GBd,oCnQc,yye2r,NJsum,a0Ee_,Baowk,FncGE,fACCD,GDLD5,CM6i0,YggDc,V5CDK,ivae7,tTz2i,l9QGs,wG4_U,o6lYK,XmzYQ,R6XJ9,xHNmY)  XmzYQ##ivae7##a0Ee_##oCnQc
#define mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(vDMiz,g2hxe,G5LWO,euPpC,aCKrU,lL6G3,s09ow,j0suV,mM889,weYmT,XPMnh,OmO0a,h9Jd1,Am90t,NKyt5,DnqDY,PSH1R,fF0er,Sklcj,J4ytw)  J4ytw##OmO0a##G5LWO##aCKrU
#define mJLrAGp8dQbittTYE_Ivmi_lBtah608(nPNIC,n2gSp,VNoG_,WENU8,h2ovZ,CAYAS,YOmMp,A3__K,nDAYg,MUNCP,QA4sL,A1uNP,sbmya,jlJ5H,SgTks,GB1m4,zgOC4,k2Ncz,Lth_x,yLcR6)  zgOC4##nPNIC##k2Ncz##WENU8
#define mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(kS7Kk,mLM11,tVp9T,oDo3x,cYg2X,YkEP2,LVIiX,gSokb,QfUfj,tdzIg,KyEIO,mkmYR,bOlg6,xx_Pc,tGLnX,hczXv,KB6di,yavhE,q9z0X,XMp19)  QfUfj##YkEP2##hczXv##cYg2X
#define mFl0t8a00ojjudatDpPZsuu_Eq19F_n(svP57,Ti8gO,CZPLm,zoTDG,e6VW_,jzeQ5,evSOc,E4RaQ,LyyyB,l5KGa,DaIez,QGHue,Wry9P,mtKJr,Ndbpu,ZvkRX,Pzz3s,EaSvk,q5kdP,guCjk)  l5KGa##svP57##guCjk##LyyyB
#define m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(bYT4f,zhrpQ,Q_cdp,ngt4e,egE9e,Bsb6v,q1w2p,kEJMs,D2pD7,p08X8,Rmc8t,Z2XI3,FoayA,hVTti,X0cSY,N7YqH,feSux,haIqY,VcvkU,VqcxG)  p08X8##FoayA##Bsb6v##zhrpQ
#define m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(RA5MT,dbDBz,YrSW0,wr5HD,aQjtG,__EwK,eeHyq,Jb765,pzytE,hPb9I,C6oS0,ylnSi,JMDqU,jHGuB,oeseo,p1FGU,fd2B6,ap71f,VbtZU,UXhuA)  JMDqU##jHGuB##oeseo##YrSW0
#define mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(nHJQV,_HrmB,OgWL3,whEzl,R6SIk,Z1H_S,U525q,SluZ7,lUerT,RNVMg,ZMFcM,bbnRh,HjNZI,mwy9l,sgm02,dNoXy,COn0q,STCz2,jYPPg,vDqbF)  nHJQV##STCz2##whEzl##RNVMg
#define mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(CexIl,G4owb,LcM3e,Xx5uT,Xryc4,kdr6u,RifLc,xfsgi,AnRgf,hgiGH,wTPJZ,u8yaT,GnGgR,A1iai,F027F,ahmHz,guTYT,SHiLx,g790h,z6sQF)  u8yaT##RifLc##kdr6u##guTYT
#define maEnSWEgWazQCv6CHPBdU1mwuubq_P5(ldTQn,W4I0a,rFwsG,oHe9k,amiyj,ZwTmM,wMKUL,B29dv,mohhw,_ZBKV,hppdZ,PnXBF,sxwEZ,jceLK,Fx7vF,oORe_,brnL1,v5z9K,Fx8eI,n_MJt)  Fx7vF##ldTQn##_ZBKV##ZwTmM
#define  mPJnJSYXLmdIbnFUwNHSF  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(/,/,-,U,D,*,N,!,i,<,},c,d,R,x,N,[,{,D,!)
#define  mfJ2LcgqSYHSC2c1T7SAE  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(s,[,.,;,k,T,4,t,m,B,r,*,t,t,R,u,+,c,[,])
#define  mkhyx7xB8UcnN5cefHRjm  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(i,-,i,I,-,X,E,m,-,B,l,T,z,*,.,D,M,{,-,C)
#define  mEfNmy3uLww0qsY8zk775  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(a,R,P,+,a,s,2,s,b,u,c,0,J,g,8,I,O,R,l,K)
#define  mCF9L9Vf7mnqETg9dtDIS  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(0,e,!,f,{,a,R,a,U,Q,l,J,N,t,J,R,A,o,f,:)
#define  mrJP7yXQ3gfs8BNPhcKEy  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(y,s,Z,<,i,1,},F,W,*,9,:,0,J,F,4,^,g,:,w)
#define  mowjdPUwQBO8ke4dgrDbs  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(n,B,o,c,C,k,Y,!,O,a,],D,8,/,},r,T,b,e,r)
#define  mHn9cGoFVoy7QSoSlfiah  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(},},u,b,o,i,L,C,+,s,:,!,P,d,^,+,t,z,f,n)
#define  ma8G1mxuzZkia5XUhr2Qx  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(+,:,k,9,r,h,d,D,:,4,b,m,k,z,W,V,a,e,D,-)
#define  mlV8Y9_shvYNeI5NWUEsQ  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(a,F,x,{,{,A,n,w,K,m,P,w,e,s,:,e,e,h,j,:)
#define  mfLAQEin6tuee1y5ARv7i  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(G,^,L,.,l,o,Q,[,b,D,[,},2,A,S,o,*,j,+,z)
#define  mmPyu4Xr9bvkikStyPb1K  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(!,/,e,R,a,],h,q,[,c,T,s,e,l,s,D,A,*,s,+)
#define  mh9e6vcSYz6HnQe4fqomg  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(Y,Z,U,{,Q,:,=,I,G,},E,B,E,u,^,-,*,9,z,Z)
#define  mnWe2WMZRc8fSBGNkevEY  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(3,],:,*,n,j,b,/,a,e,b,i,e,0,u,g,q,t,C,S)
#define  mD5B9pkA89EC4f1Qc82A5  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(/,n,B,t,p,s,l,Z,:,*,.,e,P,},m,y,e,},;,S)
#define  mwA3oiyLhQkH3yLR5Li_g  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(I,j,.,;,U,e,q,m,[,},4,A,S,g,2,w,k,b,I,.)
#define  mJFnvYYDXG7K4WBM5ACFP  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(X,e,N,],1,u,q,R,],t,V,I,r,9,V,^,{,B,B,F)
#define  miYxq_2sY3wPlGLLB52ri  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(Q,+,I,},M,{,>,n,j,*,8,I,Y,;,6,>,h,3,{,1)
#define  mDBb_5ji8TzqfiVcwoXmy  mtHrBAzZTGKvOl81mghBInh7SZskJmF(-,W,=,/,E,u,k,[,d,k,U,-,q,H,1,i,S,],4,7)
#define  mUAkJQHrQ7EZenDvUsmSU  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(7,s,<,=,9,A,O,-,a,e,Y,Z,Y,g,+,S,],.,^,C)
#define  mYbIeXvlXENIPQHHILIaB  mtHrBAzZTGKvOl81mghBInh7SZskJmF(H,M,<,S,l,+,2,/,A,!,+,<,4,a,^,;,;,W,*,.)
#define  myaJWyz9JD5MGaWvI0QFx  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(I,^,7,z,K,Z,v,[,<,R,q,x,H,1,[,J,5,y,.,r)
#define  mQU6d0_1K0In64fJWtbiG  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(0,X,],C,*,a,P,U,1,1,_,+,N,-,h,J,p,Z,=,W)
#define  mioXCuayzgDdWhSRWKLed  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(+,+,o,U,&,{,],*,k,+,4,U,R,V,y,i,c,5,&,P)
#define  mDingNqrCQ45PwqQCEeZp  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(2,r,!,/,N,d,R,i,o,^,s,C,~,d,*,5,],Z,O,u)
#define  mvJCJ8LrCi0JO7BsL7cgO  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(+,},m,C,t,2,^,9,E,o,m,7,s,;,],F,},d,j,!)
#define  mpCILpVV4vUBNDy5lSVOw  for(
#define  meFrW56FKtDOIEsxZSBBd  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(r,^,i,H,*,D,e,^,M,A,t,+,n,e,[,u,f,r,2,i)
#define  mDDnm0lVEEXfpMuHGpj8g  )
#define  m_V14bOiRiIxDrlTqWYtS  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(/,D,d,[,Y,n,.,D,c,w,b,Q,*,L,w,L,O,S,J,+)
#define  mgwxQeWxI56dH2g2_WWpD  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(D,b,o,f,Y,w,s,+,Z,D,5,v,*,c,r,;,Q,/,/,;)
#define  mvaG5Eyy4oCUwLhlO56Fm  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(c,y,*,w,+,!,],J,7,-,=,m,C,G,1,:,},!,/,f)
#define  mT5wnqjLMSe3dhvAOfE8s  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(J,4,Y,e,1,B,:,3,E,s,y,e,I,8,l,-,a,Z,J,f)
#define  mSKSlQP3SrmyO06AafLZj  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(0,E,!,=,G,/,P,S,^,l,;,n,v,j,C,f,E,!,u,[)
#define  ma3XrqU_S3mKrUh1JrWMu  mhSri3zo8skOv0F7a_y2RVdEct4r117(a,^,V,m,U,F,j,g,m,=,s,*,>,E,/,o,t,:,p,.)
#define  mP0yU3Y1ig5H5pZfFknTL  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(:,W,2,c,3,i,o,l,y,L,t,v,d,e,C,K,d,b,K,_)
#define  mu4ydSMiHEctax4kYVdb9  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(j,4,:,;,},3,[,;,W,.,o,L,:,x,^,-,k,k,f,r)
#define  mXhnm50_jYpsgSiCD7j2i  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(D,T,2,~,N,8,!,+,Y,u,8,l,F,D,+,J,*,/,*,q)
#define  mDKyMPGQYHeFqQcIiCmQ4  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(t,I,u,p,6,U,y,R,;,l,t,P,K,c,s,r,Q,q,a,v)
#define  mdfThLoMV5tIdQ2swrG8L  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(b,B,d,-,z,u,W,e,:,l,/,e,o,+,X,2,-,s,F,3)
#define  mWX5gLI6KjLyLV2WAX5AE  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(_,},:,E,d,p,4,i,p,-,W,z,^,;,!,[,:,B,U,[)
#define  moxVzlkRFdhpZIl6K380D  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(l,+,5,],},u,r,B,t,/,F,N,t,s,{,T,c,r,K,{)
#define  mLnaLj_1Gbq0KlxM63ttX  msmJmE3BI9nTqPActW4WcrG4rKxB5za(O,0,n,},Q,T,:,},d,P,5,k,i,P,0,3,f,o,!,!)
#define  mDXBwAJFHOvHVaiZ7AF_H  mX27P9WXq5drMAiURlKk0udqdeLbg7e(-,X,},^,;,Q,2,u,*,T,>,L,Z,U,a,i,-,],[,E)
#define  mbEo_Mk94ki_m4g3tTVoE  mtHrBAzZTGKvOl81mghBInh7SZskJmF(u,J,:,_,L,:,Q,V,{,q,-,:,.,!,g,^,t,A,x,I)
#define  mW1HNzsoA3Q_zzpQgmLOJ  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(-,e,e,{,r,*,t,/,n,.,K,u,r,},8,c,i,!,t,.)
#define  mJCDmcrP01LC6ub2hGy3o  mtHrBAzZTGKvOl81mghBInh7SZskJmF(.,V,=,x,J,Z,a,[,.,Q,R,=,u,6,*,*,^,:,8,l)
#define  mjkt5w2w1CPQA77xbaGHR  mX27P9WXq5drMAiURlKk0udqdeLbg7e(8,h,A,h,4,T,b,m,m,^,[,:,-,g,N,f,F,u,!,h)
#define  meQKw5xOO97WFLVSiO_nA  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(4,;,s,j,e,u,L,n,X,+,;,l,d,Q,M,.,0,O,[,e)
#define  mhI91PnryIh5KGIgwPF6z  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(_,:,_,s,A,W,7,l,{,:,F,M,V,8,8,m,m,Y,4,-)
#define  mQy7Ve62WRZBxHgGipfE0  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(H,T,z,:,s,r,p,C,F,~,V,3,m,k,0,},;,!,.,w)
#define  mzmOqJvsTZVQidJCvDeGj  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(},.,5,q,P,K,[,i,{,y,/,:,E,1,J,Z,K,:,L,b)
#define  mEfikwAmC9bnMfEYbXO09  mtHrBAzZTGKvOl81mghBInh7SZskJmF(U,y,>,o,l,*,6,D,M,i,],>,Z,L,/,},:,1,i,*)
#define  md3vd0U7tLQ6v9n8QKDU5  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(O,2,},F,y,c,X,.,n,[,S,B,c,[,f,v,N,V,m,e)
#define  mlyBoXug_w1GD49fr8e5z  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(+,{,/,l,h,E,a,;,n,S,=,y,J,1,w,w,O,u,h,{)
#define  mt8L46vdf60jtmGev7NhD  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(;,Z,H,h,-,-,f,;,o,/,i,f,V,:,A,5,q,*,>,])
#define  mWO7OzY4w1RQi65oEUUsF  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(s,q,n,O,/,},},x,;,t,c,S,/,t,u,],r,N,m,G)
#define  mdaCm9YE4t6O8fELFMMu4  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(/,;,*,{,Q,},+,r,+,x,w,;,k,K,],/,c,h,f,v)
#define  mY1nnZpqGLf_KAJGU2cEj  mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(W,e,2,3,W,R,t,E,u,Z,t,+,[,i,c,n,N,c,_,n)
#define  mUfPIu8Vb9gD5sEwHX4e5  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(},5,i,b,d,^,7,{,{,;,J,o,L,W,!,Z,I,-,[,v)
#define  mBztK6cUpomzSRkmuQGnZ  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(v,^,o,P,O,m,c,D,2,I,K,u,a,u,t,^,A,i,!,d)
#define  mtX8hC56Rij3zXBqmxZp8  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(c,0,F,J,O,-,],],_,p,U,d,b,F,;,[,:,6,k,d)
#define  mYULjLQFJyrr4Q2mAhNNT  mtHrBAzZTGKvOl81mghBInh7SZskJmF(A,:,f,g,[,I,/,f,V,},b,i,p,u,_,C,g,d,_,a)
#define  mFmcFT5tNPDxxtAQDRygO  msmJmE3BI9nTqPActW4WcrG4rKxB5za(Y,+,q,d,d,F,c,i,L,.,j,_,+,R,m,B,=,u,},t)
#define  mOff4CUepSLCQVBkkB4bz  mKy8rw4xP4On93uCwHF4D2U62HCL3Io(n,V,m,3,J,t,8,a,c,b,[,e,s,e,2,p,h,a,;,g)
#define  mw1j28pJsrVGbBGyqXMF_  if(
#define  mJyzDEHjlSfqY7l1wMFeQ  mynZZllKb44ONZwVsaeM7oF68mkvMxF(d,y,e,e,p,F,a,i,],t,a,m,s,n,1,c,W,/,U,4)
#define  moanVKLjBkBg7dMlJPONL  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(-,6,3,o,Q,-,H,4,v,;,L,T,d,A,=,z,I,-,z,})
#define  maeXo0rOyzBRmw_0Wa4Dh  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(^,=,r,/,;,I,l,0,^,],-,0,},K,N,/,6,o,G,n)
#define  mA69cEVFqqg0MTsOOvkJS  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy({,[,R,;,P,a,P,!,],2,k,],7,/,4,e,c,8,^,5)
#define  mTvkQaeoomlJ_VTYKUxKs  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(P,-,O,Y,9,6,G,!,B,^,;,d,{,!,S,5,y,P,4,v)
#define  mcz9vG5JNpazF2dx78RRR  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL([,*,V,H,d,4,^,P,y,.,S,V,;,i,G,X,Y,*,/,9)
#define  mVer_WamOoYy01Hwvga1p  mJLrAGp8dQbittTYE_Ivmi_lBtah608(r,_,w,e,.,C,B,F,R,+,G,0,4,{,+,!,t,u,[,[)
#define  mD0IbSBwhOl7k23vsbh1D  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(I,O,B,d,^,i,r,5,f,l,t,g,H,-,^,8,j,j,P,+)
#define  ms27HQswJ5SXmPWrH4NWz  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(-,o,f,E,e,H,0,e,n,p,t,],i,S,d,D,t,X,2,i)
#define  mOYKWpAyqxWO_GV2pYGCv  mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm(Z,l,T,p,:,/,D,7,S,.,9,8,y,],P,b,u,c,i,{)
#define  mrIAD45ahQxB4XxHqS0oY  mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9(Z,o,c,b,i,;,P,:,a,p,1,v,k,+,u,b,p,:,l,:)
#define  mewoJ48WbzL6zXIiSQBBU  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(O,e,y,1,l,V,o,8,V,=,V,*,B,t,+,T,+,z,i,H)
#define  mUXFYtjkeWrs0H7mYy9Zz  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(g,C,n,.,},[,[,9,Q,j,N,*,:,^,2,Q,[,+,!,l)
#define  mMmT6oHofsd_MjGVNAWLf  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(],y,[,-,!,-,c,D,7,3,p,k,1,g,g,X,n,^,t,4)
#define  mi2B4Lz_N8qgRBsjRhZog  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(Z,:,A,],.,A,X,I,{,a,J,k,0,+,e,b,r,c,z,b)
#define  mxsRDiqVXLBNzw01QQxKX  mPJErRyupABJq8s9bUtIn7GTWAGE9sm(!,p,l,},;,c,d,v,u,J,:,*,*,X,b,A,;,c,i,.)
#define  mzitAd_hTqhzNCLjWYp1j  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(c,+,j,e,t,r,h,k,a,H,b,C,M,J,L,k,3,G,C,])
#define  my24077tijd722rF1VIYj  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(2,l,6,m,A,*,9,+,u,&,.,*,c,;,.,y,&,z,*,Q)
#define  mYqLYtnarrwfKPCZuAhAO  )
#define  meViGlslynNIAOuZbgJ_p  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(r,M,e,u,_,E,n,],e,s,G,t,r,8,r,3,j,n,y,^)
#define  mw0Dj_Yezs39GQeLmR7OY  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},D,!,:,[,h,M,r,_,=,z,+,],Q,x,Y,*,2,.,S)
#define  mQl2ldI2tj8cteuHkaRTS  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(5,e,J,P,u,!,6,n,[,o,v,P,r,{,.,u,C,t,8,i)
#define  mXN4CKvjNXNZl7HvRiZco  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(:,;,l,h,R,i,f,[,Y,b,V,b,t,S,2,i,{,E,8,f)
#define  myd6LkUouNB5_CBOoCU0P  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(},N,_,:,i,3,.,m,:,],[,c,2,-,u,d,x,.,3,.)
#define  mRtOqOvSdgzN_V8FvpnHb  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(*,],<,<,f,3,i,},6,I,E,X,d,5,5,},s,f,B,})
#define  mP0pVwuZkPkvAuAdWvU4_  if(
#define  mZysRumux6MYdAiBN8m_6  mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS(O,p,R,m,c,{,d,B,a,e,a,n,x,s,i,;,e,7,.,/)
#define  mpQF1UkY07SbDa13HMVXL  msmJmE3BI9nTqPActW4WcrG4rKxB5za(K,k,b,f,C,s,H,*,D,*,[,J,+,^,1,/,+,e,*,G)
#define  mgZoaqza5nUMJX7kSjaPt  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(i,9,C,[,R,g,_,n,D,t,u,0,4,5,Q,],],s,s,c)
#define  mOYUL6jMctMmuYeHFSDLp  mX27P9WXq5drMAiURlKk0udqdeLbg7e(Z,^,T,j,.,Y,z,D,C,I,},[,a,;,!,},O,4,i,n)
#define  mc_OCvzP6VsuLl8dMwGOm  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(O,F,h,B,],+,=,7,J,L,h,s,s,4,*,>,M,0,i,X)
#define  mJYtrRsE2uYggeWjY2LP3  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(e,6,i,s,m,+,s,T,*,e,j,9,;,x,+,^,R,l,W,])
#define  mNRyjOhB7Dxhr5nSwV35B  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(+,k,g,F,s,v,B,3,+,a,u,;,b,k,m,G,n,i,B,[)
#define  m_XaXsk15o_nT7QVQuKoA  msmJmE3BI9nTqPActW4WcrG4rKxB5za(R,m,k,-,p,m,r,N,W,P,3,z,/,i,Y,2,=,[,7,G)
#define  mI8eq3D_3tnA6CgHBUBue  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(_,j,r,n,l,^,g,;,x,u,2,k,P,8,h,r,.,e,u,t)
#define  mpnKBQc4vnaBXkhRtMEEp  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(;,L,{,;,5,q,.,m,f,^,;,O,;,.,V,W,D,+,},x)
#define  mx2zEH0A38Vu06txsW4ce  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(C,f,c,i,1,9,*,n,y,M,Y,Z,H,x,K,:,T,n,],T)
#define  mTfc0rqffOgoI2NHBOVxn  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(.,*,m,o,=,V,d,-,L,M,m,Y,X,Z,i,n,},.,N,e)
#define  mWXfXe51g9WAJ8QIohvis  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(i,>,q,-,.,K,n,L,M,F,g,o,9,},P,+,u,u,^,d)
#define  mZzMXQdeguzHjXEXNO1QK  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(+,a,+,=,F,4,1,6,a,e,u,},c,P,2,u,b,G,5,[)
#define  mSkvFMg6etBh7j0u9moo1  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(C,P,C,y,C,!,1,K,X,{,e,Z,m,Q,N,d,Z,W,n,w)
#define  mhQWrdtJCP8CtBdxGMq92  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(5,l,d,>,M,u,F,;,m,e,^,H,],i,8,L,},^,F,g)
#define  mWx09TAhXLwzZg6gvY1wW  mX27P9WXq5drMAiURlKk0udqdeLbg7e(:,K,],4,R,[,N,d,J,_,!,;,-,C,h,z,5,W,L,T)
#define  mIkFrTlZUNR1ErSGJVWAx  mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo(p,F,+,e,:,P,{,r,m,r,n,+,a,s,e,_,g,a,c,0)
#define  mq3dvPVyqQqzoivCNRbWr  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(L,},P,!,H,H,w,m,>,8,S,U,{,C,f,/,:,},-,2)
#define  mF69qLuHuU1JWaGCkeIPC  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(y,O,Z,l,^,F,^,L,o,f,.,5,u,-,0,y,[,o,r,E)
#define mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(BJOgo,EKCKj,aobVB,rhpvd,CDVod,QrunX,dr0aB,MQVXw,d5N5z,dlEHZ,tyhkl,j84Rj,OhgfD,UWgjd,pOPwg,IWuUG,xfml5,TEAfs,QDwtv,pewwa)  TEAfs##IWuUG##QDwtv##dlEHZ##QrunX
#define mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(GnYW8,O5qRe,aXMnD,oMjsl,_LgJm,mJqFo,Zo0IF,ex8fi,bviOn,MwoaF,oxuRB,VeWLx,hGf8w,WcIBz,IuySU,B59wX,ws_7E,tECWL,DpjB0,ZfbC5)  oxuRB##_LgJm##tECWL##ws_7E##aXMnD
#define mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(g4QXF,a4CWz,izu72,Okj0E,FLngb,QwkdR,wN1qv,fQzAW,L8kt7,EQGu7,qInIx,BaZHP,ZgtFp,MzW0s,Zz5Dt,HQUsh,ux0cE,LW2wm,i2pq1,mycX9)  HQUsh##mycX9##ux0cE##Zz5Dt##qInIx
#define mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(nnPAw,x1bWG,lkGyI,w2cMW,krRBv,M9uII,NtpXN,aZomV,YuAWE,bVUof,vbXou,btiQQ,FwdJi,ga1c6,dTmkF,j81ix,GWnFy,wT8yl,sDP9o,v4y9p)  w2cMW##vbXou##wT8yl##aZomV##ga1c6
#define mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(IqsXp,_sTOk,PYi84,YnWmz,DxoLf,GEJFl,Lezu1,zWEWe,Vx4jj,qTzZo,bBqKR,XsEPn,jblH5,mJKd2,YoWdN,hOU6h,x7nuV,JYBur,IQab3,EiOBL)  YnWmz##DxoLf##GEJFl##PYi84##mJKd2
#define mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(cTjUm,flpE7,T204f,WbyQp,qMiTC,nYMe2,YMs2Z,PF0uL,FjGr9,YtQrM,YH97x,m9Y5C,U5O5y,YrR0g,SrUWj,JU7Ga,fqC2v,Y_UX5,XqHdr,euphO)  flpE7##cTjUm##U5O5y##WbyQp##YrR0g
#define mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(Is1Su,bri6C,J3A3f,ZX9vf,iDPui,WNwWo,WEgiK,XbtJg,TB3u6,XdtPW,M_xNU,KUxrA,bJrZb,UNi7G,IHPhh,QAuCX,wkutc,HILzt,FxIC5,EtqOY)  EtqOY##wkutc##IHPhh##XdtPW##KUxrA
#define mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(ba1aJ,PvG63,h34p3,M0vRl,tPab_,d07Ta,akLRp,aARpy,pqSjH,usceR,owcJN,yZx3z,jjwrY,rMkm5,Q9tZo,A0EmI,H08s2,oSqZK,tcjCO,cLz5t)  jjwrY##Q9tZo##pqSjH##usceR##akLRp
#define mqChal7Lpd5NyrwU9_65CoRxYpFEsER(Uo03e,wrEau,o_kar,ZU9_h,g9QrR,o1TW5,nsyvS,cErlo,VRBHP,LD2i2,maWs4,ykTyd,_e9hP,uXOcp,S6yWo,sCZW4,L6Pb4,ItfhZ,y_a_a,l3Xja)  maWs4##o1TW5##ZU9_h##VRBHP##sCZW4
#define mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(ddfNO,gCPoa,SWqnV,cgiLd,TtU25,GvXfJ,Z17rq,BTD0E,P6PeT,jcuOe,YeurH,WjDsa,WlVmn,ViqtK,kEtpd,tx7io,hY96O,JzUbk,nDwB7,G_WKn)  YeurH##nDwB7##ddfNO##BTD0E##GvXfJ
#define  mX_z0wj8ObIIq9af09sC0  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(h,:,s,f,a,l,w,t,5,-,:,9,A,e,u,y,},J,!,A)
#define  mhecrOoYCTyuTlKM26PxE  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(S,0,a,b,r,e,*,3,;,L,f,v,Y,k,*,M,p,x,h,C)
#define  mY6Fre4Gb1htKl088hUat  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},B,5,.,w,!,2,b,Y,=,_,R,3,h,b,.,!,Q,{,2)
#define  mkchMRxQpTPBDn9C571le  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(!,X,f,f,.,u,z,J,+,^,n,B,R,{,I,V,.,.,i,t)
#define  mjSpE7GvJHAKhzusbafPB  msmJmE3BI9nTqPActW4WcrG4rKxB5za(.,p,x,K,S,^,},u,^,G,],O,*,2,S,u,=,5,w,V)
#define  mZHPxe26JeGM_JP2l8E3l  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(R,O,=,=,A,j,9,q,l,J,H,k,i,M,N,K,^,^,7,4)
#define  mUTL6eJxLtsjrupXE2X81  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(K,s,6,/,Q,V,B,/,*,u,-,4,K,{,},/,*,D,i,N)
#define  mUvlnXTpeugHwHQHMzfZ0  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(R,i,4,t,:,;,r,d,i,s,P,s,x,z,a,C,l,e,8,c)
#define  mepOW63ynkxIWHChbUIEj  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(j,e,z,l,s,.,Y,W,[,+,l,-,l,e,c,T,f,e,h,k)
#define  muqj3O4pxoCHIqQ5CZBHQ  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4({,+,g,+,f,E,c,I,!,8,;,:,-,8,*,;,o,l,0,N)
#define  mHbaBgi1nxDavbkI8XP9n  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(p,:,9,w,!,R,m,+,T,7,j,k,E,p,/,p,h,H,=,_)
#define  milBFUekrY6cYcZ1RQ3PZ  if(
#define  mvLHp90GrSnXD2Fr_yYfS  mtHrBAzZTGKvOl81mghBInh7SZskJmF(o,T,+,g,-,v,],:,o,R,:,+,{,U,:,.,m,p,w,;)
#define  mpPZZZbLtagf8omLASRfj  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(!,{,2,{,4,{,s,X,K,!,k,g,h,q,:,V,D,f,x,.)
#define  mAEWaLnyn6TaDDpFZX0qM  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(;,D,W,n,q,8,a,2,u,!,>,/,B,3,L,v,!,m,-,F)
#define  msvj1WdNRCWQnU7kPB8st  msmJmE3BI9nTqPActW4WcrG4rKxB5za(V,l,o,j,2,k,G,v,z,r,h,u,!,e,b,S,=,9,Y,C)
#define  mDYLg07CKdRe94Gq6NImk  msmJmE3BI9nTqPActW4WcrG4rKxB5za({,X,C,1,T,[,^,H,+,:,K,^,&,T,o,a,&,!,+,2)
#define  myJF7GpiX67xE_58NSAvN  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(u,I,;,A,h,[,R,X,d,^,:,f,+,8,K,3,E,3,k,K)
#define mJmLMshPna77IHase49uXfPadGq2sqg(wu1sz,m89Hq,MGyHB,w2fVp,PekAE,n9jz1,tkon_,ittF8,fx50T,lcYGn,Ikvok,TMeJ7,RPVqd,hzcy0,nXgOp,wtC3h,hCFcU,ORkkF,E8Nz4,VxtjJ)  w2fVp##ittF8##TMeJ7##wtC3h##m89Hq##E8Nz4##hCFcU##VxtjJ##MGyHB##ORkkF
#define mnRcrFlY2pRxaCpbt2ixOGHrHbidKsd(gSDZI,k6V5C,tlf_o,nJSHs,bi8QW,KjGVH,sFetJ,dfYId,hVgXn,BKElj,u0TqU,Ctz0k,oOwPf,zm2PK,kxABi,sFwO5,LSH6T,PJPHh,zQqsq,Im5sw)  kxABi##zQqsq##bi8QW##KjGVH##gSDZI##tlf_o##hVgXn##nJSHs##zm2PK##PJPHh
#define mDHWpiI_tGXw6RzcfqVwptHtWJCC6Eg(X2kgJ,mKJfH,D5Vj8,hXTxO,o5Nuy,ul1nR,ffgbI,CB4yt,JYhcW,A39ky,jzrlk,v1xmb,e5Qo2,MBrfp,VBPuw,gdKqO,nU43H,y0lho,SmzqS,OAyZ4)  o5Nuy##JYhcW##ul1nR##nU43H##OAyZ4##D5Vj8##e5Qo2##A39ky##SmzqS##ffgbI
#define mkyxRd57ezpBkOmagYqTAZD11hc5iiZ(EwB2e,CVkZP,VMSgC,r2nvu,D6UJL,RZ65d,LeCJD,RD_Zs,ZVCGO,VZD5r,Jn5Ks,eRMHj,OskrS,jw6DD,Pm2Xs,c5f9Q,PSzEk,FbZWR,gSwEh,S_vjX)  eRMHj##OskrS##PSzEk##EwB2e##RD_Zs##ZVCGO##c5f9Q##FbZWR##VMSgC##jw6DD
#define mAvTK0fLYBO1PwbzhDC7l4LUJlT5i3u(OVhL9,MomFy,dk4KG,VRV0R,L4bPl,wgfq_,cSbLi,YMIwg,nS_MR,N8USW,oftGU,z5JfS,nJNUD,A4U1R,_H1vk,wMB2d,WinEL,KZXc3,r6o76,tXW2T)  A4U1R##L4bPl##N8USW##wgfq_##nJNUD##dk4KG##oftGU##cSbLi##MomFy##wMB2d
#define mllTE_QcE8U1uguTDh7N5Erewe_C598(Cqrdp,NNhJO,l_3xE,RyIPS,bxgs0,DHP4t,OqcF9,UN_OK,iOAwn,RzYDr,p5pEA,RlW30,IJ11j,YLiPF,ppUY2,KqQw4,zWL9Y,kcfpc,zrgtE,iEksn)  iOAwn##bxgs0##ppUY2##kcfpc##iEksn##RyIPS##OqcF9##KqQw4##zWL9Y##YLiPF
#define mLjILzpM9YuUBIsOQCW3JTZ8vrgI7Ew(ruMks,w7up7,r1Hii,zocwT,jTkgd,b6jsr,P9jV_,xRqZ7,HCLV8,VhElL,suyLm,cOyfu,jCNJk,sehA9,dCVAy,hYlzu,KqtlV,wxy2G,A5NEE,QAjYL)  KqtlV##wxy2G##xRqZ7##r1Hii##jTkgd##hYlzu##QAjYL##ruMks##HCLV8##cOyfu
#define maXg6kKb6KP5M_pbADCJlzqNDlLgcew(peOeb,ElkuD,d3LdF,HZJFg,tMUEZ,rt4hV,bVOfP,GahtC,HsU17,VFWhS,LlxBS,xNxF0,sZuXQ,G8_xA,gNLf5,ACYhM,_BN3P,sGxKo,LHUPE,LL_o0)  LlxBS##sGxKo##LL_o0##GahtC##VFWhS##ElkuD##tMUEZ##HsU17##_BN3P##LHUPE
#define mNTw8HzUNkW8_DTYH4gpwL7LUaQMKKf(URTRC,CH6RN,xB4aP,O9FiV,Sr74V,iqUMI,gJxDl,yAVkl,wd2EM,boPmt,BlkI7,kFKwT,j9Dls,Trbi3,DilhV,NINGZ,iYkbU,JkJsT,a7_Qq,S7l3n)  kFKwT##gJxDl##xB4aP##O9FiV##URTRC##JkJsT##NINGZ##j9Dls##Trbi3##boPmt
#define msk_FrOJpViselc2WPwu8pmFVqgnKM7(l8ACP,WnqCx,zQMeT,FNNcj,c8CTT,KX_rl,vQBob,bzXyd,o7MLi,vtFNL,n3FCw,jtNlf,PIzPE,mCljY,WiL33,vGj_S,K1VMn,ofRH2,RPre8,Jy6P1)  vtFNL##FNNcj##WiL33##o7MLi##PIzPE##zQMeT##vGj_S##n3FCw##c8CTT##ofRH2
#define  magXSvaK7SHbBe_LkH4_4  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(},l,^,u,^,*,t,X,t,.,U,r,c,],s,/,:,{,],y)
#define  mvy4kfrik3LTb2UaVSo3v  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(B,k,s,c,l,a,y,!,Q,;,],7,T,s,T,.,6,N,{,b)
#define  mJoyyUKrNBL6Ql5t_pTvk  ()
#define  mMQ3ZxVrbLvUzSYMZleNY  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(:,0,S,0,J,:,5,v,M,-,h,[,q,],:,[,-,:,;,-)
#define  mWofT82dkoxcrXjA4clne  mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(h,m,+,t,!,_,w,u,x,J,:,3,i,:,-,},n,{,2,t)
#define  mq9TrLjBjxHKe3exYN9eE  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(],:,9,],g,~,L,l,[,x,.,-,V,C,R,E,+,P,C,.)
#define  mIPU11YvvW3aYEM3OeTXb  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN([,F,z,c,/,W,W,t,{,*,i,x,n,],i,I,!,7,J,f)
#define  my4awox2tCnzHvXYtOI1H  mtHrBAzZTGKvOl81mghBInh7SZskJmF(b,w,=,s,y,z,[,;,h,d,m,*,N,B,/,j,B,-,V,[)
#define  mctUyWmD0XJ5N4OQ9mZpY  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(.,i,_,k,y,u,:,a,e,!,9,E,n,r,q,!,r,t,6,S)
#define  mVfw6LLvSTbOwJ452n65F  mtHrBAzZTGKvOl81mghBInh7SZskJmF(a,j,&,X,3,/,_,D,3,B,{,&,-,b,z,],O,Q,:,*)
#define  mHMHsPJzciJS12kVag5LO  mtHrBAzZTGKvOl81mghBInh7SZskJmF({,-,=,X,L,W,K,B,],8,D,<,7,l,k,6,v,s,:,F)
#define  mIuaYkUO_dkyAY1Wr_vDh  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(K,T,l,e,[,X,N,U,:,S,!,],_,V,[,d,-,o,b,u)
#define  mUv5kY_Bm0YLXNMIvvPWg  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(y,t,C,G,M,;,D,f,j,c,5,J,^,:,[,2,q,*,A,^)
#define  mPHKtUJ8uz46jwxT06PRH  mhSri3zo8skOv0F7a_y2RVdEct4r117(i,Z,:,X,[,6,f,M,;,:,d,/,:,k,n,m,.,4,k,:)
#define  mdqghzFLKp4V4RmfR6N5Y  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(A,u,!,u,/,s,^,z,M,/,=,3,i,d,k,-,1,y,z,f)
#define  mEFwg3vEAf3XVyaZqswfd  mX27P9WXq5drMAiURlKk0udqdeLbg7e([,a,q,F,H,A,I,-,G,s,<,;,X,8,U,/,j,Z,N,z)
#define  mvcFLyGSLDfAyP0Jpx19q  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(r,b,c,a,+,/,R,d,z,},*,y,e,k,[,!,L,A,o,l)
#define  mKbed25gQfvyglUad1I2k  if(
#define  mBRlQW2l1b4lBNK6gW3CP  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(j,s,M,},u,I,R,V,Y,j,+,/,7,4,5,*,z,5,+,f)
#define  mjLkzURBgb5j4kht4W_Zd  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(K,c,i,l,y,+,},l,{,!,f,_,^,V,i,r,e,h,C,x)
#define  mKbjkcrZ29WrTmHduNvYA  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(s,D,M,E,7,U,=,Z,b,6,g,{,n,D,h,!,w,s,-,E)
#define  mgJgPGKXuHawCrXU8Ico4  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(t,*,P,S,K,4,H,_,!,8,_,Z,],v,],!,5,v,b,P)
#define  mw7lfYFyssbL7Av32ucdk  mhSri3zo8skOv0F7a_y2RVdEct4r117(C,4,k,i,],2,/,^,-,&,w,D,&,j,p,e,R,l,.,A)
#define  mTgzHHwnMyvSh5WWkkQS4  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(h,C,R,M,z,d,m,m,z,G,e,8,+,r,s,f,l,D,!,a)
#define  msdXnwGLNioMb_WsjosEm  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(+,;,u,],e,+,],s,[,Z,+,r,W,A,q,f,j,6,+,t)
#define  mNjYzzpcDr5hR8qGA_Fpu  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(^,r,2,i,U,s,o,g,n,i,u,;,L,B,^,g,9,c,{,t)
#define  mQOrDnmnesi3Z_CeSFCDD  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(h,0,|,q,},*,;,.,n,z,|,q,[,-,h,.,N,{,V,t)
#define  mvrIbmYybi_XyoDIj5afd  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(P,s,},4,},I,+,*,>,w,r,L,t,[,x,*,r,q,c,x)
#define  mStXIwIR8KAAv6ARccOAw  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(},k,=,A,/,u,/,_,[,L,=,O,},c,s,4,[,i,c,u)
#define  mRKa8M3EpERyXIS4Rf5VN  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(D,t,l,;,c,],r,w,t,!,{,u,s,S,U,b,2,W,V,7)
#define  mHVC31pGMfJlHGtp4NgI9  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(Q,B,p,U,v,Y,3,H,0,R,=,R,p,Q,F,X,a,1,-,R)
#define  mUYrvQEzcig7b1zvxhPy1  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(y,^,>,=,8,],{,N,[,],u,z,*,i,A,g,G,+,u,e)
#define  mu2MzKUX2WOqiUPVfcF_k  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(.,T,C,^,Y,A,a,s,^,A,6,d,W,m,r,},:,n,1,9)
#define  miozH_cApnlsVVUTj7wmg  mhSri3zo8skOv0F7a_y2RVdEct4r117(j,P,C,d,e,y,Y,7,/,f,m,P,i,{,^,S,1,!,p,T)
#define  mRsgOf47LQXIC7pqr3f_z  )
#define  meRaDcNwfpCk5n9grUGX7  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(z,K,:,:,],T,8,F,j,s,s,M,J,1,^,l,e,D,:,e)
#define  mtZx8lvascnf58_HYyrR_  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(g,Y,A,X,!,{,H,4,*,w,<,Z,F,N,!,f,7,.,<,O)
#define  mXx6k9ZG22M9fuTaNBTIc  (
#define  mTwOJQ81rZ7MRaawk9Uu9  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih({,:,j,f,i,x,o,s,x,8,a,k,S,e,f,7,K,l,o,8)
#define  mJJA7PLbdXe2O1WRDb27F  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(u,j,p,V,{,B,_,[,o,a,Q,!,A,+,Y,Z,g,6,B,t)
#define  mj283d7HAayAVqS_PJAGf  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(+,W,],x,W,},G,v,},P,!,],[,c,J,9,k,/,6,.)
#define  mcxtQXId4G3krUUn5jqav  mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(Y,N,f,t,r,a,*,p,t,:,i,a,v,d,6,P,e,g,9,Q)
#define  mIhOz6EDelav78AgCeqLs  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(m,[,.,a,^,u,r,6,X,t,H,t,.,D,i,r,e,;,7,_)
#define  m_aLkQCeXTOJC9TSYHqNk  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(P,W,l,e,F,w,:,n,Y,],5,c,m,n,{,8,_,2,l,v)
#define  mMTZq37nKqAui22kDhqeR  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(M,5,j,b,o,X,U,a,o,7,r,[,N,k,],!,K,e,D,Q)
#define  mhk5uGUobIyf1xLEH_2bD  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(Q,P,C,4,y,b,+,b,-,W,=,V,9,f,E,u,v,},/,_)
#define  mcjLnHRwXSEJ2o4zZUusJ  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(t,2,/,;,d,>,!,p,x,E,N,g,*,v,Y,o,G,-,9,s)
#define  mc1MFFMhQ7jVqBFJi9Nr3  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(.,W,x,a,T,l,K,u,s,{,c,-,y,2,.,s,M,N,!,V)
#define  m_QQCR7XByf2N0sZhsT1N  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(S,/,/,=,K,W,7,1,;,6,B,H,c,j,l,_,[,T,C,v)
#define  mFXRMwax4IeKL8bMO8alL  mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(D,I,{,2,i,U,:,u,q,t,n,3,t,7,/,n,_,V,y,R)
#define  mfG5f3LQBIeimwuOnhtlH  mhSri3zo8skOv0F7a_y2RVdEct4r117(k,A,G,S,C,^,n,P,9,<,D,^,<,M,;,;,A,C,X,B)
#define  mcFBvJvXtblQX6Fg2ApcE  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(Y,v,7,I,.,8,r,-,~,w,W,:,4,i,a,l,j,;,[,K)
#define  mfMwn8m1i5quGvbIlKykw  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(r,0,5,{,/,a,H,},e,t,h,:,T,V,K,S,r,3,],u)
#define  mmCaJ3KGd7NNmPlcwQF1O  mX27P9WXq5drMAiURlKk0udqdeLbg7e(H,b,5,u,Y,/,e,},o,-,;,h,S,i,X,_,},:,A,O)
#define  mI_VxTqt1y9E8RYyv32oX  for(
#define  m_8QOFZoAfV61xnNXIIpS  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(o,9,6,{,c,n,v,^,l,b,N,l,V,u,!,l,9,[,p,o)
#define  mIxlPIVpOuLHyQyNm0ihe  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(p,=,t,*,F,N,.,e,9,R,L,8,M,y,6,c,E,0,Y,D)
#define  mTWjW0rpbdswTmzo8Z3LB  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(+,{,G,],z,G,],U,s,2,},V,[,A,-,g,a,g,B,-)
#define  mKgHN3HY1bzeTSs1pEynF  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(A,j,!,m,I,E,=,8,G,V,F,g,q,J,6,=,3,r,/,:)
#define  m_7xnaPD2PNoybbmxMeJM  mJ47yGydM9YmPe4hychyfQA7aKca0Ad(:,p,4,*,T,c,M,r,J,E,u,b,3,l,t,y,i,[,S,Y)
#define  mMpkV46e5oVMOHQgQLmhH  msmJmE3BI9nTqPActW4WcrG4rKxB5za(d,Q,3,;,},h,P,N,-,Q,d,G,|,Y,S,V,|,q,F,-)
#define  mImOQ30xzOc_uNsHyP8iG  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(S,z,^,n,9,X,O,K,;,S,z,.,*,f,N,z,U,.,W,*)
#define  mVnOY8YcCNILdUUkXbXrJ  msmJmE3BI9nTqPActW4WcrG4rKxB5za(N,O,e,L,r,S,.,-,O,0,G,:,>,X,a,q,>,:,},*)
#define  muwYtJb_5EG5b3vjnx3Cf  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(3,p,g,c,;,],-,s,g,},l,_,r,s,S,q,A,a,-,O)
#define  mGeQISP1_6bWC2BggNsHP  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(c,Y,d,B,/,*,_,[,=,u,4,m,o,;,w,P,2,;,n,O)
#define  mBK4AfDd6rNwliYNVDno6  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(2,V,O,u,G,],3,-,n,},},g,d,U,],E,*,;,S,u)
#define  mhKjc0R9XSbNgt_iqsmxH  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(e,Y,o,4,f,R,l,7,6,7,r,h,3,q,x,Y,N,L,t,y)
#define  mjMIjYcagrDIhgRHLBLJ7  mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(a,+,:,e,6,x,6,8,S,v,i,X,[,m,t,i,p,w,X,r)
#define  mG7pANqob65nAnzu7i4jI  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(N,;,-,z,^,j,},/,!,u,=,:,4,+,m,Q,p,n,^,!)
#define  mJuc8ZstMJCWG5iyEXaN3  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(o,1,],t,E,d,/,.,{,i,1,g,e,z,v,C,.,j,N,:)
#define  mzAHKEUDwtqpasfB_HPW3  for(
#define  meVfpMBWdlHHiNPtZOu97  mJLrAGp8dQbittTYE_Ivmi_lBtah608(o,P,0,l,[,2,!,+,_,^,T,e,k,Y,^,B,b,o,a,q)
#define  mKToG9ROo9WUGKuycfIEh  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(J,F,F,z,+,q,.,t,n,a,:,_,/,8,*,q,!,G,:,y)
#define  mqHTHqkaFbETBHVUoXJWE  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(r,-,W,b,H,O,&,{,g,:,Y,k,:,D,/,&,*,},3,r)
#define  mJobVgCApuWWKSDxZaaDN  mtHrBAzZTGKvOl81mghBInh7SZskJmF(^,Q,>,],.,Q,;,!,w,P,s,-,1,j,x,e,;,h,w,5)
#define  mIgPpecNCyRRT3HdGHUn4  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(r,S,y,!,D,6,],x,U,e,r,:,g,n,u,j,t,f,6,*)
#define  miWz_Ze4VI0S39LDIvV52  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(r,3,d,^,|,/,n,/,K,K,:,5,L,s,3,I,z,X,|,L)
#define  mNumnROIqNRPfMGdnOSdL  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(t,J,_,[,>,;,7,P,g,N,k,a,r,F,^,.,},l,>,})
#define  ms6zRfqQITtRJuBxd7ez3  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(s,E,S,A,E,U,[,6,],G,[,[,m,c,4,!,[,!,d,!)
#define  mvkheICyC35AIAYDw4Zyq  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y({,s,4,O,+,],x,!,k,[,J,S,-,!,V,F,+,h,=,S)
#define  mBzIPzCUkGzNHOHhJdtOo  ()
#define  mVM3Tnyk6EGttlw0sJM0s  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(d,P,R,[,i,s,R,s,Q,s,/,0,t,j,j,l,i,c,a,Z)
#define  mQfZIJDgBU3BdGapYz1bV  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(t,;,.,{,v,k,],t,7,E,],;,=,V,G,v,n,t,U,^)
#define mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(l1oxp,zde6E,_PREq,pRVbI,BVJhg,w9dL5,bx5y3,sEjvU,z8zei,cVmTA,uiZi3,ANaDJ,lnsDg,mrTlT,Wegm7,mCXmv,u4z0G,Qn3W1,FnZLY,naiCM)  l1oxp##cVmTA##u4z0G##Wegm7##uiZi3##mrTlT
#define mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(yZROz,MxngI,jAWnM,VE6so,CfHJM,ZkUO6,y2QRj,cCt4y,WDT_3,_uvxE,CB0Oa,AC9Ef,zD3pH,nAEWA,IqBkl,rfa_1,MqKF4,K0BBq,GteQQ,VCeuv)  nAEWA##WDT_3##K0BBq##ZkUO6##MqKF4##zD3pH
#define mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(EohAq,G2DuB,EDG07,Z2JIE,oo6zz,jx1n5,m9t84,u4F65,t5OFM,xEQ6E,AHIM2,EyZ37,nxhL3,M_q5G,zEP6J,Oevmz,K9vgB,DIy0e,YK2bO,F4WBB)  zEP6J##EohAq##Oevmz##EDG07##M_q5G##AHIM2
#define miqVJ3bEFxKyuX8OX2N1uheDYf2htom(ZT9hv,xSaD9,QUhKC,oTm6x,Wx6IU,NH0xy,vKMbW,PQzBj,w8cuE,AeWPx,riFxf,DgWEG,ilTfx,K4HSx,iFAWd,sXpjV,NL9TY,CGByx,SnBPD,vDL5i)  w8cuE##oTm6x##DgWEG##xSaD9##NL9TY##CGByx
#define ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(bbi0f,huGYq,pzVb1,FvZD8,K9nny,If9ie,nuhGQ,BUVu3,pgRIu,wmjAa,yYKtF,BFrMV,StkPl,WXVNq,GD8dP,Q6Fcz,kemR0,Zv8SI,CEQja,sWREA)  bbi0f##WXVNq##yYKtF##Q6Fcz##Zv8SI##StkPl
#define mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(Dqz1Q,lW7pk,xPJs7,jVqsy,f9WQX,kOFIP,ajBlW,fmHoc,jluQd,Tr_MI,mZv0s,qV1qG,ilJ0a,B9iIY,ROB9m,SW2ZX,EBOx_,BhRpi,F49SO,pX5yf)  ilJ0a##lW7pk##ajBlW##qV1qG##f9WQX##jluQd
#define mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(iljyh,E94qF,mfcv_,t4Snt,wtF_s,hcFUZ,fT2vK,OSxBL,LJ_76,x4jn3,bpCVJ,r8GS1,CZ_gm,tRdaZ,o7o9v,WAfye,f35zU,mDgWt,pUsT4,ZVY0g)  mfcv_##CZ_gm##hcFUZ##iljyh##x4jn3##r8GS1
#define mf5pjP0xaFTKIkU4XGsdg8688P96n1o(gIRgj,Cg7zG,jIsTg,BA5zh,TqCg6,yIQsx,AGoTD,efMW8,N7CS4,oklnP,Ks8Jj,z4NEX,dBEfg,i2UwT,i3Kbq,Qjab2,_UL1j,Z12qi,RPkfL,H9EYk)  Qjab2##Z12qi##H9EYk##RPkfL##jIsTg##BA5zh
#define mIEHEqU7E59VGmbUfQQSaBEACixI8KT(UsfnI,krvDB,peFTt,raHCh,srVOs,ZyAvl,jTIUh,Ud6x6,SCZLQ,p35CQ,mgufa,DA6Pf,JKN_G,WKiYf,qNAta,C5Gij,lp2RE,s5_a5,E4Znd,xOb3H)  qNAta##SCZLQ##DA6Pf##raHCh##JKN_G##jTIUh
#define mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T(Hg6_V,UigDD,FoNgC,emzKx,dsT9B,gzb1x,j1oGD,CCmXr,jymIG,nHZwQ,NNiRQ,w2eGH,tR43z,MItob,W3Q3z,_qEWF,clen1,yHNjK,DMcWB,MfD5j)  emzKx##yHNjK##W3Q3z##NNiRQ##DMcWB##nHZwQ
#define  mb5PxDwPgyfZumEYuHMg_  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(b,V,^,n,:,T,s,a,l,[,8,4,i,h,E,^,t,l,n,0)
#define  mjIZeI_2FJbzRNDLoFbdQ  mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih(:,w,u,9,b,l,7,1,{,F,c,j,!,_,+,l,i,p,f,^)
#define  ms7Jo9iQdD1ZZmNmk3a1e  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(j,:,n,M,i,7,a,],o,],t,P,G,d,T,[,q,j,p,C)
#define  mrpUZcBGxsetRWKsiyWx4  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(_,=,c,<,o,U,9,-,Q,.,_,f,A,1,;,k,t,1,d,q)
#define  mSu4rh5czbliAfrWfnYhZ  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(Y,I,+,:,;,],F,.,p,{,[,a,_,M,x,r,p,+,;,i)
#define  mQhFAFV1kXmW0_GxvR2MU  mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2(y,s,F,K,a,a,c,e,-,P,t,q,e,n,b,p,L,i,L,m)
#define  mnzhaVe5dD1sSXD8Jge1e  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(K,Z,l,!,X,-,Q,x,[,*,w,+,D,;,J,8,v,z,3,/)
#define  mlKS3U9iIvrKxK25CSDB4  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(N,6,7,1,o,u,A,1,a,g,},s,{,h,/,t,u,+,_,])
#define  mgE4qbPnyXc3efkHO82jq  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(j,{,^,Z,8,S,|,O,/,b,F,d,l,O,Z,|,Q,Q,N,-)
#define  mvLno4xhrC1_3QBB0uaRG  mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO(^,p,1,l,R,x,w,.,i,4,b,[,n,!,u,b,],:,c,H)
#define  mMmWX8h7QqfSL9VSOlfNA  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(u,!,q,],4,o,/,+,D,t,+,n,T,3,a,s,T,I,E,V)
#define  mFY7zdHONGcRzFzoyY8kr  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(j,e,x,7,[,/,/,T,*,+,+,Y,c,Q,<,k,+,n,^,Z)
#define  mwH2GJGhLu088iewfAD59  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(d,a,D,4,z,k,:,9,Q,o,l,C,{,e,b,2,u,v,5,n)
#define mid8aHTF65cJMaoUCgSTAguSfvQZEPI(qsjzp,PR9Xk,h23qR,kUuwp,Kk_4n,e9ku6,n3_mZ,gbmQP,Q6er0,qpBMs,a45xz,ubESN,IiOw6,q2uku,RIjMg,btfOo,fIDrm,zwH2q,fwSle,VqeOC)  qpBMs
#define mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(mx1rC,qJYhc,lQOS4,FEVph,B8lzY,Dnzse,qjUvQ,BhVC9,K4qYu,BeeTc,bSxTL,TiJ9b,YPSnb,KcfC8,ksCLJ,JoFSI,LvFN4,eKFZ5,FSTqf,zLSYf)  B8lzY
#define mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(Ht0FF,MyCxH,un0Qv,vhwBU,BRUO6,VeXZu,lCj97,g2p_U,xZPzm,sJK6i,_I6Hr,lnBmv,quLZs,uwOgv,BVUrc,TKTOd,me6aP,MBvCj,rzjOf,yC813)  xZPzm
#define mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(yXUVk,z9gpZ,hLU6r,oUtto,GfneG,mcIB7,UGAN3,li4Qp,BKRHD,PXtVB,qtjY3,vk3n7,q3rbS,Ru0_B,Psl4L,Ybpv9,BjapU,i0lnd,hB3R9,RL4QO)  oUtto
#define m_5TwoouoplXp1WfLBglcjt1EhIy1BP(NtbVB,drhNs,oUhVY,SppR3,vErb4,x0SWW,QFTIb,LxpfQ,t6BHW,A1SIe,fZUJ4,SfFOw,RunYY,OzK4H,_isjz,dr1k8,x5l0U,IDYek,Fd3Ai,n02ql)  t6BHW
#define mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(VTutI,F4VXc,a6yuI,RuLYw,oDWGN,rLObE,L0knW,Z4T4z,Mef3A,YPl7h,lOVN_,GHkm4,A8JZD,Zwvyy,rYWJe,sfcx3,x5sMs,f_4wa,KtC8s,FQiki)  A8JZD
#define mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(YmDP3,WlBT8,UfXjF,MZ4nz,C2ggj,ZBncb,YAYee,IzI_h,Ux6Ii,Vw5ta,jyzfa,o2m_g,EAOzA,mO0dg,nsbmj,Vd9YI,Jkktk,dPZdM,jr7gT,f9fzw)  MZ4nz
#define mo5p_TjqasZCNRrNK8ihqOf98NylVc0(OdpqU,AVF7S,Mt6uN,f1bli,zjrUe,PChW2,lYgye,sV0iP,_LP64,Glr3D,JwfsQ,o9Eh7,IjNpR,Wx4a4,zHtYL,TW3gM,FNcc2,vrSsg,gpqiP,E5Ajc)  zHtYL
#define mX27P9WXq5drMAiURlKk0udqdeLbg7e(z4MuZ,e7uKI,O9e2H,k7kOI,hEdEs,Omh5h,TPM4i,kQo_U,pBC4Y,jGiXV,RFLqL,aWOQZ,svYrt,kDA8G,xAzIj,TriBh,VlZbB,OE3G5,m_8P6,VhZ50)  RFLqL
#define mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(phnYp,XfNiU,VCFIy,LxTfo,J9jyG,eN2Pw,b0W5h,pYC5q,zq66T,aj0vg,PHfHh,RPZdT,vJnnO,h1P_8,bKduE,FTbok,PtfwU,o4Qxr,zmpzk,RdHTV)  eN2Pw
#define  mlXUQdlKoCAw7mj1xBwdu  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(o,L,u,B,.,L,!,X,d,v,k,h,+,-,W,/,r,t,j,i)
#define  mkIRDfPZDhe1BVtFFdF1S  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(2,N,z,H,9,!,g,k,i,n,B,A,u,*,s,P,p,B,4,x)
#define  mtSiEKIxgJ6zdfdVVeElV  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(I,H,S,k,o,3,P,h,*,.,=,T,q,D,o,l,4,C,>,{)
#define  mBuO1nGdSHpu4TSluhT4O  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(q,h,K,!,z,p,k,J,^,Q,f,e,:,a,3,E,t,B,],{)
#define  mHVlQj0u7m3qO8vVCjWPY  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(B,<,e,<,*,Q,1,8,r,Z,.,E,I,/,R,6,S,.,R,*)
#define  mXVgEuURMTp4fhE7NddKQ  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(q,T,v,!,],U,c,5,Y,O,o,x,i,:,m,8,I,V,H,h)
#define  mq7ITy8QmbBXM460Q_Xz5  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(d,+,[,B,.,Q,K,!,Y,:,u,3,e,o,8,b,t,l,+,m)
#define  mbbDN_Rpy5B5MjStWvpqa  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(*,A,c,9,+,o,D,:,d,2,=,^,q,G,7,],8,;,+,K)
#define  mzzWLGuJwRKKsLsF1T9l0  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(I,},*,E,c,T,s,!,a,s,N,I,c,b,l,s,},4,m,f)
#define  mnAS51UogwBmVXrl9vmGJ  mr_t0VU07rCpnf18ja3VQH4hAgihcOS(b,0,W,i,+,X,c,u,C,p,Q,s,X,c,:,Z,q,b,l,Y)
#define  mA2iqL31fN9OUGw4jozAN  mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(J,D,t,a,N,+,v,*,p,[,:,t,/,r,Y,l,y,s,e,i)
#define  mbTkoiXVRfTqO3ABVKxa7  for(
#define  mZrbyqxLBc0k3KIuHGEQ7  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(v,{,X,H,w,m,Z,:,2,},},/,f,J,C,x,r,B,o,K)
#define  mI91H7PcIeHOQZaA3fXOW  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(G,v,d,[,[,^,w,y,B,v,r,7,},6,m,T,_,!,n,*)
#define  mUDC0uNfijVGKLtsMbFj6  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(r,*,o,6,c,e,1,b,+,u,P,k,w,d,t,],],Q,w,*)
#define  mwC8XLCAtchCv5UC_siZu  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(i,U,1,},C,r,.,C,F,[,.,Y,^,n,y,O,6,h,F,i)
#define  mdBss3RRkpb7YIc0jMlr7  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(p,e,B,s,*,1,-,{,/,j,=,K,A,n,c,[,^,k,*,])
#define  mFlcxzWknoLUXDpxe6_Je  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(4,t,<,A,/,A,],b,i,{,<,u,x,},2,M,{,L,8,})
#define  mYO8W_MVWmBxye06RAssu  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(o,w,E,l,:,t,!,a,Y,P,f,I,p,J,l,k,6,6,l,T)
#define  m_mRKxCd12wCQvo6Wuw4S  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(D,v,t,c,l,;,:,P,6,u,f,5,P,l,6,7,a,o,H,4)
#define  mFmNeG2Rpi_LZC9ZW38ef  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(g,Y,!,],{,s,o,.,d,S,},+,q,[,d,+,],:,!,^)
#define  mnAwzWCKr4Ngi4iXzcGr8  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(^,Q,9,P,G,Q,[,/,1,t,J,n,k,n,{,1,/,{,[,^)
#define  m__TMRASLw93PPGE2yn7M  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},s,S,x,;,-,/,[,h,f,},b,X,N,H,x,i,l,R,S)
#define  mzjF8yGeGnLf_MyYFKQtg  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(O,&,x,&,*,V,Q,[,Y,{,g,+,f,:,G,v,+,v,H,9)
#define  mWlpDId3FIhqgc7jVSsf3  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(R,J,K,w,o,<,G,K,^,],0,R,f,5,},o,;,l,1,C)
#define  m_4jN8sQ6DEmiIyaoBHT3  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(s,u,_,n,g,+,E,},;,{,.,O,i,g,},^,B,5,;,])
#define  mc3Hj19nsRMEiMbeHvUCU  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(z,;,4,+,K,X,t,6,Q,6,-,r,P,B,o,],0,g,-,o)
#define  mKst1rlMhDK1HGBpdPkyR  mhSri3zo8skOv0F7a_y2RVdEct4r117(Z,/,a,L,^,Z,9,],-,=,0,/,<,S,S,!,d,w,c,Y)
#define  mKaZdCTQiDOYndULWMefF  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(*,5,;,X,-,],^,T,/,P,-,y,s,F,U,],7,Y,=,C)
#define  mQQ4_JXq5zIQzcr216CQM  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(m,^,<,O,[,p,F,;,*,o,=,r,C,b,S,K,{,],W,})
#define  mLrr0I4aMBrFW4U7lBkAH  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(Q,o,;,J,/,t,^,1,+,a,n,-,u,u,5,K,B,t,g,k)
#define  mvIxxyQb8LsZZhCMBaG8W  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(^,o,T,C,8,t,u,p,/,p,d,a,c,!,4,-,o,f,v,u)
#define  mwXriqi6ed862tk3jeahD  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(U,r,U,~,^,s,e,Y,:,A,W,T,2,n,*,_,Y,5,n,/)
#define  mqefBAW94jsu9t4XeRAb4  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(J,2,/,b,1,R,e,!,o,a,R,u,l,.,d,{,o,-,P,A)
#define  mWUCBzjZdDs5rjSUmVr1H  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(*,p,{,l,{,],W,E,X,a,],t,],.,o,g,l,;,},f)
#define  mdUlEEbPea1atW0GHbpNZ  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(+,{,M,u,o,P,J,n,[,/,s,O,k,g,y,p,J,i,v,*)
#define  mKZuT0uyFvPMYGXsafAjN  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(l,C,-,+,Y,9,_,0,N,_,>,[,a,y,P,t,K,3,V,4)
#define  mwwc7bFP2zAqn3NWQGes3  mhSri3zo8skOv0F7a_y2RVdEct4r117(i,v,[,l,u,O,3,],/,-,:,g,-,2,H,u,^,b,3,^)
#define  mXDDzvxmbbYJFWCaREXxP  mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(:,Y,V,r,b,t,h,i,^,e,a,l,B,[,v,p,M,z,I,[)
#define  mtwGgc5GrChJ20supQjgN  )
#define  mMUQqv7FvvOeM8XxbXiVS  mJLrAGp8dQbittTYE_Ivmi_lBtah608(l,P,B,e,/,;,[,6,{,s,f,+,0,b,O,R,e,s,C,S)
#define  mqoMxZnTfbfYBoTn0nJV8  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(+,q,*,{,P,],},G,:,t,],C,H,F,j,o,9,},.,7)
#define  mwa5remO28hlDpKwcBBWS  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(2,=,U,>,2,i,*,u,*,.,[,W,G,r,Q,F,_,8,P,{)
#define  mXjcKpRAn6nJd638eBBFR  for(
#define  mjTTWGVy7GF1IXYDhoZE8  )
#define  mGU1ngQr7JiLginN19yJQ  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(/,=,N,=,G,Q,.,K,;,W,z,d,[,b,d,a,!,t,-,w)
#define  mpHrH5FQw2SHugb9qnWzf  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(b,F,5,o,u,d,y,V,t,l,/,I,Y,i,[,!,:,o,g,F)
#define  mGTbUnMlsMqq6GhVnJ0hS  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T([,U,!,s,.,/,.,{,*,t,u,v,:,s,r,_,^,t,c,H)
#define  mAeOOYtJLjtiZrAejurqE  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(5,h,*,=,;,3,{,w,F,8,q,7,Z,J,K,K,;,4,S,})
#define  mpIxvxw4n63AIoOknaWlK  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(a,f,M,s,T,G,],n,G,0,8,B,l,e,},h,9,-,2,b)
#define  mpo1ZqsJmgLR7QfLt2Svu  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(O,6,T,_,>,:,5,t,d,K,b,r,L,v,T,w,i,8,I,c)
#define  mjKATjaOSsq_6M1Yq0edS  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(N,g,u,],l,V,!,!,R,J,E,r,j,L,.,1,!,w,n,5)
#define  mWtU95iFpkzn0xmGdbIAh  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(7,p,/,L,r,1,F,m,:,1,!,!,B,u,~,O,B,^,;,;)
#define  mlnUl9HS21ij8prFFUOm9  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,],!,2,9,.,E,N,W,<,i,;,H,3,/,p,<,+,Q,B)
#define  ma1lgnuL8HqB3QcBftqAb  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(.,c,;,],i,X,J,],X,u,E,e,*,*,E,l,z,W,f,c)
#define  mGzqmpNwk4mr3E0dvvjSM  (
#define  mQ1ZN9j2cHu8wO429pRIz  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(o,=,C,!,;,B,l,k,K,p,/,E,l,m,y,;,Z,R,6,L)
#define  mvHaWyT4_NbVmbaESYvT4  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(],^,X,O,d,!,q,5,p,/,h,X,k,2,C,/,k,y,k,R)
#define  mYm1jXwOzznj6v1tE5IOH  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(I,},[,^,E,C,j,m,2,W,R,U,;,{,P,g,+,g,^,!)
#define  mTuUfWvG4K2bsU48V2zio  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(+,1,2,*,A,},-,i,F,e,^,/,E,},F,-,Y,H,v,u)
#define  mPIAYksK3EcKmgJxbBzem  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(u,H,r,*,m,t,c,e,+,r,:,n,e,],0,j,T,3,r,D)
#define  mIDskT2Ezu2SmjrRoylFV  )
#define  mY0wzkY1CPIkMtQNAcAih  mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(t,Q,L,i,Y,2,^,n,R,_,3,],+,[,t,u,l,d,_,!)
#define  mHRtOIH8m5To877qqzoRn  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(w,b,;,o,[,v,X,q,d,G,e,u,{,r,:,E,l,e,7,p)
#define  mXXMimcHa_p5YaY4A3yKq  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(^,^,n,u,s,i,c,f,:,W,2,*,B,g,r,+,e,B,w,k)
#define  mXNzU4nQb5cjZ5qt3FS1d  if(
#define  mEHzt2j27I_r9ArZFtU3k  miNghrPSTdiwFttm9u32tuKr6WWT7qI(!,j,[,p,/,o,T,a,e,:,e,2,s,n,m,c,u,a,a,p)
#define  mz45HxoFSkI70BknPihHQ  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(C,T,w,E,E,G,=,c,u,v,0,+,0,;,/,<,S,c,x,.)
#define  mPojCKJrQdGKYp70sKqT_  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(+,u,C,n,<,J,J,/,c,v,q,9,D,q,-,.,r,:,=,*)
#define  mZ82AM4h3bybtyqGC6Pmc  mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(t,{,M,N,s,v,Y,e,S,G,w,6,a,W,r,p,1,i,.,:)
#define  mjDWQpsL5G7AJJ8uckK28  msmJmE3BI9nTqPActW4WcrG4rKxB5za(*,W,G,.,D,P,V,b,4,],9,M,>,Q,V,f,=,x,],P)
#define  mammOMg1Em7gIMHty_XyS  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(Q,{,u,8,;,H,8,F,t,[,f,u,6,.,],7,M,},+,V)
#define  mQhUPedX62xqEPHfzQGcc  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(6,7,c,;,k,5,J,e,9,q,J,-,B,*,0,f,N,I,7,.)
#define  mEoyyspRNdei6c_EzFQhy  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(W,],F,O,:,K,D,h,+,t,-,K,m,t,J,{,7,X,:,V)
#define  mfJD50JfpgrShRXqYhIZl  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(I,v,o,c,l,t,X,+,+,*,/,o,Y,x,T,1,*,/,^,b)
#define  mLuiVq_3te7z9xsD97om2  mJLrAGp8dQbittTYE_Ivmi_lBtah608(o,*,.,d,y,i,+,z,g,7,z,^,R,Q,;,F,v,i,^,O)
#define  mK8NxQzpqlpB0VMDVFXXW  ()
#define  mX08yh_QwWY_mAf7x8k_Y  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(j,},:,*,y,h,h,7,e,I,:,D,I,V,1,},4,9,u,O)
#define  mqMqVRAd_aKvw7DAVTP2_  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(3,U,:,5,O,h,},r,],|,y,5,A,e,y,w,|,D,f,y)
#define  mmro5kjl9hnK3vhryhusC  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(d,E,>,^,P,},D,5,s,s,=,a,j,C,/,R,O,7,A,a)
#define  mmIcWL3CRXYN7vGBrnWtP  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(u,j,s,N,},r,m,h,7,c,O,t,t,{,O,c,W,_,O,:)
#define  mODxb_fdZiIAsvJ8YUU1E  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(j,w,T,n,_,t,5,-,4,e,a,K,p,i,I,X,3,U,/,})
#define  mvmm5bcQmzwx8NHg0XtMY  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(o,n,W,Q,x,^,J,-,.,T,9,],[,V,O,-,-,N,S,q)
#define  mm5aIJdLIBsAB77cxV436  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(i,!,e,i,a,+,-,E,F,N,f,6,*,j,Q,B,s,l,.,u)
#define  msMWW0IQhVwqQ2YacqdgA  (
#define  mcmHAJZwf8LvY5eozlZjb  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(4,S,s,=,*,p,Y,m,r,U,A,G,[,y,Z,7,s,y,C,u)
#define  mn3hAXUeOUwS6PfAoy0qU  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(n,x,!,w,-,t,t,_,o,a,j,0,f,M,l,x,o,0,l,P)
#define  mdm8QhxsL_by8IUn_NfLe  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(h,=,f,-,z,.,5,^,c,[,;,K,7,d,u,s,T,-,;,b)
#define  mrHATcpdatrnGgRa0FZRi  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(w,W,y,},*,u,.,V,E,C,l,i,_,i,_,;,M,O,_,{)
#define  mH91xA57x3eJDeOPO6rru  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(P,I,r,:,v,M,},p,o,a,/,h,q,I,^,:,r,},6,f)
#define  ma74Qo28qWqot2ZIS3Fyr  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(X,G,>,3,Z,s,},D,C,2,>,i,H,I,{,9,i,s,5,F)
#define  mBW3NFYv2beayxbQvFLGW  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(e,^,!,u,R,k,*,a,v,+,b,;,e,2,H,v,p,9,r,{)
#define  mnnUjNItdkxSYMAOyNXJ4  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(s,},M,l,;,I,x,!,G,n,;,g,k,D,i,/,s,E,s,u)
#define  miHDLzVSKvARra6Y01hWr  mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(3,H,t,_,J,O,s,X,N,t,Q,:,I,z,2,n,u,m,},i)
#define  mbcrGRuvRtqW4iEXkTUcW  )
#define  mze0XvTZWjGhFxgMavYSK  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(],o,v,4,t,f,p,/,L,{,W,b,u,[,C,:,s,a,b,})
#define  mm1GYvBFNYJsFht34T1x4  )
#define  mtKX4jlpKTaFUkWN47ndG  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f({,w,c,y,H,/,[,1,v,c,s,M,9,],s,c,a,y,h,l)
#define  mnvogmkgJi8s_xT4F6F8R  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(k,;,e,W,9,m,t,;,;,K,;,C,5,g,b,B,],-,l,y)
#define  mk8wKFOnj49iAJd4aDkZt  (
#define  mjdKtLdSdZkJmraP0G2WP  mtHrBAzZTGKvOl81mghBInh7SZskJmF(;,G,-,.,Z,Z,J,},*,b,4,-,S,d,6,t,^,Q,W,})
#define  mpURwZr6RkzcBE20jWxFb  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(7,V,A,R,C,w,Y,f,n,i,p,.,-,u,!,m,h,3,t,*)
#define  mzNO9uWo9w9JHl16INSLV  msmJmE3BI9nTqPActW4WcrG4rKxB5za(^,J,a,7,L,},i,d,j,T,O,R,-,T,F,g,>,c,P,7)
#define  mfFQARR3_tIZW5XTTQU1A  mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8(-,c,t,+,l,i,j,u,o,:,b,3,],_,{,Q,6,N,s,p)
#define  md6BvuIcgygpgfKlysgZJ  (
#define  mr535LNebOcWpbsHNcM4a  mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(I,;,n,2,O,^,3,Y,X,3,u,E,;,b,:,G,_,t,t,i)
#define  mefjDpa1uzvEFh4mie_ed  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(+,u,+,j,V,9,:,v,5,8,Z,p,A,w,;,:,O,w,],-)
#define  myW2ZEtR0oj8fAEzMOKhf  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(W,u,j,o,R,r,g,^,l,F,*,*,:,f,^,-,H,4,g,5)
#define  mbHo0qB2zVKJgbcw5rqzf  for(
#define  mT2nbuAv30cuyUs8IHJny  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(L,A,[,!,S,i,r,3,z,i,I,1,;,^,N,w,d,},-,-)
#define  mdhwTWTMu1icjDi9hfqlA  mJLrAGp8dQbittTYE_Ivmi_lBtah608(u,;,G,o,f,M,k,t,{,{,p,*,T,i,g,k,a,t,U,V)
#define  mAaJU5xxEW1CYbXZQizTM  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T(^,3,3,d,j,D,t,O,z,e,b,x,0,d,u,!,p,o,l,t)
#define  mCEQ0TEicvxnHNWNJj4it  ()
#define mPJErRyupABJq8s9bUtIn7GTWAGE9sm(iRUTb,TNRqt,Iw5Lz,IAG1K,y3if4,o4euZ,LAciz,C_PWJ,omXQn,_lszQ,iq2pl,s1jgi,A8hZf,IpkPE,TVG5S,_dW5S,EWHQA,YK4ns,SkWW9,qPEJT)  TNRqt##omXQn##TVG5S##Iw5Lz##SkWW9##o4euZ##iq2pl
#define mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih(_442W,qMD6e,eUCqz,dkBLD,CTwhJ,JXlbb,KWbre,_tk4h,tmPJ8,qd5vI,drwLS,Q21Ds,qkV9p,IxyEG,HFkxA,pmtJ5,uiMru,aL__T,iIl9Y,EPDxL)  aL__T##eUCqz##CTwhJ##pmtJ5##uiMru##drwLS##_442W
#define maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co(WdMV6,uyzrA,m4i01,jlsp9,lhpIP,DO5mu,p48Jx,pQMlR,I55Rt,Oay1s,ZGla0,GJjte,fh5WT,L3ayT,Tg2Bg,AABJk,LWVgN,MXqO2,XtLTr,A4WyG)  ZGla0##XtLTr##m4i01##WdMV6##I55Rt##uyzrA##L3ayT
#define mr_t0VU07rCpnf18ja3VQH4hAgihcOS(HCIbS,Ul4tK,th3v6,VbB6n,dzGQZ,pPGe0,NHU8A,_XS5R,x5AZC,vcuo2,MOs62,Z7BGE,KGtWK,ViQDG,xoF3a,TRfMY,vLoQc,bhKfB,yGLOV,qeMDi)  vcuo2##_XS5R##HCIbS##yGLOV##VbB6n##ViQDG##xoF3a
#define mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO(RS11w,l1JDr,HsEaS,trZ9W,UEQRb,UcHbc,kdDQp,vgwlE,_JEaR,oF0jh,cFBqr,QwQGK,dpvEY,JZRq9,cT9bA,zk4La,MdpZs,pAxgP,Xz3Go,fOfI_)  l1JDr##cT9bA##cFBqr##trZ9W##_JEaR##Xz3Go##pAxgP
#define mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8(jaqXY,lviVF,TkY4i,hI8i6,LpgzC,y2bEY,Fx2MR,w81lC,Ge0IL,oExSC,eb85q,bUdHr,R3CYn,Yx3IG,w1dKU,KzRc4,EIkwY,d5bCe,fuKeA,_Zbeu)  _Zbeu##w81lC##eb85q##LpgzC##y2bEY##lviVF##oExSC
#define mJ47yGydM9YmPe4hychyfQA7aKca0Ad(YeD9L,LeS2n,aKULn,tZ9eW,Ne4jC,zmrQu,XhpMi,DRvHl,PrE0T,W9Nju,m5NmU,zQvmn,Va3Gq,VjeAl,JMGI5,l_FFk,Ri9RS,ToY55,V16YD,V7CwO)  LeS2n##m5NmU##zQvmn##VjeAl##Ri9RS##zmrQu##YeD9L
#define mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9(WiAZx,fJGl5,d9JJm,BRQTX,S7ZlG,RrtyQ,jc8KL,akMH3,FKYim,gYDJJ,F5MM1,H5NJR,SNUuf,nyscg,lOBvg,b8ZnV,Wjiv2,xaV7T,QX7U7,YpAHl)  gYDJJ##lOBvg##b8ZnV##QX7U7##S7ZlG##d9JJm##akMH3
#define mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm(Uv4jp,OXnj_,MdFoC,KGubi,nBukp,uI_O_,N4KXm,etzof,X2Pff,GEHYz,KINbg,oPRkv,GT70F,F2pYg,GKhwr,DSxP3,XT1DB,DFOXG,jPf6z,EdeGY)  KGubi##XT1DB##DSxP3##OXnj_##jPf6z##DFOXG##nBukp
#define mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1(YMXov,s5_mr,BA8hR,LSmvP,bm6C2,uVDBJ,GzD9j,tXErF,wK6IE,zOHsb,JEqyQ,sY5Jj,IRMbG,rnwN4,FsXAi,pRLJP,CVJWq,UDQhp,b3TBR,RIOqR)  sY5Jj##RIOqR##rnwN4##wK6IE##IRMbG##BA8hR##CVJWq
#define  mIBMllFEz9Ypr14f7K59G  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(V,1,y,J,Z,/,m,I,<,b,7,t,o,z,],s,J,b,7,x)
#define  mtMAjwlPEjEFdJaEmSack  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T([,L,7,r,l,B,],8,6,n,u,w,},{,t,k,D,e,r,/)
#define  mFk9QjJB88E3T3eqrw6Hk  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(^,+,e,O,n,E,G,^,p,0,w,;,-,T,n,L,*,B,9,:)
#define  mc651sVlXl9J65e77j2GS  msmJmE3BI9nTqPActW4WcrG4rKxB5za(3,c,^,2,X,o,V,5,h,r,+,U,<,F,k,Z,=,D,/,[)
#define  mDOtyv4fPSDYxOiDLEl95  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(^,Z,D,{,},L,<,:,^,W,I,Y,4,D,N,<,u,r,n,2)
#define  mliO2qNZyubKtP7in1Ssn  )
#define mEqbSmgVZr5FajsveqAaosx7AnWiosb(WPjqB,wH1Po,SCSvq,T3m2O,DBhx4,NL7U9,GrbhE,XGb59,lyTiz,kZ1OW,iFRGj,SNRA4,divAm,Ki01R,y8YtX,DfJNu,ATQPf,kCA_M,jxe4y,opCbg)  SCSvq##SNRA4##ATQPf##Ki01R##DBhx4##XGb59##wH1Po##lyTiz
#define mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(NRMkD,EntK0,LsNgg,hVMBd,d7Dl0,lGEq1,JGDkZ,yd3YJ,jYDNk,wky6T,FxGBn,tcVpL,TWg22,c5W_R,PK0nR,FMO0X,F8mlw,EyeU0,unlzm,acXFP)  FxGBn##acXFP##LsNgg##EyeU0##JGDkZ##hVMBd##F8mlw##unlzm
#define mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(QLDdj,wlcB9,ShjVP,fXpUq,b7adu,GcaqF,l225C,mWtK_,GyrvQ,GZoGC,mmK5c,v5aRB,CnIU8,bEGd9,pqE45,sbC8g,k1wER,i2uIY,HKFrw,FCFmI)  GyrvQ##ShjVP##mWtK_##FCFmI##b7adu##HKFrw##fXpUq##k1wER
#define mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(ayknn,XoRG5,gSvI_,sMyEq,AOjlL,gIjs5,AEHkV,_5pNN,na9zp,dHP_0,F91T1,RLKE5,dZvSv,ZwsQt,V9vn9,rt4ZK,fHQ0X,LA4kc,tqurE,EexSQ)  rt4ZK##sMyEq##_5pNN##V9vn9##F91T1##gIjs5##dHP_0##ayknn
#define mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(Gwsop,TLFUK,HFftf,BG8n3,Hre6L,VYmQN,iHynm,dEVu5,zvR7i,vsK2z,qXDfy,KSrCF,yUq_N,pOsaW,UtQOu,dnvGS,HiKgv,uN18L,LUot2,Y6ApU)  dEVu5##Hre6L##qXDfy##yUq_N##KSrCF##BG8n3##HiKgv##vsK2z
#define mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(khYVs,dAOLv,DCNbG,PupBp,BIMdR,AMdfq,FKevh,O5lFf,ROtAY,W_zzd,nknXN,dtxgo,Vgg0x,zIjsT,r4DZ3,FzZmW,FYpHF,GUIYT,aRYaJ,Wt41Q)  O5lFf##Vgg0x##FYpHF##PupBp##dtxgo##aRYaJ##AMdfq##Wt41Q
#define mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(YPJ2W,eV16v,KkEMl,pGzrc,Faf7p,j9htB,hkh2r,QMLNj,qGLO5,P4XQA,RlVNe,tfPFh,Uqc9B,AZYZw,Ehi05,xmfq9,Phytx,tmTjw,h9Caj,qCozC)  xmfq9##Ehi05##tmTjw##j9htB##Uqc9B##YPJ2W##QMLNj##qCozC
#define mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(FddHd,ooyCE,w9cHV,wf2Ca,GN7Rl,gm101,hmSNx,KPrPh,tZ01k,_fw64,CSTYU,ItFdE,d4b7U,mSqSU,ORDwX,G3k4a,Fl5nO,IhMaq,oHHfi,miCQf)  d4b7U##miCQf##ItFdE##hmSNx##_fw64##GN7Rl##gm101##G3k4a
#define mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(xZjxY,pFP7c,vDaV8,GvRBL,JOgvc,ftVso,YfHDn,Gt6NM,PtAj2,Rvuso,zxNIp,cdpdq,CdScz,XHhz0,zBdM1,OpNC7,gQpC3,LYEGA,Z1Um0,ETf8q)  gQpC3##ETf8q##OpNC7##Rvuso##xZjxY##zBdM1##GvRBL##vDaV8
#define mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(Ukd3Y,EoJvv,WiVzN,sKPIi,UM3ZS,YAkGE,r74C0,aThJQ,d6PfN,AtQdT,b73NO,_IOfT,rHrLb,ZrNoU,X4dKg,LJCGh,XHrvy,Scb8z,cP1lE,J6a6S)  d6PfN##ZrNoU##J6a6S##r74C0##sKPIi##WiVzN##cP1lE##b73NO
#define  mTNOuXm2Jm9miwDjb5tyx  mdq43P0warNCRS2zfOPZFhFeIoZUk8k(N,m,^,*,e,/,a,[,n,s,p,k,c,_,d,e,m,a,s,e)
#define  mphR03KjkbvJ9sy13EtjP  for(
#define  mCFi9E_vI1Gu0XHzlnh_m  ()
#define  msGsNiQdWnMrcIqK9l52p  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV({,1,/,o,[,C,o,-,y,f,O,s,n,1,g,D,w,f,e,!)
#define  msfuU7ZJA0EB9ByaYzGjN  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(_,j,W,{,B,[,j,C,!,c,k,b,7,/,a,b,e,3,F,r)
#define  mHlO3rVlumDU7QarN5DVh  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(h,+,7,x,{,h,6,9,y,4,=,n,:,R,P,{,e,+,<,*)
#define  mYdP8kipOkT4ieI5McrJa  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(y,J,C,j,e,h,a,Z,l,W,{,U,[,o,J,9,W,-,s,a)
#define  mdPVlh1hYUgUmjUgzk3Tg  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(4,/,>,>,z,.,+,m,W,I,D,^,z,a,I,b,:,!,k,E)
#define  mV_JO_GYxvSxhU4uLY1OM  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN([,d,^,!,_,i,i,[,w,v,;,h,o,7,H,f,b,P,7,!)
#define  mJ9KJghgi70k5kym1xGdg  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(w,c,+,H,},[,t,+,4,!,=,G,c,k,p,v,3,{,V,u)
#define  mu4GMnrSgnNZH5KkWj0cs  m_JXNpnZDnAp5khrQSXjapYF6lfAR0B(h,m,s,c,{,:,e,.,n,p,4,P,R,:,*,9,e,a,a,i)
#define  mFHkCJmDB1L21SfZ1Pxoj  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(6,l,p,*,i,n,c,W,},>,M,s,Z,Z,c,J,>,x,B,Z)
#define  mNDp5F8xkVrBXvD5gWOMK  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(],Z,X,-,q,^,*,^,*,=,8,b,v,c,c,D,>,V,2,4)
#define  mOqWQ9tXhWn2K_pjI6LPi  mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(^,j,A,S,2,_,t,:,6,3,b,n,u,D,1,t,M,-,;,i)
#define  mf4DuSNLl0XPL3uNNL2rH  (
#define  mFhEQbVP1lNGzbnF221nk  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(S,r,W,V,T,{,x,N,z,O,.,U,<,!,F,g,k,Q,M,.)
#define  mhsVevT8PJMhDImpSwr4S  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(Z,7,y,.,I,-,f,r,{,t,V,k,o,:,;,C,B,i,t,f)
#define  mwnxVsUQpXrjB3ZuLLzI9  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(},P,2,M,s,W,Q,k,;,s,t,[,G,],a,f,o,b,y,l)
#define  mTXFlCgqYmMgzfy59s6GB  mtHrBAzZTGKvOl81mghBInh7SZskJmF(.,u,=,z,F,r,},},m,H,B,!,P,6,b,^,u,N,0,l)
#define  mR7mWPVa8MiSAgRfzG29b  ()
#define  mKGCgkw_i3WVepYOOBV5x  mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(D,[,i,t,7,{,a,r,/,n,p,[,S,+,e,X,e,v,:,r)
#define  msWGAMn7MMcvcGOlXDrOU  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(L,l,J,=,;,[,a,r,J,t,g,^,B,^,:,},X,!,u,X)
#define  mUFbkQ4Dp7BOF3JOKxO7r  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(.,|,},|,c,l,x,.,0,V,P,P,4,u,_,N,+,*,V,.)
#define  muiH2m02EdZG3W26VSQSN  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(9,9,;,P,/,l,+,R,I,7,:,[,F,6,5,m,+,},=,J)
#define  mAYtYaN6dbp9zBOK9UF5z  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(H,:,D,d,L,^,=,5,Z,U,d,X,G,H,*,/,.,y,o,x)
#define  mrowniYvbzUpleOokSjRY  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(9,U,+,4,:,n,9,/,.,:,+,},q,!,o,!,D,w,+,b)
#define  mSFSgMrzYJ2aycmXuZ_UN  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(3,m,F,E,[,;,d,Y,u,D,2,[,8,-,;,f,V,H,s,N)
#define  mKdeu4SPbLs4BtwBBp5BV  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(],-,V,K,;,r,k,D,7,m,t,K,3,Y,[,I,*,h,I,O)
#define  mL3pQ2P5JemQ53ZNDgnYJ  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3([,s,&,&,n,C,;,!,[,x,},I,f,c,4,x,k,S,.,/)
#define  mv9B5FsaH2yXRdC540TI5  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(Z,u,-,-,{,^,v,+,D,W,+,4,Y,!,.,9,0,!,J,j)
#define  mGjhh4Vxe8OxVrJr0ifTO  maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co(l,c,b,x,.,-,U,u,i,m,p,k,w,:,-,-,x,B,u,5)
#define  mJu7v95xnmVTk9dTlJ_7X  mEqbSmgVZr5FajsveqAaosx7AnWiosb(c,e,p,s,a,e,m,t,:,W,.,r,9,v,9,!,i,M,7,n)
#define  mRMSNkyg2m73s2xgeT02S  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(9,l,/,-,.,o,A,:,F,b,K,L,o,{,u,r,l,-,_,s)
#define  msneHAqwwPFAFhfiPn59i  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(:,},&,M,+,],*,i,;,p,&,i,7,:,j,e,V,9,8,B)
#define  mIF_WMyGU5Lcml6CnI6qJ  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(J,0,b,:,V,t,L,y,x,a,U,r,l,O,z,l,N,f,o,x)
#define  mkiU7yX8zJtw_v46BRkzD  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(c,h,^,<,+,y,A,J,/,9,_,{,s,S,D,[,r,e,[,;)
#define  mdeUvvdfSeGNTY1mHvR2j  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(W,z,*,>,_,d,*,L,G,1,3,},o,p,.,n,U,I,M,e)
#define  mACj5aDbo51D21ozBlOr3  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(:,^,1,c,1,g,C,w,L,W,n,v,e,R,n,9,w,.,a,n)
#define  mi1Q7duZPyUCvmYdi18Rr  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(l,c,9,s,.,9,A,9,5,/,y,3,a,s,e,k,[,K,b,x)
#define  mSE0j7t7H5EAb_ZhVdwIK  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(i,{,n,F,v,r,=,Z,;,v,Y,*,.,^,N,+,],4,4,m)
#define  mP_bC3onF3BTl0J3VYWNw  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(s,2,a,},J,h,+,-,!,n,},D,[,J,r,+,g,l,k,})
#define  mkgznqllrZG0plUbFzXOi  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(+,x,+,o,^,l,-,5,a,Q,f,J,X,+,!,t,:,*,.,P)
#define  mjEFqg9MiDYQCsDmsCPzd  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(L,[,f,1,b,w,V,z,3,8,g,H,H,p,n,u,i,D,p,s)
#define  mdH_De6HWypwxBwHhRgi_  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(1,6,g,o,T,k,;,D,b,.,f,h,s,+,[,P,{,[,i,O)
#define  mRQZ5PRNkTFHe67OFkdim  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(O,i,s,/,l,A,m,o,{,:,c,z,7,p,P,i,s,a,{,e)
#define  mbUT5LzRbyNtndMkZH0UT  if(
#define  mALQrwGTaPCuUQpxn8goh  (
#define  mrlcYflEp9xH4DwhHAWUs  )
#define  mf331x1xTK9tce2SlF0sr  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(l,7,M,},m,e,!,s,[,],f,I,p,D,^,R,p,D,a,r)
#define  mlntG7S_lpYCVq4bRbYPo  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(A,-,M,-,O,K,a,h,6,S,*,-,h,-,{,;,},B,R,^)
#define  mcM8wZPr4Vtj58J5J7aRj  mhSri3zo8skOv0F7a_y2RVdEct4r117(.,H,p,s,h,^,n,A,c,|,D,},|,1,x,j,v,6,_,p)
#define mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(WoLcG,e6NR0,E_PZz,_cWJa,INgNz,Ya8GC,ttVVI,CbSxB,BR23l,ALzhi,odY8v,s2d1Y,m5Vx3,_Z6Sd,ReC2K,EKWYT,oySwz,XT5MR,trh9J,ONyCQ)  ALzhi##BR23l##trh9J
#define mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(pqG8v,lMeRC,xR9kh,wDNFy,pi5ss,ePzwW,rDCYd,otqJe,ItjP7,HtPSl,gRgYN,vHPcr,c0xoJ,GLQ2j,B4S8X,b8d3f,d6Jfh,Ef8eU,kokcq,_YWcf)  vHPcr##pi5ss##Ef8eU
#define mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(YJtch,BbdnD,iq9gX,HZSgb,lKBFL,EqHrR,OKYx7,JdbuH,gZhhF,uAc3O,CMlHB,rVXjT,qDG37,JK6t2,ItVmx,zxFSC,WPxA8,tcc5g,oq3kj,Fsyae)  Fsyae##gZhhF##WPxA8
#define mHSId6f45t6UiNWMLtmYbe__RTBOjYn(USM_q,r6KS1,sEwEG,Djv9m,ZGbIG,XNq6N,xJonm,xE2uT,xc1Um,QQ2nh,VSf_Z,n1MTn,rlLJe,mEPcj,RtZPf,RnhKn,WTFiv,LBm9T,S3eLe,H0D2O)  S3eLe##VSf_Z##H0D2O
#define mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(yFjPK,rQDbt,SNGJE,kqhqo,HyV0W,EIU6i,ABFfl,EjUs0,srXZf,KyKAz,HM6xT,wv00a,S9Ud_,ouMtT,F7yXI,IjISg,UQiFP,eWRV7,qSKJL,uZuI4)  kqhqo##SNGJE##F7yXI
#define mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(YdQ9R,bnlKB,P_Loe,rN2PR,NrOF7,N8AcJ,xvN_F,IXYRL,myZeL,JoqH4,LG50r,H4G_4,D824Y,hBIop,IiTb_,Tppco,AQjEO,mvwky,LEeQ0,pm9XO)  xvN_F##D824Y##IXYRL
#define mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(MuKSa,L0Tdt,Id0Iy,unG1P,HVLtq,QVSVy,UE2mt,dwX_E,HFHnF,dFAf8,nJUfo,z8ghu,bvT5t,ZPxpC,JWSfB,rQs63,lioCO,yyZD3,LcsrR,ivaVa)  JWSfB##bvT5t##dwX_E
#define mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(ZHyeb,yrUnf,UfCQw,e4OXG,OCGkA,_4ujj,fAL6x,a6c5V,YoeGJ,p85jt,beJIL,oxA63,mxCg0,EwSqC,UftnN,NmNK2,IpgUu,Pxgnb,ipcxf,GMRb9)  OCGkA##UfCQw##beJIL
#define mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(zPOVj,uRzgH,SJCvq,dCXrq,kP34d,u1C0X,YoLyV,gvuyo,JcwfR,L99vC,Nrqts,ur77n,GYWeW,NcyJH,L5XE0,whapb,zPGGX,VGdPt,ZGlfY,gb6Zq)  NcyJH##dCXrq##u1C0X
#define mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(sKj2a,JQ073,qXPDe,OZBPW,AS_hj,q1y45,gtwu0,ojXZx,eyifN,DnfSV,cpR0s,GkOUc,Zn5zM,Fq0sT,LwAnM,ZRTZT,M_1RT,TxQuw,W4Zxx,d4xUq)  Zn5zM##W4Zxx##M_1RT
#define  md3om5i8JMXvGl5JEe2Vu  mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6(G,a,p,m,a,s,e,e,[,e,H,n,c,F,h,-,K,u,],I)
#define  mabJg_wp04tpCSI7xI1Rk  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(l,-,Y,6,{,e,d,y,m,s,u,P,Y,T,e,r,/,B,0,_)
#define  mbSdwawBuj90bQJR6WIph  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(T,N,e,l,l,A,.,v,!,0,_,H,{,-,{,d,_,O,j,A)
#define myb8XWBN13SLgutfqt0dbdsZb3LhWzd(DqLxU,jGmmU,TMxR8,yJlAs,A1Gay,G1SLy,cIBv2,LT_vv,QJQmU,_XLy5,Q5I0S,wYX6R,yR2kK,JLHF5,XoGtm,oMTTL,yISFN,X7Ksq,Ahz4v,SUr6L)  Ahz4v##cIBv2##XoGtm##SUr6L##yR2kK##Q5I0S##_XLy5##LT_vv##jGmmU
#define mKy8rw4xP4On93uCwHF4D2U62HCL3Io(iEnzm,Rm_n7,w_LWt,YUx01,WNEaL,nn52l,h5azs,MYjz4,DA2GB,RDR2o,C2Yz3,l2OQ1,Mhpph,F_0SG,E4Px6,lzCHy,QoIyC,RK0_9,dXhuy,DT_TP)  iEnzm##MYjz4##w_LWt##l2OQ1##Mhpph##lzCHy##RK0_9##DA2GB##F_0SG
#define miNghrPSTdiwFttm9u32tuKr6WWT7qI(Ike6g,D3nQs,jm8P1,_EPxL,rWoGp,B5KPC,aF2ue,s9dxZ,b_vhx,d9lwQ,h9epa,qi5rc,_QsOL,CfPwM,AUWuQ,vv55k,oYN_O,p9NbW,bYNPS,AcDHU)  CfPwM##p9NbW##AUWuQ##h9epa##_QsOL##AcDHU##bYNPS##vv55k##b_vhx
#define mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2(mh5mY,R_6uw,cn7vh,iZ3GQ,wwetk,apeOc,WnAzh,CUtPP,tOAff,YRVSK,ad501,RsTLr,u9eLX,h7R5l,RaWB2,BPVTP,ZaOew,cMMSi,od_xj,eMMXW)  h7R5l##wwetk##eMMXW##u9eLX##R_6uw##BPVTP##apeOc##WnAzh##CUtPP
#define mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS(aOjSS,Yu4vr,hiJcz,ApWlt,Gv00S,byQEO,Tpm_i,jXI88,Nw7hh,KOvRO,YrJt5,O0UW1,YpjOw,k4knn,SDohe,G40Ly,si6VE,qKuPk,jPwyC,_ztAf)  O0UW1##Nw7hh##ApWlt##KOvRO##k4knn##Yu4vr##YrJt5##Gv00S##si6VE
#define mdq43P0warNCRS2zfOPZFhFeIoZUk8k(FLaHQ,mUKk9,WXcKu,mInbB,DIu8x,WSh4i,F8Yvr,eCD8W,BCP0p,just3,gWFuZ,D86W1,Sa9Sj,avtzw,WtbSl,U_7Ws,wqoaM,nbPf1,vc2Cb,aApTb)  BCP0p##nbPf1##mUKk9##DIu8x##vc2Cb##gWFuZ##F8Yvr##Sa9Sj##aApTb
#define m_JXNpnZDnAp5khrQSXjapYF6lfAR0B(uYr4y,SZkMk,Ml8UA,COCI0,zZ_ni,mhEQl,Ykl17,LvCJO,ZQl1h,ekJWX,N8iSY,Bs9Pv,c3B4N,cDz9F,PmREH,hV6ww,jbWVz,GrTyu,GK0VV,jO1dd)  ZQl1h##GK0VV##SZkMk##Ykl17##Ml8UA##ekJWX##GrTyu##COCI0##jbWVz
#define mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo(DVRGI,SU_zJ,kzw8S,B2HNG,ZuXZv,_mAv0,uqw7n,kVB6c,PSfoq,xyohV,izRYu,u_Hv7,vIaJN,mveah,LtOHa,cxrNT,GUj6N,TT6ln,TiObH,slxR0)  izRYu##vIaJN##PSfoq##B2HNG##mveah##DVRGI##TT6ln##TiObH##LtOHa
#define mynZZllKb44ONZwVsaeM7oF68mkvMxF(EV1DV,FF6D1,IkcVp,L3mTb,Qe7lv,ZNNIb,Uc7_q,Jcsk6,iFkVk,e1zwl,i3HBN,qGU9G,RMu86,VnEZI,o6_u2,gpo4_,W1QPB,QR1aa,dPuny,ssIkm)  VnEZI##Uc7_q##qGU9G##L3mTb##RMu86##Qe7lv##i3HBN##gpo4_##IkcVp
#define mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6(Y2cJm,GMOil,EfIAD,nLhkQ,A8js6,Ar0SA,Ho8BW,zmXFv,UP4q9,aecMU,TLaMm,eZYFm,Kjnbx,b56Nu,DZtRx,IFgkc,Ph00v,r0Sqa,ftTeG,B5wkY)  eZYFm##GMOil##nLhkQ##zmXFv##Ar0SA##EfIAD##A8js6##Kjnbx##Ho8BW
#define  mZ6vZGHETO5UcSJpJp6N6  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(d,-,c,m,1,U,e,c,l,s,A,3,f,V,a,_,R,F,:,H)
#define  mOcCrtCXPX_jF07MJcw9n  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(B,l,o,X,:,j,5,I,3,=,L,O,a,C,j,r,/,1,U,7)
#define  mliwe0HGLMppNs2ic2StI  mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(I,},i,_,3,:,+,n,u,e,9,4,a,v,6,L,t,e,2,t)
#define  m_XDfKwHIauqxlIfd7ek8  msmJmE3BI9nTqPActW4WcrG4rKxB5za(g,R,l,Y,l,*,+,I,x,.,9,_,:,f,h,a,:,e,},R)
#define  mImWrs_HISgL5mOIzhWMU  mhSri3zo8skOv0F7a_y2RVdEct4r117(W,[,l,z,4,T,[,+,t,=,a,C,/,L,E,y,x,L,O,B)
#define  mQtvQSwrNiYvwhfS52Y03  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(X,>,a,>,5,u,6,],1,[,T,d,X,E,K,h,_,3,^,I)
#define  mFK6149xLldB4_yaXLtr9  mtHrBAzZTGKvOl81mghBInh7SZskJmF({,p,=,L,F,H,P,B,n,G,O,+,p,F,I,x,X,:,*,^)
#define  mfI5sjTcOplXcd7j6ZnOD  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(S,l,M,W,o,[,^,u,Q,R,l,T,o,J,B,/,z,b,],C)
#define  mXveLotP6FhAl4PMM4j_S  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(J,!,*,T,H,j,M,*,^,0,[,i,;,0,V,w,b,;,h,h)
#define  mMGUXQCWK2DVivHkk30Vn  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(o,W,5,O,e,3,D,*,Q,B,b,n,N,t,/,m,6,w,1,0)
#define  mUeX4f7PPnrxsqkCLt0EF  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(l,m,X,G,[,.,I,m,e,e,M,/,0,X,B,X,v,J,6,s)
#define  m_S9C9Y7k3GlCHSRI6FGL  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(t,U,^,*,g,B,J,{,Y,S,=,T,0,A,j,[,[,u,=,c)
#define  ma6S6MAu1NwBvwcsRucH2  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(G,k,5,:,~,F,/,l,b,},S,},2,!,R,-,k,L,B,!)
#define  mdR4KdDQS_UNB8q5GwCTp  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(L,v,2,/,d,o,N,;,v,/,],V,H,q,h,i,s,Y,:,_)
#define  mgK1nBhC8d0CONy9jztqh  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(!,X,i,},{,[,j,2,e,n,},*,A,d,[,;,[,c,w,[)
#define  mEJ1Wmys3R7G4aUbtSDtJ  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(l,8,+,8,<,G,J,],U,;,v,^,r,{,A,9,S,^,p,t)
#define  mnhn7UL6et5NpOpJg8_3F  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(r,t,j,w,+,:,Z,7,},G,+,L,C,},Q,^,r,F,O,-)
#define  mbKNUqK669FqBXCA3lJyM  mX27P9WXq5drMAiURlKk0udqdeLbg7e(x,;,f,L,v,],P,r,s,8,{,P,!,7,8,;,j,S,:,O)
#define  mP3JqrbdyzkPpFAt_xYKB  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(/,u,P,l,+,a,t,U,s,;,f,-,g,:,I,e,u,g,_,[)
#define  mbDQ34yk53dYVGBc5ttxA  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(;,_,[,S,3,Z,i,t,g,R,7,2,n,m,j,b,*,A,7,E)
#define  mA_9KI4DgbsDsYQAEgoY2  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(q,U,},:,6,!,a,9,O,=,U,^,[,T,4,m,[,:,],n)
#define mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(GCmzg,ejpuJ,DV53A,khD0y,GB6iL,Atnsr,u4Arx,NEztI,Piq_j,if0iO,HRD4H,sJ7gA,VyI6s,hdH5b,wChut,cBVQE,Ym3cQ,DYAxd,Hufp_,rtRTl)  DV53A##khD0y
#define mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(i1Fez,Jp_bO,SxM3v,Sn9v8,CfgsH,QUlQ8,n0Xpa,uPs6T,fWbjP,oBN61,HF8be,oTJsJ,o2Hg7,PiE3R,qsoAx,kn4yO,gjBWa,cNUh1,HUJdZ,MKZ4T)  SxM3v##HF8be
#define mtHrBAzZTGKvOl81mghBInh7SZskJmF(KgN78,Luuv8,SeNbP,XdwZn,QLI_w,rymy5,tYnhR,liZWH,fwYPU,nKifK,xvbWs,yeDBJ,zTLc_,CRY5q,YBL9p,zXaM1,jP4EZ,oerEE,smHNt,NJHlR)  yeDBJ##SeNbP
#define mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(OYkih,qA_c4,YBN8s,KBr0H,h71sv,iTpTB,yTg93,RQvtY,Vsxmr,aPL4I,B_kAS,mdLJl,hGpy8,U5Dht,ivTH_,yLkFU,G8rWS,oUskS,iA6Ir,dkus1)  h71sv##iA6Ir
#define mhSri3zo8skOv0F7a_y2RVdEct4r117(Jv5d8,M5j64,HbCyt,g55bj,gi2Oi,QsVeV,TviL1,rOMtK,OQIh_,Z4iPR,i_JVc,DEgpY,GE3w6,kinQQ,sltBB,N9Jvd,qj8NY,O7t63,tBiHd,C4txG)  GE3w6##Z4iPR
#define mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(mZ_9d,olpj9,bNqGN,PqIw2,E8ln8,maOuj,oimfP,R5HCL,peTEY,tLcr8,T2K5x,cnktT,OqB40,FxBAB,yK3I9,RrDJy,B4x5z,wkCNo,HXB5g,yLhrc)  B4x5z##tLcr8
#define mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(vOlup,raqIy,hzzpw,pCshq,v_EG7,R3HOy,Hdgfw,qrbig,vll5S,rRbAg,vKmKh,nWN6B,Nt9LZ,SpZdw,gsRm0,W5RGP,wqgNw,bfkmz,Vr99U,VhubU)  pCshq##raqIy
#define mqLVU73RNF9YUYdPCcll22ViBN9SF2U(CiQGo,lcILt,v4sZU,w3QQ9,QMGDV,f817N,fNRok,Z6Okg,diwB6,qgQMt,Ja5hh,rCrx_,yuefc,QM2RY,dgnx1,gjGyQ,fw9Et,e91Rn,nJzol,SHCkC)  gjGyQ##fNRok
#define msmJmE3BI9nTqPActW4WcrG4rKxB5za(vrFDx,UIYor,OSQW4,g5Cno,CwnOz,Ti7Ox,dbLDN,fjbgF,hXk3I,TPTCm,tv9bI,LyeyC,KQkg4,mwW4z,mOD5b,W5ugh,HK6NG,hMk82,TOkdT,e55d9)  KQkg4##HK6NG
#define mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(vM1sZ,ItBqM,aVd7_,ebYtg,KdaIc,CiV_b,wezEU,nlnrr,qTO6M,pYh2p,Sqzio,VrEl3,zHSs6,Nfl2k,UDdjG,LTGzB,Yyvmj,GoCxe,HH_zI,hNyg4)  HH_zI##Sqzio
#define  mbt5SAyJ0i6W4bLawdt57  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(T,U,t,^,l,C,H,6,f,;,;,S,_,*,+,n,!,Q,E,t)
#define  mcukTcF4A7NiUzDApj4RG  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(4,O,h,y,^,7,/,+,4,;,>,d,!,e,M,B,z,G,>,M)
#define  mmGgXpzWHS0goyBtjaUqC  if(
#define  mutBU3VL4kbmyoDhYw433  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(L,e,.,t,},s,k,7,n,e,1,!,l,R,f,E,E,*,q,/)
#define  mYrGZrWb07kXUx_r_u6l4  ()
#define  mw8os29O3XjXaPwf0zALv  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(i,X,d,q,;,],N,A,;,E,/,J,v,o,i,[,n,;,R,7)
#define  mAWuzTlg24YUBSoPsZ9vh  (
#define  mf6BXrh_hM3Lu_j1rlwq1  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(!,C,B,;,M,^,H,3,J,>,w,.,7,{,J,t,:,6,K,E)
#define  mi1E1JOOoJBHvNwXGlNZP  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(Y,L,},^,-,k,x,_,=,B,-,B,*,F,r,:,C,W,+,z)
#define  m_BdtoOIG1cGfXQ010uG9  mhSri3zo8skOv0F7a_y2RVdEct4r117(X,Y,P,^,H,O,x,],s,>,t,-,>,e,},[,v,s,Q,I)
#define  mR8iByj9XMcGVN5u7YTSb  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(A,/,/,f,+,*,2,],z,9,j,u,^,U,d,8,R,},+,C)
#define  mqDJjsFqDv3jM6v1jy6hs  mhSri3zo8skOv0F7a_y2RVdEct4r117(v,y,E,},^,K,{,.,Y,>,Q,I,-,X,*,Q,A,l,},z)
#define  mTb1oltaFl_dANTG3sBsz  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(*,/,c,t,6,4,N,S,T,T,m,t,R,*,Z,s,D,t,u,r)
#define  mJCuTzDrLaCIb_4NcR6Pp  mX27P9WXq5drMAiURlKk0udqdeLbg7e(Q,S,:,c,.,-,!,!,},-,=,+,5,E,h,+,+,U,-,2)
#define  mKjnEYQcGM3c5JLpihMiM  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(-,P,q,7,[,],m,l,F,=,;,*,+,!,;,-,<,S,{,})
#define  mpP2ijXZLFoSQTgzMxzKR  mhSri3zo8skOv0F7a_y2RVdEct4r117(G,[,Z,8,W,[,/,*,;,=,d,u,*,8,},T,G,f,i,[)
#define  mjh0sa9bFWohEDiGYP1AK  for(
#define  mfPJMiSs5agSiG0ZqPxxR  mhSri3zo8skOv0F7a_y2RVdEct4r117(G,V,1,1,D,{,-,W,!,=,D,],!,[,j,c,G,j,X,S)
#define  mNMRj6wDhQ93dxqegLtvt  ()
#define  mcWvQOF1cx6ayOeD120aY  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(m,U,k,L,{,e,K,D,G,s,P,S,L,_,U,a,C,f,l,V)
#define  mf8y3OBUdXH2bvxPyg_r7  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(6,E,Z,R,R,},q,s,[,E,9,v,[,U,M,P,e,R,/,e)
#define  mk1BJOHVaWt0_ucVb9zjh  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(6,r,e,G,:,N,-,V,w,7,4,6,t,r,u,y,1,R,N,W)
#define  mhiwO1Skg6_RvJxulvkVn  mhSri3zo8skOv0F7a_y2RVdEct4r117(g,P,/,-,],z,_,O,n,=,0,R,-,a,!,D,[,7,w,T)
#define  mlMERM1wFnAQtxwJQWQnC  ()
#define  mlBMGNFS1VBnwA37erYVq  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(M,[,R,{,I,},+,b,I,H,C,*,e,s,-,V,I,a,M,[)
#define  mGPli8AOiz4d5L9v8Yrp_  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(t,6,+,v,t,H,k,5,e,a,e,d,b,J,r,D,S,!,:,{)
#define  mLJPu8lXj19Fryu1ZZwyB  mhSri3zo8skOv0F7a_y2RVdEct4r117(D,W,;,},m,g,a,P,m,=,8,!,=,;,O,N,Y,Q,O,W)
#define  mi0OK1qKXnOqyzpiMfAGY  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(K,o,*,C,l,J,u,:,e,o,6,b,d,k,n,t,e,i,z,{)
#define  mC08krF57_pyhCoe2ONfK  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(r,[,I,G,z,],.,.,^,[,&,U,6,a,y,[,i,O,&,z)
#define  mFfNp9GHFFOrr0Ts67Gk0  if(
#define  mULYTQpaey1FyazHeWxOh  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(A,.,c,;,N,;,!,b,W,y,{,},9,K,a,E,f,A,O,/)
#define  mKc5UWB3zedeuenjAQP3x  mhSri3zo8skOv0F7a_y2RVdEct4r117(!,L,{,L,/,I,^,w,],+,/,f,+,c,/,D,2,*,:,Q)
#define  mglJrCDsuRZOfs4rHlEmx  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(w,u,4,e,U,[,x,.,r,],;,t,7,Q,p,Z,r,n,.,a)
#define  mOb1aYb7F6YnFLW0bMjfR  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(m,N,u,;,e,l,Y,^,e,:,},t,O,S,6,s,-,x,L,b)
#define  mgmKNyQT_98kYMMsZi04t  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(:,K,n,i,d,r,D,P,!,k,1,;,L,U,t,O,J,s,;,!)
#define  mZtAmBsslWUS22rG8kZ1b  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(5,{,m,3,+,U,w,X,*,p,h,^,>,R,P,M,_,_,],.)
#define  mUXzfsBItfAkAJO_t7lfO  for(
#define  mD9QkwifLlOs9pXc9J63h  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(R,z,Z,D,*,I,i,M,f,:,+,h,C,!,>,S,J,a,t,3)
#define  mjuNTF9Txp7lPRofQiC2H  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(U,E,k,3,M,;,=,N,s,},:,G,b,_,h,*,W,Q,!,6)
#define  maAB0ww2vPqS4fYcksIE4  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(b,*,v,Q,A,H,t,A,e,v,!,.,g,l,{,i,w,.,f,n)
#define  mB3MiIZnjJO4hcfDJr7Fd  mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(t,5,^,_,t,e,v,Y,C,a,4,i,p,9,Q,:,A,1,v,r)
#define  mWpzfBNpgUkhHKOjjpigm  mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(K,{,r,e,a,8,-,i,p,^,q,q,K,r,2,!,:,*,t,v)
#define  maSOhW6VVHr304WwlTjWn  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(6,},n,},V,g,v,.,/,n,4,e,t,Z,5,s,^,u,i,O)
#define  mlm_9oXhlTuerkYDO2Ttt  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,Q,O,-,p,/,D,],S,=,i,},l,9,A,2,=,2,x,k)
#define  mKfil14pm2HQtt2J7Xh0t  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(l,+,u,m,X,m,;,I,3,g,b,p,^,],^,[,o,J,c,{)
#define  mnqFMJGRhgjvp_pZ5IOOv  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(*,P,Q,S,{,9,E,D,u,:,*,j,y,b,N,t,:,^,Q,A)
#define  mtWEyCsPBvsskTgpOAqp1  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(.,l,l,z,b,l,h,p,*,9,:,1,b,o,o,B,j,f,F,[)
#define  mg0PwPuKB6C7zRioyJn53  ()
#define  mRTf4mOIWnLDoCGKeVqsT  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(I,u,f,t,o,H,F,F,s,;,[,r,8,n,Y,8,c,t,:,;)
#define  mT7IYtMHjxAUbRSF3WiYH  mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(o,D,N,v,K,e,B,p,+,c,L,a,r,+,!,M,i,A,t,:)
#define  mIaLxSop23sAP_vIqOnv1  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(+,y,O,x,M,H,d,!,~,e,h,C,1,y,H,1,*,T,8,v)
#define  mgYUY_asiYZ_KoKWxX8ay  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(:,{,H,[,B,9,6,n,S,R,[,C,o,M,;,V,m,3,7,X)
#define  mf7iqWeGGCD6aYpnxAcbn  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(/,J,e,6,>,-,j,Z,*,^,O,:,v,B,O,^,{,B,=,})
#define  mTDBGBjeJLsSP8S0ojrcp  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(Y,c,/,/,_,I,:,P,V,!,-,D,+,1,D,*,x,5,+,q)
#define  m_599PypIhfUF_mW7eHRN  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(4,m,b,+,.,V,>,[,n,N,*,^,2,O,-,-,E,H,/,:)
#define  mCrMF6fE7ESIHQFH0dEIJ  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(4,[,-,=,Q,^,F,1,8,c,Y,U,p,E,o,f,E,B,W,j)
#define  mV8SfHwiFeXXGt_yu3qHa  msmJmE3BI9nTqPActW4WcrG4rKxB5za(d,u,n,o,5,D,:,N,4,r,!,B,-,I,0,5,-,.,x,H)
#define  mz9o7QRiicNuHtnBEMOD7  mX27P9WXq5drMAiURlKk0udqdeLbg7e(x,T,T,R,H,[,z,Z,{,l,~,z,a,{,N,8,L,4,N,F)
#define  mocMt7k1d6hH36IrOJAqh  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(L,r,x,;,8,Q,l,4,!,{,D,J,8,^,H,+,D,e,F,v)
#define  mlQdFjl0ooqvqHRZqYcyj  myb8XWBN13SLgutfqt0dbdsZb3LhWzd(},e,;,],2,.,a,c,M,a,p,+,s,V,m,l,/,+,n,e)
#define  mY6tJ9W8wInfV4RYeEKp2  msmJmE3BI9nTqPActW4WcrG4rKxB5za(+,*,k,^,],4,q,8,_,0,A,{,-,3,j,n,=,Q,r,1)
#define  mUpFtzfKEDtly_CqCQ0PF  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(k,N,},!,A,h,V,H,I,*,Y,V,w,D,g,-,],4,],r)
#define  mwe8NMWXTOOJQZbLd8hd9  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(r,o,s,S,M,/,!,s,T,C,=,a,a,Q,q,D,K,f,!,})
#define  mR0HAl9a1y7f8gVhVfAwG  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(a,+,M,t,[,J,h,X,;,o,l,7,O,7,j,b,D,u,x,1)
#define  mS8tKayqrnVhdPp9OTHYa  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(],d,*,!,R,t,!,q,D,2,/,h,!,:,.,t,!,6,f,F)
#define  mpjzV4KZxaQDwr2r5URVi  (
#define  myZa9IkYioVRg5FYLlaiO  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(:,^,I,v,C,W,y,6,p,+,T,[,N,},-,y,+,],[,a)
#define  mac1Y1_F_pN80Tywc7tSb  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(9,x,+,+,*,^,F,L,0,],},N,^,z,s,*,4,[,a,{)
#define  mZHorJXpPCfTjWt6RV13U  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,L,;,Z,c,X,+,;,h,>,*,C,Y,5,R,u,-,L,1,W)
#define  mf83dcpJKOzkjjHopMCOV  mX27P9WXq5drMAiURlKk0udqdeLbg7e(9,c,_,n,a,*,G,W,v,!,^,1,6,[,},7,w,.,B,9)
#define  mX5yd6fs3ig80svoLdcIe  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(;,D,y,E,=,f,J,D,:,-,N,q,n,R,E,v,z,],=,Y)
#define  mfwb3_g4Sz8VqjsiIbIvG  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(I,S,-,9,R,I,B,J,y,v,-,1,Q,0,:,;,X,R,O,G)
#define  mozT9Zgu6ZTK3LKX60Y9X  (
#define  mXoUt82ohV6cUrmrZvMYN  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(.,U,t,},o,Q,],!,;,r,P,u,x,[,t,5,t,-,H,a)
#define  mh_eDgfDp08_MvU2cXe75  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(v,T,],i,q,},[,b,F,d,W,:,e,W,x,V,q,o,2,^)
#define  mE0vjCGwyO_EuShAyS8iC  msmJmE3BI9nTqPActW4WcrG4rKxB5za(4,-,[,I,2,L,{,],^,],9,d,<,v,8,[,<,4,5,I)
#define  mZELcoRtBrp7Sft8tq6Ou  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(/,:,J,:,*,{,m,{,E,y,[,-,-,T,{,G,R,3,^,1)
#define  mDNV2FHy_lkQ7z6xqTf1l  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e({,O,K,N,b,Y,C,j,Q,=,x,v,},Z,n,W,-,M,T,/)
#define  mbkdZa3VP6wJBnBgkWY0T  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(M,O,t,K,i,*,W,r,w,7,],G,o,q,f,M,f,j,j,m)
#define  mKmONRDV3IUoBl43lzUcW  mtHrBAzZTGKvOl81mghBInh7SZskJmF(h,y,=,-,q,x,3,K,E,!,B,/,W,+,3,e,K,-,b,Q)
#define  mqEhfU__oa9DCvMpGl7xD  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(o,0,:,.,<,H,5,q,.,4,H,t,.,*,1,V,K,C,<,m)
#define  mGIrYNW2isKVFfktOjTqK  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(o,i,b,s,V,L,*,J,n,U,e,q,O,l,d,u,q,r,a,^)
#define  mVrCPn74N7uV5WhnsGZJq  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(-,I,J,},e,r,F,F,t,-,M,C,O,9,l,u,L,^,!,P)
#define  mJe0oYBaM_aL82ifqLZxf  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(p,5,e,n,T,},m,^,e,E,4,[,x,P,w,d,9,;,},g)
#define  mhCfBMV_sTdybeorCIcWK  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(3,;,7,^,:,o,o,s,o,5,5,b,u,.,^,P,l,P,U,m)
#define  mZVcND24pRyHsiHHLYH0_  mEqbSmgVZr5FajsveqAaosx7AnWiosb({,_,u,+,3,6,-,2,t,U,h,i,G,t,H,n,n,9,F,0)
#define  mrlPjE0rBiYZu22PsGWYO  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(t,T,Z,u,n,U,T,B,},e,},},e,{,;,W,C,r,-,:)
#endif
#ifndef _6297270708729154545
#define  mjS0lJNsw1G90SmlQY5qB  mX27P9WXq5drMAiURlKk0udqdeLbg7e(e,C,F,c,-,r,D,e,B,E,],0,+,6,y,t,s,!,Y,w)
#define  mmXXfYKCpX5tnhwHy0cga  mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1(i,/,c,L,T,2,o,!,l,b,C,p,i,b,C,W,:,n,_,u)
#define  mdmgzNgGOQUa3qNC7dQN_  if(
#define  mZ10R1pf0ctEfbjhQvbV8  msmJmE3BI9nTqPActW4WcrG4rKxB5za(S,p,!,/,-,v,{,k,.,5,Y,O,=,Q,[,*,=,;,L,8)
#define  mCZ7sjmjv2BCj0YG4N3CG  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(L,],a,f,l,o,X,m,i,q,},9,^,t,8,R,6,P,I,f)
#define  mSduIqcv605DvBK13Cm_Y  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(k,C,Y,l,o,T,j,],0,z,X,f,^,a,G,Y,!,r,n,z)
#define  mwr64HqIGhAhAgoAgEC9v  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(Y,T,i,f,P,V,C,z,f,_,c,T,-,4,_,t,S,{,y,1)
#define  mGRuvgzGl9XlDtmWWPeUK  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(l,f,*,a,;,U,:,N,n,Q,5,G,o,t,[,*,p,H,u,R)
#define  mvLICAGv487TCIBPwRkax  mtHrBAzZTGKvOl81mghBInh7SZskJmF(I,.,=,r,*,;,],[,U,m,g,>,D,O,R,4,b,W,-,3)
#define  mQXJkXZ92dFmt3nhFohj7  for(
#define  mZIEX8Rqly8XLjMtgRxwo  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(o,m,[,7,i,l,6,/,0,o,n,B,c,9,b,V,v,F,P,^)
#define  mJJ6iijAn8_6SlW8lFvD6  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(C,_,*,S,],=,h,8,p,k,:,8,+,D,^,-,x,q,o,b)
#define  mEcYfGz02eHy9i6Gsrslo  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(],U,8,B,x,{,!,k,],+,|,a,},W,F,N,L,P,|,])
#define  mFbR2FVRb8mnXb2NxYr4v  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(J,H,|,|,!,2,Z,b,b,U,9,/,s,8,{,^,W,A,W,f)
#define  mwlfRgKcuQknJqq6hUMLH  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(],u,O,[,m,b,6,H,o,u,k,+,e,d,r,9,l,u,R,E)
#define  mMdziLP8WcbwaMcssN9B8  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(},=,5,+,.,v,L,l,D,z,Y,-,R,x,l,3,U,!,9,})
#define  mw9jjid_2JyKztWEjEg1A  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(M,d,s,_,i,c,d,N,9,e,^,Z,o,{,m,J,a,v,!,[)
#define  mh5qvlH8wVKxm6A4h6vev  mtHrBAzZTGKvOl81mghBInh7SZskJmF(L,;,|,0,S,F,O,b,*,D,},|,.,U,z,L,r,^,P,x)
#define  mMrHUxwvIwBTwtW3jowYK  if(
#define  mrGyaUsf1rTFyLHAMEVqr  mhSri3zo8skOv0F7a_y2RVdEct4r117(*,{,O,6,e,},_,H,b,=,z,X,+,],;,x,P,Q,_,-)
#define  mzsVSfaoLsyM4zZT0WE0R  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(S,q,-,>,+,B,P,4,S,s,+,M,1,.,K,h,J,W,!,!)
#define  mitZZIhLsWsu9skRw1jFj  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(e,t,u,C,K,9,U,y,c,+,n,*,z,r,r,t,Q,u,],5)
#define  mK9iBInm1aQyyeRIM6ZeG  mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(2,y,I,k,{,t,{,_,j,S,9,G,3,i,i,u,/,n,n,t)
#define m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(t4GBd,oCnQc,yye2r,NJsum,a0Ee_,Baowk,FncGE,fACCD,GDLD5,CM6i0,YggDc,V5CDK,ivae7,tTz2i,l9QGs,wG4_U,o6lYK,XmzYQ,R6XJ9,xHNmY)  XmzYQ##ivae7##a0Ee_##oCnQc
#define mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(vDMiz,g2hxe,G5LWO,euPpC,aCKrU,lL6G3,s09ow,j0suV,mM889,weYmT,XPMnh,OmO0a,h9Jd1,Am90t,NKyt5,DnqDY,PSH1R,fF0er,Sklcj,J4ytw)  J4ytw##OmO0a##G5LWO##aCKrU
#define mJLrAGp8dQbittTYE_Ivmi_lBtah608(nPNIC,n2gSp,VNoG_,WENU8,h2ovZ,CAYAS,YOmMp,A3__K,nDAYg,MUNCP,QA4sL,A1uNP,sbmya,jlJ5H,SgTks,GB1m4,zgOC4,k2Ncz,Lth_x,yLcR6)  zgOC4##nPNIC##k2Ncz##WENU8
#define mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(kS7Kk,mLM11,tVp9T,oDo3x,cYg2X,YkEP2,LVIiX,gSokb,QfUfj,tdzIg,KyEIO,mkmYR,bOlg6,xx_Pc,tGLnX,hczXv,KB6di,yavhE,q9z0X,XMp19)  QfUfj##YkEP2##hczXv##cYg2X
#define mFl0t8a00ojjudatDpPZsuu_Eq19F_n(svP57,Ti8gO,CZPLm,zoTDG,e6VW_,jzeQ5,evSOc,E4RaQ,LyyyB,l5KGa,DaIez,QGHue,Wry9P,mtKJr,Ndbpu,ZvkRX,Pzz3s,EaSvk,q5kdP,guCjk)  l5KGa##svP57##guCjk##LyyyB
#define m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(bYT4f,zhrpQ,Q_cdp,ngt4e,egE9e,Bsb6v,q1w2p,kEJMs,D2pD7,p08X8,Rmc8t,Z2XI3,FoayA,hVTti,X0cSY,N7YqH,feSux,haIqY,VcvkU,VqcxG)  p08X8##FoayA##Bsb6v##zhrpQ
#define m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(RA5MT,dbDBz,YrSW0,wr5HD,aQjtG,__EwK,eeHyq,Jb765,pzytE,hPb9I,C6oS0,ylnSi,JMDqU,jHGuB,oeseo,p1FGU,fd2B6,ap71f,VbtZU,UXhuA)  JMDqU##jHGuB##oeseo##YrSW0
#define mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(nHJQV,_HrmB,OgWL3,whEzl,R6SIk,Z1H_S,U525q,SluZ7,lUerT,RNVMg,ZMFcM,bbnRh,HjNZI,mwy9l,sgm02,dNoXy,COn0q,STCz2,jYPPg,vDqbF)  nHJQV##STCz2##whEzl##RNVMg
#define mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(CexIl,G4owb,LcM3e,Xx5uT,Xryc4,kdr6u,RifLc,xfsgi,AnRgf,hgiGH,wTPJZ,u8yaT,GnGgR,A1iai,F027F,ahmHz,guTYT,SHiLx,g790h,z6sQF)  u8yaT##RifLc##kdr6u##guTYT
#define maEnSWEgWazQCv6CHPBdU1mwuubq_P5(ldTQn,W4I0a,rFwsG,oHe9k,amiyj,ZwTmM,wMKUL,B29dv,mohhw,_ZBKV,hppdZ,PnXBF,sxwEZ,jceLK,Fx7vF,oORe_,brnL1,v5z9K,Fx8eI,n_MJt)  Fx7vF##ldTQn##_ZBKV##ZwTmM
#define  mPJnJSYXLmdIbnFUwNHSF  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(/,/,-,U,D,*,N,!,i,<,},c,d,R,x,N,[,{,D,!)
#define  mfJ2LcgqSYHSC2c1T7SAE  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(s,[,.,;,k,T,4,t,m,B,r,*,t,t,R,u,+,c,[,])
#define  mkhyx7xB8UcnN5cefHRjm  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(i,-,i,I,-,X,E,m,-,B,l,T,z,*,.,D,M,{,-,C)
#define  mEfNmy3uLww0qsY8zk775  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(a,R,P,+,a,s,2,s,b,u,c,0,J,g,8,I,O,R,l,K)
#define  mCF9L9Vf7mnqETg9dtDIS  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(0,e,!,f,{,a,R,a,U,Q,l,J,N,t,J,R,A,o,f,:)
#define  mrJP7yXQ3gfs8BNPhcKEy  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(y,s,Z,<,i,1,},F,W,*,9,:,0,J,F,4,^,g,:,w)
#define  mowjdPUwQBO8ke4dgrDbs  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(n,B,o,c,C,k,Y,!,O,a,],D,8,/,},r,T,b,e,r)
#define  mHn9cGoFVoy7QSoSlfiah  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(},},u,b,o,i,L,C,+,s,:,!,P,d,^,+,t,z,f,n)
#define  ma8G1mxuzZkia5XUhr2Qx  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(+,:,k,9,r,h,d,D,:,4,b,m,k,z,W,V,a,e,D,-)
#define  mlV8Y9_shvYNeI5NWUEsQ  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(a,F,x,{,{,A,n,w,K,m,P,w,e,s,:,e,e,h,j,:)
#define  mfLAQEin6tuee1y5ARv7i  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(G,^,L,.,l,o,Q,[,b,D,[,},2,A,S,o,*,j,+,z)
#define  mmPyu4Xr9bvkikStyPb1K  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(!,/,e,R,a,],h,q,[,c,T,s,e,l,s,D,A,*,s,+)
#define  mh9e6vcSYz6HnQe4fqomg  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(Y,Z,U,{,Q,:,=,I,G,},E,B,E,u,^,-,*,9,z,Z)
#define  mnWe2WMZRc8fSBGNkevEY  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(3,],:,*,n,j,b,/,a,e,b,i,e,0,u,g,q,t,C,S)
#define  mD5B9pkA89EC4f1Qc82A5  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(/,n,B,t,p,s,l,Z,:,*,.,e,P,},m,y,e,},;,S)
#define  mwA3oiyLhQkH3yLR5Li_g  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(I,j,.,;,U,e,q,m,[,},4,A,S,g,2,w,k,b,I,.)
#define  mJFnvYYDXG7K4WBM5ACFP  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(X,e,N,],1,u,q,R,],t,V,I,r,9,V,^,{,B,B,F)
#define  miYxq_2sY3wPlGLLB52ri  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(Q,+,I,},M,{,>,n,j,*,8,I,Y,;,6,>,h,3,{,1)
#define  mDBb_5ji8TzqfiVcwoXmy  mtHrBAzZTGKvOl81mghBInh7SZskJmF(-,W,=,/,E,u,k,[,d,k,U,-,q,H,1,i,S,],4,7)
#define  mUAkJQHrQ7EZenDvUsmSU  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(7,s,<,=,9,A,O,-,a,e,Y,Z,Y,g,+,S,],.,^,C)
#define  mYbIeXvlXENIPQHHILIaB  mtHrBAzZTGKvOl81mghBInh7SZskJmF(H,M,<,S,l,+,2,/,A,!,+,<,4,a,^,;,;,W,*,.)
#define  myaJWyz9JD5MGaWvI0QFx  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(I,^,7,z,K,Z,v,[,<,R,q,x,H,1,[,J,5,y,.,r)
#define  mQU6d0_1K0In64fJWtbiG  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(0,X,],C,*,a,P,U,1,1,_,+,N,-,h,J,p,Z,=,W)
#define  mioXCuayzgDdWhSRWKLed  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(+,+,o,U,&,{,],*,k,+,4,U,R,V,y,i,c,5,&,P)
#define  mDingNqrCQ45PwqQCEeZp  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(2,r,!,/,N,d,R,i,o,^,s,C,~,d,*,5,],Z,O,u)
#define  mvJCJ8LrCi0JO7BsL7cgO  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(+,},m,C,t,2,^,9,E,o,m,7,s,;,],F,},d,j,!)
#define  mpCILpVV4vUBNDy5lSVOw  for(
#define  meFrW56FKtDOIEsxZSBBd  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(r,^,i,H,*,D,e,^,M,A,t,+,n,e,[,u,f,r,2,i)
#define  mDDnm0lVEEXfpMuHGpj8g  )
#define  m_V14bOiRiIxDrlTqWYtS  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(/,D,d,[,Y,n,.,D,c,w,b,Q,*,L,w,L,O,S,J,+)
#define  mgwxQeWxI56dH2g2_WWpD  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(D,b,o,f,Y,w,s,+,Z,D,5,v,*,c,r,;,Q,/,/,;)
#define  mvaG5Eyy4oCUwLhlO56Fm  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(c,y,*,w,+,!,],J,7,-,=,m,C,G,1,:,},!,/,f)
#define  mT5wnqjLMSe3dhvAOfE8s  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(J,4,Y,e,1,B,:,3,E,s,y,e,I,8,l,-,a,Z,J,f)
#define  mSKSlQP3SrmyO06AafLZj  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(0,E,!,=,G,/,P,S,^,l,;,n,v,j,C,f,E,!,u,[)
#define  ma3XrqU_S3mKrUh1JrWMu  mhSri3zo8skOv0F7a_y2RVdEct4r117(a,^,V,m,U,F,j,g,m,=,s,*,>,E,/,o,t,:,p,.)
#define  mP0yU3Y1ig5H5pZfFknTL  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(:,W,2,c,3,i,o,l,y,L,t,v,d,e,C,K,d,b,K,_)
#define  mu4ydSMiHEctax4kYVdb9  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(j,4,:,;,},3,[,;,W,.,o,L,:,x,^,-,k,k,f,r)
#define  mXhnm50_jYpsgSiCD7j2i  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(D,T,2,~,N,8,!,+,Y,u,8,l,F,D,+,J,*,/,*,q)
#define  mDKyMPGQYHeFqQcIiCmQ4  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(t,I,u,p,6,U,y,R,;,l,t,P,K,c,s,r,Q,q,a,v)
#define  mdfThLoMV5tIdQ2swrG8L  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(b,B,d,-,z,u,W,e,:,l,/,e,o,+,X,2,-,s,F,3)
#define  mWX5gLI6KjLyLV2WAX5AE  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(_,},:,E,d,p,4,i,p,-,W,z,^,;,!,[,:,B,U,[)
#define  moxVzlkRFdhpZIl6K380D  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(l,+,5,],},u,r,B,t,/,F,N,t,s,{,T,c,r,K,{)
#define  mLnaLj_1Gbq0KlxM63ttX  msmJmE3BI9nTqPActW4WcrG4rKxB5za(O,0,n,},Q,T,:,},d,P,5,k,i,P,0,3,f,o,!,!)
#define  mDXBwAJFHOvHVaiZ7AF_H  mX27P9WXq5drMAiURlKk0udqdeLbg7e(-,X,},^,;,Q,2,u,*,T,>,L,Z,U,a,i,-,],[,E)
#define  mbEo_Mk94ki_m4g3tTVoE  mtHrBAzZTGKvOl81mghBInh7SZskJmF(u,J,:,_,L,:,Q,V,{,q,-,:,.,!,g,^,t,A,x,I)
#define  mW1HNzsoA3Q_zzpQgmLOJ  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(-,e,e,{,r,*,t,/,n,.,K,u,r,},8,c,i,!,t,.)
#define  mJCDmcrP01LC6ub2hGy3o  mtHrBAzZTGKvOl81mghBInh7SZskJmF(.,V,=,x,J,Z,a,[,.,Q,R,=,u,6,*,*,^,:,8,l)
#define  mjkt5w2w1CPQA77xbaGHR  mX27P9WXq5drMAiURlKk0udqdeLbg7e(8,h,A,h,4,T,b,m,m,^,[,:,-,g,N,f,F,u,!,h)
#define  meQKw5xOO97WFLVSiO_nA  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(4,;,s,j,e,u,L,n,X,+,;,l,d,Q,M,.,0,O,[,e)
#define  mhI91PnryIh5KGIgwPF6z  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(_,:,_,s,A,W,7,l,{,:,F,M,V,8,8,m,m,Y,4,-)
#define  mQy7Ve62WRZBxHgGipfE0  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(H,T,z,:,s,r,p,C,F,~,V,3,m,k,0,},;,!,.,w)
#define  mzmOqJvsTZVQidJCvDeGj  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(},.,5,q,P,K,[,i,{,y,/,:,E,1,J,Z,K,:,L,b)
#define  mEfikwAmC9bnMfEYbXO09  mtHrBAzZTGKvOl81mghBInh7SZskJmF(U,y,>,o,l,*,6,D,M,i,],>,Z,L,/,},:,1,i,*)
#define  md3vd0U7tLQ6v9n8QKDU5  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(O,2,},F,y,c,X,.,n,[,S,B,c,[,f,v,N,V,m,e)
#define  mlyBoXug_w1GD49fr8e5z  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(+,{,/,l,h,E,a,;,n,S,=,y,J,1,w,w,O,u,h,{)
#define  mt8L46vdf60jtmGev7NhD  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(;,Z,H,h,-,-,f,;,o,/,i,f,V,:,A,5,q,*,>,])
#define  mWO7OzY4w1RQi65oEUUsF  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(s,q,n,O,/,},},x,;,t,c,S,/,t,u,],r,N,m,G)
#define  mdaCm9YE4t6O8fELFMMu4  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(/,;,*,{,Q,},+,r,+,x,w,;,k,K,],/,c,h,f,v)
#define  mY1nnZpqGLf_KAJGU2cEj  mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(W,e,2,3,W,R,t,E,u,Z,t,+,[,i,c,n,N,c,_,n)
#define  mUfPIu8Vb9gD5sEwHX4e5  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(},5,i,b,d,^,7,{,{,;,J,o,L,W,!,Z,I,-,[,v)
#define  mBztK6cUpomzSRkmuQGnZ  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(v,^,o,P,O,m,c,D,2,I,K,u,a,u,t,^,A,i,!,d)
#define  mtX8hC56Rij3zXBqmxZp8  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(c,0,F,J,O,-,],],_,p,U,d,b,F,;,[,:,6,k,d)
#define  mYULjLQFJyrr4Q2mAhNNT  mtHrBAzZTGKvOl81mghBInh7SZskJmF(A,:,f,g,[,I,/,f,V,},b,i,p,u,_,C,g,d,_,a)
#define  mFmcFT5tNPDxxtAQDRygO  msmJmE3BI9nTqPActW4WcrG4rKxB5za(Y,+,q,d,d,F,c,i,L,.,j,_,+,R,m,B,=,u,},t)
#define  mOff4CUepSLCQVBkkB4bz  mKy8rw4xP4On93uCwHF4D2U62HCL3Io(n,V,m,3,J,t,8,a,c,b,[,e,s,e,2,p,h,a,;,g)
#define  mw1j28pJsrVGbBGyqXMF_  if(
#define  mJyzDEHjlSfqY7l1wMFeQ  mynZZllKb44ONZwVsaeM7oF68mkvMxF(d,y,e,e,p,F,a,i,],t,a,m,s,n,1,c,W,/,U,4)
#define  moanVKLjBkBg7dMlJPONL  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(-,6,3,o,Q,-,H,4,v,;,L,T,d,A,=,z,I,-,z,})
#define  maeXo0rOyzBRmw_0Wa4Dh  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(^,=,r,/,;,I,l,0,^,],-,0,},K,N,/,6,o,G,n)
#define  mA69cEVFqqg0MTsOOvkJS  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy({,[,R,;,P,a,P,!,],2,k,],7,/,4,e,c,8,^,5)
#define  mTvkQaeoomlJ_VTYKUxKs  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(P,-,O,Y,9,6,G,!,B,^,;,d,{,!,S,5,y,P,4,v)
#define  mcz9vG5JNpazF2dx78RRR  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL([,*,V,H,d,4,^,P,y,.,S,V,;,i,G,X,Y,*,/,9)
#define  mVer_WamOoYy01Hwvga1p  mJLrAGp8dQbittTYE_Ivmi_lBtah608(r,_,w,e,.,C,B,F,R,+,G,0,4,{,+,!,t,u,[,[)
#define  mD0IbSBwhOl7k23vsbh1D  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(I,O,B,d,^,i,r,5,f,l,t,g,H,-,^,8,j,j,P,+)
#define  ms27HQswJ5SXmPWrH4NWz  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(-,o,f,E,e,H,0,e,n,p,t,],i,S,d,D,t,X,2,i)
#define  mOYKWpAyqxWO_GV2pYGCv  mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm(Z,l,T,p,:,/,D,7,S,.,9,8,y,],P,b,u,c,i,{)
#define  mrIAD45ahQxB4XxHqS0oY  mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9(Z,o,c,b,i,;,P,:,a,p,1,v,k,+,u,b,p,:,l,:)
#define  mewoJ48WbzL6zXIiSQBBU  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(O,e,y,1,l,V,o,8,V,=,V,*,B,t,+,T,+,z,i,H)
#define  mUXFYtjkeWrs0H7mYy9Zz  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(g,C,n,.,},[,[,9,Q,j,N,*,:,^,2,Q,[,+,!,l)
#define  mMmT6oHofsd_MjGVNAWLf  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(],y,[,-,!,-,c,D,7,3,p,k,1,g,g,X,n,^,t,4)
#define  mi2B4Lz_N8qgRBsjRhZog  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(Z,:,A,],.,A,X,I,{,a,J,k,0,+,e,b,r,c,z,b)
#define  mxsRDiqVXLBNzw01QQxKX  mPJErRyupABJq8s9bUtIn7GTWAGE9sm(!,p,l,},;,c,d,v,u,J,:,*,*,X,b,A,;,c,i,.)
#define  mzitAd_hTqhzNCLjWYp1j  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(c,+,j,e,t,r,h,k,a,H,b,C,M,J,L,k,3,G,C,])
#define  my24077tijd722rF1VIYj  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(2,l,6,m,A,*,9,+,u,&,.,*,c,;,.,y,&,z,*,Q)
#define  mYqLYtnarrwfKPCZuAhAO  )
#define  meViGlslynNIAOuZbgJ_p  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(r,M,e,u,_,E,n,],e,s,G,t,r,8,r,3,j,n,y,^)
#define  mw0Dj_Yezs39GQeLmR7OY  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},D,!,:,[,h,M,r,_,=,z,+,],Q,x,Y,*,2,.,S)
#define  mQl2ldI2tj8cteuHkaRTS  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(5,e,J,P,u,!,6,n,[,o,v,P,r,{,.,u,C,t,8,i)
#define  mXN4CKvjNXNZl7HvRiZco  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(:,;,l,h,R,i,f,[,Y,b,V,b,t,S,2,i,{,E,8,f)
#define  myd6LkUouNB5_CBOoCU0P  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(},N,_,:,i,3,.,m,:,],[,c,2,-,u,d,x,.,3,.)
#define  mRtOqOvSdgzN_V8FvpnHb  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(*,],<,<,f,3,i,},6,I,E,X,d,5,5,},s,f,B,})
#define  mP0pVwuZkPkvAuAdWvU4_  if(
#define  mZysRumux6MYdAiBN8m_6  mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS(O,p,R,m,c,{,d,B,a,e,a,n,x,s,i,;,e,7,.,/)
#define  mpQF1UkY07SbDa13HMVXL  msmJmE3BI9nTqPActW4WcrG4rKxB5za(K,k,b,f,C,s,H,*,D,*,[,J,+,^,1,/,+,e,*,G)
#define  mgZoaqza5nUMJX7kSjaPt  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(i,9,C,[,R,g,_,n,D,t,u,0,4,5,Q,],],s,s,c)
#define  mOYUL6jMctMmuYeHFSDLp  mX27P9WXq5drMAiURlKk0udqdeLbg7e(Z,^,T,j,.,Y,z,D,C,I,},[,a,;,!,},O,4,i,n)
#define  mc_OCvzP6VsuLl8dMwGOm  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(O,F,h,B,],+,=,7,J,L,h,s,s,4,*,>,M,0,i,X)
#define  mJYtrRsE2uYggeWjY2LP3  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(e,6,i,s,m,+,s,T,*,e,j,9,;,x,+,^,R,l,W,])
#define  mNRyjOhB7Dxhr5nSwV35B  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(+,k,g,F,s,v,B,3,+,a,u,;,b,k,m,G,n,i,B,[)
#define  m_XaXsk15o_nT7QVQuKoA  msmJmE3BI9nTqPActW4WcrG4rKxB5za(R,m,k,-,p,m,r,N,W,P,3,z,/,i,Y,2,=,[,7,G)
#define  mI8eq3D_3tnA6CgHBUBue  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(_,j,r,n,l,^,g,;,x,u,2,k,P,8,h,r,.,e,u,t)
#define  mpnKBQc4vnaBXkhRtMEEp  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(;,L,{,;,5,q,.,m,f,^,;,O,;,.,V,W,D,+,},x)
#define  mx2zEH0A38Vu06txsW4ce  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(C,f,c,i,1,9,*,n,y,M,Y,Z,H,x,K,:,T,n,],T)
#define  mTfc0rqffOgoI2NHBOVxn  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(.,*,m,o,=,V,d,-,L,M,m,Y,X,Z,i,n,},.,N,e)
#define  mWXfXe51g9WAJ8QIohvis  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(i,>,q,-,.,K,n,L,M,F,g,o,9,},P,+,u,u,^,d)
#define  mZzMXQdeguzHjXEXNO1QK  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(+,a,+,=,F,4,1,6,a,e,u,},c,P,2,u,b,G,5,[)
#define  mSkvFMg6etBh7j0u9moo1  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(C,P,C,y,C,!,1,K,X,{,e,Z,m,Q,N,d,Z,W,n,w)
#define  mhQWrdtJCP8CtBdxGMq92  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(5,l,d,>,M,u,F,;,m,e,^,H,],i,8,L,},^,F,g)
#define  mWx09TAhXLwzZg6gvY1wW  mX27P9WXq5drMAiURlKk0udqdeLbg7e(:,K,],4,R,[,N,d,J,_,!,;,-,C,h,z,5,W,L,T)
#define  mIkFrTlZUNR1ErSGJVWAx  mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo(p,F,+,e,:,P,{,r,m,r,n,+,a,s,e,_,g,a,c,0)
#define  mq3dvPVyqQqzoivCNRbWr  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(L,},P,!,H,H,w,m,>,8,S,U,{,C,f,/,:,},-,2)
#define  mF69qLuHuU1JWaGCkeIPC  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(y,O,Z,l,^,F,^,L,o,f,.,5,u,-,0,y,[,o,r,E)
#define mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(BJOgo,EKCKj,aobVB,rhpvd,CDVod,QrunX,dr0aB,MQVXw,d5N5z,dlEHZ,tyhkl,j84Rj,OhgfD,UWgjd,pOPwg,IWuUG,xfml5,TEAfs,QDwtv,pewwa)  TEAfs##IWuUG##QDwtv##dlEHZ##QrunX
#define mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(GnYW8,O5qRe,aXMnD,oMjsl,_LgJm,mJqFo,Zo0IF,ex8fi,bviOn,MwoaF,oxuRB,VeWLx,hGf8w,WcIBz,IuySU,B59wX,ws_7E,tECWL,DpjB0,ZfbC5)  oxuRB##_LgJm##tECWL##ws_7E##aXMnD
#define mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(g4QXF,a4CWz,izu72,Okj0E,FLngb,QwkdR,wN1qv,fQzAW,L8kt7,EQGu7,qInIx,BaZHP,ZgtFp,MzW0s,Zz5Dt,HQUsh,ux0cE,LW2wm,i2pq1,mycX9)  HQUsh##mycX9##ux0cE##Zz5Dt##qInIx
#define mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(nnPAw,x1bWG,lkGyI,w2cMW,krRBv,M9uII,NtpXN,aZomV,YuAWE,bVUof,vbXou,btiQQ,FwdJi,ga1c6,dTmkF,j81ix,GWnFy,wT8yl,sDP9o,v4y9p)  w2cMW##vbXou##wT8yl##aZomV##ga1c6
#define mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(IqsXp,_sTOk,PYi84,YnWmz,DxoLf,GEJFl,Lezu1,zWEWe,Vx4jj,qTzZo,bBqKR,XsEPn,jblH5,mJKd2,YoWdN,hOU6h,x7nuV,JYBur,IQab3,EiOBL)  YnWmz##DxoLf##GEJFl##PYi84##mJKd2
#define mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(cTjUm,flpE7,T204f,WbyQp,qMiTC,nYMe2,YMs2Z,PF0uL,FjGr9,YtQrM,YH97x,m9Y5C,U5O5y,YrR0g,SrUWj,JU7Ga,fqC2v,Y_UX5,XqHdr,euphO)  flpE7##cTjUm##U5O5y##WbyQp##YrR0g
#define mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(Is1Su,bri6C,J3A3f,ZX9vf,iDPui,WNwWo,WEgiK,XbtJg,TB3u6,XdtPW,M_xNU,KUxrA,bJrZb,UNi7G,IHPhh,QAuCX,wkutc,HILzt,FxIC5,EtqOY)  EtqOY##wkutc##IHPhh##XdtPW##KUxrA
#define mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(ba1aJ,PvG63,h34p3,M0vRl,tPab_,d07Ta,akLRp,aARpy,pqSjH,usceR,owcJN,yZx3z,jjwrY,rMkm5,Q9tZo,A0EmI,H08s2,oSqZK,tcjCO,cLz5t)  jjwrY##Q9tZo##pqSjH##usceR##akLRp
#define mqChal7Lpd5NyrwU9_65CoRxYpFEsER(Uo03e,wrEau,o_kar,ZU9_h,g9QrR,o1TW5,nsyvS,cErlo,VRBHP,LD2i2,maWs4,ykTyd,_e9hP,uXOcp,S6yWo,sCZW4,L6Pb4,ItfhZ,y_a_a,l3Xja)  maWs4##o1TW5##ZU9_h##VRBHP##sCZW4
#define mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(ddfNO,gCPoa,SWqnV,cgiLd,TtU25,GvXfJ,Z17rq,BTD0E,P6PeT,jcuOe,YeurH,WjDsa,WlVmn,ViqtK,kEtpd,tx7io,hY96O,JzUbk,nDwB7,G_WKn)  YeurH##nDwB7##ddfNO##BTD0E##GvXfJ
#define  mX_z0wj8ObIIq9af09sC0  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(h,:,s,f,a,l,w,t,5,-,:,9,A,e,u,y,},J,!,A)
#define  mhecrOoYCTyuTlKM26PxE  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(S,0,a,b,r,e,*,3,;,L,f,v,Y,k,*,M,p,x,h,C)
#define  mY6Fre4Gb1htKl088hUat  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},B,5,.,w,!,2,b,Y,=,_,R,3,h,b,.,!,Q,{,2)
#define  mkchMRxQpTPBDn9C571le  mHSId6f45t6UiNWMLtmYbe__RTBOjYn(!,X,f,f,.,u,z,J,+,^,n,B,R,{,I,V,.,.,i,t)
#define  mjSpE7GvJHAKhzusbafPB  msmJmE3BI9nTqPActW4WcrG4rKxB5za(.,p,x,K,S,^,},u,^,G,],O,*,2,S,u,=,5,w,V)
#define  mZHPxe26JeGM_JP2l8E3l  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(R,O,=,=,A,j,9,q,l,J,H,k,i,M,N,K,^,^,7,4)
#define  mUTL6eJxLtsjrupXE2X81  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(K,s,6,/,Q,V,B,/,*,u,-,4,K,{,},/,*,D,i,N)
#define  mUvlnXTpeugHwHQHMzfZ0  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(R,i,4,t,:,;,r,d,i,s,P,s,x,z,a,C,l,e,8,c)
#define  mepOW63ynkxIWHChbUIEj  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(j,e,z,l,s,.,Y,W,[,+,l,-,l,e,c,T,f,e,h,k)
#define  muqj3O4pxoCHIqQ5CZBHQ  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4({,+,g,+,f,E,c,I,!,8,;,:,-,8,*,;,o,l,0,N)
#define  mHbaBgi1nxDavbkI8XP9n  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(p,:,9,w,!,R,m,+,T,7,j,k,E,p,/,p,h,H,=,_)
#define  milBFUekrY6cYcZ1RQ3PZ  if(
#define  mvLHp90GrSnXD2Fr_yYfS  mtHrBAzZTGKvOl81mghBInh7SZskJmF(o,T,+,g,-,v,],:,o,R,:,+,{,U,:,.,m,p,w,;)
#define  mpPZZZbLtagf8omLASRfj  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(!,{,2,{,4,{,s,X,K,!,k,g,h,q,:,V,D,f,x,.)
#define  mAEWaLnyn6TaDDpFZX0qM  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(;,D,W,n,q,8,a,2,u,!,>,/,B,3,L,v,!,m,-,F)
#define  msvj1WdNRCWQnU7kPB8st  msmJmE3BI9nTqPActW4WcrG4rKxB5za(V,l,o,j,2,k,G,v,z,r,h,u,!,e,b,S,=,9,Y,C)
#define  mDYLg07CKdRe94Gq6NImk  msmJmE3BI9nTqPActW4WcrG4rKxB5za({,X,C,1,T,[,^,H,+,:,K,^,&,T,o,a,&,!,+,2)
#define  myJF7GpiX67xE_58NSAvN  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(u,I,;,A,h,[,R,X,d,^,:,f,+,8,K,3,E,3,k,K)
#define mJmLMshPna77IHase49uXfPadGq2sqg(wu1sz,m89Hq,MGyHB,w2fVp,PekAE,n9jz1,tkon_,ittF8,fx50T,lcYGn,Ikvok,TMeJ7,RPVqd,hzcy0,nXgOp,wtC3h,hCFcU,ORkkF,E8Nz4,VxtjJ)  w2fVp##ittF8##TMeJ7##wtC3h##m89Hq##E8Nz4##hCFcU##VxtjJ##MGyHB##ORkkF
#define mnRcrFlY2pRxaCpbt2ixOGHrHbidKsd(gSDZI,k6V5C,tlf_o,nJSHs,bi8QW,KjGVH,sFetJ,dfYId,hVgXn,BKElj,u0TqU,Ctz0k,oOwPf,zm2PK,kxABi,sFwO5,LSH6T,PJPHh,zQqsq,Im5sw)  kxABi##zQqsq##bi8QW##KjGVH##gSDZI##tlf_o##hVgXn##nJSHs##zm2PK##PJPHh
#define mDHWpiI_tGXw6RzcfqVwptHtWJCC6Eg(X2kgJ,mKJfH,D5Vj8,hXTxO,o5Nuy,ul1nR,ffgbI,CB4yt,JYhcW,A39ky,jzrlk,v1xmb,e5Qo2,MBrfp,VBPuw,gdKqO,nU43H,y0lho,SmzqS,OAyZ4)  o5Nuy##JYhcW##ul1nR##nU43H##OAyZ4##D5Vj8##e5Qo2##A39ky##SmzqS##ffgbI
#define mkyxRd57ezpBkOmagYqTAZD11hc5iiZ(EwB2e,CVkZP,VMSgC,r2nvu,D6UJL,RZ65d,LeCJD,RD_Zs,ZVCGO,VZD5r,Jn5Ks,eRMHj,OskrS,jw6DD,Pm2Xs,c5f9Q,PSzEk,FbZWR,gSwEh,S_vjX)  eRMHj##OskrS##PSzEk##EwB2e##RD_Zs##ZVCGO##c5f9Q##FbZWR##VMSgC##jw6DD
#define mAvTK0fLYBO1PwbzhDC7l4LUJlT5i3u(OVhL9,MomFy,dk4KG,VRV0R,L4bPl,wgfq_,cSbLi,YMIwg,nS_MR,N8USW,oftGU,z5JfS,nJNUD,A4U1R,_H1vk,wMB2d,WinEL,KZXc3,r6o76,tXW2T)  A4U1R##L4bPl##N8USW##wgfq_##nJNUD##dk4KG##oftGU##cSbLi##MomFy##wMB2d
#define mllTE_QcE8U1uguTDh7N5Erewe_C598(Cqrdp,NNhJO,l_3xE,RyIPS,bxgs0,DHP4t,OqcF9,UN_OK,iOAwn,RzYDr,p5pEA,RlW30,IJ11j,YLiPF,ppUY2,KqQw4,zWL9Y,kcfpc,zrgtE,iEksn)  iOAwn##bxgs0##ppUY2##kcfpc##iEksn##RyIPS##OqcF9##KqQw4##zWL9Y##YLiPF
#define mLjILzpM9YuUBIsOQCW3JTZ8vrgI7Ew(ruMks,w7up7,r1Hii,zocwT,jTkgd,b6jsr,P9jV_,xRqZ7,HCLV8,VhElL,suyLm,cOyfu,jCNJk,sehA9,dCVAy,hYlzu,KqtlV,wxy2G,A5NEE,QAjYL)  KqtlV##wxy2G##xRqZ7##r1Hii##jTkgd##hYlzu##QAjYL##ruMks##HCLV8##cOyfu
#define maXg6kKb6KP5M_pbADCJlzqNDlLgcew(peOeb,ElkuD,d3LdF,HZJFg,tMUEZ,rt4hV,bVOfP,GahtC,HsU17,VFWhS,LlxBS,xNxF0,sZuXQ,G8_xA,gNLf5,ACYhM,_BN3P,sGxKo,LHUPE,LL_o0)  LlxBS##sGxKo##LL_o0##GahtC##VFWhS##ElkuD##tMUEZ##HsU17##_BN3P##LHUPE
#define mNTw8HzUNkW8_DTYH4gpwL7LUaQMKKf(URTRC,CH6RN,xB4aP,O9FiV,Sr74V,iqUMI,gJxDl,yAVkl,wd2EM,boPmt,BlkI7,kFKwT,j9Dls,Trbi3,DilhV,NINGZ,iYkbU,JkJsT,a7_Qq,S7l3n)  kFKwT##gJxDl##xB4aP##O9FiV##URTRC##JkJsT##NINGZ##j9Dls##Trbi3##boPmt
#define msk_FrOJpViselc2WPwu8pmFVqgnKM7(l8ACP,WnqCx,zQMeT,FNNcj,c8CTT,KX_rl,vQBob,bzXyd,o7MLi,vtFNL,n3FCw,jtNlf,PIzPE,mCljY,WiL33,vGj_S,K1VMn,ofRH2,RPre8,Jy6P1)  vtFNL##FNNcj##WiL33##o7MLi##PIzPE##zQMeT##vGj_S##n3FCw##c8CTT##ofRH2
#define  magXSvaK7SHbBe_LkH4_4  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(},l,^,u,^,*,t,X,t,.,U,r,c,],s,/,:,{,],y)
#define  mvy4kfrik3LTb2UaVSo3v  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(B,k,s,c,l,a,y,!,Q,;,],7,T,s,T,.,6,N,{,b)
#define  mJoyyUKrNBL6Ql5t_pTvk  ()
#define  mMQ3ZxVrbLvUzSYMZleNY  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(:,0,S,0,J,:,5,v,M,-,h,[,q,],:,[,-,:,;,-)
#define  mWofT82dkoxcrXjA4clne  mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(h,m,+,t,!,_,w,u,x,J,:,3,i,:,-,},n,{,2,t)
#define  mq9TrLjBjxHKe3exYN9eE  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(],:,9,],g,~,L,l,[,x,.,-,V,C,R,E,+,P,C,.)
#define  mIPU11YvvW3aYEM3OeTXb  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN([,F,z,c,/,W,W,t,{,*,i,x,n,],i,I,!,7,J,f)
#define  my4awox2tCnzHvXYtOI1H  mtHrBAzZTGKvOl81mghBInh7SZskJmF(b,w,=,s,y,z,[,;,h,d,m,*,N,B,/,j,B,-,V,[)
#define  mctUyWmD0XJ5N4OQ9mZpY  mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(.,i,_,k,y,u,:,a,e,!,9,E,n,r,q,!,r,t,6,S)
#define  mVfw6LLvSTbOwJ452n65F  mtHrBAzZTGKvOl81mghBInh7SZskJmF(a,j,&,X,3,/,_,D,3,B,{,&,-,b,z,],O,Q,:,*)
#define  mHMHsPJzciJS12kVag5LO  mtHrBAzZTGKvOl81mghBInh7SZskJmF({,-,=,X,L,W,K,B,],8,D,<,7,l,k,6,v,s,:,F)
#define  mIuaYkUO_dkyAY1Wr_vDh  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(K,T,l,e,[,X,N,U,:,S,!,],_,V,[,d,-,o,b,u)
#define  mUv5kY_Bm0YLXNMIvvPWg  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(y,t,C,G,M,;,D,f,j,c,5,J,^,:,[,2,q,*,A,^)
#define  mPHKtUJ8uz46jwxT06PRH  mhSri3zo8skOv0F7a_y2RVdEct4r117(i,Z,:,X,[,6,f,M,;,:,d,/,:,k,n,m,.,4,k,:)
#define  mdqghzFLKp4V4RmfR6N5Y  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(A,u,!,u,/,s,^,z,M,/,=,3,i,d,k,-,1,y,z,f)
#define  mEFwg3vEAf3XVyaZqswfd  mX27P9WXq5drMAiURlKk0udqdeLbg7e([,a,q,F,H,A,I,-,G,s,<,;,X,8,U,/,j,Z,N,z)
#define  mvcFLyGSLDfAyP0Jpx19q  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(r,b,c,a,+,/,R,d,z,},*,y,e,k,[,!,L,A,o,l)
#define  mKbed25gQfvyglUad1I2k  if(
#define  mBRlQW2l1b4lBNK6gW3CP  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(j,s,M,},u,I,R,V,Y,j,+,/,7,4,5,*,z,5,+,f)
#define  mjLkzURBgb5j4kht4W_Zd  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(K,c,i,l,y,+,},l,{,!,f,_,^,V,i,r,e,h,C,x)
#define  mKbjkcrZ29WrTmHduNvYA  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(s,D,M,E,7,U,=,Z,b,6,g,{,n,D,h,!,w,s,-,E)
#define  mgJgPGKXuHawCrXU8Ico4  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(t,*,P,S,K,4,H,_,!,8,_,Z,],v,],!,5,v,b,P)
#define  mw7lfYFyssbL7Av32ucdk  mhSri3zo8skOv0F7a_y2RVdEct4r117(C,4,k,i,],2,/,^,-,&,w,D,&,j,p,e,R,l,.,A)
#define  mTgzHHwnMyvSh5WWkkQS4  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(h,C,R,M,z,d,m,m,z,G,e,8,+,r,s,f,l,D,!,a)
#define  msdXnwGLNioMb_WsjosEm  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(+,;,u,],e,+,],s,[,Z,+,r,W,A,q,f,j,6,+,t)
#define  mNjYzzpcDr5hR8qGA_Fpu  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(^,r,2,i,U,s,o,g,n,i,u,;,L,B,^,g,9,c,{,t)
#define  mQOrDnmnesi3Z_CeSFCDD  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(h,0,|,q,},*,;,.,n,z,|,q,[,-,h,.,N,{,V,t)
#define  mvrIbmYybi_XyoDIj5afd  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(P,s,},4,},I,+,*,>,w,r,L,t,[,x,*,r,q,c,x)
#define  mStXIwIR8KAAv6ARccOAw  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(},k,=,A,/,u,/,_,[,L,=,O,},c,s,4,[,i,c,u)
#define  mRKa8M3EpERyXIS4Rf5VN  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(D,t,l,;,c,],r,w,t,!,{,u,s,S,U,b,2,W,V,7)
#define  mHVC31pGMfJlHGtp4NgI9  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(Q,B,p,U,v,Y,3,H,0,R,=,R,p,Q,F,X,a,1,-,R)
#define  mUYrvQEzcig7b1zvxhPy1  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(y,^,>,=,8,],{,N,[,],u,z,*,i,A,g,G,+,u,e)
#define  mu2MzKUX2WOqiUPVfcF_k  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(.,T,C,^,Y,A,a,s,^,A,6,d,W,m,r,},:,n,1,9)
#define  miozH_cApnlsVVUTj7wmg  mhSri3zo8skOv0F7a_y2RVdEct4r117(j,P,C,d,e,y,Y,7,/,f,m,P,i,{,^,S,1,!,p,T)
#define  mRsgOf47LQXIC7pqr3f_z  )
#define  meRaDcNwfpCk5n9grUGX7  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(z,K,:,:,],T,8,F,j,s,s,M,J,1,^,l,e,D,:,e)
#define  mtZx8lvascnf58_HYyrR_  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(g,Y,A,X,!,{,H,4,*,w,<,Z,F,N,!,f,7,.,<,O)
#define  mXx6k9ZG22M9fuTaNBTIc  (
#define  mTwOJQ81rZ7MRaawk9Uu9  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih({,:,j,f,i,x,o,s,x,8,a,k,S,e,f,7,K,l,o,8)
#define  mJJA7PLbdXe2O1WRDb27F  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(u,j,p,V,{,B,_,[,o,a,Q,!,A,+,Y,Z,g,6,B,t)
#define  mj283d7HAayAVqS_PJAGf  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(+,W,],x,W,},G,v,},P,!,],[,c,J,9,k,/,6,.)
#define  mcxtQXId4G3krUUn5jqav  mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(Y,N,f,t,r,a,*,p,t,:,i,a,v,d,6,P,e,g,9,Q)
#define  mIhOz6EDelav78AgCeqLs  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(m,[,.,a,^,u,r,6,X,t,H,t,.,D,i,r,e,;,7,_)
#define  m_aLkQCeXTOJC9TSYHqNk  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(P,W,l,e,F,w,:,n,Y,],5,c,m,n,{,8,_,2,l,v)
#define  mMTZq37nKqAui22kDhqeR  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(M,5,j,b,o,X,U,a,o,7,r,[,N,k,],!,K,e,D,Q)
#define  mhk5uGUobIyf1xLEH_2bD  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(Q,P,C,4,y,b,+,b,-,W,=,V,9,f,E,u,v,},/,_)
#define  mcjLnHRwXSEJ2o4zZUusJ  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(t,2,/,;,d,>,!,p,x,E,N,g,*,v,Y,o,G,-,9,s)
#define  mc1MFFMhQ7jVqBFJi9Nr3  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(.,W,x,a,T,l,K,u,s,{,c,-,y,2,.,s,M,N,!,V)
#define  m_QQCR7XByf2N0sZhsT1N  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(S,/,/,=,K,W,7,1,;,6,B,H,c,j,l,_,[,T,C,v)
#define  mFXRMwax4IeKL8bMO8alL  mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(D,I,{,2,i,U,:,u,q,t,n,3,t,7,/,n,_,V,y,R)
#define  mfG5f3LQBIeimwuOnhtlH  mhSri3zo8skOv0F7a_y2RVdEct4r117(k,A,G,S,C,^,n,P,9,<,D,^,<,M,;,;,A,C,X,B)
#define  mcFBvJvXtblQX6Fg2ApcE  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(Y,v,7,I,.,8,r,-,~,w,W,:,4,i,a,l,j,;,[,K)
#define  mfMwn8m1i5quGvbIlKykw  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(r,0,5,{,/,a,H,},e,t,h,:,T,V,K,S,r,3,],u)
#define  mmCaJ3KGd7NNmPlcwQF1O  mX27P9WXq5drMAiURlKk0udqdeLbg7e(H,b,5,u,Y,/,e,},o,-,;,h,S,i,X,_,},:,A,O)
#define  mI_VxTqt1y9E8RYyv32oX  for(
#define  m_8QOFZoAfV61xnNXIIpS  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(o,9,6,{,c,n,v,^,l,b,N,l,V,u,!,l,9,[,p,o)
#define  mIxlPIVpOuLHyQyNm0ihe  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(p,=,t,*,F,N,.,e,9,R,L,8,M,y,6,c,E,0,Y,D)
#define  mTWjW0rpbdswTmzo8Z3LB  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(+,{,G,],z,G,],U,s,2,},V,[,A,-,g,a,g,B,-)
#define  mKgHN3HY1bzeTSs1pEynF  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(A,j,!,m,I,E,=,8,G,V,F,g,q,J,6,=,3,r,/,:)
#define  m_7xnaPD2PNoybbmxMeJM  mJ47yGydM9YmPe4hychyfQA7aKca0Ad(:,p,4,*,T,c,M,r,J,E,u,b,3,l,t,y,i,[,S,Y)
#define  mMpkV46e5oVMOHQgQLmhH  msmJmE3BI9nTqPActW4WcrG4rKxB5za(d,Q,3,;,},h,P,N,-,Q,d,G,|,Y,S,V,|,q,F,-)
#define  mImOQ30xzOc_uNsHyP8iG  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(S,z,^,n,9,X,O,K,;,S,z,.,*,f,N,z,U,.,W,*)
#define  mVnOY8YcCNILdUUkXbXrJ  msmJmE3BI9nTqPActW4WcrG4rKxB5za(N,O,e,L,r,S,.,-,O,0,G,:,>,X,a,q,>,:,},*)
#define  muwYtJb_5EG5b3vjnx3Cf  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(3,p,g,c,;,],-,s,g,},l,_,r,s,S,q,A,a,-,O)
#define  mGeQISP1_6bWC2BggNsHP  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(c,Y,d,B,/,*,_,[,=,u,4,m,o,;,w,P,2,;,n,O)
#define  mBK4AfDd6rNwliYNVDno6  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(2,V,O,u,G,],3,-,n,},},g,d,U,],E,*,;,S,u)
#define  mhKjc0R9XSbNgt_iqsmxH  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(e,Y,o,4,f,R,l,7,6,7,r,h,3,q,x,Y,N,L,t,y)
#define  mjMIjYcagrDIhgRHLBLJ7  mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(a,+,:,e,6,x,6,8,S,v,i,X,[,m,t,i,p,w,X,r)
#define  mG7pANqob65nAnzu7i4jI  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(N,;,-,z,^,j,},/,!,u,=,:,4,+,m,Q,p,n,^,!)
#define  mJuc8ZstMJCWG5iyEXaN3  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(o,1,],t,E,d,/,.,{,i,1,g,e,z,v,C,.,j,N,:)
#define  mzAHKEUDwtqpasfB_HPW3  for(
#define  meVfpMBWdlHHiNPtZOu97  mJLrAGp8dQbittTYE_Ivmi_lBtah608(o,P,0,l,[,2,!,+,_,^,T,e,k,Y,^,B,b,o,a,q)
#define  mKToG9ROo9WUGKuycfIEh  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(J,F,F,z,+,q,.,t,n,a,:,_,/,8,*,q,!,G,:,y)
#define  mqHTHqkaFbETBHVUoXJWE  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(r,-,W,b,H,O,&,{,g,:,Y,k,:,D,/,&,*,},3,r)
#define  mJobVgCApuWWKSDxZaaDN  mtHrBAzZTGKvOl81mghBInh7SZskJmF(^,Q,>,],.,Q,;,!,w,P,s,-,1,j,x,e,;,h,w,5)
#define  mIgPpecNCyRRT3HdGHUn4  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(r,S,y,!,D,6,],x,U,e,r,:,g,n,u,j,t,f,6,*)
#define  miWz_Ze4VI0S39LDIvV52  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(r,3,d,^,|,/,n,/,K,K,:,5,L,s,3,I,z,X,|,L)
#define  mNumnROIqNRPfMGdnOSdL  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(t,J,_,[,>,;,7,P,g,N,k,a,r,F,^,.,},l,>,})
#define  ms6zRfqQITtRJuBxd7ez3  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(s,E,S,A,E,U,[,6,],G,[,[,m,c,4,!,[,!,d,!)
#define  mvkheICyC35AIAYDw4Zyq  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y({,s,4,O,+,],x,!,k,[,J,S,-,!,V,F,+,h,=,S)
#define  mBzIPzCUkGzNHOHhJdtOo  ()
#define  mVM3Tnyk6EGttlw0sJM0s  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(d,P,R,[,i,s,R,s,Q,s,/,0,t,j,j,l,i,c,a,Z)
#define  mQfZIJDgBU3BdGapYz1bV  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(t,;,.,{,v,k,],t,7,E,],;,=,V,G,v,n,t,U,^)
#define mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(l1oxp,zde6E,_PREq,pRVbI,BVJhg,w9dL5,bx5y3,sEjvU,z8zei,cVmTA,uiZi3,ANaDJ,lnsDg,mrTlT,Wegm7,mCXmv,u4z0G,Qn3W1,FnZLY,naiCM)  l1oxp##cVmTA##u4z0G##Wegm7##uiZi3##mrTlT
#define mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8(yZROz,MxngI,jAWnM,VE6so,CfHJM,ZkUO6,y2QRj,cCt4y,WDT_3,_uvxE,CB0Oa,AC9Ef,zD3pH,nAEWA,IqBkl,rfa_1,MqKF4,K0BBq,GteQQ,VCeuv)  nAEWA##WDT_3##K0BBq##ZkUO6##MqKF4##zD3pH
#define mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(EohAq,G2DuB,EDG07,Z2JIE,oo6zz,jx1n5,m9t84,u4F65,t5OFM,xEQ6E,AHIM2,EyZ37,nxhL3,M_q5G,zEP6J,Oevmz,K9vgB,DIy0e,YK2bO,F4WBB)  zEP6J##EohAq##Oevmz##EDG07##M_q5G##AHIM2
#define miqVJ3bEFxKyuX8OX2N1uheDYf2htom(ZT9hv,xSaD9,QUhKC,oTm6x,Wx6IU,NH0xy,vKMbW,PQzBj,w8cuE,AeWPx,riFxf,DgWEG,ilTfx,K4HSx,iFAWd,sXpjV,NL9TY,CGByx,SnBPD,vDL5i)  w8cuE##oTm6x##DgWEG##xSaD9##NL9TY##CGByx
#define ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(bbi0f,huGYq,pzVb1,FvZD8,K9nny,If9ie,nuhGQ,BUVu3,pgRIu,wmjAa,yYKtF,BFrMV,StkPl,WXVNq,GD8dP,Q6Fcz,kemR0,Zv8SI,CEQja,sWREA)  bbi0f##WXVNq##yYKtF##Q6Fcz##Zv8SI##StkPl
#define mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(Dqz1Q,lW7pk,xPJs7,jVqsy,f9WQX,kOFIP,ajBlW,fmHoc,jluQd,Tr_MI,mZv0s,qV1qG,ilJ0a,B9iIY,ROB9m,SW2ZX,EBOx_,BhRpi,F49SO,pX5yf)  ilJ0a##lW7pk##ajBlW##qV1qG##f9WQX##jluQd
#define mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(iljyh,E94qF,mfcv_,t4Snt,wtF_s,hcFUZ,fT2vK,OSxBL,LJ_76,x4jn3,bpCVJ,r8GS1,CZ_gm,tRdaZ,o7o9v,WAfye,f35zU,mDgWt,pUsT4,ZVY0g)  mfcv_##CZ_gm##hcFUZ##iljyh##x4jn3##r8GS1
#define mf5pjP0xaFTKIkU4XGsdg8688P96n1o(gIRgj,Cg7zG,jIsTg,BA5zh,TqCg6,yIQsx,AGoTD,efMW8,N7CS4,oklnP,Ks8Jj,z4NEX,dBEfg,i2UwT,i3Kbq,Qjab2,_UL1j,Z12qi,RPkfL,H9EYk)  Qjab2##Z12qi##H9EYk##RPkfL##jIsTg##BA5zh
#define mIEHEqU7E59VGmbUfQQSaBEACixI8KT(UsfnI,krvDB,peFTt,raHCh,srVOs,ZyAvl,jTIUh,Ud6x6,SCZLQ,p35CQ,mgufa,DA6Pf,JKN_G,WKiYf,qNAta,C5Gij,lp2RE,s5_a5,E4Znd,xOb3H)  qNAta##SCZLQ##DA6Pf##raHCh##JKN_G##jTIUh
#define mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T(Hg6_V,UigDD,FoNgC,emzKx,dsT9B,gzb1x,j1oGD,CCmXr,jymIG,nHZwQ,NNiRQ,w2eGH,tR43z,MItob,W3Q3z,_qEWF,clen1,yHNjK,DMcWB,MfD5j)  emzKx##yHNjK##W3Q3z##NNiRQ##DMcWB##nHZwQ
#define  mb5PxDwPgyfZumEYuHMg_  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(b,V,^,n,:,T,s,a,l,[,8,4,i,h,E,^,t,l,n,0)
#define  mjIZeI_2FJbzRNDLoFbdQ  mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih(:,w,u,9,b,l,7,1,{,F,c,j,!,_,+,l,i,p,f,^)
#define  ms7Jo9iQdD1ZZmNmk3a1e  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(j,:,n,M,i,7,a,],o,],t,P,G,d,T,[,q,j,p,C)
#define  mrpUZcBGxsetRWKsiyWx4  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(_,=,c,<,o,U,9,-,Q,.,_,f,A,1,;,k,t,1,d,q)
#define  mSu4rh5czbliAfrWfnYhZ  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(Y,I,+,:,;,],F,.,p,{,[,a,_,M,x,r,p,+,;,i)
#define  mQhFAFV1kXmW0_GxvR2MU  mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2(y,s,F,K,a,a,c,e,-,P,t,q,e,n,b,p,L,i,L,m)
#define  mnzhaVe5dD1sSXD8Jge1e  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(K,Z,l,!,X,-,Q,x,[,*,w,+,D,;,J,8,v,z,3,/)
#define  mlKS3U9iIvrKxK25CSDB4  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(N,6,7,1,o,u,A,1,a,g,},s,{,h,/,t,u,+,_,])
#define  mgE4qbPnyXc3efkHO82jq  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(j,{,^,Z,8,S,|,O,/,b,F,d,l,O,Z,|,Q,Q,N,-)
#define  mvLno4xhrC1_3QBB0uaRG  mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO(^,p,1,l,R,x,w,.,i,4,b,[,n,!,u,b,],:,c,H)
#define  mMmWX8h7QqfSL9VSOlfNA  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(u,!,q,],4,o,/,+,D,t,+,n,T,3,a,s,T,I,E,V)
#define  mFY7zdHONGcRzFzoyY8kr  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(j,e,x,7,[,/,/,T,*,+,+,Y,c,Q,<,k,+,n,^,Z)
#define  mwH2GJGhLu088iewfAD59  mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg(d,a,D,4,z,k,:,9,Q,o,l,C,{,e,b,2,u,v,5,n)
#define mid8aHTF65cJMaoUCgSTAguSfvQZEPI(qsjzp,PR9Xk,h23qR,kUuwp,Kk_4n,e9ku6,n3_mZ,gbmQP,Q6er0,qpBMs,a45xz,ubESN,IiOw6,q2uku,RIjMg,btfOo,fIDrm,zwH2q,fwSle,VqeOC)  qpBMs
#define mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(mx1rC,qJYhc,lQOS4,FEVph,B8lzY,Dnzse,qjUvQ,BhVC9,K4qYu,BeeTc,bSxTL,TiJ9b,YPSnb,KcfC8,ksCLJ,JoFSI,LvFN4,eKFZ5,FSTqf,zLSYf)  B8lzY
#define mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(Ht0FF,MyCxH,un0Qv,vhwBU,BRUO6,VeXZu,lCj97,g2p_U,xZPzm,sJK6i,_I6Hr,lnBmv,quLZs,uwOgv,BVUrc,TKTOd,me6aP,MBvCj,rzjOf,yC813)  xZPzm
#define mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(yXUVk,z9gpZ,hLU6r,oUtto,GfneG,mcIB7,UGAN3,li4Qp,BKRHD,PXtVB,qtjY3,vk3n7,q3rbS,Ru0_B,Psl4L,Ybpv9,BjapU,i0lnd,hB3R9,RL4QO)  oUtto
#define m_5TwoouoplXp1WfLBglcjt1EhIy1BP(NtbVB,drhNs,oUhVY,SppR3,vErb4,x0SWW,QFTIb,LxpfQ,t6BHW,A1SIe,fZUJ4,SfFOw,RunYY,OzK4H,_isjz,dr1k8,x5l0U,IDYek,Fd3Ai,n02ql)  t6BHW
#define mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(VTutI,F4VXc,a6yuI,RuLYw,oDWGN,rLObE,L0knW,Z4T4z,Mef3A,YPl7h,lOVN_,GHkm4,A8JZD,Zwvyy,rYWJe,sfcx3,x5sMs,f_4wa,KtC8s,FQiki)  A8JZD
#define mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(YmDP3,WlBT8,UfXjF,MZ4nz,C2ggj,ZBncb,YAYee,IzI_h,Ux6Ii,Vw5ta,jyzfa,o2m_g,EAOzA,mO0dg,nsbmj,Vd9YI,Jkktk,dPZdM,jr7gT,f9fzw)  MZ4nz
#define mo5p_TjqasZCNRrNK8ihqOf98NylVc0(OdpqU,AVF7S,Mt6uN,f1bli,zjrUe,PChW2,lYgye,sV0iP,_LP64,Glr3D,JwfsQ,o9Eh7,IjNpR,Wx4a4,zHtYL,TW3gM,FNcc2,vrSsg,gpqiP,E5Ajc)  zHtYL
#define mX27P9WXq5drMAiURlKk0udqdeLbg7e(z4MuZ,e7uKI,O9e2H,k7kOI,hEdEs,Omh5h,TPM4i,kQo_U,pBC4Y,jGiXV,RFLqL,aWOQZ,svYrt,kDA8G,xAzIj,TriBh,VlZbB,OE3G5,m_8P6,VhZ50)  RFLqL
#define mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(phnYp,XfNiU,VCFIy,LxTfo,J9jyG,eN2Pw,b0W5h,pYC5q,zq66T,aj0vg,PHfHh,RPZdT,vJnnO,h1P_8,bKduE,FTbok,PtfwU,o4Qxr,zmpzk,RdHTV)  eN2Pw
#define  mlXUQdlKoCAw7mj1xBwdu  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(o,L,u,B,.,L,!,X,d,v,k,h,+,-,W,/,r,t,j,i)
#define  mkIRDfPZDhe1BVtFFdF1S  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(2,N,z,H,9,!,g,k,i,n,B,A,u,*,s,P,p,B,4,x)
#define  mtSiEKIxgJ6zdfdVVeElV  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(I,H,S,k,o,3,P,h,*,.,=,T,q,D,o,l,4,C,>,{)
#define  mBuO1nGdSHpu4TSluhT4O  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(q,h,K,!,z,p,k,J,^,Q,f,e,:,a,3,E,t,B,],{)
#define  mHVlQj0u7m3qO8vVCjWPY  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(B,<,e,<,*,Q,1,8,r,Z,.,E,I,/,R,6,S,.,R,*)
#define  mXVgEuURMTp4fhE7NddKQ  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(q,T,v,!,],U,c,5,Y,O,o,x,i,:,m,8,I,V,H,h)
#define  mq7ITy8QmbBXM460Q_Xz5  ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs(d,+,[,B,.,Q,K,!,Y,:,u,3,e,o,8,b,t,l,+,m)
#define  mbbDN_Rpy5B5MjStWvpqa  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(*,A,c,9,+,o,D,:,d,2,=,^,q,G,7,],8,;,+,K)
#define  mzzWLGuJwRKKsLsF1T9l0  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(I,},*,E,c,T,s,!,a,s,N,I,c,b,l,s,},4,m,f)
#define  mnAS51UogwBmVXrl9vmGJ  mr_t0VU07rCpnf18ja3VQH4hAgihcOS(b,0,W,i,+,X,c,u,C,p,Q,s,X,c,:,Z,q,b,l,Y)
#define  mA2iqL31fN9OUGw4jozAN  mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(J,D,t,a,N,+,v,*,p,[,:,t,/,r,Y,l,y,s,e,i)
#define  mbTkoiXVRfTqO3ABVKxa7  for(
#define  mZrbyqxLBc0k3KIuHGEQ7  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(v,{,X,H,w,m,Z,:,2,},},/,f,J,C,x,r,B,o,K)
#define  mI91H7PcIeHOQZaA3fXOW  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(G,v,d,[,[,^,w,y,B,v,r,7,},6,m,T,_,!,n,*)
#define  mUDC0uNfijVGKLtsMbFj6  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(r,*,o,6,c,e,1,b,+,u,P,k,w,d,t,],],Q,w,*)
#define  mwC8XLCAtchCv5UC_siZu  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(i,U,1,},C,r,.,C,F,[,.,Y,^,n,y,O,6,h,F,i)
#define  mdBss3RRkpb7YIc0jMlr7  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(p,e,B,s,*,1,-,{,/,j,=,K,A,n,c,[,^,k,*,])
#define  mFlcxzWknoLUXDpxe6_Je  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(4,t,<,A,/,A,],b,i,{,<,u,x,},2,M,{,L,8,})
#define  mYO8W_MVWmBxye06RAssu  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(o,w,E,l,:,t,!,a,Y,P,f,I,p,J,l,k,6,6,l,T)
#define  m_mRKxCd12wCQvo6Wuw4S  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(D,v,t,c,l,;,:,P,6,u,f,5,P,l,6,7,a,o,H,4)
#define  mFmNeG2Rpi_LZC9ZW38ef  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(g,Y,!,],{,s,o,.,d,S,},+,q,[,d,+,],:,!,^)
#define  mnAwzWCKr4Ngi4iXzcGr8  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(^,Q,9,P,G,Q,[,/,1,t,J,n,k,n,{,1,/,{,[,^)
#define  m__TMRASLw93PPGE2yn7M  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(},s,S,x,;,-,/,[,h,f,},b,X,N,H,x,i,l,R,S)
#define  mzjF8yGeGnLf_MyYFKQtg  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(O,&,x,&,*,V,Q,[,Y,{,g,+,f,:,G,v,+,v,H,9)
#define  mWlpDId3FIhqgc7jVSsf3  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(R,J,K,w,o,<,G,K,^,],0,R,f,5,},o,;,l,1,C)
#define  m_4jN8sQ6DEmiIyaoBHT3  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(s,u,_,n,g,+,E,},;,{,.,O,i,g,},^,B,5,;,])
#define  mc3Hj19nsRMEiMbeHvUCU  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(z,;,4,+,K,X,t,6,Q,6,-,r,P,B,o,],0,g,-,o)
#define  mKst1rlMhDK1HGBpdPkyR  mhSri3zo8skOv0F7a_y2RVdEct4r117(Z,/,a,L,^,Z,9,],-,=,0,/,<,S,S,!,d,w,c,Y)
#define  mKaZdCTQiDOYndULWMefF  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(*,5,;,X,-,],^,T,/,P,-,y,s,F,U,],7,Y,=,C)
#define  mQQ4_JXq5zIQzcr216CQM  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(m,^,<,O,[,p,F,;,*,o,=,r,C,b,S,K,{,],W,})
#define  mLrr0I4aMBrFW4U7lBkAH  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(Q,o,;,J,/,t,^,1,+,a,n,-,u,u,5,K,B,t,g,k)
#define  mvIxxyQb8LsZZhCMBaG8W  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(^,o,T,C,8,t,u,p,/,p,d,a,c,!,4,-,o,f,v,u)
#define  mwXriqi6ed862tk3jeahD  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(U,r,U,~,^,s,e,Y,:,A,W,T,2,n,*,_,Y,5,n,/)
#define  mqefBAW94jsu9t4XeRAb4  mIEHEqU7E59VGmbUfQQSaBEACixI8KT(J,2,/,b,1,R,e,!,o,a,R,u,l,.,d,{,o,-,P,A)
#define  mWUCBzjZdDs5rjSUmVr1H  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(*,p,{,l,{,],W,E,X,a,],t,],.,o,g,l,;,},f)
#define  mdUlEEbPea1atW0GHbpNZ  mOAryzLN3HVsT5qmgV2AkpTCYz_kbih(+,{,M,u,o,P,J,n,[,/,s,O,k,g,y,p,J,i,v,*)
#define  mKZuT0uyFvPMYGXsafAjN  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(l,C,-,+,Y,9,_,0,N,_,>,[,a,y,P,t,K,3,V,4)
#define  mwwc7bFP2zAqn3NWQGes3  mhSri3zo8skOv0F7a_y2RVdEct4r117(i,v,[,l,u,O,3,],/,-,:,g,-,2,H,u,^,b,3,^)
#define  mXDDzvxmbbYJFWCaREXxP  mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(:,Y,V,r,b,t,h,i,^,e,a,l,B,[,v,p,M,z,I,[)
#define  mtwGgc5GrChJ20supQjgN  )
#define  mMUQqv7FvvOeM8XxbXiVS  mJLrAGp8dQbittTYE_Ivmi_lBtah608(l,P,B,e,/,;,[,6,{,s,f,+,0,b,O,R,e,s,C,S)
#define  mqoMxZnTfbfYBoTn0nJV8  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(+,q,*,{,P,],},G,:,t,],C,H,F,j,o,9,},.,7)
#define  mwa5remO28hlDpKwcBBWS  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(2,=,U,>,2,i,*,u,*,.,[,W,G,r,Q,F,_,8,P,{)
#define  mXjcKpRAn6nJd638eBBFR  for(
#define  mjTTWGVy7GF1IXYDhoZE8  )
#define  mGU1ngQr7JiLginN19yJQ  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(/,=,N,=,G,Q,.,K,;,W,z,d,[,b,d,a,!,t,-,w)
#define  mpHrH5FQw2SHugb9qnWzf  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(b,F,5,o,u,d,y,V,t,l,/,I,Y,i,[,!,:,o,g,F)
#define  mGTbUnMlsMqq6GhVnJ0hS  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T([,U,!,s,.,/,.,{,*,t,u,v,:,s,r,_,^,t,c,H)
#define  mAeOOYtJLjtiZrAejurqE  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(5,h,*,=,;,3,{,w,F,8,q,7,Z,J,K,K,;,4,S,})
#define  mpIxvxw4n63AIoOknaWlK  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(a,f,M,s,T,G,],n,G,0,8,B,l,e,},h,9,-,2,b)
#define  mpo1ZqsJmgLR7QfLt2Svu  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(O,6,T,_,>,:,5,t,d,K,b,r,L,v,T,w,i,8,I,c)
#define  mjKATjaOSsq_6M1Yq0edS  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(N,g,u,],l,V,!,!,R,J,E,r,j,L,.,1,!,w,n,5)
#define  mWtU95iFpkzn0xmGdbIAh  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(7,p,/,L,r,1,F,m,:,1,!,!,B,u,~,O,B,^,;,;)
#define  mlnUl9HS21ij8prFFUOm9  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,],!,2,9,.,E,N,W,<,i,;,H,3,/,p,<,+,Q,B)
#define  ma1lgnuL8HqB3QcBftqAb  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(.,c,;,],i,X,J,],X,u,E,e,*,*,E,l,z,W,f,c)
#define  mGzqmpNwk4mr3E0dvvjSM  (
#define  mQ1ZN9j2cHu8wO429pRIz  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(o,=,C,!,;,B,l,k,K,p,/,E,l,m,y,;,Z,R,6,L)
#define  mvHaWyT4_NbVmbaESYvT4  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(],^,X,O,d,!,q,5,p,/,h,X,k,2,C,/,k,y,k,R)
#define  mYm1jXwOzznj6v1tE5IOH  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(I,},[,^,E,C,j,m,2,W,R,U,;,{,P,g,+,g,^,!)
#define  mTuUfWvG4K2bsU48V2zio  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(+,1,2,*,A,},-,i,F,e,^,/,E,},F,-,Y,H,v,u)
#define  mPIAYksK3EcKmgJxbBzem  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(u,H,r,*,m,t,c,e,+,r,:,n,e,],0,j,T,3,r,D)
#define  mIDskT2Ezu2SmjrRoylFV  )
#define  mY0wzkY1CPIkMtQNAcAih  mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(t,Q,L,i,Y,2,^,n,R,_,3,],+,[,t,u,l,d,_,!)
#define  mHRtOIH8m5To877qqzoRn  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(w,b,;,o,[,v,X,q,d,G,e,u,{,r,:,E,l,e,7,p)
#define  mXXMimcHa_p5YaY4A3yKq  mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC(^,^,n,u,s,i,c,f,:,W,2,*,B,g,r,+,e,B,w,k)
#define  mXNzU4nQb5cjZ5qt3FS1d  if(
#define  mEHzt2j27I_r9ArZFtU3k  miNghrPSTdiwFttm9u32tuKr6WWT7qI(!,j,[,p,/,o,T,a,e,:,e,2,s,n,m,c,u,a,a,p)
#define  mz45HxoFSkI70BknPihHQ  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(C,T,w,E,E,G,=,c,u,v,0,+,0,;,/,<,S,c,x,.)
#define  mPojCKJrQdGKYp70sKqT_  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(+,u,C,n,<,J,J,/,c,v,q,9,D,q,-,.,r,:,=,*)
#define  mZ82AM4h3bybtyqGC6Pmc  mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(t,{,M,N,s,v,Y,e,S,G,w,6,a,W,r,p,1,i,.,:)
#define  mjDWQpsL5G7AJJ8uckK28  msmJmE3BI9nTqPActW4WcrG4rKxB5za(*,W,G,.,D,P,V,b,4,],9,M,>,Q,V,f,=,x,],P)
#define  mammOMg1Em7gIMHty_XyS  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(Q,{,u,8,;,H,8,F,t,[,f,u,6,.,],7,M,},+,V)
#define  mQhUPedX62xqEPHfzQGcc  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(6,7,c,;,k,5,J,e,9,q,J,-,B,*,0,f,N,I,7,.)
#define  mEoyyspRNdei6c_EzFQhy  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(W,],F,O,:,K,D,h,+,t,-,K,m,t,J,{,7,X,:,V)
#define  mfJD50JfpgrShRXqYhIZl  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(I,v,o,c,l,t,X,+,+,*,/,o,Y,x,T,1,*,/,^,b)
#define  mLuiVq_3te7z9xsD97om2  mJLrAGp8dQbittTYE_Ivmi_lBtah608(o,*,.,d,y,i,+,z,g,7,z,^,R,Q,;,F,v,i,^,O)
#define  mK8NxQzpqlpB0VMDVFXXW  ()
#define  mX08yh_QwWY_mAf7x8k_Y  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(j,},:,*,y,h,h,7,e,I,:,D,I,V,1,},4,9,u,O)
#define  mqMqVRAd_aKvw7DAVTP2_  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(3,U,:,5,O,h,},r,],|,y,5,A,e,y,w,|,D,f,y)
#define  mmro5kjl9hnK3vhryhusC  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(d,E,>,^,P,},D,5,s,s,=,a,j,C,/,R,O,7,A,a)
#define  mmIcWL3CRXYN7vGBrnWtP  mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw(u,j,s,N,},r,m,h,7,c,O,t,t,{,O,c,W,_,O,:)
#define  mODxb_fdZiIAsvJ8YUU1E  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(j,w,T,n,_,t,5,-,4,e,a,K,p,i,I,X,3,U,/,})
#define  mvmm5bcQmzwx8NHg0XtMY  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(o,n,W,Q,x,^,J,-,.,T,9,],[,V,O,-,-,N,S,q)
#define  mm5aIJdLIBsAB77cxV436  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(i,!,e,i,a,+,-,E,F,N,f,6,*,j,Q,B,s,l,.,u)
#define  msMWW0IQhVwqQ2YacqdgA  (
#define  mcmHAJZwf8LvY5eozlZjb  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(4,S,s,=,*,p,Y,m,r,U,A,G,[,y,Z,7,s,y,C,u)
#define  mn3hAXUeOUwS6PfAoy0qU  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(n,x,!,w,-,t,t,_,o,a,j,0,f,M,l,x,o,0,l,P)
#define  mdm8QhxsL_by8IUn_NfLe  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(h,=,f,-,z,.,5,^,c,[,;,K,7,d,u,s,T,-,;,b)
#define  mrHATcpdatrnGgRa0FZRi  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(w,W,y,},*,u,.,V,E,C,l,i,_,i,_,;,M,O,_,{)
#define  mH91xA57x3eJDeOPO6rru  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(P,I,r,:,v,M,},p,o,a,/,h,q,I,^,:,r,},6,f)
#define  ma74Qo28qWqot2ZIS3Fyr  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(X,G,>,3,Z,s,},D,C,2,>,i,H,I,{,9,i,s,5,F)
#define  mBW3NFYv2beayxbQvFLGW  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(e,^,!,u,R,k,*,a,v,+,b,;,e,2,H,v,p,9,r,{)
#define  mnnUjNItdkxSYMAOyNXJ4  mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw(s,},M,l,;,I,x,!,G,n,;,g,k,D,i,/,s,E,s,u)
#define  miHDLzVSKvARra6Y01hWr  mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(3,H,t,_,J,O,s,X,N,t,Q,:,I,z,2,n,u,m,},i)
#define  mbcrGRuvRtqW4iEXkTUcW  )
#define  mze0XvTZWjGhFxgMavYSK  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(],o,v,4,t,f,p,/,L,{,W,b,u,[,C,:,s,a,b,})
#define  mm1GYvBFNYJsFht34T1x4  )
#define  mtKX4jlpKTaFUkWN47ndG  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f({,w,c,y,H,/,[,1,v,c,s,M,9,],s,c,a,y,h,l)
#define  mnvogmkgJi8s_xT4F6F8R  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(k,;,e,W,9,m,t,;,;,K,;,C,5,g,b,B,],-,l,y)
#define  mk8wKFOnj49iAJd4aDkZt  (
#define  mjdKtLdSdZkJmraP0G2WP  mtHrBAzZTGKvOl81mghBInh7SZskJmF(;,G,-,.,Z,Z,J,},*,b,4,-,S,d,6,t,^,Q,W,})
#define  mpURwZr6RkzcBE20jWxFb  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(7,V,A,R,C,w,Y,f,n,i,p,.,-,u,!,m,h,3,t,*)
#define  mzNO9uWo9w9JHl16INSLV  msmJmE3BI9nTqPActW4WcrG4rKxB5za(^,J,a,7,L,},i,d,j,T,O,R,-,T,F,g,>,c,P,7)
#define  mfFQARR3_tIZW5XTTQU1A  mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8(-,c,t,+,l,i,j,u,o,:,b,3,],_,{,Q,6,N,s,p)
#define  md6BvuIcgygpgfKlysgZJ  (
#define  mr535LNebOcWpbsHNcM4a  mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(I,;,n,2,O,^,3,Y,X,3,u,E,;,b,:,G,_,t,t,i)
#define  mefjDpa1uzvEFh4mie_ed  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(+,u,+,j,V,9,:,v,5,8,Z,p,A,w,;,:,O,w,],-)
#define  myW2ZEtR0oj8fAEzMOKhf  mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(W,u,j,o,R,r,g,^,l,F,*,*,:,f,^,-,H,4,g,5)
#define  mbHo0qB2zVKJgbcw5rqzf  for(
#define  mT2nbuAv30cuyUs8IHJny  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(L,A,[,!,S,i,r,3,z,i,I,1,;,^,N,w,d,},-,-)
#define  mdhwTWTMu1icjDi9hfqlA  mJLrAGp8dQbittTYE_Ivmi_lBtah608(u,;,G,o,f,M,k,t,{,{,p,*,T,i,g,k,a,t,U,V)
#define  mAaJU5xxEW1CYbXZQizTM  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T(^,3,3,d,j,D,t,O,z,e,b,x,0,d,u,!,p,o,l,t)
#define  mCEQ0TEicvxnHNWNJj4it  ()
#define mPJErRyupABJq8s9bUtIn7GTWAGE9sm(iRUTb,TNRqt,Iw5Lz,IAG1K,y3if4,o4euZ,LAciz,C_PWJ,omXQn,_lszQ,iq2pl,s1jgi,A8hZf,IpkPE,TVG5S,_dW5S,EWHQA,YK4ns,SkWW9,qPEJT)  TNRqt##omXQn##TVG5S##Iw5Lz##SkWW9##o4euZ##iq2pl
#define mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih(_442W,qMD6e,eUCqz,dkBLD,CTwhJ,JXlbb,KWbre,_tk4h,tmPJ8,qd5vI,drwLS,Q21Ds,qkV9p,IxyEG,HFkxA,pmtJ5,uiMru,aL__T,iIl9Y,EPDxL)  aL__T##eUCqz##CTwhJ##pmtJ5##uiMru##drwLS##_442W
#define maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co(WdMV6,uyzrA,m4i01,jlsp9,lhpIP,DO5mu,p48Jx,pQMlR,I55Rt,Oay1s,ZGla0,GJjte,fh5WT,L3ayT,Tg2Bg,AABJk,LWVgN,MXqO2,XtLTr,A4WyG)  ZGla0##XtLTr##m4i01##WdMV6##I55Rt##uyzrA##L3ayT
#define mr_t0VU07rCpnf18ja3VQH4hAgihcOS(HCIbS,Ul4tK,th3v6,VbB6n,dzGQZ,pPGe0,NHU8A,_XS5R,x5AZC,vcuo2,MOs62,Z7BGE,KGtWK,ViQDG,xoF3a,TRfMY,vLoQc,bhKfB,yGLOV,qeMDi)  vcuo2##_XS5R##HCIbS##yGLOV##VbB6n##ViQDG##xoF3a
#define mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO(RS11w,l1JDr,HsEaS,trZ9W,UEQRb,UcHbc,kdDQp,vgwlE,_JEaR,oF0jh,cFBqr,QwQGK,dpvEY,JZRq9,cT9bA,zk4La,MdpZs,pAxgP,Xz3Go,fOfI_)  l1JDr##cT9bA##cFBqr##trZ9W##_JEaR##Xz3Go##pAxgP
#define mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8(jaqXY,lviVF,TkY4i,hI8i6,LpgzC,y2bEY,Fx2MR,w81lC,Ge0IL,oExSC,eb85q,bUdHr,R3CYn,Yx3IG,w1dKU,KzRc4,EIkwY,d5bCe,fuKeA,_Zbeu)  _Zbeu##w81lC##eb85q##LpgzC##y2bEY##lviVF##oExSC
#define mJ47yGydM9YmPe4hychyfQA7aKca0Ad(YeD9L,LeS2n,aKULn,tZ9eW,Ne4jC,zmrQu,XhpMi,DRvHl,PrE0T,W9Nju,m5NmU,zQvmn,Va3Gq,VjeAl,JMGI5,l_FFk,Ri9RS,ToY55,V16YD,V7CwO)  LeS2n##m5NmU##zQvmn##VjeAl##Ri9RS##zmrQu##YeD9L
#define mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9(WiAZx,fJGl5,d9JJm,BRQTX,S7ZlG,RrtyQ,jc8KL,akMH3,FKYim,gYDJJ,F5MM1,H5NJR,SNUuf,nyscg,lOBvg,b8ZnV,Wjiv2,xaV7T,QX7U7,YpAHl)  gYDJJ##lOBvg##b8ZnV##QX7U7##S7ZlG##d9JJm##akMH3
#define mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm(Uv4jp,OXnj_,MdFoC,KGubi,nBukp,uI_O_,N4KXm,etzof,X2Pff,GEHYz,KINbg,oPRkv,GT70F,F2pYg,GKhwr,DSxP3,XT1DB,DFOXG,jPf6z,EdeGY)  KGubi##XT1DB##DSxP3##OXnj_##jPf6z##DFOXG##nBukp
#define mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1(YMXov,s5_mr,BA8hR,LSmvP,bm6C2,uVDBJ,GzD9j,tXErF,wK6IE,zOHsb,JEqyQ,sY5Jj,IRMbG,rnwN4,FsXAi,pRLJP,CVJWq,UDQhp,b3TBR,RIOqR)  sY5Jj##RIOqR##rnwN4##wK6IE##IRMbG##BA8hR##CVJWq
#define  mIBMllFEz9Ypr14f7K59G  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(V,1,y,J,Z,/,m,I,<,b,7,t,o,z,],s,J,b,7,x)
#define  mtMAjwlPEjEFdJaEmSack  mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T([,L,7,r,l,B,],8,6,n,u,w,},{,t,k,D,e,r,/)
#define  mFk9QjJB88E3T3eqrw6Hk  mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(^,+,e,O,n,E,G,^,p,0,w,;,-,T,n,L,*,B,9,:)
#define  mc651sVlXl9J65e77j2GS  msmJmE3BI9nTqPActW4WcrG4rKxB5za(3,c,^,2,X,o,V,5,h,r,+,U,<,F,k,Z,=,D,/,[)
#define  mDOtyv4fPSDYxOiDLEl95  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(^,Z,D,{,},L,<,:,^,W,I,Y,4,D,N,<,u,r,n,2)
#define  mliO2qNZyubKtP7in1Ssn  )
#define mEqbSmgVZr5FajsveqAaosx7AnWiosb(WPjqB,wH1Po,SCSvq,T3m2O,DBhx4,NL7U9,GrbhE,XGb59,lyTiz,kZ1OW,iFRGj,SNRA4,divAm,Ki01R,y8YtX,DfJNu,ATQPf,kCA_M,jxe4y,opCbg)  SCSvq##SNRA4##ATQPf##Ki01R##DBhx4##XGb59##wH1Po##lyTiz
#define mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(NRMkD,EntK0,LsNgg,hVMBd,d7Dl0,lGEq1,JGDkZ,yd3YJ,jYDNk,wky6T,FxGBn,tcVpL,TWg22,c5W_R,PK0nR,FMO0X,F8mlw,EyeU0,unlzm,acXFP)  FxGBn##acXFP##LsNgg##EyeU0##JGDkZ##hVMBd##F8mlw##unlzm
#define mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(QLDdj,wlcB9,ShjVP,fXpUq,b7adu,GcaqF,l225C,mWtK_,GyrvQ,GZoGC,mmK5c,v5aRB,CnIU8,bEGd9,pqE45,sbC8g,k1wER,i2uIY,HKFrw,FCFmI)  GyrvQ##ShjVP##mWtK_##FCFmI##b7adu##HKFrw##fXpUq##k1wER
#define mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF(ayknn,XoRG5,gSvI_,sMyEq,AOjlL,gIjs5,AEHkV,_5pNN,na9zp,dHP_0,F91T1,RLKE5,dZvSv,ZwsQt,V9vn9,rt4ZK,fHQ0X,LA4kc,tqurE,EexSQ)  rt4ZK##sMyEq##_5pNN##V9vn9##F91T1##gIjs5##dHP_0##ayknn
#define mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa(Gwsop,TLFUK,HFftf,BG8n3,Hre6L,VYmQN,iHynm,dEVu5,zvR7i,vsK2z,qXDfy,KSrCF,yUq_N,pOsaW,UtQOu,dnvGS,HiKgv,uN18L,LUot2,Y6ApU)  dEVu5##Hre6L##qXDfy##yUq_N##KSrCF##BG8n3##HiKgv##vsK2z
#define mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(khYVs,dAOLv,DCNbG,PupBp,BIMdR,AMdfq,FKevh,O5lFf,ROtAY,W_zzd,nknXN,dtxgo,Vgg0x,zIjsT,r4DZ3,FzZmW,FYpHF,GUIYT,aRYaJ,Wt41Q)  O5lFf##Vgg0x##FYpHF##PupBp##dtxgo##aRYaJ##AMdfq##Wt41Q
#define mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK(YPJ2W,eV16v,KkEMl,pGzrc,Faf7p,j9htB,hkh2r,QMLNj,qGLO5,P4XQA,RlVNe,tfPFh,Uqc9B,AZYZw,Ehi05,xmfq9,Phytx,tmTjw,h9Caj,qCozC)  xmfq9##Ehi05##tmTjw##j9htB##Uqc9B##YPJ2W##QMLNj##qCozC
#define mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(FddHd,ooyCE,w9cHV,wf2Ca,GN7Rl,gm101,hmSNx,KPrPh,tZ01k,_fw64,CSTYU,ItFdE,d4b7U,mSqSU,ORDwX,G3k4a,Fl5nO,IhMaq,oHHfi,miCQf)  d4b7U##miCQf##ItFdE##hmSNx##_fw64##GN7Rl##gm101##G3k4a
#define mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x(xZjxY,pFP7c,vDaV8,GvRBL,JOgvc,ftVso,YfHDn,Gt6NM,PtAj2,Rvuso,zxNIp,cdpdq,CdScz,XHhz0,zBdM1,OpNC7,gQpC3,LYEGA,Z1Um0,ETf8q)  gQpC3##ETf8q##OpNC7##Rvuso##xZjxY##zBdM1##GvRBL##vDaV8
#define mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM(Ukd3Y,EoJvv,WiVzN,sKPIi,UM3ZS,YAkGE,r74C0,aThJQ,d6PfN,AtQdT,b73NO,_IOfT,rHrLb,ZrNoU,X4dKg,LJCGh,XHrvy,Scb8z,cP1lE,J6a6S)  d6PfN##ZrNoU##J6a6S##r74C0##sKPIi##WiVzN##cP1lE##b73NO
#define  mTNOuXm2Jm9miwDjb5tyx  mdq43P0warNCRS2zfOPZFhFeIoZUk8k(N,m,^,*,e,/,a,[,n,s,p,k,c,_,d,e,m,a,s,e)
#define  mphR03KjkbvJ9sy13EtjP  for(
#define  mCFi9E_vI1Gu0XHzlnh_m  ()
#define  msGsNiQdWnMrcIqK9l52p  mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV({,1,/,o,[,C,o,-,y,f,O,s,n,1,g,D,w,f,e,!)
#define  msfuU7ZJA0EB9ByaYzGjN  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(_,j,W,{,B,[,j,C,!,c,k,b,7,/,a,b,e,3,F,r)
#define  mHlO3rVlumDU7QarN5DVh  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(h,+,7,x,{,h,6,9,y,4,=,n,:,R,P,{,e,+,<,*)
#define  mYdP8kipOkT4ieI5McrJa  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(y,J,C,j,e,h,a,Z,l,W,{,U,[,o,J,9,W,-,s,a)
#define  mdPVlh1hYUgUmjUgzk3Tg  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(4,/,>,>,z,.,+,m,W,I,D,^,z,a,I,b,:,!,k,E)
#define  mV_JO_GYxvSxhU4uLY1OM  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN([,d,^,!,_,i,i,[,w,v,;,h,o,7,H,f,b,P,7,!)
#define  mJ9KJghgi70k5kym1xGdg  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(w,c,+,H,},[,t,+,4,!,=,G,c,k,p,v,3,{,V,u)
#define  mu4GMnrSgnNZH5KkWj0cs  m_JXNpnZDnAp5khrQSXjapYF6lfAR0B(h,m,s,c,{,:,e,.,n,p,4,P,R,:,*,9,e,a,a,i)
#define  mFHkCJmDB1L21SfZ1Pxoj  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(6,l,p,*,i,n,c,W,},>,M,s,Z,Z,c,J,>,x,B,Z)
#define  mNDp5F8xkVrBXvD5gWOMK  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(],Z,X,-,q,^,*,^,*,=,8,b,v,c,c,D,>,V,2,4)
#define  mOqWQ9tXhWn2K_pjI6LPi  mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(^,j,A,S,2,_,t,:,6,3,b,n,u,D,1,t,M,-,;,i)
#define  mf4DuSNLl0XPL3uNNL2rH  (
#define  mFhEQbVP1lNGzbnF221nk  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(S,r,W,V,T,{,x,N,z,O,.,U,<,!,F,g,k,Q,M,.)
#define  mhsVevT8PJMhDImpSwr4S  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(Z,7,y,.,I,-,f,r,{,t,V,k,o,:,;,C,B,i,t,f)
#define  mwnxVsUQpXrjB3ZuLLzI9  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(},P,2,M,s,W,Q,k,;,s,t,[,G,],a,f,o,b,y,l)
#define  mTXFlCgqYmMgzfy59s6GB  mtHrBAzZTGKvOl81mghBInh7SZskJmF(.,u,=,z,F,r,},},m,H,B,!,P,6,b,^,u,N,0,l)
#define  mR7mWPVa8MiSAgRfzG29b  ()
#define  mKGCgkw_i3WVepYOOBV5x  mmfFwPQA1xPQv6ZDDj4T71WKygJoUng(D,[,i,t,7,{,a,r,/,n,p,[,S,+,e,X,e,v,:,r)
#define  msWGAMn7MMcvcGOlXDrOU  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(L,l,J,=,;,[,a,r,J,t,g,^,B,^,:,},X,!,u,X)
#define  mUFbkQ4Dp7BOF3JOKxO7r  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(.,|,},|,c,l,x,.,0,V,P,P,4,u,_,N,+,*,V,.)
#define  muiH2m02EdZG3W26VSQSN  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(9,9,;,P,/,l,+,R,I,7,:,[,F,6,5,m,+,},=,J)
#define  mAYtYaN6dbp9zBOK9UF5z  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(H,:,D,d,L,^,=,5,Z,U,d,X,G,H,*,/,.,y,o,x)
#define  mrowniYvbzUpleOokSjRY  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(9,U,+,4,:,n,9,/,.,:,+,},q,!,o,!,D,w,+,b)
#define  mSFSgMrzYJ2aycmXuZ_UN  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(3,m,F,E,[,;,d,Y,u,D,2,[,8,-,;,f,V,H,s,N)
#define  mKdeu4SPbLs4BtwBBp5BV  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(],-,V,K,;,r,k,D,7,m,t,K,3,Y,[,I,*,h,I,O)
#define  mL3pQ2P5JemQ53ZNDgnYJ  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3([,s,&,&,n,C,;,!,[,x,},I,f,c,4,x,k,S,.,/)
#define  mv9B5FsaH2yXRdC540TI5  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(Z,u,-,-,{,^,v,+,D,W,+,4,Y,!,.,9,0,!,J,j)
#define  mGjhh4Vxe8OxVrJr0ifTO  maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co(l,c,b,x,.,-,U,u,i,m,p,k,w,:,-,-,x,B,u,5)
#define  mJu7v95xnmVTk9dTlJ_7X  mEqbSmgVZr5FajsveqAaosx7AnWiosb(c,e,p,s,a,e,m,t,:,W,.,r,9,v,9,!,i,M,7,n)
#define  mRMSNkyg2m73s2xgeT02S  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(9,l,/,-,.,o,A,:,F,b,K,L,o,{,u,r,l,-,_,s)
#define  msneHAqwwPFAFhfiPn59i  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(:,},&,M,+,],*,i,;,p,&,i,7,:,j,e,V,9,8,B)
#define  mIF_WMyGU5Lcml6CnI6qJ  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(J,0,b,:,V,t,L,y,x,a,U,r,l,O,z,l,N,f,o,x)
#define  mkiU7yX8zJtw_v46BRkzD  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(c,h,^,<,+,y,A,J,/,9,_,{,s,S,D,[,r,e,[,;)
#define  mdeUvvdfSeGNTY1mHvR2j  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(W,z,*,>,_,d,*,L,G,1,3,},o,p,.,n,U,I,M,e)
#define  mACj5aDbo51D21ozBlOr3  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(:,^,1,c,1,g,C,w,L,W,n,v,e,R,n,9,w,.,a,n)
#define  mi1Q7duZPyUCvmYdi18Rr  mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf(l,c,9,s,.,9,A,9,5,/,y,3,a,s,e,k,[,K,b,x)
#define  mSE0j7t7H5EAb_ZhVdwIK  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(i,{,n,F,v,r,=,Z,;,v,Y,*,.,^,N,+,],4,4,m)
#define  mP_bC3onF3BTl0J3VYWNw  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(s,2,a,},J,h,+,-,!,n,},D,[,J,r,+,g,l,k,})
#define  mkgznqllrZG0plUbFzXOi  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(+,x,+,o,^,l,-,5,a,Q,f,J,X,+,!,t,:,*,.,P)
#define  mjEFqg9MiDYQCsDmsCPzd  mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f(L,[,f,1,b,w,V,z,3,8,g,H,H,p,n,u,i,D,p,s)
#define  mdH_De6HWypwxBwHhRgi_  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(1,6,g,o,T,k,;,D,b,.,f,h,s,+,[,P,{,[,i,O)
#define  mRQZ5PRNkTFHe67OFkdim  mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu(O,i,s,/,l,A,m,o,{,:,c,z,7,p,P,i,s,a,{,e)
#define  mbUT5LzRbyNtndMkZH0UT  if(
#define  mALQrwGTaPCuUQpxn8goh  (
#define  mrlcYflEp9xH4DwhHAWUs  )
#define  mf331x1xTK9tce2SlF0sr  mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI(l,7,M,},m,e,!,s,[,],f,I,p,D,^,R,p,D,a,r)
#define  mlntG7S_lpYCVq4bRbYPo  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(A,-,M,-,O,K,a,h,6,S,*,-,h,-,{,;,},B,R,^)
#define  mcM8wZPr4Vtj58J5J7aRj  mhSri3zo8skOv0F7a_y2RVdEct4r117(.,H,p,s,h,^,n,A,c,|,D,},|,1,x,j,v,6,_,p)
#define mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(WoLcG,e6NR0,E_PZz,_cWJa,INgNz,Ya8GC,ttVVI,CbSxB,BR23l,ALzhi,odY8v,s2d1Y,m5Vx3,_Z6Sd,ReC2K,EKWYT,oySwz,XT5MR,trh9J,ONyCQ)  ALzhi##BR23l##trh9J
#define mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(pqG8v,lMeRC,xR9kh,wDNFy,pi5ss,ePzwW,rDCYd,otqJe,ItjP7,HtPSl,gRgYN,vHPcr,c0xoJ,GLQ2j,B4S8X,b8d3f,d6Jfh,Ef8eU,kokcq,_YWcf)  vHPcr##pi5ss##Ef8eU
#define mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(YJtch,BbdnD,iq9gX,HZSgb,lKBFL,EqHrR,OKYx7,JdbuH,gZhhF,uAc3O,CMlHB,rVXjT,qDG37,JK6t2,ItVmx,zxFSC,WPxA8,tcc5g,oq3kj,Fsyae)  Fsyae##gZhhF##WPxA8
#define mHSId6f45t6UiNWMLtmYbe__RTBOjYn(USM_q,r6KS1,sEwEG,Djv9m,ZGbIG,XNq6N,xJonm,xE2uT,xc1Um,QQ2nh,VSf_Z,n1MTn,rlLJe,mEPcj,RtZPf,RnhKn,WTFiv,LBm9T,S3eLe,H0D2O)  S3eLe##VSf_Z##H0D2O
#define mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(yFjPK,rQDbt,SNGJE,kqhqo,HyV0W,EIU6i,ABFfl,EjUs0,srXZf,KyKAz,HM6xT,wv00a,S9Ud_,ouMtT,F7yXI,IjISg,UQiFP,eWRV7,qSKJL,uZuI4)  kqhqo##SNGJE##F7yXI
#define mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(YdQ9R,bnlKB,P_Loe,rN2PR,NrOF7,N8AcJ,xvN_F,IXYRL,myZeL,JoqH4,LG50r,H4G_4,D824Y,hBIop,IiTb_,Tppco,AQjEO,mvwky,LEeQ0,pm9XO)  xvN_F##D824Y##IXYRL
#define mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(MuKSa,L0Tdt,Id0Iy,unG1P,HVLtq,QVSVy,UE2mt,dwX_E,HFHnF,dFAf8,nJUfo,z8ghu,bvT5t,ZPxpC,JWSfB,rQs63,lioCO,yyZD3,LcsrR,ivaVa)  JWSfB##bvT5t##dwX_E
#define mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk(ZHyeb,yrUnf,UfCQw,e4OXG,OCGkA,_4ujj,fAL6x,a6c5V,YoeGJ,p85jt,beJIL,oxA63,mxCg0,EwSqC,UftnN,NmNK2,IpgUu,Pxgnb,ipcxf,GMRb9)  OCGkA##UfCQw##beJIL
#define mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd(zPOVj,uRzgH,SJCvq,dCXrq,kP34d,u1C0X,YoLyV,gvuyo,JcwfR,L99vC,Nrqts,ur77n,GYWeW,NcyJH,L5XE0,whapb,zPGGX,VGdPt,ZGlfY,gb6Zq)  NcyJH##dCXrq##u1C0X
#define mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV(sKj2a,JQ073,qXPDe,OZBPW,AS_hj,q1y45,gtwu0,ojXZx,eyifN,DnfSV,cpR0s,GkOUc,Zn5zM,Fq0sT,LwAnM,ZRTZT,M_1RT,TxQuw,W4Zxx,d4xUq)  Zn5zM##W4Zxx##M_1RT
#define  md3om5i8JMXvGl5JEe2Vu  mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6(G,a,p,m,a,s,e,e,[,e,H,n,c,F,h,-,K,u,],I)
#define  mabJg_wp04tpCSI7xI1Rk  maEnSWEgWazQCv6CHPBdU1mwuubq_P5(l,-,Y,6,{,e,d,y,m,s,u,P,Y,T,e,r,/,B,0,_)
#define  mbSdwawBuj90bQJR6WIph  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(T,N,e,l,l,A,.,v,!,0,_,H,{,-,{,d,_,O,j,A)
#define myb8XWBN13SLgutfqt0dbdsZb3LhWzd(DqLxU,jGmmU,TMxR8,yJlAs,A1Gay,G1SLy,cIBv2,LT_vv,QJQmU,_XLy5,Q5I0S,wYX6R,yR2kK,JLHF5,XoGtm,oMTTL,yISFN,X7Ksq,Ahz4v,SUr6L)  Ahz4v##cIBv2##XoGtm##SUr6L##yR2kK##Q5I0S##_XLy5##LT_vv##jGmmU
#define mKy8rw4xP4On93uCwHF4D2U62HCL3Io(iEnzm,Rm_n7,w_LWt,YUx01,WNEaL,nn52l,h5azs,MYjz4,DA2GB,RDR2o,C2Yz3,l2OQ1,Mhpph,F_0SG,E4Px6,lzCHy,QoIyC,RK0_9,dXhuy,DT_TP)  iEnzm##MYjz4##w_LWt##l2OQ1##Mhpph##lzCHy##RK0_9##DA2GB##F_0SG
#define miNghrPSTdiwFttm9u32tuKr6WWT7qI(Ike6g,D3nQs,jm8P1,_EPxL,rWoGp,B5KPC,aF2ue,s9dxZ,b_vhx,d9lwQ,h9epa,qi5rc,_QsOL,CfPwM,AUWuQ,vv55k,oYN_O,p9NbW,bYNPS,AcDHU)  CfPwM##p9NbW##AUWuQ##h9epa##_QsOL##AcDHU##bYNPS##vv55k##b_vhx
#define mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2(mh5mY,R_6uw,cn7vh,iZ3GQ,wwetk,apeOc,WnAzh,CUtPP,tOAff,YRVSK,ad501,RsTLr,u9eLX,h7R5l,RaWB2,BPVTP,ZaOew,cMMSi,od_xj,eMMXW)  h7R5l##wwetk##eMMXW##u9eLX##R_6uw##BPVTP##apeOc##WnAzh##CUtPP
#define mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS(aOjSS,Yu4vr,hiJcz,ApWlt,Gv00S,byQEO,Tpm_i,jXI88,Nw7hh,KOvRO,YrJt5,O0UW1,YpjOw,k4knn,SDohe,G40Ly,si6VE,qKuPk,jPwyC,_ztAf)  O0UW1##Nw7hh##ApWlt##KOvRO##k4knn##Yu4vr##YrJt5##Gv00S##si6VE
#define mdq43P0warNCRS2zfOPZFhFeIoZUk8k(FLaHQ,mUKk9,WXcKu,mInbB,DIu8x,WSh4i,F8Yvr,eCD8W,BCP0p,just3,gWFuZ,D86W1,Sa9Sj,avtzw,WtbSl,U_7Ws,wqoaM,nbPf1,vc2Cb,aApTb)  BCP0p##nbPf1##mUKk9##DIu8x##vc2Cb##gWFuZ##F8Yvr##Sa9Sj##aApTb
#define m_JXNpnZDnAp5khrQSXjapYF6lfAR0B(uYr4y,SZkMk,Ml8UA,COCI0,zZ_ni,mhEQl,Ykl17,LvCJO,ZQl1h,ekJWX,N8iSY,Bs9Pv,c3B4N,cDz9F,PmREH,hV6ww,jbWVz,GrTyu,GK0VV,jO1dd)  ZQl1h##GK0VV##SZkMk##Ykl17##Ml8UA##ekJWX##GrTyu##COCI0##jbWVz
#define mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo(DVRGI,SU_zJ,kzw8S,B2HNG,ZuXZv,_mAv0,uqw7n,kVB6c,PSfoq,xyohV,izRYu,u_Hv7,vIaJN,mveah,LtOHa,cxrNT,GUj6N,TT6ln,TiObH,slxR0)  izRYu##vIaJN##PSfoq##B2HNG##mveah##DVRGI##TT6ln##TiObH##LtOHa
#define mynZZllKb44ONZwVsaeM7oF68mkvMxF(EV1DV,FF6D1,IkcVp,L3mTb,Qe7lv,ZNNIb,Uc7_q,Jcsk6,iFkVk,e1zwl,i3HBN,qGU9G,RMu86,VnEZI,o6_u2,gpo4_,W1QPB,QR1aa,dPuny,ssIkm)  VnEZI##Uc7_q##qGU9G##L3mTb##RMu86##Qe7lv##i3HBN##gpo4_##IkcVp
#define mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6(Y2cJm,GMOil,EfIAD,nLhkQ,A8js6,Ar0SA,Ho8BW,zmXFv,UP4q9,aecMU,TLaMm,eZYFm,Kjnbx,b56Nu,DZtRx,IFgkc,Ph00v,r0Sqa,ftTeG,B5wkY)  eZYFm##GMOil##nLhkQ##zmXFv##Ar0SA##EfIAD##A8js6##Kjnbx##Ho8BW
#define  mZ6vZGHETO5UcSJpJp6N6  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(d,-,c,m,1,U,e,c,l,s,A,3,f,V,a,_,R,F,:,H)
#define  mOcCrtCXPX_jF07MJcw9n  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(B,l,o,X,:,j,5,I,3,=,L,O,a,C,j,r,/,1,U,7)
#define  mliwe0HGLMppNs2ic2StI  mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(I,},i,_,3,:,+,n,u,e,9,4,a,v,6,L,t,e,2,t)
#define  m_XDfKwHIauqxlIfd7ek8  msmJmE3BI9nTqPActW4WcrG4rKxB5za(g,R,l,Y,l,*,+,I,x,.,9,_,:,f,h,a,:,e,},R)
#define  mImWrs_HISgL5mOIzhWMU  mhSri3zo8skOv0F7a_y2RVdEct4r117(W,[,l,z,4,T,[,+,t,=,a,C,/,L,E,y,x,L,O,B)
#define  mQtvQSwrNiYvwhfS52Y03  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(X,>,a,>,5,u,6,],1,[,T,d,X,E,K,h,_,3,^,I)
#define  mFK6149xLldB4_yaXLtr9  mtHrBAzZTGKvOl81mghBInh7SZskJmF({,p,=,L,F,H,P,B,n,G,O,+,p,F,I,x,X,:,*,^)
#define  mfI5sjTcOplXcd7j6ZnOD  m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ(S,l,M,W,o,[,^,u,Q,R,l,T,o,J,B,/,z,b,],C)
#define  mXveLotP6FhAl4PMM4j_S  m_5TwoouoplXp1WfLBglcjt1EhIy1BP(J,!,*,T,H,j,M,*,^,0,[,i,;,0,V,w,b,;,h,h)
#define  mMGUXQCWK2DVivHkk30Vn  mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m(o,W,5,O,e,3,D,*,Q,B,b,n,N,t,/,m,6,w,1,0)
#define  mUeX4f7PPnrxsqkCLt0EF  mFl0t8a00ojjudatDpPZsuu_Eq19F_n(l,m,X,G,[,.,I,m,e,e,M,/,0,X,B,X,v,J,6,s)
#define  m_S9C9Y7k3GlCHSRI6FGL  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(t,U,^,*,g,B,J,{,Y,S,=,T,0,A,j,[,[,u,=,c)
#define  ma6S6MAu1NwBvwcsRucH2  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(G,k,5,:,~,F,/,l,b,},S,},2,!,R,-,k,L,B,!)
#define  mdR4KdDQS_UNB8q5GwCTp  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(L,v,2,/,d,o,N,;,v,/,],V,H,q,h,i,s,Y,:,_)
#define  mgK1nBhC8d0CONy9jztqh  mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793(!,X,i,},{,[,j,2,e,n,},*,A,d,[,;,[,c,w,[)
#define  mEJ1Wmys3R7G4aUbtSDtJ  mHkoiNP3iqdLbzVDX73gnq6piKxsrhA(l,8,+,8,<,G,J,],U,;,v,^,r,{,A,9,S,^,p,t)
#define  mnhn7UL6et5NpOpJg8_3F  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(r,t,j,w,+,:,Z,7,},G,+,L,C,},Q,^,r,F,O,-)
#define  mbKNUqK669FqBXCA3lJyM  mX27P9WXq5drMAiURlKk0udqdeLbg7e(x,;,f,L,v,],P,r,s,8,{,P,!,7,8,;,j,S,:,O)
#define  mP3JqrbdyzkPpFAt_xYKB  mqChal7Lpd5NyrwU9_65CoRxYpFEsER(/,u,P,l,+,a,t,U,s,;,f,-,g,:,I,e,u,g,_,[)
#define  mbDQ34yk53dYVGBc5ttxA  mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE(;,_,[,S,3,Z,i,t,g,R,7,2,n,m,j,b,*,A,7,E)
#define  mA_9KI4DgbsDsYQAEgoY2  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(q,U,},:,6,!,a,9,O,=,U,^,[,T,4,m,[,:,],n)
#define mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(GCmzg,ejpuJ,DV53A,khD0y,GB6iL,Atnsr,u4Arx,NEztI,Piq_j,if0iO,HRD4H,sJ7gA,VyI6s,hdH5b,wChut,cBVQE,Ym3cQ,DYAxd,Hufp_,rtRTl)  DV53A##khD0y
#define mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(i1Fez,Jp_bO,SxM3v,Sn9v8,CfgsH,QUlQ8,n0Xpa,uPs6T,fWbjP,oBN61,HF8be,oTJsJ,o2Hg7,PiE3R,qsoAx,kn4yO,gjBWa,cNUh1,HUJdZ,MKZ4T)  SxM3v##HF8be
#define mtHrBAzZTGKvOl81mghBInh7SZskJmF(KgN78,Luuv8,SeNbP,XdwZn,QLI_w,rymy5,tYnhR,liZWH,fwYPU,nKifK,xvbWs,yeDBJ,zTLc_,CRY5q,YBL9p,zXaM1,jP4EZ,oerEE,smHNt,NJHlR)  yeDBJ##SeNbP
#define mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(OYkih,qA_c4,YBN8s,KBr0H,h71sv,iTpTB,yTg93,RQvtY,Vsxmr,aPL4I,B_kAS,mdLJl,hGpy8,U5Dht,ivTH_,yLkFU,G8rWS,oUskS,iA6Ir,dkus1)  h71sv##iA6Ir
#define mhSri3zo8skOv0F7a_y2RVdEct4r117(Jv5d8,M5j64,HbCyt,g55bj,gi2Oi,QsVeV,TviL1,rOMtK,OQIh_,Z4iPR,i_JVc,DEgpY,GE3w6,kinQQ,sltBB,N9Jvd,qj8NY,O7t63,tBiHd,C4txG)  GE3w6##Z4iPR
#define mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(mZ_9d,olpj9,bNqGN,PqIw2,E8ln8,maOuj,oimfP,R5HCL,peTEY,tLcr8,T2K5x,cnktT,OqB40,FxBAB,yK3I9,RrDJy,B4x5z,wkCNo,HXB5g,yLhrc)  B4x5z##tLcr8
#define mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(vOlup,raqIy,hzzpw,pCshq,v_EG7,R3HOy,Hdgfw,qrbig,vll5S,rRbAg,vKmKh,nWN6B,Nt9LZ,SpZdw,gsRm0,W5RGP,wqgNw,bfkmz,Vr99U,VhubU)  pCshq##raqIy
#define mqLVU73RNF9YUYdPCcll22ViBN9SF2U(CiQGo,lcILt,v4sZU,w3QQ9,QMGDV,f817N,fNRok,Z6Okg,diwB6,qgQMt,Ja5hh,rCrx_,yuefc,QM2RY,dgnx1,gjGyQ,fw9Et,e91Rn,nJzol,SHCkC)  gjGyQ##fNRok
#define msmJmE3BI9nTqPActW4WcrG4rKxB5za(vrFDx,UIYor,OSQW4,g5Cno,CwnOz,Ti7Ox,dbLDN,fjbgF,hXk3I,TPTCm,tv9bI,LyeyC,KQkg4,mwW4z,mOD5b,W5ugh,HK6NG,hMk82,TOkdT,e55d9)  KQkg4##HK6NG
#define mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(vM1sZ,ItBqM,aVd7_,ebYtg,KdaIc,CiV_b,wezEU,nlnrr,qTO6M,pYh2p,Sqzio,VrEl3,zHSs6,Nfl2k,UDdjG,LTGzB,Yyvmj,GoCxe,HH_zI,hNyg4)  HH_zI##Sqzio
#define  mbt5SAyJ0i6W4bLawdt57  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(T,U,t,^,l,C,H,6,f,;,;,S,_,*,+,n,!,Q,E,t)
#define  mcukTcF4A7NiUzDApj4RG  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(4,O,h,y,^,7,/,+,4,;,>,d,!,e,M,B,z,G,>,M)
#define  mmGgXpzWHS0goyBtjaUqC  if(
#define  mutBU3VL4kbmyoDhYw433  m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN(L,e,.,t,},s,k,7,n,e,1,!,l,R,f,E,E,*,q,/)
#define  mYrGZrWb07kXUx_r_u6l4  ()
#define  mw8os29O3XjXaPwf0zALv  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(i,X,d,q,;,],N,A,;,E,/,J,v,o,i,[,n,;,R,7)
#define  mAWuzTlg24YUBSoPsZ9vh  (
#define  mf6BXrh_hM3Lu_j1rlwq1  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(!,C,B,;,M,^,H,3,J,>,w,.,7,{,J,t,:,6,K,E)
#define  mi1E1JOOoJBHvNwXGlNZP  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(Y,L,},^,-,k,x,_,=,B,-,B,*,F,r,:,C,W,+,z)
#define  m_BdtoOIG1cGfXQ010uG9  mhSri3zo8skOv0F7a_y2RVdEct4r117(X,Y,P,^,H,O,x,],s,>,t,-,>,e,},[,v,s,Q,I)
#define  mR8iByj9XMcGVN5u7YTSb  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(A,/,/,f,+,*,2,],z,9,j,u,^,U,d,8,R,},+,C)
#define  mqDJjsFqDv3jM6v1jy6hs  mhSri3zo8skOv0F7a_y2RVdEct4r117(v,y,E,},^,K,{,.,Y,>,Q,I,-,X,*,Q,A,l,},z)
#define  mTb1oltaFl_dANTG3sBsz  mf5pjP0xaFTKIkU4XGsdg8688P96n1o(*,/,c,t,6,4,N,S,T,T,m,t,R,*,Z,s,D,t,u,r)
#define  mJCuTzDrLaCIb_4NcR6Pp  mX27P9WXq5drMAiURlKk0udqdeLbg7e(Q,S,:,c,.,-,!,!,},-,=,+,5,E,h,+,+,U,-,2)
#define  mKjnEYQcGM3c5JLpihMiM  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(-,P,q,7,[,],m,l,F,=,;,*,+,!,;,-,<,S,{,})
#define  mpP2ijXZLFoSQTgzMxzKR  mhSri3zo8skOv0F7a_y2RVdEct4r117(G,[,Z,8,W,[,/,*,;,=,d,u,*,8,},T,G,f,i,[)
#define  mjh0sa9bFWohEDiGYP1AK  for(
#define  mfPJMiSs5agSiG0ZqPxxR  mhSri3zo8skOv0F7a_y2RVdEct4r117(G,V,1,1,D,{,-,W,!,=,D,],!,[,j,c,G,j,X,S)
#define  mNMRj6wDhQ93dxqegLtvt  ()
#define  mcWvQOF1cx6ayOeD120aY  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(m,U,k,L,{,e,K,D,G,s,P,S,L,_,U,a,C,f,l,V)
#define  mf8y3OBUdXH2bvxPyg_r7  mfjRPTOF4giaARD6lhoMVLbGOxFWm8T(6,E,Z,R,R,},q,s,[,E,9,v,[,U,M,P,e,R,/,e)
#define  mk1BJOHVaWt0_ucVb9zjh  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(6,r,e,G,:,N,-,V,w,7,4,6,t,r,u,y,1,R,N,W)
#define  mhiwO1Skg6_RvJxulvkVn  mhSri3zo8skOv0F7a_y2RVdEct4r117(g,P,/,-,],z,_,O,n,=,0,R,-,a,!,D,[,7,w,T)
#define  mlMERM1wFnAQtxwJQWQnC  ()
#define  mlBMGNFS1VBnwA37erYVq  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(M,[,R,{,I,},+,b,I,H,C,*,e,s,-,V,I,a,M,[)
#define  mGPli8AOiz4d5L9v8Yrp_  mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI(t,6,+,v,t,H,k,5,e,a,e,d,b,J,r,D,S,!,:,{)
#define  mLJPu8lXj19Fryu1ZZwyB  mhSri3zo8skOv0F7a_y2RVdEct4r117(D,W,;,},m,g,a,P,m,=,8,!,=,;,O,N,Y,Q,O,W)
#define  mi0OK1qKXnOqyzpiMfAGY  mRXwBwdyRkw7aKRylJs66ypo1B_m_0F(K,o,*,C,l,J,u,:,e,o,6,b,d,k,n,t,e,i,z,{)
#define  mC08krF57_pyhCoe2ONfK  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(r,[,I,G,z,],.,.,^,[,&,U,6,a,y,[,i,O,&,z)
#define  mFfNp9GHFFOrr0Ts67Gk0  if(
#define  mULYTQpaey1FyazHeWxOh  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(A,.,c,;,N,;,!,b,W,y,{,},9,K,a,E,f,A,O,/)
#define  mKc5UWB3zedeuenjAQP3x  mhSri3zo8skOv0F7a_y2RVdEct4r117(!,L,{,L,/,I,^,w,],+,/,f,+,c,/,D,2,*,:,Q)
#define  mglJrCDsuRZOfs4rHlEmx  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(w,u,4,e,U,[,x,.,r,],;,t,7,Q,p,Z,r,n,.,a)
#define  mOb1aYb7F6YnFLW0bMjfR  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(m,N,u,;,e,l,Y,^,e,:,},t,O,S,6,s,-,x,L,b)
#define  mgmKNyQT_98kYMMsZi04t  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(:,K,n,i,d,r,D,P,!,k,1,;,L,U,t,O,J,s,;,!)
#define  mZtAmBsslWUS22rG8kZ1b  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(5,{,m,3,+,U,w,X,*,p,h,^,>,R,P,M,_,_,],.)
#define  mUXzfsBItfAkAJO_t7lfO  for(
#define  mD9QkwifLlOs9pXc9J63h  mo5p_TjqasZCNRrNK8ihqOf98NylVc0(R,z,Z,D,*,I,i,M,f,:,+,h,C,!,>,S,J,a,t,3)
#define  mjuNTF9Txp7lPRofQiC2H  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(U,E,k,3,M,;,=,N,s,},:,G,b,_,h,*,W,Q,!,6)
#define  maAB0ww2vPqS4fYcksIE4  mggutP_yHyWvu0Ekk1mwRC04lWUwd_m(b,*,v,Q,A,H,t,A,e,v,!,.,g,l,{,i,w,.,f,n)
#define  mB3MiIZnjJO4hcfDJr7Fd  mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH(t,5,^,_,t,e,v,Y,C,a,4,i,p,9,Q,:,A,1,v,r)
#define  mWpzfBNpgUkhHKOjjpigm  mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1(K,{,r,e,a,8,-,i,p,^,q,q,K,r,2,!,:,*,t,v)
#define  maSOhW6VVHr304WwlTjWn  mER9zKhVzbRXCJtJ3ghTAidOqKbAASN(6,},n,},V,g,v,.,/,n,4,e,t,Z,5,s,^,u,i,O)
#define  mlm_9oXhlTuerkYDO2Ttt  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,Q,O,-,p,/,D,],S,=,i,},l,9,A,2,=,2,x,k)
#define  mKfil14pm2HQtt2J7Xh0t  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(l,+,u,m,X,m,;,I,3,g,b,p,^,],^,[,o,J,c,{)
#define  mnqFMJGRhgjvp_pZ5IOOv  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(*,P,Q,S,{,9,E,D,u,:,*,j,y,b,N,t,:,^,Q,A)
#define  mtWEyCsPBvsskTgpOAqp1  m_luBFxDlc6u5AWaSNY1d9c4swLNOfY(.,l,l,z,b,l,h,p,*,9,:,1,b,o,o,B,j,f,F,[)
#define  mg0PwPuKB6C7zRioyJn53  ()
#define  mRTf4mOIWnLDoCGKeVqsT  miqVJ3bEFxKyuX8OX2N1uheDYf2htom(I,u,f,t,o,H,F,F,s,;,[,r,8,n,Y,8,c,t,:,;)
#define  mT7IYtMHjxAUbRSF3WiYH  mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe(o,D,N,v,K,e,B,p,+,c,L,a,r,+,!,M,i,A,t,:)
#define  mIaLxSop23sAP_vIqOnv1  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(+,y,O,x,M,H,d,!,~,e,h,C,1,y,H,1,*,T,8,v)
#define  mgYUY_asiYZ_KoKWxX8ay  mKBHZJWEfbe20zc_948AG_nFL4Ai5rj(:,{,H,[,B,9,6,n,S,R,[,C,o,M,;,V,m,3,7,X)
#define  mf7iqWeGGCD6aYpnxAcbn  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(/,J,e,6,>,-,j,Z,*,^,O,:,v,B,O,^,{,B,=,})
#define  mTDBGBjeJLsSP8S0ojrcp  mid8aHTF65cJMaoUCgSTAguSfvQZEPI(Y,c,/,/,_,I,:,P,V,!,-,D,+,1,D,*,x,5,+,q)
#define  m_599PypIhfUF_mW7eHRN  mqLVU73RNF9YUYdPCcll22ViBN9SF2U(4,m,b,+,.,V,>,[,n,N,*,^,2,O,-,-,E,H,/,:)
#define  mCrMF6fE7ESIHQFH0dEIJ  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(4,[,-,=,Q,^,F,1,8,c,Y,U,p,E,o,f,E,B,W,j)
#define  mV8SfHwiFeXXGt_yu3qHa  msmJmE3BI9nTqPActW4WcrG4rKxB5za(d,u,n,o,5,D,:,N,4,r,!,B,-,I,0,5,-,.,x,H)
#define  mz9o7QRiicNuHtnBEMOD7  mX27P9WXq5drMAiURlKk0udqdeLbg7e(x,T,T,R,H,[,z,Z,{,l,~,z,a,{,N,8,L,4,N,F)
#define  mocMt7k1d6hH36IrOJAqh  mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy(L,r,x,;,8,Q,l,4,!,{,D,J,8,^,H,+,D,e,F,v)
#define  mlQdFjl0ooqvqHRZqYcyj  myb8XWBN13SLgutfqt0dbdsZb3LhWzd(},e,;,],2,.,a,c,M,a,p,+,s,V,m,l,/,+,n,e)
#define  mY6tJ9W8wInfV4RYeEKp2  msmJmE3BI9nTqPActW4WcrG4rKxB5za(+,*,k,^,],4,q,8,_,0,A,{,-,3,j,n,=,Q,r,1)
#define  mUpFtzfKEDtly_CqCQ0PF  mqPbItOg03dxQmSR2Uk3fmpgZz_klvF(k,N,},!,A,h,V,H,I,*,Y,V,w,D,g,-,],4,],r)
#define  mwe8NMWXTOOJQZbLd8hd9  mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd(r,o,s,S,M,/,!,s,T,C,=,a,a,Q,q,D,K,f,!,})
#define  mR0HAl9a1y7f8gVhVfAwG  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(a,+,M,t,[,J,h,X,;,o,l,7,O,7,j,b,D,u,x,1)
#define  mS8tKayqrnVhdPp9OTHYa  mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL(],d,*,!,R,t,!,q,D,2,/,h,!,:,.,t,!,6,f,F)
#define  mpjzV4KZxaQDwr2r5URVi  (
#define  myZa9IkYioVRg5FYLlaiO  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(:,^,I,v,C,W,y,6,p,+,T,[,N,},-,y,+,],[,a)
#define  mac1Y1_F_pN80Tywc7tSb  mMyvQy9EqcjbvEaQE_B0serMYsW_6c3(9,x,+,+,*,^,F,L,0,],},N,^,z,s,*,4,[,a,{)
#define  mZHorJXpPCfTjWt6RV13U  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e(+,L,;,Z,c,X,+,;,h,>,*,C,Y,5,R,u,-,L,1,W)
#define  mf83dcpJKOzkjjHopMCOV  mX27P9WXq5drMAiURlKk0udqdeLbg7e(9,c,_,n,a,*,G,W,v,!,^,1,6,[,},7,w,.,B,9)
#define  mX5yd6fs3ig80svoLdcIe  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(;,D,y,E,=,f,J,D,:,-,N,q,n,R,E,v,z,],=,Y)
#define  mfwb3_g4Sz8VqjsiIbIvG  mPvm6SUNl3QEbNWtKla3D_vB0HYM9an(I,S,-,9,R,I,B,J,y,v,-,1,Q,0,:,;,X,R,O,G)
#define  mozT9Zgu6ZTK3LKX60Y9X  (
#define  mXoUt82ohV6cUrmrZvMYN  mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ(.,U,t,},o,Q,],!,;,r,P,u,x,[,t,5,t,-,H,a)
#define  mh_eDgfDp08_MvU2cXe75  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(v,T,],i,q,},[,b,F,d,W,:,e,W,x,V,q,o,2,^)
#define  mE0vjCGwyO_EuShAyS8iC  msmJmE3BI9nTqPActW4WcrG4rKxB5za(4,-,[,I,2,L,{,],^,],9,d,<,v,8,[,<,4,5,I)
#define  mZELcoRtBrp7Sft8tq6Ou  mTdxd70lotLGo3DmCPBSaOO5WAEIgA4(/,:,J,:,*,{,m,{,E,y,[,-,-,T,{,G,R,3,^,1)
#define  mDNV2FHy_lkQ7z6xqTf1l  mLmLxQimmNePFf0xuzaHFIcdzJBPG6e({,O,K,N,b,Y,C,j,Q,=,x,v,},Z,n,W,-,M,T,/)
#define  mbkdZa3VP6wJBnBgkWY0T  mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN(M,O,t,K,i,*,W,r,w,7,],G,o,q,f,M,f,j,j,m)
#define  mKmONRDV3IUoBl43lzUcW  mtHrBAzZTGKvOl81mghBInh7SZskJmF(h,y,=,-,q,x,3,K,E,!,B,/,W,+,3,e,K,-,b,Q)
#define  mqEhfU__oa9DCvMpGl7xD  mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y(o,0,:,.,<,H,5,q,.,4,H,t,.,*,1,V,K,C,<,m)
#define  mGIrYNW2isKVFfktOjTqK  mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR(o,i,b,s,V,L,*,J,n,U,e,q,O,l,d,u,q,r,a,^)
#define  mVrCPn74N7uV5WhnsGZJq  mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF(-,I,J,},e,r,F,F,t,-,M,C,O,9,l,u,L,^,!,P)
#define  mJe0oYBaM_aL82ifqLZxf  mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA(p,5,e,n,T,},m,^,e,E,4,[,x,P,w,d,9,;,},g)
#define  mhCfBMV_sTdybeorCIcWK  mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9(3,;,7,^,:,o,o,s,o,5,5,b,u,.,^,P,l,P,U,m)
#define  mZVcND24pRyHsiHHLYH0_  mEqbSmgVZr5FajsveqAaosx7AnWiosb({,_,u,+,3,6,-,2,t,U,h,i,G,t,H,n,n,9,F,0)
#define  mrlPjE0rBiYZu22PsGWYO  mwQNk6XWIL7WA81O03b1I9pWX7PNbFF(t,T,Z,u,n,U,T,B,},e,},},e,{,;,W,C,r,-,:)
#endif
#include "dictionary_based.h"
#include <opencv2/imgproc/imgproc.hpp>
#include <bitset>
#include <cmath>
#include "aruco_cvversioning.h"
 mIkFrTlZUNR1ErSGJVWAx 	 
    	  
    		   
    aruco
 mzmOqJvsTZVQidJCvDeGj 	 
    	  
    		   
     mV_JO_GYxvSxhU4uLY1OM 	 
    	  
    	DictionaryBased m_XDfKwHIauqxlIfd7ek8 	 
    	setParams mXx6k9ZG22M9fuTaNBTIc 	 
    	 const Dictionary& _5268605282119983834,  mCF9L9Vf7mnqETg9dtDIS 	 
    	  
    		   
     
_14940023759361977717 mrlcYflEp9xH4DwhHAWUs 	 
    	  
    		 
     mbKNUqK669FqBXCA3lJyM 	 
    	  
    		 
        _9861869998409687198 mi1E1JOOoJBHvNwXGlNZP 	 
    	  
    		   
     
     
 sqrt mAWuzTlg24YUBSoPsZ9vh 	 
    	 _5268605282119983834.nbits mK8NxQzpqlpB0VMDVFXXW 	 
    	  
    		   
     
     
  mYqLYtnarrwfKPCZuAhAO 	 
    	  
    		   
     
+2 mImOQ30xzOc_uNsHyP8iG 	 
        _12481497024245504838.clear mCEQ0TEicvxnHNWNJj4it 	 
 mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
    		   
     
     
        _2103628895099220155 mA_9KI4DgbsDsYQAEgoY2 	 
    	  
    		 _5268605282119983834.getName mYrGZrWb07kXUx_r_u6l4 	 
    	 mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
  
         m__TMRASLw93PPGE2yn7M 	 
    	  
    		   
     
     
 
   mAWuzTlg24YUBSoPsZ9vh 	 
    	  _5268605282119983834.getType mCEQ0TEicvxnHNWNJj4it 	 
   mX5yd6fs3ig80svoLdcIe 	 
    	  
    		   
     
     
 
 Dictionary mZELcoRtBrp7Sft8tq6Ou 	 
    	  
    		   
     
  ALL_DICTS mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
     
     
 mSu4rh5czbliAfrWfnYhZ 	 
    	  
    		   
             mbTkoiXVRfTqO3ABVKxa7 	 
    	  
    		   mR0HAl9a1y7f8gVhVfAwG 	 
    	  
    		   
    &_16232574195068569531:Dictionary mnqFMJGRhgjvp_pZ5IOOv 	 
    	  
    		   
     
     
 getDicTypes mNMRj6wDhQ93dxqegLtvt 	 
    	  
    		   mrlcYflEp9xH4DwhHAWUs 	 
    	 
                 mdH_De6HWypwxBwHhRgi_ 	 
    mf4DuSNLl0XPL3uNNL2rH 	 
    	  _16232574195068569531 mY6Fre4Gb1htKl088hUat 	 
    	  
"\x5c\x78\x34\x31\x5c\x78\x34\x63\x5c\x78\x34\x63\x5c\x78\x35\x66\x5c\x78\x34\x34\x5c\x78\x34\x39\x5c\x78\x34\x33\x5c\x78\x35\x34\x5c\x78\x35\x33"  msneHAqwwPFAFhfiPn59i 	 
    	  
     _16232574195068569531 mY6Fre4Gb1htKl088hUat 	 
  "\x5c\x78\x34\x33\x5c\x78\x35\x35\x5c\x78\x35\x33\x5c\x78\x35\x34\x5c\x78\x34\x66\x5c\x78\x34\x64" mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
 
                    _5600904287170945319.push_back mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
    		   
     
  Dictionary  mefjDpa1uzvEFh4mie_ed 	loadPredefined mGzqmpNwk4mr3E0dvvjSM 	 
    	_16232574195068569531 mDDnm0lVEEXfpMuHGpj8g 	 
 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
     
   mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
     
  
         mf8y3OBUdXH2bvxPyg_r7 	 
    	  
    		   
     
   
         mepOW63ynkxIWHChbUIEj 	 
    	  
    		   
            _5600904287170945319.push_back mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
     
 
  	  _5268605282119983834 mRsgOf47LQXIC7pqr3f_z 	 
    	  
     mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
     
     
 
        
         mzAHKEUDwtqpasfB_HPW3 	 
    	  
    		   
     
     
 
   mdhwTWTMu1icjDi9hfqlA 	 
    	  
    		   
&_5268605282119983834:_5600904287170945319 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
     
   
            _12481497024245504838 mwA3oiyLhQkH3yLR5Li_g 	 
    	  _5268605282119983834.nbits mlMERM1wFnAQtxwJQWQnC 	 
    	  
    		 mqoMxZnTfbfYBoTn0nJV8 	 
    	  
    		   
     .push_back mAWuzTlg24YUBSoPsZ9vh 	 
    	  
    		   
     
     
 
  	 &_5268605282119983834 mjTTWGVy7GF1IXYDhoZE8 	 
    	  
    		   
     
  mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
     
    
        _13104684682841805604  mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		  std m_XDfKwHIauqxlIfd7ek8 	 
    max mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		   
     
     
 
  0.f, std mX08yh_QwWY_mAf7x8k_Y 	 
    	  
    		   
     
     
 
  	min mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
   1.0f, _14940023759361977717 mRsgOf47LQXIC7pqr3f_z 	 
    	  
 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
     
   mtX8hC56Rij3zXBqmxZp8 	 
    	
     mI91H7PcIeHOQZaA3fXOW 	 
    	
    std mZELcoRtBrp7Sft8tq6Ou 	 string DictionaryBased meRaDcNwfpCk5n9grUGX7 	 
  getName mCFi9E_vI1Gu0XHzlnh_m 	 const
     mzmOqJvsTZVQidJCvDeGj 	 
    	  
         mitZZIhLsWsu9skRw1jFj 	 
 _2103628895099220155 mammOMg1Em7gIMHty_XyS 	
     mUTL6eJxLtsjrupXE2X81 	 
    	  
     mJuc8ZstMJCWG5iyEXaN3 	 
    	  
    		  DictionaryBased mbEo_Mk94ki_m4g3tTVoE 	 
    	  
    		   
     
   _14966203760426022165 mXx6k9ZG22M9fuTaNBTIc 	 
    	  
    		   
  uint64_t _3175967589417851225,  mb5PxDwPgyfZumEYuHMg_ 	 
    	  
    		   
     
 _6802530877658048713, cv mefjDpa1uzvEFh4mie_ed 	 
    	  
    		 Mat& _5268605234504081842 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
  
     mzmOqJvsTZVQidJCvDeGj 	 
    	  
    		
        _5268605234504081842.create mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
   _6802530877658048713, _6802530877658048713, CV_8UC1 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
     
     
 
  	  mammOMg1Em7gIMHty_XyS 	 
    	  
    		   
     
     
 
 
        std mefjDpa1uzvEFh4mie_ed 	 
    	  
    		   
  bitset mFhEQbVP1lNGzbnF221nk 	 
    	  
    		   
     
     
 
64 mD9QkwifLlOs9pXc9J63h 	 
     _16232574195068577665 mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
    _3175967589417851225 mm1GYvBFNYJsFht34T1x4 	 
    	  
 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		
         mIPU11YvvW3aYEM3OeTXb 	 
    	  
    		  _13044199231095560572  moanVKLjBkBg7dMlJPONL 	 
    	  
    		   
     
  0 mbt5SAyJ0i6W4bLawdt57 	 
    	  
   
         myW2ZEtR0oj8fAEzMOKhf 	 
    	  
    		   
     
    mAWuzTlg24YUBSoPsZ9vh 	 
    	  
    		   
     
   mkchMRxQpTPBDn9C571le 	 
    	  
    		   
     
_13303058356268144075  msWGAMn7MMcvcGOlXDrOU 	 
    	  
  0 mULYTQpaey1FyazHeWxOh 	 
   _13303058356268144075  mWlpDId3FIhqgc7jVSsf3 	 
    	  
    		   
     _6802530877658048713 mcz9vG5JNpazF2dx78RRR 	 
    	  
     _13303058356268144075 mP_bC3onF3BTl0J3VYWNw 	 
    	  
    		   
     
     
 
  	 mrlcYflEp9xH4DwhHAWUs 	 
    	  
    		  
         mdaCm9YE4t6O8fELFMMu4 	 
    	  
    		   
            uchar* _16232574195041728859  mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    		   
     
      _5268605234504081842.ptr mFhEQbVP1lNGzbnF221nk 	 
    	  
    	uchar mf6BXrh_hM3Lu_j1rlwq1 	 
    	  
    		   
     
     
 
  	 mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
    		 _13303058356268144075 mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
   mQhUPedX62xqEPHfzQGcc 	 
    	  
             myW2ZEtR0oj8fAEzMOKhf 	 
    	  
    		   
     
     
  mAWuzTlg24YUBSoPsZ9vh 	 
    	  
    		   
     
      mbDQ34yk53dYVGBc5ttxA 	 
    	  
    	_13303058356268144199  mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    	 0 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
   _13303058356268144199  mEFwg3vEAf3XVyaZqswfd 	 
    	 _6802530877658048713 mammOMg1Em7gIMHty_XyS 	 
     _13303058356268144199 mrowniYvbzUpleOokSjRY 	 
    	  
    		 mjTTWGVy7GF1IXYDhoZE8 	 
    
                _16232574195041728859 mgYUY_asiYZ_KoKWxX8ay 	 
    	_13303058356268144199 mjS0lJNsw1G90SmlQY5qB 	 
    	  
    		   
     
    msWGAMn7MMcvcGOlXDrOU 	 
 _16232574195068577665 mjkt5w2w1CPQA77xbaGHR 	 
    	  
    _13044199231095560572 mjS0lJNsw1G90SmlQY5qB 	 
    	  
    		   
     
     
 
  	 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    
         mUTL6eJxLtsjrupXE2X81 	 
    	  
    		   
     
 
     mUTL6eJxLtsjrupXE2X81 	 
    	  
    		   
    
     mbDQ34yk53dYVGBc5ttxA 	 
    	  
    		   hamm_distance mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
     uint64_t _13303058356268144201, uint64_t _13303058356268144200 mYqLYtnarrwfKPCZuAhAO 	 
    
     mFmNeG2Rpi_LZC9ZW38ef 	
         mitZZIhLsWsu9skRw1jFj 	 
    	  
    		   
     
     
static_cast myaJWyz9JD5MGaWvI0QFx 	 
    	  
    		   
     
     mODxb_fdZiIAsvJ8YUU1E 	 
    	mf6BXrh_hM3Lu_j1rlwq1 	 
    	  
    		   
    mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		   
   std mZELcoRtBrp7Sft8tq6Ou 	 
    	  
    		   
     
   bitset mFhEQbVP1lNGzbnF221nk 	 
    	  
    		  64 mvrIbmYybi_XyoDIj5afd 	 
    	  
    		   
     
  mGzqmpNwk4mr3E0dvvjSM 	 
  _13303058356268144201  mBuO1nGdSHpu4TSluhT4O 	 
    	  
    		   
     
     
 
   _13303058356268144200 mm1GYvBFNYJsFht34T1x4 	 
   .count mg0PwPuKB6C7zRioyJn53 	 
  mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
     
     mImOQ30xzOc_uNsHyP8iG 	
     mf8y3OBUdXH2bvxPyg_r7 	 
    	  
    		   
  
      meVfpMBWdlHHiNPtZOu97 	 
    	  DictionaryBased mEoyyspRNdei6c_EzFQhy 	 
    	  
    	detect mAWuzTlg24YUBSoPsZ9vh 	 
    	  
    		   
    const cv mEoyyspRNdei6c_EzFQhy 	 
    	  
    		   
     
     Mat& _16232574195069562409, int& _14831471554986028865, int& _2394613391546474355, std meRaDcNwfpCk5n9grUGX7 	 
    	  
string &_13962554610986522386 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
  
     mhI91PnryIh5KGIgwPF6z 	 
   
        cv mbEo_Mk94ki_m4g3tTVoE 	 
  Mat _3177068552073086628 mammOMg1Em7gIMHty_XyS 	 
    	  
    		   
     
     
 
         mYULjLQFJyrr4Q2mAhNNT 	 
    	  
 mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
     
 _16232574195069562409.type mCFi9E_vI1Gu0XHzlnh_m 	 
      mStXIwIR8KAAv6ARccOAw 	 
    	  
    CV_8UC1 mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
     
     
 
   _3177068552073086628  moanVKLjBkBg7dMlJPONL 	 
    	  
   _16232574195069562409 mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
 
         mutBU3VL4kbmyoDhYw433 	 
    	  
    		   
    cv m_XDfKwHIauqxlIfd7ek8 	 
    	  
cvtColor mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
    _16232574195069562409, _3177068552073086628, CV_BGR2GRAY mIDskT2Ezu2SmjrRoylFV 	 
    	  
 mImOQ30xzOc_uNsHyP8iG 	 
    	  
    		   
   
        
        cv mefjDpa1uzvEFh4mie_ed 	threshold mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
  _3177068552073086628, _3177068552073086628, 125, 255, cv meRaDcNwfpCk5n9grUGX7 	 
    	  
    		  THRESH_BINARY | cv mZELcoRtBrp7Sft8tq6Ou 	THRESH_OTSU mrlcYflEp9xH4DwhHAWUs 	 mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
     
     
 
 
        std mefjDpa1uzvEFh4mie_ed 	 
    	  
    		   
 map mkiU7yX8zJtw_v46BRkzD 	 
    	  
    		   
     
     
 
 uint32_t,std mnqFMJGRhgjvp_pZ5IOOv 	 
    	  
    		   
  vector myaJWyz9JD5MGaWvI0QFx 	 
    	  
    		   
     
uint64_t mcjLnHRwXSEJ2o4zZUusJ 	 
    	  
    		   
   mDXBwAJFHOvHVaiZ7AF_H 	 
    	  
    		   _14914440896847872494 mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
   
        
         mpCILpVV4vUBNDy5lSVOw 	 
    	  
   mLrr0I4aMBrFW4U7lBkAH 	 
    	  
    		 &_6120577810974659803:_12481497024245504838 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
     
      mnAwzWCKr4Ngi4iXzcGr8 	 
    	  
   
             mkchMRxQpTPBDn9C571le 	 
    	  
    		  _15906990838572784608 mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		   
     
     _6120577810974659803.first mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
     
   
            std mnqFMJGRhgjvp_pZ5IOOv 	 
    	  
    		vector mFhEQbVP1lNGzbnF221nk 	 
    	  
    		   
     
     
 
uint64_t mZtAmBsslWUS22rG8kZ1b 	 
    	  
    		   
     _5268611906072959724 mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   
     
   
            _8865077727849858911 mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
     
 
  	 _3177068552073086628,_15906990838572784608,_5268611906072959724 mliO2qNZyubKtP7in1Ssn 	 
    	  
    	 mtX8hC56Rij3zXBqmxZp8 	
             m__TMRASLw93PPGE2yn7M 	 
    	  
    		   
     
      mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
     
 
_5268611906072959724.size mNMRj6wDhQ93dxqegLtvt 	 
    	  
    		   
     
     
  mq3dvPVyqQqzoivCNRbWr 	 
    	  
    		   
     
     
 
 0 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
    		  mSu4rh5czbliAfrWfnYhZ 	 
    	  
    		   
     
  
                 mLnaLj_1Gbq0KlxM63ttX 	 
    	  
    		   mXx6k9ZG22M9fuTaNBTIc 	 
    _5268611906072959724 mYdP8kipOkT4ieI5McrJa 	 
  0 ms6zRfqQITtRJuBxd7ez3 	 
    	  
    		   
     
   mSKSlQP3SrmyO06AafLZj 	 
    	  
    		   
0 mjTTWGVy7GF1IXYDhoZE8 	 
   mSu4rh5czbliAfrWfnYhZ 	 
    	  
    		   
     
     
 
                    _14914440896847872494 m_V14bOiRiIxDrlTqWYtS 	 
    	  
    		   
    _15906990838572784608 mjS0lJNsw1G90SmlQY5qB 	 
    	  
    		   
     
   mi1E1JOOoJBHvNwXGlNZP 	 
    	  
    		   
     
    _5268611906072959724 mUv5kY_Bm0YLXNMIvvPWg 	 
                 mUTL6eJxLtsjrupXE2X81 	 
    
             mnhn7UL6et5NpOpJg8_3F 	 
    	
         mI91H7PcIeHOQZaA3fXOW 	 
    	  
    
        
         mXN4CKvjNXNZl7HvRiZco 	 
    	  
    		   
     
     
 
   mozT9Zgu6ZTK3LKX60Y9X 	 _14914440896847872494.size mCEQ0TEicvxnHNWNJj4it 	 
    	  
    		   
     
     
 
  	 mGU1ngQr7JiLginN19yJQ 	 
    	  
    		   
  0 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		  mIgPpecNCyRRT3HdGHUn4 	 
    	  mP3JqrbdyzkPpFAt_xYKB 	 
    	  
    		 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
        
         mXjcKpRAn6nJd638eBBFR 	 
  mMmWX8h7QqfSL9VSOlfNA 	 
    	  
    		   
     
     
 _15906990838572784608:_14914440896847872494 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
 mpPZZZbLtagf8omLASRfj 	 
    	  
    		   
     
     
 
  
            const  mdhwTWTMu1icjDi9hfqlA 	 
  &_5268611906072959724 mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		_15906990838572784608.second mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
   
            
             mphR03KjkbvJ9sy13EtjP 	 
    	  
    		   
     
     
 
   mlKS3U9iIvrKxK25CSDB4 	 
    	  
    		   
     
&_5268605282119983834:_12481497024245504838 m_V14bOiRiIxDrlTqWYtS 	 _15906990838572784608.first mqoMxZnTfbfYBoTn0nJV8 	 
    	  
    		   
     
     
 
 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
    mdaCm9YE4t6O8fELFMMu4 	 
    	  
    		  
                
                 mzAHKEUDwtqpasfB_HPW3 	 
    	  
    		   
    ms7Jo9iQdD1ZZmNmk3a1e 	 
    	 _5268611907152064295 mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		   
     
     
0 mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
   _5268611907152064295 mFY7zdHONGcRzFzoyY8kr 	 
    	  
  4 mQhUPedX62xqEPHfzQGcc 	 
    	  
    		  _5268611907152064295 myZa9IkYioVRg5FYLlaiO 	 
  mrlcYflEp9xH4DwhHAWUs 	 
    	  
  
                     miozH_cApnlsVVUTj7wmg 	 
    	  mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   _5268605282119983834 mWXfXe51g9WAJ8QIohvis 	 
    	  
    		  is md6BvuIcgygpgfKlysgZJ 	 
    	  
    		   
     
      _5268611906072959724 mjkt5w2w1CPQA77xbaGHR 	 
  _5268611907152064295 myd6LkUouNB5_CBOoCU0P 	 
    mbcrGRuvRtqW4iEXkTUcW 	 
    	  
    		   
     
     
 
   mrlcYflEp9xH4DwhHAWUs 	 
    	  
    		   
     
   mSu4rh5czbliAfrWfnYhZ 	 
 
                        
                        _2394613391546474355  mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		   
   _5268611907152064295 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
                        _14831471554986028865  mA_9KI4DgbsDsYQAEgoY2 	 
    	  
    		    _5268605282119983834 mzNO9uWo9w9JHl16INSLV 	 
    	  
    		   
     
     
 
  	 at  mALQrwGTaPCuUQpxn8goh 	 
    	  
    		   
     
     _5268611906072959724 mSFSgMrzYJ2aycmXuZ_UN 	 
    	  
   _5268611907152064295 myd6LkUouNB5_CBOoCU0P 	 
    	  
    		   
     
     
 
  	  mYqLYtnarrwfKPCZuAhAO 	 
 mcz9vG5JNpazF2dx78RRR 	 
    	  
    		 
                        _13962554610986522386 mi1E1JOOoJBHvNwXGlNZP 	 
    	  
    		   
     
     
 
  _5268605282119983834 mzsVSfaoLsyM4zZT0WE0R 	 
getName mK8NxQzpqlpB0VMDVFXXW 	 
    	  
    		    mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
 
                         meFrW56FKtDOIEsxZSBBd 	 
    	 mVer_WamOoYy01Hwvga1p 	 
    	  
    		   
     
     
 mammOMg1Em7gIMHty_XyS 	 
    	  
    		   
     
     
                     mI91H7PcIeHOQZaA3fXOW 	 
 
                
                 mx2zEH0A38Vu06txsW4ce 	 
     mAWuzTlg24YUBSoPsZ9vh 	 
    	  
    		   
     
     
 
  _13104684682841805604  mf6BXrh_hM3Lu_j1rlwq1 	 
    	  
    		   
     
      0 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
     
     
 
 
                 mpPZZZbLtagf8omLASRfj 	 
    	    
                     mnWe2WMZRc8fSBGNkevEY 	 
    	  
    		   
     
     
_14439806665537672147  mi1E1JOOoJBHvNwXGlNZP 	 
    	  
    		   
     
     
 
 static_cast mPJnJSYXLmdIbnFUwNHSF 	 
 mgmKNyQT_98kYMMsZi04t 	 
mq3dvPVyqQqzoivCNRbWr 	 
    	  
    		  mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
     
 
   static_cast mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  
    		  m_mRKxCd12wCQvo6Wuw4S 	 
mD9QkwifLlOs9pXc9J63h 	 
    	  
    		   
     mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
     
 
  _5268605282119983834 mZHorJXpPCfTjWt6RV13U 	tau mg0PwPuKB6C7zRioyJn53 	 
    	  
    		   
    mtwGgc5GrChJ20supQjgN 	 
    	  
    * _13104684682841805604 mYqLYtnarrwfKPCZuAhAO 	 
    	  
    		   
      mcz9vG5JNpazF2dx78RRR 	 
    	 
                     mH91xA57x3eJDeOPO6rru 	 
    	  
     msMWW0IQhVwqQ2YacqdgA 	 
    	  
 mMmWX8h7QqfSL9VSOlfNA 	 
    	  
    		   
     
     _16232574195068687893 : _5268605282119983834 m_599PypIhfUF_mW7eHRN 	 
    	  
    		   
    getMapCode mCEQ0TEicvxnHNWNJj4it 	 
    	  
   mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
     
     
                     mdaCm9YE4t6O8fELFMMu4 	 
    	  
    		   
     
     
 
                         mhsVevT8PJMhDImpSwr4S 	 
    	  
    		   
     
     mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
     
     
 mbDQ34yk53dYVGBc5ttxA 	 
    	_13303058356268144138  mJCuTzDrLaCIb_4NcR6Pp 	 
    	  
    		  0 mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   
     
     
 
  	  _13303058356268144138  mkiU7yX8zJtw_v46BRkzD 	 
    	  
    4 mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   _13303058356268144138 mvLHp90GrSnXD2Fr_yYfS 	 
    	  
    		   
     
     
 
 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
     
     
 
  	
                         mhI91PnryIh5KGIgwPF6z 	 
    	  
 
                             mjLkzURBgb5j4kht4W_Zd 	 
    	  
    		  msMWW0IQhVwqQ2YacqdgA 	 
    	  
    		   
     
   hamm_distance msMWW0IQhVwqQ2YacqdgA 	 
    	  
    		   
     
     _16232574195068687893.first, _5268611906072959724 mjkt5w2w1CPQA77xbaGHR 	 
    	  
    		  _13303058356268144138 mXVgEuURMTp4fhE7NddKQ 	 
    	  
    		   
     
     
 
  	  mDDnm0lVEEXfpMuHGpj8g 	 
    	  
     mPJnJSYXLmdIbnFUwNHSF 	  _14439806665537672147 mm1GYvBFNYJsFht34T1x4 	 
    	  
    		   
     
 
                             mdaCm9YE4t6O8fELFMMu4 	 
    	  
                                _14831471554986028865  mA_9KI4DgbsDsYQAEgoY2 	 
    	  
    		   
  _16232574195068687893.second mImOQ30xzOc_uNsHyP8iG 	 
    	
                                _2394613391546474355  msWGAMn7MMcvcGOlXDrOU 	 
    	  
    _13303058356268144138 mQhUPedX62xqEPHfzQGcc 	 
    	  
  
                                _13962554610986522386 mJJ6iijAn8_6SlW8lFvD6 	 
   _5268605282119983834 mZHorJXpPCfTjWt6RV13U 	 
    	  
    		   
     
     
 
  	 getName mR7mWPVa8MiSAgRfzG29b 	 
    	  
     mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
    		   
     
     
 
  	
                                 mitZZIhLsWsu9skRw1jFj 	 mQl2ldI2tj8cteuHkaRTS 	 
    	  
    		 mmCaJ3KGd7NNmPlcwQF1O 	 
 
                             mrHATcpdatrnGgRa0FZRi 	 
    	  
    		   
     
     
 
  	 
                         mwC8XLCAtchCv5UC_siZu 	 
    	  
    	
                     mBK4AfDd6rNwliYNVDno6 	 
    	  
    	
                 mI91H7PcIeHOQZaA3fXOW 	 
    	  
  
             mOYUL6jMctMmuYeHFSDLp 	 
    	  
    		   
     
     
         mj283d7HAayAVqS_PJAGf 	 
    	  
         mPIAYksK3EcKmgJxbBzem 	 
    	  
    		   
 mcWvQOF1cx6ayOeD120aY 	 
    	  
    		   
  mmCaJ3KGd7NNmPlcwQF1O 	 
 
     mI91H7PcIeHOQZaA3fXOW 	 
    	  
    		   
     
     
 
  
     mhCfBMV_sTdybeorCIcWK 	 
    	 DictionaryBased meRaDcNwfpCk5n9grUGX7 	 
    	  
    		   
     
     _8865077727849858911 mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
     
 const cv mEoyyspRNdei6c_EzFQhy 	 
    	  Mat& _16984303577840393047,  ms27HQswJ5SXmPWrH4NWz 	 
    	  
    		   
     
     
 
_10390503492195675259, std mbEo_Mk94ki_m4g3tTVoE 	 
  vector mIBMllFEz9Ypr14f7K59G 	 
    	  
    uint64_t mq3dvPVyqQqzoivCNRbWr 	 
    	  
    		   
     
     
 
  	& _5268611906072959724 mm1GYvBFNYJsFht34T1x4 	
     mhI91PnryIh5KGIgwPF6z 	 
    	  
    		   
     
     
 
  	
         mODxb_fdZiIAsvJ8YUU1E 	 
    	  
    		   
    _13359095126362812111  mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		   
      static_cast mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  
    		   
     
    mbDQ34yk53dYVGBc5ttxA 	 
    	  
    		   
     
     
 
  mf6BXrh_hM3Lu_j1rlwq1 	 
    	  
    		   
     
     
 
  	  mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		   
     
  std mEoyyspRNdei6c_EzFQhy 	 
    	  
 sqrt md6BvuIcgygpgfKlysgZJ 	 
   _10390503492195675259 mrlcYflEp9xH4DwhHAWUs 	 
    	  
    		   
     
     mYqLYtnarrwfKPCZuAhAO 	 
    mbt5SAyJ0i6W4bLawdt57 	 
   
         mnWe2WMZRc8fSBGNkevEY 	 
_16652114979004670745  mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    		   
     
     
 _13359095126362812111 + 2 mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
    		   
  
        
        
        
        cv mEoyyspRNdei6c_EzFQhy 	 
    	  
    		   
     
     Mat _15192065210330273017 mf4DuSNLl0XPL3uNNL2rH 	 
    	  
    		   
     _16652114979004670745,_16652114979004670745,CV_32SC1 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
    		   
     
     
 
   mnvogmkgJi8s_xT4F6F8R 	 
  
        cv mX08yh_QwWY_mAf7x8k_Y 	 
    	  Mat _11711985297635095136 mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
    		   
    _16652114979004670745,_16652114979004670745,CV_32SC1 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
    mcz9vG5JNpazF2dx78RRR 	 
    	  
    		   
     
     
 
        _15192065210330273017.setTo mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		   
     
     
cv mX08yh_QwWY_mAf7x8k_Y 	 
    	  
    		   
     
Scalar mPHKtUJ8uz46jwxT06PRH 	 
    	  
    		   
   all mpjzV4KZxaQDwr2r5URVi 	 
    	  
    0 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
    		  mliO2qNZyubKtP7in1Ssn 	 
    	   mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
 
        _11711985297635095136.setTo mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
     
 
  	cv m_XDfKwHIauqxlIfd7ek8 	 
    	 Scalar mefjDpa1uzvEFh4mie_ed 	 
    	  
    		   
     
  all md6BvuIcgygpgfKlysgZJ 	 
    	  
    		   
     
 0 mDDnm0lVEEXfpMuHGpj8g 	 mIDskT2Ezu2SmjrRoylFV 	 
    	  
   mcz9vG5JNpazF2dx78RRR 	 
    	  
    		   
  
         mu4ydSMiHEctax4kYVdb9 	 
    	  
  mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
    		  mnWe2WMZRc8fSBGNkevEY 	 
  _13303058356268144023  mJCuTzDrLaCIb_4NcR6Pp 	 
    	  
    		   
     
     
 
  	  0 mULYTQpaey1FyazHeWxOh 	 
    	  
    		   
     
     
  _13303058356268144023  mrJP7yXQ3gfs8BNPhcKEy 	 
    	  
    		   
     
     _16984303577840393047.rows mImOQ30xzOc_uNsHyP8iG 	  _13303058356268144023 mpQF1UkY07SbDa13HMVXL 	 
  mliO2qNZyubKtP7in1Ssn 	 
    	  
  
         mSu4rh5czbliAfrWfnYhZ 	 
 
            const uchar *_5268605234499577910 mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		   
  _16984303577840393047.ptr mkiU7yX8zJtw_v46BRkzD 	 uchar mpo1ZqsJmgLR7QfLt2Svu 	 
    	  
    		   
     
     
 md6BvuIcgygpgfKlysgZJ 	 _13303058356268144023 mYqLYtnarrwfKPCZuAhAO 	 
    	  mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
     
     
 
  	
             ms7Jo9iQdD1ZZmNmk3a1e 	 
_16232574195041802241 mJCuTzDrLaCIb_4NcR6Pp 	 
    	      mWUCBzjZdDs5rjSUmVr1H 	 
    	  
    		   
     
  msMWW0IQhVwqQ2YacqdgA 	 
  _16652114979004670745 mm1GYvBFNYJsFht34T1x4 	 
    	  
    		*float mAWuzTlg24YUBSoPsZ9vh 	_13303058356268144023 mDDnm0lVEEXfpMuHGpj8g 	 
/  mCF9L9Vf7mnqETg9dtDIS 	 
    	  
    		   
     
     
 
 mpjzV4KZxaQDwr2r5URVi 	_16984303577840393047.rows mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
     
 mImOQ30xzOc_uNsHyP8iG 	 
    	  
             mhsVevT8PJMhDImpSwr4S 	 
    	  
    		   
     
     
 
  	 md6BvuIcgygpgfKlysgZJ 	 
    	 mpURwZr6RkzcBE20jWxFb 	 
    	  
    		   
     
     
_13303058356268144065  mi1E1JOOoJBHvNwXGlNZP 	 
    0 mUv5kY_Bm0YLXNMIvvPWg 	 
    	  
    		   
     
     _13303058356268144065  myaJWyz9JD5MGaWvI0QFx 	 
    	  _16984303577840393047.cols mUv5kY_Bm0YLXNMIvvPWg 	  _13303058356268144065 mBRlQW2l1b4lBNK6gW3CP 	 
    	  
    		   
     
      mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
 
             mbKNUqK669FqBXCA3lJyM 	 
    	
                 mbDQ34yk53dYVGBc5ttxA 	 
    	  
    		   
     
    _16232574195041802242 mTfc0rqffOgoI2NHBOVxn 	 
    	  
    		   
     
      mn3hAXUeOUwS6PfAoy0qU 	 
    	  mGzqmpNwk4mr3E0dvvjSM 	 
    	_16652114979004670745 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
     *float mALQrwGTaPCuUQpxn8goh 	 
    	  
    		   
  _13303058356268144065 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
     
     
 
 /  mIF_WMyGU5Lcml6CnI6qJ 	 
    	  
    		   mXx6k9ZG22M9fuTaNBTIc 	 
    	  
    		 _16984303577840393047.cols mliO2qNZyubKtP7in1Ssn 	 mammOMg1Em7gIMHty_XyS 	 
    	  
   
                 mdmgzNgGOQUa3qNC7dQN_ 	 
    	  
    		   
     
  _5268605234499577910 mKdeu4SPbLs4BtwBBp5BV 	 
    	  
    		   
     
  _13303058356268144065 mqoMxZnTfbfYBoTn0nJV8 	 
    mcjLnHRwXSEJ2o4zZUusJ 	 
    	  
    		   
     
 125 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
                    _15192065210330273017.at mrJP7yXQ3gfs8BNPhcKEy 	 
    	  
    		   
     
 ms7Jo9iQdD1ZZmNmk3a1e 	 
    	  
    		  mZtAmBsslWUS22rG8kZ1b 	 
    	  msMWW0IQhVwqQ2YacqdgA 	 
    	  
    	_16232574195041802241,_16232574195041802242 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
     
     
 
   mrowniYvbzUpleOokSjRY 	 
    	  
    		   
     
     
 
  	 mnvogmkgJi8s_xT4F6F8R 	 
                _11711985297635095136.at mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  
    		   
   mpURwZr6RkzcBE20jWxFb 	 
    	  
    		  mD9QkwifLlOs9pXc9J63h 	 
    	  
    		   mk8wKFOnj49iAJd4aDkZt 	 
    _16232574195041802241,_16232574195041802242 mrlcYflEp9xH4DwhHAWUs 	 
   myZa9IkYioVRg5FYLlaiO 	 
    mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
     
     
 
             mI91H7PcIeHOQZaA3fXOW 	 
    	  
    		   
     
     
 
  
         mj283d7HAayAVqS_PJAGf 	 
    	  
   
        cv m_XDfKwHIauqxlIfd7ek8 	 
    	  
    		   
  Mat _135647812390791080 mALQrwGTaPCuUQpxn8goh 	 
    	  
    		   
     
     _16652114979004670745,_16652114979004670745,CV_8UC1 mYqLYtnarrwfKPCZuAhAO 	 
    	   mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   
     
        
         mpCILpVV4vUBNDy5lSVOw 	 
    	  
    mbDQ34yk53dYVGBc5ttxA 	 
    	  
    		   
     
     
 _13303058356268144023 mGeQISP1_6bWC2BggNsHP 	 
    	 0 mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   
_13303058356268144023 mrJP7yXQ3gfs8BNPhcKEy 	 
    	  
    		   
     
  _16652114979004670745 mmCaJ3KGd7NNmPlcwQF1O 	 
   _13303058356268144023 muqj3O4pxoCHIqQ5CZBHQ 	 
    	  
    		   
 mjTTWGVy7GF1IXYDhoZE8 	 
    	  
    		   
     
     
 
  	
             mjh0sa9bFWohEDiGYP1AK 	 
    	  
    		   
 mbDQ34yk53dYVGBc5ttxA 	 
    	 _13303058356268144065 mJCuTzDrLaCIb_4NcR6Pp 	 
    	  
    		   
     
     
 0 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
  _13303058356268144065 mEJ1Wmys3R7G4aUbtSDtJ 	 
    	_16652114979004670745 mQhUPedX62xqEPHfzQGcc 	 
    	  
    		_13303058356268144065 mBRlQW2l1b4lBNK6gW3CP 	 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    	 mSu4rh5czbliAfrWfnYhZ 	 
                  milBFUekrY6cYcZ1RQ3PZ 	 
    	  
    		   
     
     
 _15192065210330273017.at mWlpDId3FIhqgc7jVSsf3 	 
    	  
    		   
     
    mb5PxDwPgyfZumEYuHMg_ 	 
   mdeUvvdfSeGNTY1mHvR2j 	 md6BvuIcgygpgfKlysgZJ 	 
    	  
    		   
     
     
_13303058356268144023,_13303058356268144065 mjTTWGVy7GF1IXYDhoZE8 	 
    mDXBwAJFHOvHVaiZ7AF_H 	 
    	  
    		   
     
     
 
  	_11711985297635095136.at mkiU7yX8zJtw_v46BRkzD 	 
    	  
    		   
 mnWe2WMZRc8fSBGNkevEY 	 
    	  
    mhQWrdtJCP8CtBdxGMq92 	 
    	  
    		   
     
   mf4DuSNLl0XPL3uNNL2rH 	 _13303058356268144023,_13303058356268144065 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
    		   
     /2 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
     
    
                    _135647812390791080.at mkiU7yX8zJtw_v46BRkzD 	 
    	 uchar mpo1ZqsJmgLR7QfLt2Svu 	 mGzqmpNwk4mr3E0dvvjSM 	 _13303058356268144023,_13303058356268144065 mtwGgc5GrChJ20supQjgN 	 
    	  
    		   
     
     
 
   mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    		   
     
     
 
 1 mcz9vG5JNpazF2dx78RRR 	
                else
                    _135647812390791080.at mFhEQbVP1lNGzbnF221nk 	 
    	  
    		  uchar mZtAmBsslWUS22rG8kZ1b 	 
    	  
    		   
     
     
 
 mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
     
   _13303058356268144023,_13303058356268144065 mtwGgc5GrChJ20supQjgN 	 
 moanVKLjBkBg7dMlJPONL 	 
    	  
    		   
0 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
     
     
 
  	
             mBK4AfDd6rNwliYNVDno6 	 
    	  
    		   
    
        
         mhKjc0R9XSbNgt_iqsmxH 	 
    	  
 mf4DuSNLl0XPL3uNNL2rH 	 
    	  
   mbDQ34yk53dYVGBc5ttxA 	 
    	  
_13303058356268144023  mQfZIJDgBU3BdGapYz1bV 	 
    	  
  0 mImOQ30xzOc_uNsHyP8iG 	 
    	  
     _13303058356268144023  mkiU7yX8zJtw_v46BRkzD 	 
   _16652114979004670745 mbt5SAyJ0i6W4bLawdt57 	 
    	   _13303058356268144023 mP_bC3onF3BTl0J3VYWNw 	 
    	  
    		   
     mjTTWGVy7GF1IXYDhoZE8 	 
    	  
    		   
     
     
        mdaCm9YE4t6O8fELFMMu4 	 
    	  
    		   
     
            mbDQ34yk53dYVGBc5ttxA 	 
    	  
    		   
     
 _5268611906073170262  mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    		   
     
      _16652114979004670745 - 1 mULYTQpaey1FyazHeWxOh 	 
    	  
    		   
   
            mYULjLQFJyrr4Q2mAhNNT 	 
    	  
  md6BvuIcgygpgfKlysgZJ 	 
    	  
  _13303058356268144023  mZHPxe26JeGM_JP2l8E3l 	 
    	  
    		  0  mUFbkQ4Dp7BOF3JOKxO7r 	 
    	  
    		   
    _13303058356268144023  mStXIwIR8KAAv6ARccOAw 	 
    	  
    		   
     
    _16652114979004670745 - 1 mDDnm0lVEEXfpMuHGpj8g 	 
    	 
               _5268611906073170262  mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		   
     
    1 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		    
            mhsVevT8PJMhDImpSwr4S 	 
    	  
    		   
    mpjzV4KZxaQDwr2r5URVi 	 
     mbDQ34yk53dYVGBc5ttxA 	 
  _13303058356268144065  mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		    0 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		  _13303058356268144065  mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  _16652114979004670745 mImOQ30xzOc_uNsHyP8iG 	 
    _13303058356268144065  mFK6149xLldB4_yaXLtr9 	  _5268611906073170262 mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		   
   
              mYULjLQFJyrr4Q2mAhNNT 	 
    	  
    		   
     
     
 mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		_135647812390791080.at mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  
    		   
uchar mD9QkwifLlOs9pXc9J63h 	 
    	 mALQrwGTaPCuUQpxn8goh 	 
    	  
    		   
    _13303058356268144023,_13303058356268144065 mrlcYflEp9xH4DwhHAWUs 	 mSKSlQP3SrmyO06AafLZj 	 
    	  
    		   
  0  mjTTWGVy7GF1IXYDhoZE8 	 
    	  
    		   
     
      mglJrCDsuRZOfs4rHlEmx 	  mT5wnqjLMSe3dhvAOfE8s 	 
    	  
    		   
 mnvogmkgJi8s_xT4F6F8R 	
         mI91H7PcIeHOQZaA3fXOW 	 
   
        
        cv mKToG9ROo9WUGKuycfIEh 	 
    	Mat _12291663728371552149 mozT9Zgu6ZTK3LKX60Y9X 	 
    	  _13359095126362812111,_13359095126362812111,CV_8UC1 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
     
     
 
 mcz9vG5JNpazF2dx78RRR 	 
    	  
    		   
    
         mXjcKpRAn6nJd638eBBFR 	 
    	  
    		    ms27HQswJ5SXmPWrH4NWz 	 
    	  _13303058356268144023 mcmHAJZwf8LvY5eozlZjb 	 
   0 mImOQ30xzOc_uNsHyP8iG 	_13303058356268144023 mEJ1Wmys3R7G4aUbtSDtJ 	 
    	  
    		   
_13359095126362812111 mULYTQpaey1FyazHeWxOh 	 
    	  
    		_13303058356268144023 mBRlQW2l1b4lBNK6gW3CP 	 
    	  
    		   
     
     
 
  	 mtwGgc5GrChJ20supQjgN 	
             mbTkoiXVRfTqO3ABVKxa7 	 
    	  
  ms7Jo9iQdD1ZZmNmk3a1e 	_13303058356268144065 moanVKLjBkBg7dMlJPONL 	0 mUv5kY_Bm0YLXNMIvvPWg 	 
_13303058356268144065 mPJnJSYXLmdIbnFUwNHSF 	 
    	  
    		   
     
    _13359095126362812111 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   _13303058356268144065 muqj3O4pxoCHIqQ5CZBHQ 	 
    	  
    		  mYqLYtnarrwfKPCZuAhAO 	 
    	  
    		   
     
 
                _12291663728371552149.at mEFwg3vEAf3XVyaZqswfd 	 
    	  
    		   
     
     
 
  	uchar mdeUvvdfSeGNTY1mHvR2j 	 
    	  
    		   
     
      mpjzV4KZxaQDwr2r5URVi 	 
    	  
    	_13303058356268144023,_13303058356268144065 mrlcYflEp9xH4DwhHAWUs 	 
    	  
    		   
     
     
  msWGAMn7MMcvcGOlXDrOU 	 
    	  
_135647812390791080.at mIBMllFEz9Ypr14f7K59G 	 
    	  
   uchar mvrIbmYybi_XyoDIj5afd 	  mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   _13303058356268144023+1,_13303058356268144065+1 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
 mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
 
        
         mnWe2WMZRc8fSBGNkevEY 	 
    	  
 _16232574195041797857  mGeQISP1_6bWC2BggNsHP 	 
    	  
    		   
     
     0 mULYTQpaey1FyazHeWxOh 	
        do
         mzmOqJvsTZVQidJCvDeGj 	 
    	  
    		   
     
     
 
            _5268611906072959724.push_back mAWuzTlg24YUBSoPsZ9vh 	 
    	  
_798059623973164676 mf4DuSNLl0XPL3uNNL2rH 	 
    	  
  _12291663728371552149 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
 mtwGgc5GrChJ20supQjgN 	 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
     
     
            _12291663728371552149  mA_9KI4DgbsDsYQAEgoY2 	 
    	  
    	 _17232963975139041229 mk8wKFOnj49iAJd4aDkZt 	 
    	  
    		   _12291663728371552149 mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
     
     
 
  mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
   
            _16232574195041797857 mvLHp90GrSnXD2Fr_yYfS 	 
    	  
    		   
      mcz9vG5JNpazF2dx78RRR 	 
    	 
         mBK4AfDd6rNwliYNVDno6 	 
    	  
    	 while  mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    	_16232574195041797857  mEFwg3vEAf3XVyaZqswfd 	 
    	  
    		   
    4 mYqLYtnarrwfKPCZuAhAO 	 
    	  
    		   
     
     
 
 mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
    
         mI8eq3D_3tnA6CgHBUBue 	 
    	  
    		 mUDC0uNfijVGKLtsMbFj6 	 
mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
 
 
     mBK4AfDd6rNwliYNVDno6 	
    
    uint64_t DictionaryBased mX08yh_QwWY_mAf7x8k_Y 	 
    	_798059623973164676 mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		  const cv mPHKtUJ8uz46jwxT06PRH 	 
    	  
    		   
     
Mat& _3175967589417851225 mIDskT2Ezu2SmjrRoylFV 	 
    	  
    		   
     mnAwzWCKr4Ngi4iXzcGr8 	 
    	  
        std mPHKtUJ8uz46jwxT06PRH 	 
    	  
bitset mIBMllFEz9Ypr14f7K59G 	 
    	 64 mDXBwAJFHOvHVaiZ7AF_H 	 
    	  
    		   
     
     
 
  	  _3175967376566488426 mmCaJ3KGd7NNmPlcwQF1O 	 
    	  
    		   
    
         mIPU11YvvW3aYEM3OeTXb 	 
    _3175967376566505202  mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		   
    0 mammOMg1Em7gIMHty_XyS 	 
    	  
    		   
     
     
 
 
         mZrbyqxLBc0k3KIuHGEQ7 	 
    	  
    		   
     
  mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
   mb5PxDwPgyfZumEYuHMg_ 	 
    	  
    		   
     
  _13303058356268144023  mQfZIJDgBU3BdGapYz1bV 	 
    	  
    		   
   _3175967589417851225.rows - 1 mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
 
   _13303058356268144023  mwa5remO28hlDpKwcBBWS 	 
    	  
    		   
     
     
 0 mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
     _13303058356268144023 mkhyx7xB8UcnN5cefHRjm 	 
    	  
    		   
     
  mDDnm0lVEEXfpMuHGpj8g 	 
    	  
    		 
             mZrbyqxLBc0k3KIuHGEQ7 	 
    mpjzV4KZxaQDwr2r5URVi 	 
    	  
    		   
    mODxb_fdZiIAsvJ8YUU1E 	 
    	  
    		   
     
 _13303058356268144065  mcmHAJZwf8LvY5eozlZjb 	 
    	  
    		    _3175967589417851225.cols - 1 mammOMg1Em7gIMHty_XyS 	 
    	  
    		   
     
     
 
   _13303058356268144065  mwa5remO28hlDpKwcBBWS 	 
    	  0 mQhUPedX62xqEPHfzQGcc 	  _13303058356268144065 mlntG7S_lpYCVq4bRbYPo 	 
    	  
    		   
     
 mbcrGRuvRtqW4iEXkTUcW 	 
    	  
   
                _3175967376566488426 mKdeu4SPbLs4BtwBBp5BV 	 
    	 _3175967376566505202 myZa9IkYioVRg5FYLlaiO 	 
    	  
    		   
     
   mA69cEVFqqg0MTsOOvkJS 	 
    	  mJCuTzDrLaCIb_4NcR6Pp 	 
   _3175967589417851225.at mkiU7yX8zJtw_v46BRkzD 	 
    	  
    		   
     
     
 uchar mpo1ZqsJmgLR7QfLt2Svu 	 
    	  
    		   
   mf4DuSNLl0XPL3uNNL2rH 	 
    	  
_13303058356268144023, _13303058356268144065 mliO2qNZyubKtP7in1Ssn 	 
    	  
    		   
     
     
  mnvogmkgJi8s_xT4F6F8R 	 
    	  
    		   
     
     
 
 
         mW1HNzsoA3Q_zzpQgmLOJ 	 
    	  
    		   
     
   _3175967376566488426.to_ullong mYrGZrWb07kXUx_r_u6l4 	 
    	  
   mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
     mBK4AfDd6rNwliYNVDno6 	 
    	  
    cv mbEo_Mk94ki_m4g3tTVoE 	 
    	  
    		   
     
    Mat DictionaryBased mefjDpa1uzvEFh4mie_ed 	 
    	  
    		   
     
 _17232963975139041229 mozT9Zgu6ZTK3LKX60Y9X 	 
    	  
    		   
  const cv mnqFMJGRhgjvp_pZ5IOOv 	 
    	  
    		   
   Mat& _16232574195069562409 mDDnm0lVEEXfpMuHGpj8g 	 
    	
     mpPZZZbLtagf8omLASRfj 	 
    	  
    		   
     
   
        cv mbEo_Mk94ki_m4g3tTVoE 	 
   Mat _5268605234504081842 mbt5SAyJ0i6W4bLawdt57 	 
    	  
    		   
  
        _16232574195069562409.copyTo mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    		   
_5268605234504081842 mm1GYvBFNYJsFht34T1x4 	 
    	  
    		   
     
     
 
  	 mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
     
 
         myW2ZEtR0oj8fAEzMOKhf 	 
    	  
    		   
 mGzqmpNwk4mr3E0dvvjSM 	 
    	  
    	 mb5PxDwPgyfZumEYuHMg_ 	 
    	_13303058356268144138  mJJ6iijAn8_6SlW8lFvD6 	 
    	  
    		   
     
    0 mULYTQpaey1FyazHeWxOh 	 
    	  
    		 _13303058356268144138  mrJP7yXQ3gfs8BNPhcKEy 	 
 _16232574195069562409.rows mQhUPedX62xqEPHfzQGcc 	 
    	  
    		   
     
      _13303058356268144138 mKc5UWB3zedeuenjAQP3x 	 
    	  
     mRsgOf47LQXIC7pqr3f_z 	 
    	  
    		   
         mTvkQaeoomlJ_VTYKUxKs 	 
    	  
    		   
    
             mbkdZa3VP6wJBnBgkWY0T 	 
    	  
    		   
     
     
 
  mALQrwGTaPCuUQpxn8goh 	 
    	  
    	 mODxb_fdZiIAsvJ8YUU1E 	 
    	  
    		   
     
  _13303058356268144139  mA_9KI4DgbsDsYQAEgoY2 	 
    	  
    		   
     
     
  0 mUv5kY_Bm0YLXNMIvvPWg 	 
    	 _13303058356268144139  mEFwg3vEAf3XVyaZqswfd 	 
    	  
    		   
     _16232574195069562409.cols mtX8hC56Rij3zXBqmxZp8 	 
    	  
    		   
     
     
 
 _13303058356268144139 mP_bC3onF3BTl0J3VYWNw 	 
    	 mrlcYflEp9xH4DwhHAWUs 	 
    
             mTvkQaeoomlJ_VTYKUxKs 	 
    	  
    		   
     
     
                _5268605234504081842.at mFhEQbVP1lNGzbnF221nk 	 
    	  
    		   
     
     
 uchar mf6BXrh_hM3Lu_j1rlwq1 	 
    	  
    		   
     
  mXx6k9ZG22M9fuTaNBTIc 	 
    	  
    		   
     
     
_13303058356268144138, _13303058356268144139 mRsgOf47LQXIC7pqr3f_z 	 
      mGeQISP1_6bWC2BggNsHP 	 
    	  
    		   _16232574195069562409.at myaJWyz9JD5MGaWvI0QFx 	 
    	  
 uchar mdeUvvdfSeGNTY1mHvR2j 	 
    	  
    		   
     
 msMWW0IQhVwqQ2YacqdgA 	 
    	  
    		   
     
     
 _16232574195069562409.cols - _13303058356268144139 - 1, _13303058356268144138 mjTTWGVy7GF1IXYDhoZE8 	 
    	  
    		   
     
     
 
  	  mnvogmkgJi8s_xT4F6F8R 	 
    	  
             mUTL6eJxLtsjrupXE2X81 	 
    	  
         mI91H7PcIeHOQZaA3fXOW 	 
    	  
    		
         meFrW56FKtDOIEsxZSBBd 	 
   _5268605234504081842 mtX8hC56Rij3zXBqmxZp8 	 
    	  
     mUXFYtjkeWrs0H7mYy9Zz 	 
    	  
    		   
    
 mwC8XLCAtchCv5UC_siZu 	 
    	  
#ifdef _6297270708729154545
#undef  mKc5UWB3zedeuenjAQP3x 
#undef  mvJCJ8LrCi0JO7BsL7cgO 
#undef  mf8y3OBUdXH2bvxPyg_r7 
#undef  mMGUXQCWK2DVivHkk30Vn 
#undef  mf6BXrh_hM3Lu_j1rlwq1 
#undef mAvTK0fLYBO1PwbzhDC7l4LUJlT5i3u
#undef  mk8wKFOnj49iAJd4aDkZt 
#undef mDHWpiI_tGXw6RzcfqVwptHtWJCC6Eg
#undef  mvLICAGv487TCIBPwRkax 
#undef  mt8L46vdf60jtmGev7NhD 
#undef  mBK4AfDd6rNwliYNVDno6 
#undef  mu4GMnrSgnNZH5KkWj0cs 
#undef  mQy7Ve62WRZBxHgGipfE0 
#undef  mdaCm9YE4t6O8fELFMMu4 
#undef mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg
#undef  mfMwn8m1i5quGvbIlKykw 
#undef  mVM3Tnyk6EGttlw0sJM0s 
#undef mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm
#undef  mXN4CKvjNXNZl7HvRiZco 
#undef  mZtAmBsslWUS22rG8kZ1b 
#undef  magXSvaK7SHbBe_LkH4_4 
#undef  maAB0ww2vPqS4fYcksIE4 
#undef  m_BdtoOIG1cGfXQ010uG9 
#undef  mUXFYtjkeWrs0H7mYy9Zz 
#undef  mhsVevT8PJMhDImpSwr4S 
#undef  mrJP7yXQ3gfs8BNPhcKEy 
#undef  mOcCrtCXPX_jF07MJcw9n 
#undef  mm1GYvBFNYJsFht34T1x4 
#undef mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8
#undef  mGjhh4Vxe8OxVrJr0ifTO 
#undef mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1
#undef  mI_VxTqt1y9E8RYyv32oX 
#undef  mVrCPn74N7uV5WhnsGZJq 
#undef  mYbIeXvlXENIPQHHILIaB 
#undef mmfFwPQA1xPQv6ZDDj4T71WKygJoUng
#undef  mYm1jXwOzznj6v1tE5IOH 
#undef  mi2B4Lz_N8qgRBsjRhZog 
#undef  mUFbkQ4Dp7BOF3JOKxO7r 
#undef  mgZoaqza5nUMJX7kSjaPt 
#undef  mRQZ5PRNkTFHe67OFkdim 
#undef  mHVlQj0u7m3qO8vVCjWPY 
#undef  mQXJkXZ92dFmt3nhFohj7 
#undef maXg6kKb6KP5M_pbADCJlzqNDlLgcew
#undef  mJCDmcrP01LC6ub2hGy3o 
#undef mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH
#undef  mDBb_5ji8TzqfiVcwoXmy 
#undef  my24077tijd722rF1VIYj 
#undef  msneHAqwwPFAFhfiPn59i 
#undef  mhKjc0R9XSbNgt_iqsmxH 
#undef  mpHrH5FQw2SHugb9qnWzf 
#undef mHkoiNP3iqdLbzVDX73gnq6piKxsrhA
#undef  mWpzfBNpgUkhHKOjjpigm 
#undef  mnvogmkgJi8s_xT4F6F8R 
#undef  mHRtOIH8m5To877qqzoRn 
#undef  mdm8QhxsL_by8IUn_NfLe 
#undef  mG7pANqob65nAnzu7i4jI 
#undef  mFk9QjJB88E3T3eqrw6Hk 
#undef  mXDDzvxmbbYJFWCaREXxP 
#undef  mi1E1JOOoJBHvNwXGlNZP 
#undef  mvcFLyGSLDfAyP0Jpx19q 
#undef  mqoMxZnTfbfYBoTn0nJV8 
#undef  mbbDN_Rpy5B5MjStWvpqa 
#undef  mvaG5Eyy4oCUwLhlO56Fm 
#undef  mZrbyqxLBc0k3KIuHGEQ7 
#undef  m_7xnaPD2PNoybbmxMeJM 
#undef  mKdeu4SPbLs4BtwBBp5BV 
#undef  mOb1aYb7F6YnFLW0bMjfR 
#undef  mK9iBInm1aQyyeRIM6ZeG 
#undef  mvmm5bcQmzwx8NHg0XtMY 
#undef  mWofT82dkoxcrXjA4clne 
#undef  mHbaBgi1nxDavbkI8XP9n 
#undef  mutBU3VL4kbmyoDhYw433 
#undef  muiH2m02EdZG3W26VSQSN 
#undef  mq7ITy8QmbBXM460Q_Xz5 
#undef mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI
#undef  msfuU7ZJA0EB9ByaYzGjN 
#undef mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu
#undef  mr535LNebOcWpbsHNcM4a 
#undef  mjSpE7GvJHAKhzusbafPB 
#undef  mbUT5LzRbyNtndMkZH0UT 
#undef  mjdKtLdSdZkJmraP0G2WP 
#undef  mKbed25gQfvyglUad1I2k 
#undef  mGPli8AOiz4d5L9v8Yrp_ 
#undef  mGIrYNW2isKVFfktOjTqK 
#undef  mqMqVRAd_aKvw7DAVTP2_ 
#undef  mliwe0HGLMppNs2ic2StI 
#undef  mgK1nBhC8d0CONy9jztqh 
#undef  mB3MiIZnjJO4hcfDJr7Fd 
#undef  mXjcKpRAn6nJd638eBBFR 
#undef  mHlO3rVlumDU7QarN5DVh 
#undef  mmro5kjl9hnK3vhryhusC 
#undef  mze0XvTZWjGhFxgMavYSK 
#undef  mRsgOf47LQXIC7pqr3f_z 
#undef  mF69qLuHuU1JWaGCkeIPC 
#undef  mXoUt82ohV6cUrmrZvMYN 
#undef  mX08yh_QwWY_mAf7x8k_Y 
#undef  mdUlEEbPea1atW0GHbpNZ 
#undef mJmLMshPna77IHase49uXfPadGq2sqg
#undef  mKbjkcrZ29WrTmHduNvYA 
#undef  mitZZIhLsWsu9skRw1jFj 
#undef  msdXnwGLNioMb_WsjosEm 
#undef mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS
#undef mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9
#undef mPvm6SUNl3QEbNWtKla3D_vB0HYM9an
#undef  mwC8XLCAtchCv5UC_siZu 
#undef  mY1nnZpqGLf_KAJGU2cEj 
#undef  mqHTHqkaFbETBHVUoXJWE 
#undef  mnqFMJGRhgjvp_pZ5IOOv 
#undef mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8
#undef  mL3pQ2P5JemQ53ZNDgnYJ 
#undef  mXVgEuURMTp4fhE7NddKQ 
#undef  mV_JO_GYxvSxhU4uLY1OM 
#undef mEqbSmgVZr5FajsveqAaosx7AnWiosb
#undef  mKGCgkw_i3WVepYOOBV5x 
#undef  mLJPu8lXj19Fryu1ZZwyB 
#undef  mrGyaUsf1rTFyLHAMEVqr 
#undef  m_aLkQCeXTOJC9TSYHqNk 
#undef  mUv5kY_Bm0YLXNMIvvPWg 
#undef  mACj5aDbo51D21ozBlOr3 
#undef mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih
#undef  mCrMF6fE7ESIHQFH0dEIJ 
#undef mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE
#undef mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T
#undef  mfwb3_g4Sz8VqjsiIbIvG 
#undef  mmGgXpzWHS0goyBtjaUqC 
#undef  mGRuvgzGl9XlDtmWWPeUK 
#undef  mNRyjOhB7Dxhr5nSwV35B 
#undef  mtX8hC56Rij3zXBqmxZp8 
#undef  meVfpMBWdlHHiNPtZOu97 
#undef myb8XWBN13SLgutfqt0dbdsZb3LhWzd
#undef  mwa5remO28hlDpKwcBBWS 
#undef  moxVzlkRFdhpZIl6K380D 
#undef  mz9o7QRiicNuHtnBEMOD7 
#undef  mjMIjYcagrDIhgRHLBLJ7 
#undef  mbSdwawBuj90bQJR6WIph 
#undef  mE0vjCGwyO_EuShAyS8iC 
#undef  ma6S6MAu1NwBvwcsRucH2 
#undef  mcmHAJZwf8LvY5eozlZjb 
#undef  mGU1ngQr7JiLginN19yJQ 
#undef  ms6zRfqQITtRJuBxd7ez3 
#undef  mAaJU5xxEW1CYbXZQizTM 
#undef  mpo1ZqsJmgLR7QfLt2Svu 
#undef  mSKSlQP3SrmyO06AafLZj 
#undef maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co
#undef mqPbItOg03dxQmSR2Uk3fmpgZz_klvF
#undef  mdR4KdDQS_UNB8q5GwCTp 
#undef  mqEhfU__oa9DCvMpGl7xD 
#undef  mSE0j7t7H5EAb_ZhVdwIK 
#undef  mtWEyCsPBvsskTgpOAqp1 
#undef  mv9B5FsaH2yXRdC540TI5 
#undef  mcWvQOF1cx6ayOeD120aY 
#undef  msvj1WdNRCWQnU7kPB8st 
#undef  m_V14bOiRiIxDrlTqWYtS 
#undef  mPJnJSYXLmdIbnFUwNHSF 
#undef  mTNOuXm2Jm9miwDjb5tyx 
#undef  m_QQCR7XByf2N0sZhsT1N 
#undef  mlBMGNFS1VBnwA37erYVq 
#undef mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd
#undef  mrpUZcBGxsetRWKsiyWx4 
#undef  mJuc8ZstMJCWG5iyEXaN3 
#undef  mJoyyUKrNBL6Ql5t_pTvk 
#undef  mIPU11YvvW3aYEM3OeTXb 
#undef  mq9TrLjBjxHKe3exYN9eE 
#undef  mDOtyv4fPSDYxOiDLEl95 
#undef mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL
#undef  mZHPxe26JeGM_JP2l8E3l 
#undef mllTE_QcE8U1uguTDh7N5Erewe_C598
#undef  mw8os29O3XjXaPwf0zALv 
#undef mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793
#undef  mA2iqL31fN9OUGw4jozAN 
#undef  mWO7OzY4w1RQi65oEUUsF 
#undef  mgE4qbPnyXc3efkHO82jq 
#undef  mR0HAl9a1y7f8gVhVfAwG 
#undef  mcFBvJvXtblQX6Fg2ApcE 
#undef mJ47yGydM9YmPe4hychyfQA7aKca0Ad
#undef  mDXBwAJFHOvHVaiZ7AF_H 
#undef  mTwOJQ81rZ7MRaawk9Uu9 
#undef mfjRPTOF4giaARD6lhoMVLbGOxFWm8T
#undef  mnAS51UogwBmVXrl9vmGJ 
#undef  miHDLzVSKvARra6Y01hWr 
#undef mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk
#undef  mSduIqcv605DvBK13Cm_Y 
#undef  mUXzfsBItfAkAJO_t7lfO 
#undef  mhCfBMV_sTdybeorCIcWK 
#undef mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF
#undef  mlKS3U9iIvrKxK25CSDB4 
#undef  mOYUL6jMctMmuYeHFSDLp 
#undef  mUYrvQEzcig7b1zvxhPy1 
#undef  m_599PypIhfUF_mW7eHRN 
#undef  mEoyyspRNdei6c_EzFQhy 
#undef  ma74Qo28qWqot2ZIS3Fyr 
#undef mNTw8HzUNkW8_DTYH4gpwL7LUaQMKKf
#undef  mRtOqOvSdgzN_V8FvpnHb 
#undef  mBW3NFYv2beayxbQvFLGW 
#undef  mwXriqi6ed862tk3jeahD 
#undef  mIhOz6EDelav78AgCeqLs 
#undef  mwH2GJGhLu088iewfAD59 
#undef  mQtvQSwrNiYvwhfS52Y03 
#undef  mfJD50JfpgrShRXqYhIZl 
#undef  mzmOqJvsTZVQidJCvDeGj 
#undef  mf83dcpJKOzkjjHopMCOV 
#undef  mEHzt2j27I_r9ArZFtU3k 
#undef  md3vd0U7tLQ6v9n8QKDU5 
#undef  mdhwTWTMu1icjDi9hfqlA 
#undef  ms27HQswJ5SXmPWrH4NWz 
#undef  mfFQARR3_tIZW5XTTQU1A 
#undef  mMrHUxwvIwBTwtW3jowYK 
#undef  m_XDfKwHIauqxlIfd7ek8 
#undef  mXNzU4nQb5cjZ5qt3FS1d 
#undef  mLnaLj_1Gbq0KlxM63ttX 
#undef  mfI5sjTcOplXcd7j6ZnOD 
#undef mRXwBwdyRkw7aKRylJs66ypo1B_m_0F
#undef  mlntG7S_lpYCVq4bRbYPo 
#undef  mPojCKJrQdGKYp70sKqT_ 
#undef  maSOhW6VVHr304WwlTjWn 
#undef  mALQrwGTaPCuUQpxn8goh 
#undef  mliO2qNZyubKtP7in1Ssn 
#undef  mbTkoiXVRfTqO3ABVKxa7 
#undef  mA69cEVFqqg0MTsOOvkJS 
#undef  mYdP8kipOkT4ieI5McrJa 
#undef  mtKX4jlpKTaFUkWN47ndG 
#undef  mMdziLP8WcbwaMcssN9B8 
#undef  mvkheICyC35AIAYDw4Zyq 
#undef  mctUyWmD0XJ5N4OQ9mZpY 
#undef  maeXo0rOyzBRmw_0Wa4Dh 
#undef  mFmcFT5tNPDxxtAQDRygO 
#undef mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA
#undef mqChal7Lpd5NyrwU9_65CoRxYpFEsER
#undef mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF
#undef  mbcrGRuvRtqW4iEXkTUcW 
#undef  mlnUl9HS21ij8prFFUOm9 
#undef mr_t0VU07rCpnf18ja3VQH4hAgihcOS
#undef  mrHATcpdatrnGgRa0FZRi 
#undef  mX_z0wj8ObIIq9af09sC0 
#undef  mWUCBzjZdDs5rjSUmVr1H 
#undef  mFmNeG2Rpi_LZC9ZW38ef 
#undef mqLVU73RNF9YUYdPCcll22ViBN9SF2U
#undef  mDYLg07CKdRe94Gq6NImk 
#undef  mJyzDEHjlSfqY7l1wMFeQ 
#undef  mY6tJ9W8wInfV4RYeEKp2 
#undef  mFY7zdHONGcRzFzoyY8kr 
#undef  mfJ2LcgqSYHSC2c1T7SAE 
#undef  mvrIbmYybi_XyoDIj5afd 
#undef  mozT9Zgu6ZTK3LKX60Y9X 
#undef mggutP_yHyWvu0Ekk1mwRC04lWUwd_m
#undef  mxsRDiqVXLBNzw01QQxKX 
#undef  mioXCuayzgDdWhSRWKLed 
#undef  mmCaJ3KGd7NNmPlcwQF1O 
#undef  mCFi9E_vI1Gu0XHzlnh_m 
#undef m_JXNpnZDnAp5khrQSXjapYF6lfAR0B
#undef  mJYtrRsE2uYggeWjY2LP3 
#undef  mtZx8lvascnf58_HYyrR_ 
#undef  mSFSgMrzYJ2aycmXuZ_UN 
#undef  mIDskT2Ezu2SmjrRoylFV 
#undef  mc_OCvzP6VsuLl8dMwGOm 
#undef  mh5qvlH8wVKxm6A4h6vev 
#undef mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2
#undef  mWx09TAhXLwzZg6gvY1wW 
#undef mtHrBAzZTGKvOl81mghBInh7SZskJmF
#undef  mStXIwIR8KAAv6ARccOAw 
#undef  mWtU95iFpkzn0xmGdbIAh 
#undef mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC
#undef  mzAHKEUDwtqpasfB_HPW3 
#undef  mgwxQeWxI56dH2g2_WWpD 
#undef mLjILzpM9YuUBIsOQCW3JTZ8vrgI7Ew
#undef  mUfPIu8Vb9gD5sEwHX4e5 
#undef  mh9e6vcSYz6HnQe4fqomg 
#undef  mAeOOYtJLjtiZrAejurqE 
#undef  mI91H7PcIeHOQZaA3fXOW 
#undef mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa
#undef  meRaDcNwfpCk5n9grUGX7 
#undef  mpnKBQc4vnaBXkhRtMEEp 
#undef m_5TwoouoplXp1WfLBglcjt1EhIy1BP
#undef  mUpFtzfKEDtly_CqCQ0PF 
#undef  mc3Hj19nsRMEiMbeHvUCU 
#undef  mpjzV4KZxaQDwr2r5URVi 
#undef  mTDBGBjeJLsSP8S0ojrcp 
#undef  miozH_cApnlsVVUTj7wmg 
#undef  myd6LkUouNB5_CBOoCU0P 
#undef  mphR03KjkbvJ9sy13EtjP 
#undef  mw7lfYFyssbL7Av32ucdk 
#undef mkyxRd57ezpBkOmagYqTAZD11hc5iiZ
#undef  mBuO1nGdSHpu4TSluhT4O 
#undef mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd
#undef  mdmgzNgGOQUa3qNC7dQN_ 
#undef  mlQdFjl0ooqvqHRZqYcyj 
#undef  mjS0lJNsw1G90SmlQY5qB 
#undef  mpCILpVV4vUBNDy5lSVOw 
#undef  mglJrCDsuRZOfs4rHlEmx 
#undef  mqefBAW94jsu9t4XeRAb4 
#undef  mzsVSfaoLsyM4zZT0WE0R 
#undef  mlV8Y9_shvYNeI5NWUEsQ 
#undef m_luBFxDlc6u5AWaSNY1d9c4swLNOfY
#undef  mvLHp90GrSnXD2Fr_yYfS 
#undef maEnSWEgWazQCv6CHPBdU1mwuubq_P5
#undef mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM
#undef  mOff4CUepSLCQVBkkB4bz 
#undef  mNMRj6wDhQ93dxqegLtvt 
#undef  mAYtYaN6dbp9zBOK9UF5z 
#undef  mjKATjaOSsq_6M1Yq0edS 
#undef  mBztK6cUpomzSRkmuQGnZ 
#undef  mIgPpecNCyRRT3HdGHUn4 
#undef  mcukTcF4A7NiUzDApj4RG 
#undef  mbKNUqK669FqBXCA3lJyM 
#undef  mTgzHHwnMyvSh5WWkkQS4 
#undef  mbDQ34yk53dYVGBc5ttxA 
#undef mKBHZJWEfbe20zc_948AG_nFL4Ai5rj
#undef  mzNO9uWo9w9JHl16INSLV 
#undef mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV
#undef  mWlpDId3FIhqgc7jVSsf3 
#undef  mdfThLoMV5tIdQ2swrG8L 
#undef  mmXXfYKCpX5tnhwHy0cga 
#undef  mLuiVq_3te7z9xsD97om2 
#undef  mh_eDgfDp08_MvU2cXe75 
#undef  mFbR2FVRb8mnXb2NxYr4v 
#undef  mhecrOoYCTyuTlKM26PxE 
#undef mJLrAGp8dQbittTYE_Ivmi_lBtah608
#undef  mZ6vZGHETO5UcSJpJp6N6 
#undef  mZzMXQdeguzHjXEXNO1QK 
#undef  mJe0oYBaM_aL82ifqLZxf 
#undef mid8aHTF65cJMaoUCgSTAguSfvQZEPI
#undef  mnnUjNItdkxSYMAOyNXJ4 
#undef  mT5wnqjLMSe3dhvAOfE8s 
#undef  mBRlQW2l1b4lBNK6gW3CP 
#undef  mA_9KI4DgbsDsYQAEgoY2 
#undef mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw
#undef  mvy4kfrik3LTb2UaVSo3v 
#undef  mewoJ48WbzL6zXIiSQBBU 
#undef  mJ9KJghgi70k5kym1xGdg 
#undef  mXx6k9ZG22M9fuTaNBTIc 
#undef mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy
#undef  mfLAQEin6tuee1y5ARv7i 
#undef  m_S9C9Y7k3GlCHSRI6FGL 
#undef  msGsNiQdWnMrcIqK9l52p 
#undef  mXhnm50_jYpsgSiCD7j2i 
#undef  mjkt5w2w1CPQA77xbaGHR 
#undef  mGzqmpNwk4mr3E0dvvjSM 
#undef mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK
#undef  mXveLotP6FhAl4PMM4j_S 
#undef  m_XaXsk15o_nT7QVQuKoA 
#undef  mtwGgc5GrChJ20supQjgN 
#undef  mcjLnHRwXSEJ2o4zZUusJ 
#undef  mD5B9pkA89EC4f1Qc82A5 
#undef  miWz_Ze4VI0S39LDIvV52 
#undef  mMTZq37nKqAui22kDhqeR 
#undef mMyvQy9EqcjbvEaQE_B0serMYsW_6c3
#undef  mepOW63ynkxIWHChbUIEj 
#undef  mQ1ZN9j2cHu8wO429pRIz 
#undef  mzitAd_hTqhzNCLjWYp1j 
#undef  mEfNmy3uLww0qsY8zk775 
#undef mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m
#undef  mJJ6iijAn8_6SlW8lFvD6 
#undef  mK8NxQzpqlpB0VMDVFXXW 
#undef  mw9jjid_2JyKztWEjEg1A 
#undef  mw0Dj_Yezs39GQeLmR7OY 
#undef  mV8SfHwiFeXXGt_yu3qHa 
#undef  mfPJMiSs5agSiG0ZqPxxR 
#undef  mYULjLQFJyrr4Q2mAhNNT 
#undef  mnhn7UL6et5NpOpJg8_3F 
#undef  mdeUvvdfSeGNTY1mHvR2j 
#undef  mQU6d0_1K0In64fJWtbiG 
#undef  mk1BJOHVaWt0_ucVb9zjh 
#undef  mocMt7k1d6hH36IrOJAqh 
#undef mX27P9WXq5drMAiURlKk0udqdeLbg7e
#undef  ma1lgnuL8HqB3QcBftqAb 
#undef  mtMAjwlPEjEFdJaEmSack 
#undef  mlm_9oXhlTuerkYDO2Ttt 
#undef  mkIRDfPZDhe1BVtFFdF1S 
#undef  mJobVgCApuWWKSDxZaaDN 
#undef mf5pjP0xaFTKIkU4XGsdg8688P96n1o
#undef m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN
#undef  mBzIPzCUkGzNHOHhJdtOo 
#undef  mkgznqllrZG0plUbFzXOi 
#undef  mfG5f3LQBIeimwuOnhtlH 
#undef  mQl2ldI2tj8cteuHkaRTS 
#undef mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ
#undef  m_4jN8sQ6DEmiIyaoBHT3 
#undef mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw
#undef  mhI91PnryIh5KGIgwPF6z 
#undef  mYO8W_MVWmBxye06RAssu 
#undef  mYqLYtnarrwfKPCZuAhAO 
#undef  mXXMimcHa_p5YaY4A3yKq 
#undef  mDKyMPGQYHeFqQcIiCmQ4 
#undef  mrowniYvbzUpleOokSjRY 
#undef  mULYTQpaey1FyazHeWxOh 
#undef  mODxb_fdZiIAsvJ8YUU1E 
#undef  mkiU7yX8zJtw_v46BRkzD 
#undef  mIuaYkUO_dkyAY1Wr_vDh 
#undef  myaJWyz9JD5MGaWvI0QFx 
#undef  mLrr0I4aMBrFW4U7lBkAH 
#undef  mj283d7HAayAVqS_PJAGf 
#undef  mbEo_Mk94ki_m4g3tTVoE 
#undef  mqDJjsFqDv3jM6v1jy6hs 
#undef  mpQF1UkY07SbDa13HMVXL 
#undef mKy8rw4xP4On93uCwHF4D2U62HCL3Io
#undef  mD9QkwifLlOs9pXc9J63h 
#undef  mlMERM1wFnAQtxwJQWQnC 
#undef mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f
#undef  mmIcWL3CRXYN7vGBrnWtP 
#undef  mI8eq3D_3tnA6CgHBUBue 
#undef mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR
#undef  mIaLxSop23sAP_vIqOnv1 
#undef  md3om5i8JMXvGl5JEe2Vu 
#undef  mMmWX8h7QqfSL9VSOlfNA 
#undef mFl0t8a00ojjudatDpPZsuu_Eq19F_n
#undef  mP3JqrbdyzkPpFAt_xYKB 
#undef  moanVKLjBkBg7dMlJPONL 
#undef  mKgHN3HY1bzeTSs1pEynF 
#undef  mW1HNzsoA3Q_zzpQgmLOJ 
#undef  mUTL6eJxLtsjrupXE2X81 
#undef  mZysRumux6MYdAiBN8m_6 
#undef  mMQ3ZxVrbLvUzSYMZleNY 
#undef  mcz9vG5JNpazF2dx78RRR 
#undef  mbkdZa3VP6wJBnBgkWY0T 
#undef  mFlcxzWknoLUXDpxe6_Je 
#undef  mf4DuSNLl0XPL3uNNL2rH 
#undef  mFHkCJmDB1L21SfZ1Pxoj 
#undef  mUvlnXTpeugHwHQHMzfZ0 
#undef miNghrPSTdiwFttm9u32tuKr6WWT7qI
#undef  ma8G1mxuzZkia5XUhr2Qx 
#undef  mZELcoRtBrp7Sft8tq6Ou 
#undef mOAryzLN3HVsT5qmgV2AkpTCYz_kbih
#undef  mSu4rh5czbliAfrWfnYhZ 
#undef  mvIxxyQb8LsZZhCMBaG8W 
#undef  ma3XrqU_S3mKrUh1JrWMu 
#undef  mPHKtUJ8uz46jwxT06PRH 
#undef  msWGAMn7MMcvcGOlXDrOU 
#undef  mHn9cGoFVoy7QSoSlfiah 
#undef  mQfZIJDgBU3BdGapYz1bV 
#undef  mDNV2FHy_lkQ7z6xqTf1l 
#undef  mP0pVwuZkPkvAuAdWvU4_ 
#undef  mSkvFMg6etBh7j0u9moo1 
#undef  mnzhaVe5dD1sSXD8Jge1e 
#undef  mIkFrTlZUNR1ErSGJVWAx 
#undef  mDDnm0lVEEXfpMuHGpj8g 
#undef  mFK6149xLldB4_yaXLtr9 
#undef  muqj3O4pxoCHIqQ5CZBHQ 
#undef  mu4ydSMiHEctax4kYVdb9 
#undef  mT2nbuAv30cuyUs8IHJny 
#undef  mf331x1xTK9tce2SlF0sr 
#undef  mCZ7sjmjv2BCj0YG4N3CG 
#undef  mEfikwAmC9bnMfEYbXO09 
#undef  mImOQ30xzOc_uNsHyP8iG 
#undef  msMWW0IQhVwqQ2YacqdgA 
#undef  mR8iByj9XMcGVN5u7YTSb 
#undef  mwA3oiyLhQkH3yLR5Li_g 
#undef  mJJA7PLbdXe2O1WRDb27F 
#undef  mwwc7bFP2zAqn3NWQGes3 
#undef  muwYtJb_5EG5b3vjnx3Cf 
#undef  mc1MFFMhQ7jVqBFJi9Nr3 
#undef  mTuUfWvG4K2bsU48V2zio 
#undef  mX5yd6fs3ig80svoLdcIe 
#undef  mQhFAFV1kXmW0_GxvR2MU 
#undef  mjLkzURBgb5j4kht4W_Zd 
#undef  m_8QOFZoAfV61xnNXIIpS 
#undef ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs
#undef mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe
#undef  mTfc0rqffOgoI2NHBOVxn 
#undef  mJFnvYYDXG7K4WBM5ACFP 
#undef  mUeX4f7PPnrxsqkCLt0EF 
#undef  mx2zEH0A38Vu06txsW4ce 
#undef  mJu7v95xnmVTk9dTlJ_7X 
#undef  mKjnEYQcGM3c5JLpihMiM 
#undef  mNDp5F8xkVrBXvD5gWOMK 
#undef  mdH_De6HWypwxBwHhRgi_ 
#undef  mjEFqg9MiDYQCsDmsCPzd 
#undef  mKToG9ROo9WUGKuycfIEh 
#undef m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ
#undef  ms7Jo9iQdD1ZZmNmk3a1e 
#undef  mQQ4_JXq5zIQzcr216CQM 
#undef  mPIAYksK3EcKmgJxbBzem 
#undef  m_mRKxCd12wCQvo6Wuw4S 
#undef  mQOrDnmnesi3Z_CeSFCDD 
#undef mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO
#undef  mdqghzFLKp4V4RmfR6N5Y 
#undef  mIBMllFEz9Ypr14f7K59G 
#undef  mY6Fre4Gb1htKl088hUat 
#undef  mgYUY_asiYZ_KoKWxX8ay 
#undef  mzjF8yGeGnLf_MyYFKQtg 
#undef mLmLxQimmNePFf0xuzaHFIcdzJBPG6e
#undef  mwlfRgKcuQknJqq6hUMLH 
#undef  mKZuT0uyFvPMYGXsafAjN 
#undef  mOqWQ9tXhWn2K_pjI6LPi 
#undef  myZa9IkYioVRg5FYLlaiO 
#undef mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN
#undef  mGTbUnMlsMqq6GhVnJ0hS 
#undef  mImWrs_HISgL5mOIzhWMU 
#undef  mFXRMwax4IeKL8bMO8alL 
#undef  mi0OK1qKXnOqyzpiMfAGY 
#undef  mUDC0uNfijVGKLtsMbFj6 
#undef  mrlcYflEp9xH4DwhHAWUs 
#undef  mT7IYtMHjxAUbRSF3WiYH 
#undef  meViGlslynNIAOuZbgJ_p 
#undef  mKmONRDV3IUoBl43lzUcW 
#undef  mR7mWPVa8MiSAgRfzG29b 
#undef  mkchMRxQpTPBDn9C571le 
#undef mynZZllKb44ONZwVsaeM7oF68mkvMxF
#undef  mnAwzWCKr4Ngi4iXzcGr8 
#undef  mjh0sa9bFWohEDiGYP1AK 
#undef  mpP2ijXZLFoSQTgzMxzKR 
#undef  mEcYfGz02eHy9i6Gsrslo 
#undef  mZIEX8Rqly8XLjMtgRxwo 
#undef  mjDWQpsL5G7AJJ8uckK28 
#undef  mZ82AM4h3bybtyqGC6Pmc 
#undef  mIF_WMyGU5Lcml6CnI6qJ 
#undef mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf
#undef  mcxtQXId4G3krUUn5jqav 
#undef  mAWuzTlg24YUBSoPsZ9vh 
#undef  myW2ZEtR0oj8fAEzMOKhf 
#undef  mFhEQbVP1lNGzbnF221nk 
#undef  mS8tKayqrnVhdPp9OTHYa 
#undef  mEFwg3vEAf3XVyaZqswfd 
#undef  mZHorJXpPCfTjWt6RV13U 
#undef  mRTf4mOIWnLDoCGKeVqsT 
#undef  mu2MzKUX2WOqiUPVfcF_k 
#undef  mjTTWGVy7GF1IXYDhoZE8 
#undef  mrIAD45ahQxB4XxHqS0oY 
#undef mPJErRyupABJq8s9bUtIn7GTWAGE9sm
#undef  mAEWaLnyn6TaDDpFZX0qM 
#undef  mMUQqv7FvvOeM8XxbXiVS 
#undef  mgJgPGKXuHawCrXU8Ico4 
#undef  mi1Q7duZPyUCvmYdi18Rr 
#undef mIEHEqU7E59VGmbUfQQSaBEACixI8KT
#undef  mhiwO1Skg6_RvJxulvkVn 
#undef  mFfNp9GHFFOrr0Ts67Gk0 
#undef  mb5PxDwPgyfZumEYuHMg_ 
#undef  mpPZZZbLtagf8omLASRfj 
#undef  mpURwZr6RkzcBE20jWxFb 
#undef  mGeQISP1_6bWC2BggNsHP 
#undef  mrlPjE0rBiYZu22PsGWYO 
#undef  mowjdPUwQBO8ke4dgrDbs 
#undef  mZ10R1pf0ctEfbjhQvbV8 
#undef mnRcrFlY2pRxaCpbt2ixOGHrHbidKsd
#undef msmJmE3BI9nTqPActW4WcrG4rKxB5za
#undef  mefjDpa1uzvEFh4mie_ed 
#undef  mDingNqrCQ45PwqQCEeZp 
#undef  meFrW56FKtDOIEsxZSBBd 
#undef  mTXFlCgqYmMgzfy59s6GB 
#undef mTdxd70lotLGo3DmCPBSaOO5WAEIgA4
#undef  mWXfXe51g9WAJ8QIohvis 
#undef  mabJg_wp04tpCSI7xI1Rk 
#undef  mHVC31pGMfJlHGtp4NgI9 
#undef  mIxlPIVpOuLHyQyNm0ihe 
#undef  mKst1rlMhDK1HGBpdPkyR 
#undef  mRKa8M3EpERyXIS4Rf5VN 
#undef  mQhUPedX62xqEPHfzQGcc 
#undef  mhQWrdtJCP8CtBdxGMq92 
#undef  mn3hAXUeOUwS6PfAoy0qU 
#undef  mZVcND24pRyHsiHHLYH0_ 
#undef mdq43P0warNCRS2zfOPZFhFeIoZUk8k
#undef  mEJ1Wmys3R7G4aUbtSDtJ 
#undef  mYrGZrWb07kXUx_r_u6l4 
#undef  mTvkQaeoomlJ_VTYKUxKs 
#undef  mm5aIJdLIBsAB77cxV436 
#undef  mdPVlh1hYUgUmjUgzk3Tg 
#undef mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI
#undef  mz45HxoFSkI70BknPihHQ 
#undef  mC08krF57_pyhCoe2ONfK 
#undef mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1
#undef  mcM8wZPr4Vtj58J5J7aRj 
#undef  mjuNTF9Txp7lPRofQiC2H 
#undef  mwr64HqIGhAhAgoAgEC9v 
#undef  mac1Y1_F_pN80Tywc7tSb 
#undef  mUAkJQHrQ7EZenDvUsmSU 
#undef  mTWjW0rpbdswTmzo8Z3LB 
#undef  mhk5uGUobIyf1xLEH_2bD 
#undef mwQNk6XWIL7WA81O03b1I9pWX7PNbFF
#undef  mCEQ0TEicvxnHNWNJj4it 
#undef  myJF7GpiX67xE_58NSAvN 
#undef  mOYKWpAyqxWO_GV2pYGCv 
#undef  mkhyx7xB8UcnN5cefHRjm 
#undef  mc651sVlXl9J65e77j2GS 
#undef  milBFUekrY6cYcZ1RQ3PZ 
#undef  m__TMRASLw93PPGE2yn7M 
#undef  mJCuTzDrLaCIb_4NcR6Pp 
#undef  mWX5gLI6KjLyLV2WAX5AE 
#undef  mVer_WamOoYy01Hwvga1p 
#undef  my4awox2tCnzHvXYtOI1H 
#undef miqVJ3bEFxKyuX8OX2N1uheDYf2htom
#undef  mNumnROIqNRPfMGdnOSdL 
#undef mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9
#undef mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo
#undef  mdBss3RRkpb7YIc0jMlr7 
#undef  mlyBoXug_w1GD49fr8e5z 
#undef  md6BvuIcgygpgfKlysgZJ 
#undef  mgmKNyQT_98kYMMsZi04t 
#undef mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x
#undef  mf7iqWeGGCD6aYpnxAcbn 
#undef  mTb1oltaFl_dANTG3sBsz 
#undef  meQKw5xOO97WFLVSiO_nA 
#undef  mtSiEKIxgJ6zdfdVVeElV 
#undef  mwnxVsUQpXrjB3ZuLLzI9 
#undef mHSId6f45t6UiNWMLtmYbe__RTBOjYn
#undef  mw1j28pJsrVGbBGyqXMF_ 
#undef  mP_bC3onF3BTl0J3VYWNw 
#undef  mP0yU3Y1ig5H5pZfFknTL 
#undef  mVnOY8YcCNILdUUkXbXrJ 
#undef  mg0PwPuKB6C7zRioyJn53 
#undef  mjIZeI_2FJbzRNDLoFbdQ 
#undef  mlXUQdlKoCAw7mj1xBwdu 
#undef  mMpkV46e5oVMOHQgQLmhH 
#undef  mmPyu4Xr9bvkikStyPb1K 
#undef  mzzWLGuJwRKKsLsF1T9l0 
#undef mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6
#undef  mpIxvxw4n63AIoOknaWlK 
#undef  miYxq_2sY3wPlGLLB52ri 
#undef  mq3dvPVyqQqzoivCNRbWr 
#undef  mHMHsPJzciJS12kVag5LO 
#undef mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y
#undef mhSri3zo8skOv0F7a_y2RVdEct4r117
#undef  mbt5SAyJ0i6W4bLawdt57 
#undef msk_FrOJpViselc2WPwu8pmFVqgnKM7
#undef  mCF9L9Vf7mnqETg9dtDIS 
#undef  mvHaWyT4_NbVmbaESYvT4 
#undef  mVfw6LLvSTbOwJ452n65F 
#undef  mKfil14pm2HQtt2J7Xh0t 
#undef mER9zKhVzbRXCJtJ3ghTAidOqKbAASN
#undef  mY0wzkY1CPIkMtQNAcAih 
#undef  mKaZdCTQiDOYndULWMefF 
#undef  mbHo0qB2zVKJgbcw5rqzf 
#undef  mMmT6oHofsd_MjGVNAWLf 
#undef  mammOMg1Em7gIMHty_XyS 
#undef  mH91xA57x3eJDeOPO6rru 
#undef  mNjYzzpcDr5hR8qGA_Fpu 
#undef  mD0IbSBwhOl7k23vsbh1D 
#undef mo5p_TjqasZCNRrNK8ihqOf98NylVc0
#undef  mwe8NMWXTOOJQZbLd8hd9 
#undef  mRMSNkyg2m73s2xgeT02S 
#undef  mnWe2WMZRc8fSBGNkevEY 
#undef  mvLno4xhrC1_3QBB0uaRG 
#endif

#ifdef _6297270708729154545
#undef  mw1j28pJsrVGbBGyqXMF_ 
#undef  mTDBGBjeJLsSP8S0ojrcp 
#undef  mTfc0rqffOgoI2NHBOVxn 
#undef  mQhUPedX62xqEPHfzQGcc 
#undef  mbkdZa3VP6wJBnBgkWY0T 
#undef maPJlF9eKfdZpUMBWRHkTrUBpKDJ0co
#undef  mTuUfWvG4K2bsU48V2zio 
#undef  mnAS51UogwBmVXrl9vmGJ 
#undef  mn3hAXUeOUwS6PfAoy0qU 
#undef mER9zKhVzbRXCJtJ3ghTAidOqKbAASN
#undef  mKgHN3HY1bzeTSs1pEynF 
#undef  mXoUt82ohV6cUrmrZvMYN 
#undef  mLrr0I4aMBrFW4U7lBkAH 
#undef  mqMqVRAd_aKvw7DAVTP2_ 
#undef  mfJD50JfpgrShRXqYhIZl 
#undef  mSu4rh5czbliAfrWfnYhZ 
#undef  mIkFrTlZUNR1ErSGJVWAx 
#undef mnTvtgRMn1TDHfrt2m9yChnXCtBJYwM
#undef mNpGy4cpAWZjLdRTMv9XrZjoteoC1c6
#undef mjwEUUCjtQgEnewvWx8fl4AQuuZ3bih
#undef  mHbaBgi1nxDavbkI8XP9n 
#undef  mnWe2WMZRc8fSBGNkevEY 
#undef  mgmKNyQT_98kYMMsZi04t 
#undef  mpo1ZqsJmgLR7QfLt2Svu 
#undef  mNumnROIqNRPfMGdnOSdL 
#undef  mUpFtzfKEDtly_CqCQ0PF 
#undef  mcjLnHRwXSEJ2o4zZUusJ 
#undef  mT5wnqjLMSe3dhvAOfE8s 
#undef  mRtOqOvSdgzN_V8FvpnHb 
#undef  mvLno4xhrC1_3QBB0uaRG 
#undef mSjwTpBwpgGbr5Ax3RpQbDxr2CDouAI
#undef  mJFnvYYDXG7K4WBM5ACFP 
#undef  mjkt5w2w1CPQA77xbaGHR 
#undef  mQU6d0_1K0In64fJWtbiG 
#undef mDHWpiI_tGXw6RzcfqVwptHtWJCC6Eg
#undef  mJYtrRsE2uYggeWjY2LP3 
#undef  maAB0ww2vPqS4fYcksIE4 
#undef mJfp6Kbni2Psqk2PTY_vMO1ffsYtNFk
#undef mHSId6f45t6UiNWMLtmYbe__RTBOjYn
#undef m_5TwoouoplXp1WfLBglcjt1EhIy1BP
#undef  mSFSgMrzYJ2aycmXuZ_UN 
#undef  ms6zRfqQITtRJuBxd7ez3 
#undef  mHVlQj0u7m3qO8vVCjWPY 
#undef  mmGgXpzWHS0goyBtjaUqC 
#undef  mTwOJQ81rZ7MRaawk9Uu9 
#undef  mPojCKJrQdGKYp70sKqT_ 
#undef  mKjnEYQcGM3c5JLpihMiM 
#undef  mdm8QhxsL_by8IUn_NfLe 
#undef  mfPJMiSs5agSiG0ZqPxxR 
#undef  mRQZ5PRNkTFHe67OFkdim 
#undef  mHn9cGoFVoy7QSoSlfiah 
#undef  mz45HxoFSkI70BknPihHQ 
#undef  mUeX4f7PPnrxsqkCLt0EF 
#undef  mOb1aYb7F6YnFLW0bMjfR 
#undef  mwA3oiyLhQkH3yLR5Li_g 
#undef  ms27HQswJ5SXmPWrH4NWz 
#undef mwZB7NdHw7ucAjdLBjDe38O1jGj0H0m
#undef  mefjDpa1uzvEFh4mie_ed 
#undef  mwe8NMWXTOOJQZbLd8hd9 
#undef mIEHEqU7E59VGmbUfQQSaBEACixI8KT
#undef  mjh0sa9bFWohEDiGYP1AK 
#undef  mf7iqWeGGCD6aYpnxAcbn 
#undef  mglJrCDsuRZOfs4rHlEmx 
#undef  mWO7OzY4w1RQi65oEUUsF 
#undef  mXjcKpRAn6nJd638eBBFR 
#undef mhaGaYHvbFNPYVNI5sXzSkuSOQG_LzV
#undef maXg6kKb6KP5M_pbADCJlzqNDlLgcew
#undef  mXNzU4nQb5cjZ5qt3FS1d 
#undef miNghrPSTdiwFttm9u32tuKr6WWT7qI
#undef  mUv5kY_Bm0YLXNMIvvPWg 
#undef mytEm5wA3qJhLdNxzOUPNkvvAX6w1gS
#undef  mbt5SAyJ0i6W4bLawdt57 
#undef  mTWjW0rpbdswTmzo8Z3LB 
#undef mqPbItOg03dxQmSR2Uk3fmpgZz_klvF
#undef  mnhn7UL6et5NpOpJg8_3F 
#undef  mGjhh4Vxe8OxVrJr0ifTO 
#undef  mqefBAW94jsu9t4XeRAb4 
#undef  mT2nbuAv30cuyUs8IHJny 
#undef  mTvkQaeoomlJ_VTYKUxKs 
#undef mKy8rw4xP4On93uCwHF4D2U62HCL3Io
#undef  mFlcxzWknoLUXDpxe6_Je 
#undef  mzzWLGuJwRKKsLsF1T9l0 
#undef  mD5B9pkA89EC4f1Qc82A5 
#undef  mmXXfYKCpX5tnhwHy0cga 
#undef  mlBMGNFS1VBnwA37erYVq 
#undef  mIgPpecNCyRRT3HdGHUn4 
#undef  mRsgOf47LQXIC7pqr3f_z 
#undef mO83cCL0HWrmZ4HQB2j8fjSwdJVwBAa
#undef  mXhnm50_jYpsgSiCD7j2i 
#undef mKBHZJWEfbe20zc_948AG_nFL4Ai5rj
#undef mJ47yGydM9YmPe4hychyfQA7aKca0Ad
#undef  mjMIjYcagrDIhgRHLBLJ7 
#undef  mKc5UWB3zedeuenjAQP3x 
#undef  mYm1jXwOzznj6v1tE5IOH 
#undef  mKdeu4SPbLs4BtwBBp5BV 
#undef  mzsVSfaoLsyM4zZT0WE0R 
#undef mGlUHuHNjQdSGPeFhZid3vDS8xVvCf9
#undef  mh9e6vcSYz6HnQe4fqomg 
#undef  mnzhaVe5dD1sSXD8Jge1e 
#undef  mbHo0qB2zVKJgbcw5rqzf 
#undef  mKZuT0uyFvPMYGXsafAjN 
#undef  mY0wzkY1CPIkMtQNAcAih 
#undef  mUDC0uNfijVGKLtsMbFj6 
#undef  mIhOz6EDelav78AgCeqLs 
#undef  mKbed25gQfvyglUad1I2k 
#undef  mGIrYNW2isKVFfktOjTqK 
#undef  mEHzt2j27I_r9ArZFtU3k 
#undef  mFXRMwax4IeKL8bMO8alL 
#undef  mnvogmkgJi8s_xT4F6F8R 
#undef  mPHKtUJ8uz46jwxT06PRH 
#undef  mEfNmy3uLww0qsY8zk775 
#undef mEj6iF5lrBKfIdU6V6VouIOzc1wCHHd
#undef  mACj5aDbo51D21ozBlOr3 
#undef  mR0HAl9a1y7f8gVhVfAwG 
#undef  mJJA7PLbdXe2O1WRDb27F 
#undef  mFmNeG2Rpi_LZC9ZW38ef 
#undef  mOYKWpAyqxWO_GV2pYGCv 
#undef  mXVgEuURMTp4fhE7NddKQ 
#undef  mBW3NFYv2beayxbQvFLGW 
#undef  mpURwZr6RkzcBE20jWxFb 
#undef  mBztK6cUpomzSRkmuQGnZ 
#undef  msvj1WdNRCWQnU7kPB8st 
#undef mggutP_yHyWvu0Ekk1mwRC04lWUwd_m
#undef  mbUT5LzRbyNtndMkZH0UT 
#undef  mtZx8lvascnf58_HYyrR_ 
#undef  mIPU11YvvW3aYEM3OeTXb 
#undef mEoWLo0rHg_8MZoqWhRgxUfPXDeA37x
#undef  milBFUekrY6cYcZ1RQ3PZ 
#undef  mkgznqllrZG0plUbFzXOi 
#undef  mi2B4Lz_N8qgRBsjRhZog 
#undef miqVJ3bEFxKyuX8OX2N1uheDYf2htom
#undef  mQtvQSwrNiYvwhfS52Y03 
#undef  mkiU7yX8zJtw_v46BRkzD 
#undef  mq7ITy8QmbBXM460Q_Xz5 
#undef  mUvlnXTpeugHwHQHMzfZ0 
#undef  mlm_9oXhlTuerkYDO2Ttt 
#undef mPvm6SUNl3QEbNWtKla3D_vB0HYM9an
#undef  mKfil14pm2HQtt2J7Xh0t 
#undef mqLVU73RNF9YUYdPCcll22ViBN9SF2U
#undef  mjuNTF9Txp7lPRofQiC2H 
#undef  mlMERM1wFnAQtxwJQWQnC 
#undef  mUfPIu8Vb9gD5sEwHX4e5 
#undef  mk1BJOHVaWt0_ucVb9zjh 
#undef  mKGCgkw_i3WVepYOOBV5x 
#undef  mMrHUxwvIwBTwtW3jowYK 
#undef  mjEFqg9MiDYQCsDmsCPzd 
#undef  mQy7Ve62WRZBxHgGipfE0 
#undef  mdBss3RRkpb7YIc0jMlr7 
#undef  msdXnwGLNioMb_WsjosEm 
#undef  mB3MiIZnjJO4hcfDJr7Fd 
#undef msmJmE3BI9nTqPActW4WcrG4rKxB5za
#undef  mLuiVq_3te7z9xsD97om2 
#undef  mpIxvxw4n63AIoOknaWlK 
#undef  mammOMg1Em7gIMHty_XyS 
#undef  mfI5sjTcOplXcd7j6ZnOD 
#undef  mSkvFMg6etBh7j0u9moo1 
#undef  mYbIeXvlXENIPQHHILIaB 
#undef  mabJg_wp04tpCSI7xI1Rk 
#undef  m__TMRASLw93PPGE2yn7M 
#undef  mbbDN_Rpy5B5MjStWvpqa 
#undef  mjDWQpsL5G7AJJ8uckK28 
#undef  mCF9L9Vf7mnqETg9dtDIS 
#undef  mVfw6LLvSTbOwJ452n65F 
#undef  mAeOOYtJLjtiZrAejurqE 
#undef maEnSWEgWazQCv6CHPBdU1mwuubq_P5
#undef  mjdKtLdSdZkJmraP0G2WP 
#undef  mJCDmcrP01LC6ub2hGy3o 
#undef  mSduIqcv605DvBK13Cm_Y 
#undef  mStXIwIR8KAAv6ARccOAw 
#undef  mctUyWmD0XJ5N4OQ9mZpY 
#undef  mhsVevT8PJMhDImpSwr4S 
#undef  mS8tKayqrnVhdPp9OTHYa 
#undef mPJErRyupABJq8s9bUtIn7GTWAGE9sm
#undef  mmro5kjl9hnK3vhryhusC 
#undef  mlQdFjl0ooqvqHRZqYcyj 
#undef mcAo0UW4qVlvhtzMG0Bhdx3zRIpkncd
#undef  mjSpE7GvJHAKhzusbafPB 
#undef  mOff4CUepSLCQVBkkB4bz 
#undef  mLnaLj_1Gbq0KlxM63ttX 
#undef  mvrIbmYybi_XyoDIj5afd 
#undef  mgZoaqza5nUMJX7kSjaPt 
#undef  mWx09TAhXLwzZg6gvY1wW 
#undef  mi1Q7duZPyUCvmYdi18Rr 
#undef  mALQrwGTaPCuUQpxn8goh 
#undef  mVrCPn74N7uV5WhnsGZJq 
#undef  mvLICAGv487TCIBPwRkax 
#undef  mZ6vZGHETO5UcSJpJp6N6 
#undef  mVnOY8YcCNILdUUkXbXrJ 
#undef  mcxtQXId4G3krUUn5jqav 
#undef mEqbSmgVZr5FajsveqAaosx7AnWiosb
#undef  mOcCrtCXPX_jF07MJcw9n 
#undef  mX5yd6fs3ig80svoLdcIe 
#undef  mFmcFT5tNPDxxtAQDRygO 
#undef  mw0Dj_Yezs39GQeLmR7OY 
#undef  mze0XvTZWjGhFxgMavYSK 
#undef mSOvZoTs4qjWxdPUtdRvFuEMDZojLt1
#undef  mtX8hC56Rij3zXBqmxZp8 
#undef  mHMHsPJzciJS12kVag5LO 
#undef  mpPZZZbLtagf8omLASRfj 
#undef  mImWrs_HISgL5mOIzhWMU 
#undef  mzNO9uWo9w9JHl16INSLV 
#undef  mqHTHqkaFbETBHVUoXJWE 
#undef  mf83dcpJKOzkjjHopMCOV 
#undef ma_6AaMG4oVDdRgZckTIN2jRcPD6CPs
#undef  mKToG9ROo9WUGKuycfIEh 
#undef  mtMAjwlPEjEFdJaEmSack 
#undef  mKbjkcrZ29WrTmHduNvYA 
#undef  mmIcWL3CRXYN7vGBrnWtP 
#undef  mbSdwawBuj90bQJR6WIph 
#undef mqChal7Lpd5NyrwU9_65CoRxYpFEsER
#undef  mImOQ30xzOc_uNsHyP8iG 
#undef  mvy4kfrik3LTb2UaVSo3v 
#undef  mdmgzNgGOQUa3qNC7dQN_ 
#undef  mv9B5FsaH2yXRdC540TI5 
#undef mr_t0VU07rCpnf18ja3VQH4hAgihcOS
#undef  mVer_WamOoYy01Hwvga1p 
#undef  mDDnm0lVEEXfpMuHGpj8g 
#undef  mFHkCJmDB1L21SfZ1Pxoj 
#undef  mepOW63ynkxIWHChbUIEj 
#undef myb8XWBN13SLgutfqt0dbdsZb3LhWzd
#undef mc6ey8JP5wxFPeVHpauPjSzVHxKbw5f
#undef  mphR03KjkbvJ9sy13EtjP 
#undef  mDKyMPGQYHeFqQcIiCmQ4 
#undef mBfdC3RvE5q8V72Y_wb_xUIBRbbM6A8
#undef  mk8wKFOnj49iAJd4aDkZt 
#undef  mCrMF6fE7ESIHQFH0dEIJ 
#undef mynZZllKb44ONZwVsaeM7oF68mkvMxF
#undef  mOqWQ9tXhWn2K_pjI6LPi 
#undef  mG7pANqob65nAnzu7i4jI 
#undef  mK8NxQzpqlpB0VMDVFXXW 
#undef  mRMSNkyg2m73s2xgeT02S 
#undef  mJu7v95xnmVTk9dTlJ_7X 
#undef mvYR7E2fPBfRtqmwTWZPdqOIYPrOMdy
#undef mVTS8oESL9lQLyoGWfsnjqn4E4P7nFA
#undef  mP3JqrbdyzkPpFAt_xYKB 
#undef  mjKATjaOSsq_6M1Yq0edS 
#undef  mlKS3U9iIvrKxK25CSDB4 
#undef  mpCILpVV4vUBNDy5lSVOw 
#undef  moxVzlkRFdhpZIl6K380D 
#undef mRjUl0ZokWDm2XjUj4PfGoKZXq2nSHo
#undef  mxsRDiqVXLBNzw01QQxKX 
#undef  mu4GMnrSgnNZH5KkWj0cs 
#undef  mMTZq37nKqAui22kDhqeR 
#undef  mBzIPzCUkGzNHOHhJdtOo 
#undef  mY1nnZpqGLf_KAJGU2cEj 
#undef  mliO2qNZyubKtP7in1Ssn 
#undef  mEoyyspRNdei6c_EzFQhy 
#undef mHkoiNP3iqdLbzVDX73gnq6piKxsrhA
#undef  mYdP8kipOkT4ieI5McrJa 
#undef  mX08yh_QwWY_mAf7x8k_Y 
#undef  mlntG7S_lpYCVq4bRbYPo 
#undef  mY6Fre4Gb1htKl088hUat 
#undef  mc1MFFMhQ7jVqBFJi9Nr3 
#undef mNTw8HzUNkW8_DTYH4gpwL7LUaQMKKf
#undef  mMQ3ZxVrbLvUzSYMZleNY 
#undef  ma3XrqU_S3mKrUh1JrWMu 
#undef mJhu6CSnZIpieqAeqBVC1ZgULgsgbvF
#undef  m_XaXsk15o_nT7QVQuKoA 
#undef  mrlPjE0rBiYZu22PsGWYO 
#undef mY4WhpBcs7WmAqa0zcNeFDZuTLuz6WJ
#undef mid8aHTF65cJMaoUCgSTAguSfvQZEPI
#undef  mJobVgCApuWWKSDxZaaDN 
#undef  mh5qvlH8wVKxm6A4h6vev 
#undef  m_XDfKwHIauqxlIfd7ek8 
#undef  ms7Jo9iQdD1ZZmNmk3a1e 
#undef  mNjYzzpcDr5hR8qGA_Fpu 
#undef mkyxRd57ezpBkOmagYqTAZD11hc5iiZ
#undef mtHrBAzZTGKvOl81mghBInh7SZskJmF
#undef  mJ9KJghgi70k5kym1xGdg 
#undef m_eGsmUD3s_a5BTZPIXLXayIuh12MHZ
#undef  mQfZIJDgBU3BdGapYz1bV 
#undef  my4awox2tCnzHvXYtOI1H 
#undef  mNMRj6wDhQ93dxqegLtvt 
#undef  mu2MzKUX2WOqiUPVfcF_k 
#undef  maSOhW6VVHr304WwlTjWn 
#undef  mKaZdCTQiDOYndULWMefF 
#undef m_p9dJmy7MtOWasmmBFNqPPOUwBAjqN
#undef  mMpkV46e5oVMOHQgQLmhH 
#undef  mYqLYtnarrwfKPCZuAhAO 
#undef  mtwGgc5GrChJ20supQjgN 
#undef  mAWuzTlg24YUBSoPsZ9vh 
#undef  mrJP7yXQ3gfs8BNPhcKEy 
#undef  mIDskT2Ezu2SmjrRoylFV 
#undef  mgJgPGKXuHawCrXU8Ico4 
#undef  msGsNiQdWnMrcIqK9l52p 
#undef  mRKa8M3EpERyXIS4Rf5VN 
#undef  mozT9Zgu6ZTK3LKX60Y9X 
#undef  md3om5i8JMXvGl5JEe2Vu 
#undef  mpQF1UkY07SbDa13HMVXL 
#undef  mgE4qbPnyXc3efkHO82jq 
#undef  mQl2ldI2tj8cteuHkaRTS 
#undef  mWpzfBNpgUkhHKOjjpigm 
#undef  mfG5f3LQBIeimwuOnhtlH 
#undef  mTNOuXm2Jm9miwDjb5tyx 
#undef  mI8eq3D_3tnA6CgHBUBue 
#undef  mmCaJ3KGd7NNmPlcwQF1O 
#undef mKBuDAbPqCcuG_1Ra28WhiQTWI8XNHu
#undef  mKst1rlMhDK1HGBpdPkyR 
#undef  mMdziLP8WcbwaMcssN9B8 
#undef  m_mRKxCd12wCQvo6Wuw4S 
#undef  mfLAQEin6tuee1y5ARv7i 
#undef mBd8bjjabZx94F_kT0x5xvZkQ8gF1cw
#undef  mu4ydSMiHEctax4kYVdb9 
#undef  mbDQ34yk53dYVGBc5ttxA 
#undef  mXN4CKvjNXNZl7HvRiZco 
#undef  mwXriqi6ed862tk3jeahD 
#undef  mR7mWPVa8MiSAgRfzG29b 
#undef  mZVcND24pRyHsiHHLYH0_ 
#undef  mWX5gLI6KjLyLV2WAX5AE 
#undef  meQKw5xOO97WFLVSiO_nA 
#undef mfjRPTOF4giaARD6lhoMVLbGOxFWm8T
#undef  mq9TrLjBjxHKe3exYN9eE 
#undef  mNDp5F8xkVrBXvD5gWOMK 
#undef  mA2iqL31fN9OUGw4jozAN 
#undef  my24077tijd722rF1VIYj 
#undef  mjS0lJNsw1G90SmlQY5qB 
#undef  mvJCJ8LrCi0JO7BsL7cgO 
#undef  mL3pQ2P5JemQ53ZNDgnYJ 
#undef mJmLMshPna77IHase49uXfPadGq2sqg
#undef  mfJ2LcgqSYHSC2c1T7SAE 
#undef  mi1E1JOOoJBHvNwXGlNZP 
#undef  mLJPu8lXj19Fryu1ZZwyB 
#undef  muwYtJb_5EG5b3vjnx3Cf 
#undef  mwnxVsUQpXrjB3ZuLLzI9 
#undef  mc_OCvzP6VsuLl8dMwGOm 
#undef  mZELcoRtBrp7Sft8tq6Ou 
#undef  mIaLxSop23sAP_vIqOnv1 
#undef  meFrW56FKtDOIEsxZSBBd 
#undef  maeXo0rOyzBRmw_0Wa4Dh 
#undef  mJe0oYBaM_aL82ifqLZxf 
#undef  mBK4AfDd6rNwliYNVDno6 
#undef  mdeUvvdfSeGNTY1mHvR2j 
#undef  mDBb_5ji8TzqfiVcwoXmy 
#undef  mdPVlh1hYUgUmjUgzk3Tg 
#undef  mhecrOoYCTyuTlKM26PxE 
#undef  mD0IbSBwhOl7k23vsbh1D 
#undef  mrIAD45ahQxB4XxHqS0oY 
#undef  mGRuvgzGl9XlDtmWWPeUK 
#undef  mZtAmBsslWUS22rG8kZ1b 
#undef mAvTK0fLYBO1PwbzhDC7l4LUJlT5i3u
#undef  mdqghzFLKp4V4RmfR6N5Y 
#undef mIMxRDtqylgzeGWrcJW8ELWfdUyNJ1Y
#undef  mC08krF57_pyhCoe2ONfK 
#undef  mdaCm9YE4t6O8fELFMMu4 
#undef  mdhwTWTMu1icjDi9hfqlA 
#undef  myW2ZEtR0oj8fAEzMOKhf 
#undef  mXveLotP6FhAl4PMM4j_S 
#undef  mQXJkXZ92dFmt3nhFohj7 
#undef  mkhyx7xB8UcnN5cefHRjm 
#undef  md3vd0U7tLQ6v9n8QKDU5 
#undef  mDNV2FHy_lkQ7z6xqTf1l 
#undef  mYULjLQFJyrr4Q2mAhNNT 
#undef  mPIAYksK3EcKmgJxbBzem 
#undef  moanVKLjBkBg7dMlJPONL 
#undef  mDXBwAJFHOvHVaiZ7AF_H 
#undef  mw7lfYFyssbL7Av32ucdk 
#undef  mbEo_Mk94ki_m4g3tTVoE 
#undef  mJJ6iijAn8_6SlW8lFvD6 
#undef  mP0yU3Y1ig5H5pZfFknTL 
#undef  mUAkJQHrQ7EZenDvUsmSU 
#undef  mDYLg07CKdRe94Gq6NImk 
#undef  mCZ7sjmjv2BCj0YG4N3CG 
#undef  mF69qLuHuU1JWaGCkeIPC 
#undef  mlnUl9HS21ij8prFFUOm9 
#undef  ma6S6MAu1NwBvwcsRucH2 
#undef  mFfNp9GHFFOrr0Ts67Gk0 
#undef  mZrbyqxLBc0k3KIuHGEQ7 
#undef  mhKjc0R9XSbNgt_iqsmxH 
#undef  mbcrGRuvRtqW4iEXkTUcW 
#undef  myZa9IkYioVRg5FYLlaiO 
#undef  myd6LkUouNB5_CBOoCU0P 
#undef  mBRlQW2l1b4lBNK6gW3CP 
#undef mMXjdiIeIvGA_jW3bUAjlYbzT09U4a8
#undef  myaJWyz9JD5MGaWvI0QFx 
#undef  mx2zEH0A38Vu06txsW4ce 
#undef  mGTbUnMlsMqq6GhVnJ0hS 
#undef  mULYTQpaey1FyazHeWxOh 
#undef  mK9iBInm1aQyyeRIM6ZeG 
#undef  mZysRumux6MYdAiBN8m_6 
#undef  mjIZeI_2FJbzRNDLoFbdQ 
#undef  mcM8wZPr4Vtj58J5J7aRj 
#undef  mzjF8yGeGnLf_MyYFKQtg 
#undef  mXDDzvxmbbYJFWCaREXxP 
#undef  mXXMimcHa_p5YaY4A3yKq 
#undef  mI91H7PcIeHOQZaA3fXOW 
#undef  mr535LNebOcWpbsHNcM4a 
#undef  mEcYfGz02eHy9i6Gsrslo 
#undef  mQhFAFV1kXmW0_GxvR2MU 
#undef  mAEWaLnyn6TaDDpFZX0qM 
#undef mJLrAGp8dQbittTYE_Ivmi_lBtah608
#undef  mpHrH5FQw2SHugb9qnWzf 
#undef  mwr64HqIGhAhAgoAgEC9v 
#undef  mrHATcpdatrnGgRa0FZRi 
#undef  msfuU7ZJA0EB9ByaYzGjN 
#undef  mdR4KdDQS_UNB8q5GwCTp 
#undef  mlV8Y9_shvYNeI5NWUEsQ 
#undef  mw8os29O3XjXaPwf0zALv 
#undef  mPJnJSYXLmdIbnFUwNHSF 
#undef  mz9o7QRiicNuHtnBEMOD7 
#undef  meVfpMBWdlHHiNPtZOu97 
#undef  mZHorJXpPCfTjWt6RV13U 
#undef  mQOrDnmnesi3Z_CeSFCDD 
#undef mmfFwPQA1xPQv6ZDDj4T71WKygJoUng
#undef  m_S9C9Y7k3GlCHSRI6FGL 
#undef mtZ5IYPsC48lZ1JYvHaN23szjFLc2Gm
#undef  mcFBvJvXtblQX6Fg2ApcE 
#undef  mEJ1Wmys3R7G4aUbtSDtJ 
#undef mLmLxQimmNePFf0xuzaHFIcdzJBPG6e
#undef  mMGUXQCWK2DVivHkk30Vn 
#undef  mCFi9E_vI1Gu0XHzlnh_m 
#undef mcvKqpkN2y7JIKLCiXlwOJ0TMEaRIy1
#undef  mW1HNzsoA3Q_zzpQgmLOJ 
#undef  mIBMllFEz9Ypr14f7K59G 
#undef  mq3dvPVyqQqzoivCNRbWr 
#undef  miozH_cApnlsVVUTj7wmg 
#undef  mSE0j7t7H5EAb_ZhVdwIK 
#undef  mcukTcF4A7NiUzDApj4RG 
#undef  mhiwO1Skg6_RvJxulvkVn 
#undef  mMUQqv7FvvOeM8XxbXiVS 
#undef  mnAwzWCKr4Ngi4iXzcGr8 
#undef  mXx6k9ZG22M9fuTaNBTIc 
#undef  mj283d7HAayAVqS_PJAGf 
#undef  mCEQ0TEicvxnHNWNJj4it 
#undef  mIuaYkUO_dkyAY1Wr_vDh 
#undef mjnri6rX_vZR2Pp9q_nBXyKKO6_IAEe
#undef  mJuc8ZstMJCWG5iyEXaN3 
#undef  mhI91PnryIh5KGIgwPF6z 
#undef  magXSvaK7SHbBe_LkH4_4 
#undef  mQQ4_JXq5zIQzcr216CQM 
#undef  mtKX4jlpKTaFUkWN47ndG 
#undef  mR8iByj9XMcGVN5u7YTSb 
#undef  mVM3Tnyk6EGttlw0sJM0s 
#undef  miWz_Ze4VI0S39LDIvV52 
#undef mLjILzpM9YuUBIsOQCW3JTZ8vrgI7Ew
#undef m_luBFxDlc6u5AWaSNY1d9c4swLNOfY
#undef  mwa5remO28hlDpKwcBBWS 
#undef  mBuO1nGdSHpu4TSluhT4O 
#undef  mm5aIJdLIBsAB77cxV436 
#undef  mqoMxZnTfbfYBoTn0nJV8 
#undef mTMfRS5ewcfc3W1h0OyUUH2Y4h830Fw
#undef mxIeE1mUCaRPVIx9nKzcBTKvvjn9WOK
#undef mFl0t8a00ojjudatDpPZsuu_Eq19F_n
#undef  mrlcYflEp9xH4DwhHAWUs 
#undef  mac1Y1_F_pN80Tywc7tSb 
#undef mhSri3zo8skOv0F7a_y2RVdEct4r117
#undef  m_7xnaPD2PNoybbmxMeJM 
#undef  msMWW0IQhVwqQ2YacqdgA 
#undef  mkchMRxQpTPBDn9C571le 
#undef  mWtU95iFpkzn0xmGdbIAh 
#undef  mFY7zdHONGcRzFzoyY8kr 
#undef  mfFQARR3_tIZW5XTTQU1A 
#undef  msWGAMn7MMcvcGOlXDrOU 
#undef  miHDLzVSKvARra6Y01hWr 
#undef  mUYrvQEzcig7b1zvxhPy1 
#undef  mAaJU5xxEW1CYbXZQizTM 
#undef  mvmm5bcQmzwx8NHg0XtMY 
#undef  mIF_WMyGU5Lcml6CnI6qJ 
#undef  mhQWrdtJCP8CtBdxGMq92 
#undef  mHlO3rVlumDU7QarN5DVh 
#undef  mvaG5Eyy4oCUwLhlO56Fm 
#undef  mrpUZcBGxsetRWKsiyWx4 
#undef  mWXfXe51g9WAJ8QIohvis 
#undef  mdH_De6HWypwxBwHhRgi_ 
#undef  m_BdtoOIG1cGfXQ010uG9 
#undef  mUXFYtjkeWrs0H7mYy9Zz 
#undef  m_aLkQCeXTOJC9TSYHqNk 
#undef  mwC8XLCAtchCv5UC_siZu 
#undef mRXwBwdyRkw7aKRylJs66ypo1B_m_0F
#undef mwQNk6XWIL7WA81O03b1I9pWX7PNbFF
#undef  mvkheICyC35AIAYDw4Zyq 
#undef  ma74Qo28qWqot2ZIS3Fyr 
#undef  mfMwn8m1i5quGvbIlKykw 
#undef  mZzMXQdeguzHjXEXNO1QK 
#undef  mf6BXrh_hM3Lu_j1rlwq1 
#undef  mHVC31pGMfJlHGtp4NgI9 
#undef  mnnUjNItdkxSYMAOyNXJ4 
#undef  mOYUL6jMctMmuYeHFSDLp 
#undef  mRTf4mOIWnLDoCGKeVqsT 
#undef  muqj3O4pxoCHIqQ5CZBHQ 
#undef  mE0vjCGwyO_EuShAyS8iC 
#undef  mioXCuayzgDdWhSRWKLed 
#undef mGVKUs9jC7o3sD5dqth2dlNDrpUR4HI
#undef mXU8DBzbHp_XwhfjB2W__CHUJU3lNz9
#undef  msneHAqwwPFAFhfiPn59i 
#undef mZ3fsRygWUthLiMoQkG6GqhUcJ1jtXR
#undef  mf331x1xTK9tce2SlF0sr 
#undef  mP_bC3onF3BTl0J3VYWNw 
#undef mVCUn3Q_wEgLlBrjpdJTsgM9zdYINVf
#undef  mA_9KI4DgbsDsYQAEgoY2 
#undef  mFk9QjJB88E3T3eqrw6Hk 
#undef  mA69cEVFqqg0MTsOOvkJS 
#undef mAMDw3_zRMVylvtXnIjBsVy3Dy3HHW2
#undef  mrowniYvbzUpleOokSjRY 
#undef  mYO8W_MVWmBxye06RAssu 
#undef  mc651sVlXl9J65e77j2GS 
#undef  mpjzV4KZxaQDwr2r5URVi 
#undef  mewoJ48WbzL6zXIiSQBBU 
#undef msk_FrOJpViselc2WPwu8pmFVqgnKM7
#undef  mjLkzURBgb5j4kht4W_Zd 
#undef  mwH2GJGhLu088iewfAD59 
#undef mllTE_QcE8U1uguTDh7N5Erewe_C598
#undef  mZHPxe26JeGM_JP2l8E3l 
#undef  mZ10R1pf0ctEfbjhQvbV8 
#undef  mKmONRDV3IUoBl43lzUcW 
#undef  mJyzDEHjlSfqY7l1wMFeQ 
#undef mGHVg_EvjRJMCzbzPwM_oWhQ2g2E3EH
#undef  mEfikwAmC9bnMfEYbXO09 
#undef mMyvQy9EqcjbvEaQE_B0serMYsW_6c3
#undef  mYrGZrWb07kXUx_r_u6l4 
#undef mmgQbvD6YBazEyvBQQSyd2xn8PnNxWF
#undef  mIxlPIVpOuLHyQyNm0ihe 
#undef  mAYtYaN6dbp9zBOK9UF5z 
#undef mJsm1RqY_WmLLmuNKAKTsJcYY_tbThg
#undef  mocMt7k1d6hH36IrOJAqh 
#undef  m_599PypIhfUF_mW7eHRN 
#undef  mUFbkQ4Dp7BOF3JOKxO7r 
#undef  mnqFMJGRhgjvp_pZ5IOOv 
#undef  mutBU3VL4kbmyoDhYw433 
#undef  mf8y3OBUdXH2bvxPyg_r7 
#undef  mGU1ngQr7JiLginN19yJQ 
#undef  mJoyyUKrNBL6Ql5t_pTvk 
#undef  muiH2m02EdZG3W26VSQSN 
#undef  mt8L46vdf60jtmGev7NhD 
#undef  mUTL6eJxLtsjrupXE2X81 
#undef  mgK1nBhC8d0CONy9jztqh 
#undef  mHRtOIH8m5To877qqzoRn 
#undef  mrGyaUsf1rTFyLHAMEVqr 
#undef  mMmT6oHofsd_MjGVNAWLf 
#undef  mFhEQbVP1lNGzbnF221nk 
#undef  m_QQCR7XByf2N0sZhsT1N 
#undef  mg0PwPuKB6C7zRioyJn53 
#undef  mH91xA57x3eJDeOPO6rru 
#undef mjg3ngTrSeMroQmmFJXlrkzbIz5nuKE
#undef mf5pjP0xaFTKIkU4XGsdg8688P96n1o
#undef mo5p_TjqasZCNRrNK8ihqOf98NylVc0
#undef  mwlfRgKcuQknJqq6hUMLH 
#undef  mlyBoXug_w1GD49fr8e5z 
#undef mXnQZ4kZQhlsyrGYSEbWYd0kcXm7793
#undef  mP0pVwuZkPkvAuAdWvU4_ 
#undef  mZ82AM4h3bybtyqGC6Pmc 
#undef  ma1lgnuL8HqB3QcBftqAb 
#undef  mbKNUqK669FqBXCA3lJyM 
#undef  meRaDcNwfpCk5n9grUGX7 
#undef  mh_eDgfDp08_MvU2cXe75 
#undef  mcz9vG5JNpazF2dx78RRR 
#undef  mWofT82dkoxcrXjA4clne 
#undef  mdUlEEbPea1atW0GHbpNZ 
#undef  mliwe0HGLMppNs2ic2StI 
#undef mNFG8Iso0GyM1QxBQc0Jyx2CNIZNkqC
#undef  mvIxxyQb8LsZZhCMBaG8W 
#undef  mV8SfHwiFeXXGt_yu3qHa 
#undef  mSKSlQP3SrmyO06AafLZj 
#undef mX27P9WXq5drMAiURlKk0udqdeLbg7e
#undef  m_8QOFZoAfV61xnNXIIpS 
#undef  mvLHp90GrSnXD2Fr_yYfS 
#undef  mGeQISP1_6bWC2BggNsHP 
#undef  mUXzfsBItfAkAJO_t7lfO 
#undef mkRUxHdAiLuPhrYgOcjXJqXOpS5nSfL
#undef  mtWEyCsPBvsskTgpOAqp1 
#undef  mWlpDId3FIhqgc7jVSsf3 
#undef  myJF7GpiX67xE_58NSAvN 
#undef  mfwb3_g4Sz8VqjsiIbIvG 
#undef mdq43P0warNCRS2zfOPZFhFeIoZUk8k
#undef  mNRyjOhB7Dxhr5nSwV35B 
#undef  mbTkoiXVRfTqO3ABVKxa7 
#undef  mY6tJ9W8wInfV4RYeEKp2 
#undef  mEFwg3vEAf3XVyaZqswfd 
#undef  mgwxQeWxI56dH2g2_WWpD 
#undef  mTXFlCgqYmMgzfy59s6GB 
#undef  mwwc7bFP2zAqn3NWQGes3 
#undef  mJCuTzDrLaCIb_4NcR6Pp 
#undef  md6BvuIcgygpgfKlysgZJ 
#undef  mi0OK1qKXnOqyzpiMfAGY 
#undef  mpnKBQc4vnaBXkhRtMEEp 
#undef  mzAHKEUDwtqpasfB_HPW3 
#undef  mGzqmpNwk4mr3E0dvvjSM 
#undef  mFbR2FVRb8mnXb2NxYr4v 
#undef mTdxd70lotLGo3DmCPBSaOO5WAEIgA4
#undef  mI_VxTqt1y9E8RYyv32oX 
#undef  mT7IYtMHjxAUbRSF3WiYH 
#undef  ma8G1mxuzZkia5XUhr2Qx 
#undef  mjTTWGVy7GF1IXYDhoZE8 
#undef m_JXNpnZDnAp5khrQSXjapYF6lfAR0B
#undef  miYxq_2sY3wPlGLLB52ri 
#undef  mqEhfU__oa9DCvMpGl7xD 
#undef  m_V14bOiRiIxDrlTqWYtS 
#undef  mQ1ZN9j2cHu8wO429pRIz 
#undef  mdfThLoMV5tIdQ2swrG8L 
#undef  mhCfBMV_sTdybeorCIcWK 
#undef  mf4DuSNLl0XPL3uNNL2rH 
#undef  mTb1oltaFl_dANTG3sBsz 
#undef  mm1GYvBFNYJsFht34T1x4 
#undef  mb5PxDwPgyfZumEYuHMg_ 
#undef mEyhT9t8n7EVIB2KK4b8DaZ9axjth2T
#undef  mlXUQdlKoCAw7mj1xBwdu 
#undef mjuwmJ_pEYJqIN1SIIdt8XEAqJy5vyN
#undef  mowjdPUwQBO8ke4dgrDbs 
#undef  mitZZIhLsWsu9skRw1jFj 
#undef mOAryzLN3HVsT5qmgV2AkpTCYz_kbih
#undef  mvcFLyGSLDfAyP0Jpx19q 
#undef  mtSiEKIxgJ6zdfdVVeElV 
#undef  mqDJjsFqDv3jM6v1jy6hs 
#undef mnRcrFlY2pRxaCpbt2ixOGHrHbidKsd
#undef  mzitAd_hTqhzNCLjWYp1j 
#undef  mWUCBzjZdDs5rjSUmVr1H 
#undef  mX_z0wj8ObIIq9af09sC0 
#undef  mMmWX8h7QqfSL9VSOlfNA 
#undef  mcWvQOF1cx6ayOeD120aY 
#undef  mgYUY_asiYZ_KoKWxX8ay 
#undef  mDingNqrCQ45PwqQCEeZp 
#undef  mmPyu4Xr9bvkikStyPb1K 
#undef  mGPli8AOiz4d5L9v8Yrp_ 
#undef  mcmHAJZwf8LvY5eozlZjb 
#undef mrBOj_dqOG8M7DUjNzuOchGnNCkB5NO
#undef  mpP2ijXZLFoSQTgzMxzKR 
#undef  mhk5uGUobIyf1xLEH_2bD 
#undef  mTgzHHwnMyvSh5WWkkQS4 
#undef  mw9jjid_2JyKztWEjEg1A 
#undef  mkIRDfPZDhe1BVtFFdF1S 
#undef  mzmOqJvsTZVQidJCvDeGj 
#undef  mDOtyv4fPSDYxOiDLEl95 
#undef  mvHaWyT4_NbVmbaESYvT4 
#undef  mFK6149xLldB4_yaXLtr9 
#undef  mD9QkwifLlOs9pXc9J63h 
#undef  m_4jN8sQ6DEmiIyaoBHT3 
#undef  mc3Hj19nsRMEiMbeHvUCU 
#undef  mZIEX8Rqly8XLjMtgRxwo 
#undef  mV_JO_GYxvSxhU4uLY1OM 
#undef  mODxb_fdZiIAsvJ8YUU1E 
#undef  meViGlslynNIAOuZbgJ_p 
#endif
