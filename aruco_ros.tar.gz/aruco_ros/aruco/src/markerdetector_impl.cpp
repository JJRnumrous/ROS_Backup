#ifndef _3643599497981880515
#define  muh3toWhBpay0OfyCHmRI  m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(9,X,w,2,_,S,*,:,:,w,h,3,!,t,i,8,t,n,u,2)
#define  mCBPKKFCRSbvDkZsS_B45  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(!,k,e,-,9,],z,U,/,v,^,b,H,Y,a,I,Z,M,!,r)
#define  maSZLm7xL0jGtxyrdwaul  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(W,A,z,z,_,.,*,7,C,v,z,u,t,:,v,R,~,.,+,u)
#define  mmB6x9VkGrq_qpFtMKL7A  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(t,5,{,r,O,E,t,7,7,w,},/,:,c,+,s,u,/,v,:)
#define  mriCvhMavpfheoLNc0eCD  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(_,U,a,X,;,j,d,c,+,N,{,+,m,i,h,I,],[,k,q)
#define  ma6VjqdfajK4BX9gkoGiD  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(T,2,y,.,G,[,a,l,s,D,4,Z,q,H,W,=,:,+,x,S)
#define  m_Bc574zvmsa5bmM8Ay7H  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(z,-,n,t,^,U,t,g,:,+,E,M,c,H,6,9,P,Q,-,L)
#define  mtDHooAMb6ubWraYLa7pj  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(:,P,-,],t,:,U,!,-,J,A,L,=,i,k,Z,-,A,7,!)
#define  mgor9wB6mrVARR8vJt7rC  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(4,q,E,r,_,-,{,u,e,7,O,Y,N,[,t,+,5,R,B,0)
#define  mRltbJjpZ8AzImbP6r6M4  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(W,+,U,1,{,X,p,g,F,^,!,^,:,X,b,J,W,w,e,O)
#define  mabeHDqoCFUg5Mty5oLni  mztFjkqY05BHqxhJraeJTl0p2s3heFu(},J,*,2,3,i,f,y,R,[,d,Z,L,3,c,s,L,R,J,a)
#define  m_BNZbnU2Y1bOBnnPOF0b  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(o,V,.,G,r,[,4,N,:,r,P,U,:,},^,i,w,3,f,g)
#define  maCQ9r5fSln_CXgRXGFvO  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(D,b,s,v,S,g,^,^,.,+,},3,C,{,.,U,L,7,P,C)
#define  mu5MgGYXZDetF61l00p1M  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(d,J,T,C,3,.,7,5,v,o,-,i,O,9,!,*,*,-,X,g)
#define  mGyGrvv4NjvJFmxY5zFqS  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(C,*,Z,],s,F,X,o,:,_,i,w,C,/,>,[,t,>,t,Y)
#define  mxMl9vPEiIZkGZuxtm_RI  m_Gim03zcA2esaeteCftKMhV2X3oFiR(V,/,*,b,c,8,T,:,/,p,a,i,^,H,^,c,l,b,u,x)
#define  mYfpOohym5jydVBxgDUop  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(z,W,N,/,D,j,r,k,N,t,5,>,a,h,>,j,h,^,Y,V)
#define  mRawsH1LNxMcHXhyroWR7  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(5,;,4,c,j,4,4,E,},m,l,^,|,I,F,!,L,1,C,|)
#define  mo03bPDhF7WKTf8ndM1Bk  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(U,J,F,7,I,d,9,h,u,/,.,r,9,r,n,e,a,V,.,t)
#define  mH1xQMRmYb0Y4RDp2hARz  ()
#define  mHgo4JTEAdFhAHz3buc5U  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(},=,q,!,-,L,/,A,s,],U,T,b,+,m,K,-,{,w,{)
#define  mSa4WnWih0z4lSo9RYUGU  (
#define  mT1nRBXOOPTe1uInaQg48  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,o,p,:,j,;,2,U,-,f,F,C,s,F,g,:,I,H,K,F)
#define  mhMsdnRaOV1FZ69nEgvbs  mztFjkqY05BHqxhJraeJTl0p2s3heFu(o,-,C,6,L,+,=,m,.,F,T,[,d,/,C,x,d,T,w,X)
#define  mdNWJa6f_e7wadzG60ejq  mqm5corqEX8t35Uu6nBYm_yWWsarIow(P,x,D,d,-,^,7,],c,;,W,6,s,:,o,U,:,i,p,_)
#define  mGXmXMs8LhHsVpd3vA7qq  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(Z,!,k,G,},/,v,H,J,e,K,-,5,r,F,O,a,k,4,>)
#define  mWkGo8xUdRIKgJ1DEUvvn  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(D,Y,w,!,{,u,.,j,p,[,.,[,7,t,u,!,N,;,!,w)
#define  mSuHweZ8NLqp3TniIO9nc  if(
#define  mr45_AiDx2WPxM5kKJ73c  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},M,u,.,-,T,L,N,-,Y,*,>,+,3,Z,;,^,7,d,=)
#define  mSQwieae_zm87QxGSkqhw  mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj(l,v,T,G,^,5,6,:,c,b,/,p,X,u,p,i,],U,S,u)
#define  mqQspPZKCoa6LP0Jj0qH2  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(!,Q,[,+,:,1,T,e,u,l,L,6,J,r,t,u,^,z,N,y)
#define  mnqZGwZqTTi1dekKxujAE  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(P,a,z,m,f,^,o,;,j,F,X,C,l,1,*,Y,d,N,+,t)
#define  mQwlYb2fiOk1ogUVAZU22  m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(t,b,},t,e,i,},!,s,V,o,a,^,:,r,W,v,i,p,G)
#define  mEGd5SkTeDLeSnWPvzGk3  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(>,U,[,{,G,y,u,f,=,t,^,H,x,*,[,Q,Q,-,l,2)
#define  mIYvQtGxrUTK9jCV0wgjB  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(],r,I,B,4,z,[,=,^,[,H,/,S,A,M,6,m,r,t,B)
#define  mLdYY4X2b7VOjtTSnd7Hj  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(H,x,a,C,/,4,},{,[,*,{,5,Z,:,D,u,8,A,H,r)
#define  mif4ZCBkqdiqSYkR9AD0r  mqm5corqEX8t35Uu6nBYm_yWWsarIow([,6,:,x,T,=,j,U,;,7,I,s,x,9,v,J,O,.,-,.)
#define  mlqM0snvYcrWCw2_QjhQi  )
#define  mLBxgVrVeq7bTUcDGJqNH  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(C,_,o,V,Y,r,1,h,},R,-,*,J,f,+,:,1,A,P,r)
#define  maDn6NcmB5JPmBvJglMEd  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(M,f,^,j,Z,h,*,R,{,+,a,:,c,k,=,-,P,=,R,v)
#define  mC854TxsErP91YgtWBjLs  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(*,-,*,_,*,*,n,I,{,8,X,t,=,+,v,I,f,/,T,/)
#define  mqENAtmVRtspFcCyFxQkl  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(A,:,x,W,S,2,z,s,l,s,n,*,>,M,^,-,N,6,.,-)
#define  mn7NaVKR8Eys8MRznQhqq  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(6,n,c,N,u,P,i,D,F,o,Z,v,s,Z,8,f,-,d,:,g)
#define  mW1YUos9eL_9NmgJuSDH7  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1([,X,q,+,6,:,4,r,I,K,j,!,M,.,;,;,/,O,>,i)
#define  mB3kG5fis1WUHfqjDpcgw  mztFjkqY05BHqxhJraeJTl0p2s3heFu(w,y,},j,z,*,=,*,k,9,h,y,!,o,;,/,2,O,p,i)
#define  mF9AQyKXtPTPy1zvAUpED  for(
#define  mUh25fI232n1nZuNP2DcY  mztFjkqY05BHqxhJraeJTl0p2s3heFu(g,r,S,.,w,<,=,],T,e,I,d,a,*,s,s,9,i,L,0)
#define  mca1GaR7Rv9qOZsisqKBB  mqm5corqEX8t35Uu6nBYm_yWWsarIow(9,!,k,*,},<,u,r,[,+,V,5,w,b,7,P,^,O,8,;)
#define  mDjDVHrQ1nua2LsKX9HSc  mJRcV3UxOoHUziTla6CTItAztGL9WSZ(n,_,4,t,7,3,3,Y,^,Y,2,r,s,h,t,B,C,u,l,i)
#define  mbndM1iNeSBZryqPzzxpU  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(5,C,},B,},I,8,f,3,U,.,d,5,H,-,1,^,h,{,x)
#define  mN1cOqoznikSSj4MMYyFX  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(e,{,/,O,^,4,Q,7,o,],C,6,A,B,d,K,q,=,M,!)
#define  mMXwD61a3ZsfucFBja1D_  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(-,Y,J,7,],C,Q,i,:,H,;,Z,=,:,;,Y,R,t,M,<)
#define  mtFjgCt4NTpjOcEST1puq  mX2089XJEUghT4WdpeqIpdVl5urfw9e(c,o,q,S,1,N,F,f,g,o,l,R,7,+,],L,b,I,O,o)
#define  mt3VEObKOLfcodk2q6Hb4  meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(L,_,8,r,a,Y,v,i,q,t,e,B,f,G,},},.,F,:,p)
#define  mYwsOAvDOXneTzOST0d5c  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF({,},_,!,*,i,m,u,[,.,X,M,w,f,+,X,;,=,T,r)
#define  mwQUfI7G4pBH6IJQiBjmU  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t,U,i,m,N,_,b,n,x,/,o,f,6,m,a,J,n,f,a,f)
#define  mYM4ze6K0DiGvfExY0uu0  mwuimZUNEQYuguDYpIp15llEoOqkXc0(n,{,a,c,4,k,z,Y,p,e,9,e,a,s,I,S,m,d,r,h)
#define  mcJvl68QD2UYT9DPOREOj  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(l,0,r,<,/,^,;,x,G,0,v,g,{,Y,A,i,:,<,+,+)
#define  mBpPKNB5wfuTOV223BA2r  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(:,/,y,R,>,Z,M,!,[,m,E,j,r,u,{,x,[,Z,c,4)
#define  mSBH4REv5nn8iXIXWLqFa  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(H,l,e,d,u,d,[,E,;,[,u,.,M,;,4,B,b,O,o,k)
#define  mvAxy99EwaX0EkXFRf6SN  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(o,V,p,q,-,y,.,:,a,u,G,t,[,{,q,S,d,G,6,x)
#define  mRzhpvoeHZK7yCqqzYDDp  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(:,a,Y,f,{,0,j,a,K,F,-,5,.,S,6,O,i,i,R,^)
#define  mNAgAegAkh3aostDDex0p  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(-,Y,4,w,1,e,v,Y,W,t,+,T,!,;,*,E,G,Q,w,n)
#define  mifrRvzkyTJgS5ZnlEWNT  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(L,6,Z,;,W,G,A,L,l,[,!,X,L,E,<,Y,8,<,d,A)
#define  miFyHzo07syL8tsy3JLAT  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(8,r,n,k,t,r,K,F,1,g,-,^,;,U,F,O,u,n,e,.)
#define  mglDNKH5ah89GptW6H4Cu  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,t,o,g,^,d,[,d,^,u,x,f,2,a,a,B,-,G,/,l)
#define  mb_mniVMqcXJMFkJcXnTV  if(
#define  mHXoMWKZSiZYUvqmVkLF5  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(d,j,R,u,J,U,m,t,o,n,k,k,:,J,a,F,F,n,N,1)
#define  mc6SGgM2Uzvo_wy5KTima  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(.,],Z,P,/,n,o,D,P,e,p,8,d,v,A,q,A,/,i,d)
#define  mlJqcdUT0sl1_64qaqDwc  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(-,.,{,r,n,i,[,[,v,e,e,Q,z,1,u,8,r,t,r,I)
#define  mgWtxscBTuWBkK7X3fJ_M  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(>,U,R,7,[,W,r,O,>,f,],q,u,*,I,^,A,!,9,Z)
#define  mnAk2iR9Su1JlXNU__70t  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(e,Y,R,{,w,u,b,g,g,N,z,e,8,h,X,I,.,A,n,;)
#define  mGmn6AwhPqDzvkxFmEeXf  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0([,},j,=,o,O,[,Z,3,F,/,.,f,q,{,Z,R,-,y,3)
#define  mICILgDpdCTDSJqQAn06L  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(-,O,;,k,X,],*,N,a,6,o,r,W,:,6,},i,e,W,-)
#define  mCAzyIDtopeLXRxFfI0EK  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(^,Y,e,.,i,:,E,k,u,-,e,5,s,r,S,t,r,u,O,h)
#define  mDWRa2VXHJyGtXnU3Z9De  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(/,1,],B,^,s,+,S,L,a,K,.,>,[,*,l,5,Y,:,>)
#define  mwkUVn0D8pUxgFq_rx20G  for(
#define  msRrpu3bfxgN_CQlh5kGb  mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(2,t,i,t,_,-,P,i,p,+,y,A,u,n,v,5,3,T,b,W)
#define  mUq8qfNXjDE9FPlMHvjf4  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(C,9,Y,K,z,f,:,_,s,-,y,p,F,M,+,/,G,+,c,Z)
#define  mnkTvEdpCXelpIHLLqQno  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(G,^,d,:,s,e,g,:,e,e,;,e,],V,5,6,j,t,l,w)
#define  mYsjCP2nXqW2Jls3JAUkc  mztFjkqY05BHqxhJraeJTl0p2s3heFu(U,k,V,9,5,=,=,G,8,E,f,{,^,D,i,h,w,p,M,:)
#define  mKdH1o6rFuMJ1Fl0PA_sn  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(Q,O,:,e,{,+,*,b,k,.,E,&,0,u,&,-,c,q,/,K)
#define  mwu5s8ye7pYEdPIYXjU5h  mX2089XJEUghT4WdpeqIpdVl5urfw9e(R,i,3,8,F,W,h,R,X,9,d,y,v,7,B,n,v,1,x,o)
#define  mnt0Yxwh2kXjuvEydiY6Z  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(^,>,q,-,a,[,J,/,F,+,t,5,H,M,M,s,5,W,*,n)
#define  mA9OyoOle98msK0BnFc8I  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(f,M,G,+,0,Q,6,9,W,m,1,*,:,A,D,o,-,N,r,n)
#define  maB_pNl4zuODt3oqXg9EB  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(W,L,l,f,a,!,j,*,3,S,o,u,],H,^,x,J,q,r,*)
#define  mFlVjO0mLpwnCN5a1Quio  (
#define  mypSy3lS4LRIjRYTxVxzg  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(-,},[,l,/,L,j,;,G,{,-,{,b,V,8,^,Z,t,O,C)
#define  mwnRQJQKy9VbzznJbM76_  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(q,7,h,},U,:,k,^,z,w,5,=,L,;,/,7,R,/,j,6)
#define  myqrAJLu9GRcs5sFEN1xM  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(A,G,P,;,d,b,4,d,i,0,u,*,[,o,v,u,:,V,q,H)
#define  mhyL_M5gnmQzwyHW45MdA  )
#define  ms9iveRK8Fk_QtPMDvDcP  for(
#define  mYfYoOWdsOLTDCIBT7npX  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(C,G,{,b,/,B,i,n,^,],6,N,*,e,L,v,O,e,j,<)
#define  mndAbF8Mhqs6wYK8Ew3E6  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(u,e,e,d,d,k,b,l,o,k,n,/,o,E,*,L,M,v,l,a)
#define  mAQWugjGggd1dm4Esoytv  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(;,5,G,d,v,;,+,.,b,A,A,o,^,l,M,i,B,B,_,s)
#define  mQu7TMP4YfBcqf0WCzN18  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(e,9,!,Q,*,.,W,K,S,r,],],n,U,!,2,;,-,w,5)
#define  mNhNSN2gx5KERe8tfdmgu  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(i,/,{,i,Y,X,A,b,f,:,d,7,e,x,+,.,[,3,a,9)
#define  mdmuaUz9iCkCckSUhcEv1  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(l,_,H,;,R,!,X,d,^,[,5,h,u,Z,o,R,W,A,K,b)
#define  mVVBTZX2L35xKLlbqB8u4  for(
#define  mI_QuD605u2H3qQFyuTju  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(/,8,g,D,d,a,l,x,9,E,;,B,o,+,t,A,f,^,P,7)
#define  mrzvE9vOXIlwaUYsJynGX  mjE2s1jSu76TqssWv5OkpQyTNcXDW0j(s,x,c,k,e,m,!,B,w,n,a,O,a,p,e,W,*,9,l,K)
#define  mUB1yrSrKOwldqxmCatN2  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(^,e,/,n,],:,h,Z,s,],],;,u,R,v,6,0,P,n,v)
#define  mMGij61UZUIIYyztVz9vN  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(t,],B,M,5,2,L,o,!,{,f,N,],0,e,.,i,n,-,T)
#define  mYI2nkSxgJHf1pY1PttV1  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(1,r,T,j,2,.,z,<,T,},a,;,L,b,},E,q,],l,2)
#define  mKqJtaKtNNFCDA9awnods  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(;,n,:,7,R,C,N,J,k,-,d,J,y,o,w,v,-,i,g,C)
#define  myYaYWcsrnLoe6SxorDYt  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(D,H,[,r,r,a,;,H,*,e,-,t,o,3,G,u,o,H,n,V)
#define  mIM7YEc9Ba5XWDEr0m2YG  mRpzyAUUkieNHbskgKP0AofElml4apw(1,l,h,B,G,s,c,a,T,6,R,^,b,p,s,L,9,T,.,!)
#define  mZQqomBcB_Prq89ftbAiD  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(+,^,!,O,N,6,4,e,s,},d,f,t,l,e,_,_,X,+,z)
#define  mG9O2bX6GrjZ7A14g4o0R  mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps(l,b,f,O,:,p,c,W,*,],*,5,r,f,*,i,K,G,u,;)
#define  mTQiPILYbCv0nYwQtndF8  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(t,N,6,^,T,d,W,B,N,o,p,N,z,^,t,q,2,6,x,-)
#define  miTVnDZI0mihWq9STK4vZ  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(O,t,O,!,F,S,D,W,D,7,/,/,K,[,h,s,p,x,{,=)
#define  mv4kxLDTrK8Y14srOeMs9  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(s,.,i,h,c,s,{,s,a,N,N,^,Z,Z,.,!,F,H,l,p)
#define  mfurntceIvF3j4__Qp6L5  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(r,c,r,u,b,J,C,Y,u,2,t,g,i,t,H,5,s,n,+,r)
#define  mq_LX9xWjqEZjC_8nIQQB  mMinTurqhjOTBoJcyTuRpllwDXFTRab(p,v,B,b,4,l,Y,i,O,c,J,d,J,:,[,W,q,e,u,G)
#define  mmhvewuTDMRQuh4yozZj0  mztFjkqY05BHqxhJraeJTl0p2s3heFu(n,/,U,a,-,/,=,W,X,x,Q,.,[,.,u,;,C,!,Q,l)
#define  mb7CDbA8OAKKL51zp5Kp2  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(M,;,{,Z,o,/,:,},:,!,F,a,!,o,.,8,!,l,*,F)
#define  mUrLXSL7g29oB1gxfN8O0  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(V,.,},h,R,n,s,/,5,-,;,;,i,n,g,!,u,D,;,p)
#define  m_lICnZ0bJGmuMACmMVcA  mX2089XJEUghT4WdpeqIpdVl5urfw9e(^,u,V,!,S,k,-,/,},{,e,G,{,n,J,Q,t,!,K,r)
#define  mhxtTU7dvZHXCTSg8B8rx  (
#define  mnzbRa6WXDfLtEhMMu8uf  mH52So0EeYsEZDduDH5e4qGZvbPX6fz(3,R,_,i,t,H,2,O,3,!,d,:,u,2,/,H,+,d,t,n)
#define  mO3OYAsYlFzrizsYt__9m  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(:,a,C,:,b,5,e,K,K,5,1,4,r,Y,G,7,K,T,4,k)
#define  mukpDKZCMfw2TrxqBczvn  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(/,[,R,R,0,{,.,K,=,x,-,^,!,n,z,-,1,2,i,G)
#define  mlxKATcGFZZXuYzEVZko1  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(B,[,[,5,K,:,f,!,M,g,4,S,D,:,^,9,u,N,u,})
#define  mDzQQrEx5Ki0C6uDHU2cy  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(/,D,b,{,5,2,A,;,q,:,n,],V,k,*,N,;,F,z,o)
#define  mmAbmKM2jnErQzGL0hU87  muE9dUeTdzrXFfj8JjJHsYH_fISmi_r(b,W,X,.,h,_,p,l,p,1,c,*,!,u,i,:,K,:,P,B)
#define  mbvotPuLfQMMkHkrWczyy  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(c,I,K,k,s,s,.,D,Q,r,I,I,2,9,a,B,^,l,e,g)
#define  mILr1bxfFRdMH70QJkaPL  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(r,e,t,s,5,},u,B,v,G,],1,t,-,x,j,{,7,c,})
#define  meOIEIGNtns3N9UkZHp_p  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(!,],l,u,3,/,n,L,l,!,c,l,s,!,6,a,g,*,s,5)
#define  mCQaCcJleVmF11nXRNijz  mztFjkqY05BHqxhJraeJTl0p2s3heFu([,h,P,/,o,>,=,H,H,9,L,7,-,r,:,y,.,X,T,d)
#define  mm2qioZxIvP_11cqVcoVX  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(^,p,x,X,U,5,[,Q,-,{,Z,p,<,N,3,c,N,*,s,<)
#define  mqHHu9OC8XdQm9Yh7V7x0  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(r,},K,O,R,6,i,;,n,B,Q,;,2,W,|,!,V,|,w,L)
#define  mxjRBOqzfKYNpief2KWEu  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(S,},<,J,8,1,V,c,Y,^,5,;,:,6,},:,3,<,K,^)
#define  mi0dc2wlXgNoHf9VPli9f  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(G,v,I,=,Z,^,j,K,J,g,:,S,O,h,!,Q,B,=,m,5)
#define  mZHJfF8VODcHrGq0YEwM_  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(A,.,W,!,},!,u,l,8,c,{,7,T,a,{,*,-,/,t,o)
#define  mPrvhmoEgzU_ThNhPmGUb  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(<,z,_,!,[,-,j,{,<,L,1,I,W,!,B,e,],T,A,p)
#define  mij4fDpzx7A1fAEkEKDEN  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(S,5,+,*,Y,P,S,d,m,7,.,m,E,W,>,f,F,=,p,B)
#define  migVyykpmr2io3DNlFdHK  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(;,>,d,>,3,^,h,Z,U,M,x,s,*,m,k,4,N,Y,m,s)
#define  mK5OxIt23gZzSiTA8trU8  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(S,/,a,/,P,5,S,-,;,2,R,m,I,.,A,-,0,.,<,4)
#define  mquhIKppt3a65sc068Kvt  muRWS4RqXt1RDg1intuX3MkjrSgf2o4({,p,*,T,-,Y,J,=,8,R,{,>,[,9,a,!,_,t,l,t)
#define  mS2LGTpbZiAMEweak007k  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(Y,=,w,/,j,k,H,G,X,6,f,t,D,b,O,l,x,;,O,c)
#define  mSDkw9ayb_9gGdMv3ViWL  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(R,g,i,s,c,.,z,S,p,*,s,u,^,!,n,d,D,b,G,s)
#define  mIyKKzozGjE84ROdV4z79  meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(t,Z,Q,i,3,E,t,n,^,2,_,;,.,5,Q,x,^,v,t,u)
#define  mKcyQhGKewGQ8D80ltPKd  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(t,t,e,g,k,u,N,c,j,^,U,{,s,:,E,V,R,{,r,])
#define  mLplHCs9IECRrk3AL90fE  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(Z,8,p,*,!,:,D,H,k,c,G,S,;,p,o,Q,f,*,t,j)
#define  mv50Xfpo4ITZHLXGtKNlu  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(u,g,+,7,g,n,0,R,V,Z,M,^,[,^,i,f,^,s,0,^)
#define  mvW7MwxFgHE1jUFn6bpuP  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(T,&,L,&,;,P,+,Q,0,],P,X,A,J,;,3,8,[,q,U)
#define  mo7mKuzaX2h9vw2rEj5qh  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT([,_,I,9,d,R,B,H,R,{,1,+,z,7,+,;,f,4,!,/)
#define  mJtGCV8zXQjnVDVBVdvFZ  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(X,*,E,I,3,_,!,],-,d,{,W,1,-,J,^,2,5,q,N)
#define  mfx1fLYDWN4YRZNnQEsJN  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(j,q,S,Q,^,^,+,],7,-,r,_,_,6,:,[,c,:,;,^)
#define  msao8K6SR84Lu5ND7NCVt  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(+,=,u,>,!,},],7,S,S,X,1,6,E,.,^,x,1,o,.)
#define  muQdV4OJL6V6gVxW6AdRy  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(4,*,^,i,E,q,g,=,N,4,-,U,^,m,_,v,.,-,{,o)
#define  mgRihfujs8Yyx1O6Z75ze  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(:,h,e,[,X,x,x,0,A,3,},l,a,x,s,4,f,2,x,.)
#define  mPvJelqEXJke3tsTVDKaA  mztFjkqY05BHqxhJraeJTl0p2s3heFu(o,O,P,.,S,>,>,V,r,u,:,-,h,O,X,3,N,],m,d)
#define  mF8CPQI5IssWjwlV2CXVE  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(4,*,*,o,a,2,z,*,{,},W,u,5,6,b,t,F,R,},p)
#define  mIkhxhgSNMt_JUZR7ce1U  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(!,Q,t,5,G,B,h,.,d,/,6,k,Z,g,d,-,z,/,],S)
#define  mBh4lc09qKYGXyU7FeqOv  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(H,+,5,+,{,^,{,:,1,a,G,R,*,i,V,+,*,*,^,N)
#define  mgjPImSFwUcUKl9XTKqqB  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(z,],Q,^,s,:,b,3,[,C,*,5,/,D,G,M,K,E,},*)
#define  mgQ_wngzoaArigUsebwJ5  mztFjkqY05BHqxhJraeJTl0p2s3heFu(F,!,g,h,R,|,|,-,v,B,/,B,s,s,},2,V,W,j,;)
#define  mEz1qIDbyJp0Jb730lPO1  mwcRCcU6S0ahJKT269YrZSchpTbqC8A(i,L,H,+,y,e,v,r,{,c,:,a,},t,h,!,V,p,/,H)
#define  m_owRLEm0gIJ4StPRwTkZ  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(9,b,^,E,Q,R,*,r,o,!,/,B,o,:,;,f,s,:,;,Q)
#define  mcznTYeCGOAygtXXAPYS_  ()
#define  mXh8R2TW8u4BE0GHtpbVz  mztFjkqY05BHqxhJraeJTl0p2s3heFu([,[,q,^,i,-,-,},:,w,Z,w,p,-,j,h,-,{,u,I)
#define  mh5Oneq9KX80ZFd7dCoKK  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(j,/,3,=,-,;,;,m,R,x,p,I,W,;,M,d,Y,>,a,!)
#define  mA4oXllup8K3T5dxkluRR  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(},m,j,X,8,T,7,^,;,:,J,2,T,S,{,e,u,s,[,m)
#define  mep87jMrgQZcK1mXjlt_w  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(V,A,g,!,:,-,},j,C,{,p,=,x,;,-,z,/,1,:,K)
#define  mIwyzOHEkeXgErUDD0EEp  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(e,R,K,x,f,},t,s,l,Q,O,E,C,j,t,p,/,X,a,9)
#define  mikiSyOnVry6pvQ1Ds28H  if(
#define  mbQuioGdvAG5jcbGdIlbv  mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(3,u,i,T,t,O,9,t,_,E,9,/,x,2,I,d,u,t,n,1)
#define  mECcJc0jrNRWKGTvkEzeA  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(E,b,^,^,m,n,],A,U,^,S,<,J,9,c,1,h,Q,!,<)
#define  mMcZ82Suei3klnF_x2Lcx  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(v,v,U,e,O,G,],V,},^,:,h,],D,g,q,F,z,U,K)
#define  mm9xpbYUQ152i_zNBGUZu  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh([,[,o,S,o,z,],D,b,l,e,4,{,D,C,t,},:,o,^)
#define  mX_x9bVx2zqKO8c2FxqgZ  if(
#define  mel3l7ZRXwnAEsy0Wfxj_  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(+,D,*,t,h,p,{,b,U,;,A,F,m,h,},A,>,y,:,V)
#define  mTna5ZWhTRHGhmpdDhP8Q  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(8,Q,:,P,v,N,x,=,T,[,/,!,:,Y,+,T,-,M,k,W)
#define  mEDa32iTjVIlpXzu_8bXW  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(L,s,f,J,c,a,a,j,l,i,n,5,l,h,4,Y,w,/,q,s)
#define  mK02Cexqsx6vNaoTzun_D  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(],P,9,!,^,N,{,z,O,*,X,+,F,!,h,6,D,C,+,I)
#define  mfJA9NVd6FBgGhRSkkhhs  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(a,l,R,o,w,-,H,i,d,;,6,x,k,N,v,s,T,9,R,6)
#define  mMNJIG0z6TLGgbjrhllmy  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(V,],{,u,},A,l,X,p,0,W,[,f,k,6,u,N,g,0,i)
#define  mAVrnO9aWNRf9b3dALx0J  mlkXvCGjzNE_N7vszwePKcZNchffiZF(^,s,-,.,p,e,I,],v,e,m,a,c,x,n,M,a,.,B,9)
#define  mtPtbM6hNfOIkqlx661ci  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(0,u,:,y,L,v,a,=,x,Z,g,=,q,2,q,h,+,.,h,P)
#define  moT0JKxDJVSALTDfSRUYM  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(C,F,+,:,T,Y,],5,9,[,e,c,w,l,k,e,k,s,a,/)
#define  mhgVj3QiKBmvoTbS8WYEn  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(b,H,>,e,6,9,1,.,!,4,q,/,a,g,6,r,[,=,e,.)
#define  mhGXMe8LHJXydR9dMisHj  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(G,A,I,/,s,x,*,q,I,l,P,P,i,p,H,Y,c,j,d,;)
#define  mCujczJix6jMpJcynoBiA  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(n,Z,;,o,t,b,g,E,.,O,R,V,I,U,t,C,0,H,i,q)
#define  mHAbGd4HvG2QvOxZcs3lT  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(o,e,u,R,a,b,c,l,_,o,N,n,d,{,s,0,t,:,u,V)
#define  mtBaSZn4xtaMpMhvfebM_  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(],*,O,g,{,v,a,l,:,N,},n,l,d,*,p,u,=,/,!)
#define  mEc9zv3P8LW8haIvtztwe  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(F,1,I,>,},3,A,C,[,[,d,L,/,*,*,e,H,W,o,4)
#define  mdssZV6TB06aiisDwN1cX  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},a,A,C,c,0,;,X,H,e,W,:,*,{,v,q,3,1,Z,:)
#define  mAtZroqlrY5Hmm_G3pFca  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(2,w,y,W,B,i,/,i,o,Z,O,=,z,3,+,i,*,r,W,3)
#define  mRuVXNtG32xpaNLi1hDLk  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(Z,*,9,!,.,w,P,!,J,V,+,=,],0,K,z,{,z,f,=)
#define  mIt7rZ26ebLuaPjnQsvmi  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(a,=,9,<,/,g,_,[,m,Q,/,[,M,/,K,G,v,A,+,G)
#define  mC7CcuPGpz81aizhogiZL  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(S,B,!,=,P,o,;,[,g,e,V,T,],},T,/,d,+,G,f)
#define  msubWq7nTVSPilWqmTzkx  )
#define  mjxPa00ei9qkuuQmiGB3C  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(N,j,.,o,I,[,p,^,h,b,;,},g,},I,>,*,v,.,-)
#define  muxyK0XEbbiarSy_y8QSe  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(!,7,:,*,u,d,z,],=,v,d,I,b,j,{,q,C,W,-,m)
#define  mt6CTIKlbWyEq7tYJENOL  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(5,I,l,T,V,d,b,:,6,x,/,*,1,L,M,E,*,:,Z,=)
#define  m_wyaFib5_cQG4j1HqokH  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF([,*,x,e,t,n,1,2,.,^,Y,r,Y,z,],u,-,f,/,/)
#define  mmCJ670wA_VHgip7JZ1dW  )
#define  mQfgxxEXCA984FTu8Jz8Q  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(M,R,7,9,!,Q,+,[,V,o,N,|,^,x,|,.,;,v,J,s)
#define  mRHNkLPwUSnx20pmLgrTq  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW({,V,+,q,R,{,T,},l,Y,a,/,G,3,z,W,B,N,.,>)
#define  mYPzKChOwisp1u2IoCgxk  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(!,J,L,Y,X,.,.,=,:,+,W,*,c,{,s,M,B,8,M,I)
#define  msMfR3R5kzP8SqAQ3DWTq  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(i,^,.,s,P,*,6,*,J,/,3,+,I,{,T,R,+,m,E,=)
#define  mUtcrfgjMX2yuzlJWU7ae  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(j,Q,/,w,t,M,x,=,.,b,T,<,k,h,Z,5,u,M,O,+)
#define  mJTScPpWt8plE9Cz9fDU6  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(J,0,u,3,*,:,^,L,t,1,;,C,],W,X,{,:,I,D,:)
#define  mWA_ETdQ9hsfQKo10V6Ed  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(2,=,9,-,6,E,T,-,T,X,T,!,6,t,C,N,p,K,8,K)
#define  mnNakURRgCUtkCBzEeIbT  mQaMmAoZTrzB9rh95SV_SNzHqc0isDC(x,+,u,e,a,:,U,s,m,Y,e,c,V,n,p,^,a,M,],P)
#define  mReDuVelSknxaDAoDEmwT  (
#define  mYA_OUCZSQycbIZ5oB16m  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(l,A,/,W,e,l,L,/,b,o,Z,o,w,+,5,j,Z,z,g,z)
#define  mIyXpca78p_CKHmulak4e  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(c,1,k,j,],U,^,<,p,s,D,<,!,:,T,k,S,V,e,/)
#define  mCpxQXTS3AV0wU8W7TGY0  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(E,6,c,k,{,F,g,/,_,l,^,^,/,a,/,[,s,!,F,s)
#define  mm3KIQTUMZkPidze1WHnH  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(f,1,9,y,8,K,J,w,L,f,G,u,g,N,4,:,J,i,E,^)
#define  mLOAPVN3DUqvZfrHEsp7F  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(X,G,F,o,q,i,W,y,.,J,C,>,w,!,+,M,M,9,Y,>)
#define  mE4_Vrik0lveh4HNJUk1B  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(*,3,v,w,M,c,d,>,P,e,j,6,7,k,j,0,W,+,T,X)
#define  mOcs0qqtJYmueMnfTyCFx  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(o,I,f,h,e,x,B,b,I,l,m,W,!,o,5,G,t,1,P,a)
#define  mw_6Ab4pR3RtOt7wvMnqF  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(s,u,t,r,K,t,/,3,;,c,+,2,},;,t,0,l,y,y,U)
#define  mvfKgFvXHh0Jqv_PZxbka  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(p,l,{,b,7,;,S,Q,Y,z,o,y,9,e,Y,J,d,/,z,u)
#define  mjbtcSgN5ZQfkGDsoYG4l  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(O,!,d,X,l,A,z,*,i,q,},e,l,E,w,V,i,!,{,.)
#define  mAwnIBmzoGA1R_JK770kK  mpoy16fiv_eugwBU4NxPwSY0pkiHptx(h,X,D,p,v,+,v,W,+,p,i,3,T,:,r,P,e,],a,t)
#define  mpJt2kGThF7wb3VNzG38b  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(5,;,O,U,2,P,J,:,L,q,c,:,K,Q,D,i,3,b,Y,K)
#define  mxD0ASUiBIk9J4KLYW_eX  mqm5corqEX8t35Uu6nBYm_yWWsarIow(K,I,F,d,N,!,7,/,G,4,O,c,0,;,x,.,T,H,U,S)
#define  mOwM0Kfjt44STnd1SP93u  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(t,d,/,c,t,o,],f,Y,r,t,s,z,n,u,k,N,r,s,;)
#define  myYAiLHDT3JvFKUJCC_FN  muKLilOLbFZ3yJM00gLINUymjA4CZq_(l,o,g,D,U,u,q,a,z,{,T,D,t,E,7,p,[,7,j,U)
#define  mow1IjdflpN81ICD702rC  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(e,n,l,8,N,u,k,r,:,[,u,i,r,8,X,7,Q,G,t,Z)
#define  mhpoAZakkKCTBIsnDg7v3  mztFjkqY05BHqxhJraeJTl0p2s3heFu({,Y,:,B,u,<,<,4,l,W,8,},P,y,*,U,V,t,.,+)
#define  mzqBtnG8Ja0w84lba1GCT  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(P,c,t,;,r,s,j,m,/,Y,+,u,S,l,8,_,u,!,t,s)
#define  mclhRCo4dM7MadZp5V8m6  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(X,.,C,/,t,2,T,7,o,H,E,x,T,r,a,1,u,X,G,9)
#define  mhl3Z6oGBbP13ZxehUcg9  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(k,:,:,;,2,:,g,4,4,},z,/,9,h,v,s,},f,V,})
#define  mHkLXuUOlyX2vZI7w3FQj  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(9,!,G,<,N,V,V,M,o,a,A,],I,R,O,G,.,/,b,b)
#define  mTjppsgNpY1Pjyv5Z_zMr  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(3,t,3,t,f,s,6,E,O,o,v,q,h,7,s,5,[,K,q,h)
#define  me9YsE5_K5dlCgWRVtztQ  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(5,t,F,.,P,s,a,o,Z,s,+,C,l,A,e,q,f,K,l,-)
#define  myFE4ZIOynNe4GHuzkHmk  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(W,N,S,M,},R,K,b,q,s,F,>,o,z,-,e,r,*,!,;)
#define  mGuK55c17XqU0IVL5INTz  muRWS4RqXt1RDg1intuX3MkjrSgf2o4({,y,a,O,},1,/,>,},t,9,-,y,u,U,],[,n,N,X)
#define  mlqoNTA3LQoUJF6i5YDFc  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(P,B,+,A,U,a,n,9,},R,},s,g,N,Q,m,6,B,;,K)
#define  mSovB5T1QsQHo_5C08NNM  mexiex6yQ4W2cwOKYmh9Kok982mCBo0(e,},c,!,n,p,T,+,e,v,m,/,a,s,i,a,p,{,],e)
#define  mYB93ieg1KMHexoJXsKQO  mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q(a,e,5,e,X,],p,g,!,!,I,0,a,y,n,{,m,c,!,s)
#define  mdKhcOUXVqyCMdccisL_a  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(q,:,v,T,S,{,-,a,r,5,=,*,t,/,S,b,E,h,;,8)
#define  mnZ6t3BhMZ_1d7zzE72ah  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(7,W,=,.,^,*,-,/,i,9,1,[,W,b,V,;,[,=,+,[)
#define  mUFzn4yJGA8c9qnEcb9dH  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(-,},[,K,/,0,.,i,o,3,4,i,!,Q,h,S,h,0,+,f)
#define  mNQatzTrxcdXGxcIUXU8h  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(;,/,G,X,B,O,},f,q,f,b,r,k,E,k,e,H,V,a,R)
#define  muESrr63SaH81rmeBWzRi  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(g,n,E,.,*,a,0,^,M,o,f,a,e,4,n,l,;,u,s,s)
#define  mEmzu5ycY6iORBuT83fJe  mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3(f,!,*,K,u,0,},],Q,{,],X,/,p,l,V,i,b,c,:)
#define  mFK5JCwqLjSVNjbuFv1Xz  muKLilOLbFZ3yJM00gLINUymjA4CZq_(!,e,^,O,L,l,[,e,-,Y,M,T,s,e,i,F,.,n,},n)
#define  mdF98bHO7yrxGJn0aQZVK  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(S,j,K,I,[,_,r,J,Y,R,W,{,},R,;,2,D,;,+,*)
#define  mtggfblAKFVUli3PxtdvW  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(q,g,v,q,Z,U,!,;,*,i,7,n,u,G,n,{,[,2,s,a)
#define  miFg9XqPeEmQjjY9dOISI  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(E,c,m,1,!,h,6,Z,L,+,+,O,a,3,-,J,-,l,.,~)
#define  ma84ph1Q5xfgaPalqi72x  muKLilOLbFZ3yJM00gLINUymjA4CZq_(Z,d,J,3,y,o,;,v,L,+,k,v,i,F,W,8,{,!,X,_)
#define  mC_m9rmwsKDO6tF3NGSKw  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,s,a,^,R,W,F,v,r,S,5,c,e,*,s,L,H,l,.,l)
#define  mu_nOcTFwUo8r0uNE351R  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(H,{,*,0,=,V,F,*,G,k,5,g,K,h,+,},6,},_,I)
#define  mlujXFTq8HgFCDqLu7dpu  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(d,b,o,u,a,j,/,w,0,l,^,W,/,6,e,/,g,/,5,J)
#define  mkyaUNysRlFi3wOJaaFye  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(Q,X,6,{,l,E,-,|,[,*,5,|,g,{,c,:,/,A,4,v)
#define  mN0TszoCQmyzxmobsgV2H  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(-,N,z,_,Q,7,O,{,l,},r,o,M,^,b,{,P,-,Y,7)
#define  mdLKGc6TH1B4fmpMEcP4V  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(y,L,Z,Y,A,+,+,J,F,.,+,=,p,h,*,W,y,o,+,{)
#define  mIMikP4zsPvXTvXr7Rfnr  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(s,s,y,v,v,F,{,c,2,a,:,],c,;,s,z,U,P,l,x)
#define  maKLz6mCz5anFyVle_MtD  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(u,L,Z,:,X,B,w,W,J,s,L,:,:,:,K,P,[,*,Q,:)
#define  mUgRzGHHwu8B0HUYWcJfg  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(A,[,w,n,X,.,p,-,D,U,e,4,K,:,_,w,G,7,w,Y)
#define  mzeHK1hG1SYQMISNMWMB8  ()
#define  mbViqhyIcr6lGWibuo3Im  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(;,;,N,{,f,1,B,z,1,/,v,q,9,;,9,],c,W,j,Q)
#define  mtDtuj5HWLyTAsK7Fmx4g  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(;,:,7,_,i,A,p,.,t,!,9,f,g,S,-,Z,{,-,{,})
#define  mCm219F3DHVwNe_CsrCeK  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(s,;,4,9,_,E,c,},F,!,!,+,R,b,[,!,F,2,B,=)
#define  mM0eyBFMShg9qdQPSMqiz  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(s,_,],-,0,:,;,m,H,m,{,^,5,+,z,5,Y,^,~,7)
#define  ma43zKzGwyDT5C3mNdj6s  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(X,^,8,=,_,w,{,L,;,{,[,!,J,H,e,v,;,!,4,Z)
#define  mQk9KGg1kmiZQnIZzbOuE  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(},z,n,^,i,X,Z,8,d,r,f,+,V,Y,v,n,o,c,H,l)
#define  mzf4ZxeZY8wF2XnrdYK61  )
#define  mm3iTU9Va924R0kb0bFj1  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(;,*,g,{,},S,},Y,7,J,6,i,s,],n,G,u,J,!,5)
#define  mneGB1iZsOWGhJroSY5fV  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(F,^,/,~,!,1,!,{,8,.,S,A,R,!,9,6,G,t,*,d)
#define  mwTp2D1d4PfxNNOzzUfhS  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(V,C,},x,/,/,z,T,W,U,;,p,5,+,],h,a,/,5,])
#define  mHIh6WyQKJh1ZKme1nslP  mr0l01irlQTHxEjA5eunteQkeoLuBQY(r,/,N,o,;,g,P,8,+,F,},^,Y,[,i,9,f,7,5,J)
#define  mFKRUYDiDlNmwfGKdBg2S  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(;,c,V,c,l,-,_,h,z,3,Z,-,e,^,9,^,K,:,E,=)
#define  miFbFMaHNYmE7ZhdtdD1I  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(},G,V,*,X,},J,d,d,B,Z,3,-,o,w,-,P,g,!,:)
#define  mWHxIxEh8g9mg3Hyipn8D  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(s,r,H,{,C,Y,1,/,U,u,},f,l,9,i,!,3,u,:,;)
#define  mEFd2D2UDF9SIoPfQtUv6  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(+,+,:,b,u,!,l,x,[,h,],a,x,r,{,+,y,.,v,_)
#define  mPJvcMzH2GoPEPAArs6CO  mRpzyAUUkieNHbskgKP0AofElml4apw(j,r,W,V,N,k,b,e,K,m,-,f,w,0,a,J,l,K,w,^)
#define mElbPhFy9PzMYpwK0rJM72HTzRPloIw(ckBP7,txZe9,Gtqmd,bdhav,d8p7I,uStGt,ywxDa,xzz8l,LDDBm,XIGVQ,OW2Zn,KRqVf,uyOa7,xaLOn,AVRm0,CfMNC,cla8F,RrDxP,SavRx,MS90E)  uStGt##SavRx##d8p7I##cla8F##txZe9##Gtqmd
#define mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(Ui6fN,WVlas,omdPb,Thx1A,QahIr,v6Kum,PNBzw,xKmwk,IV5nX,t_qPH,a5oKy,_BuAB,CTBxN,oDQO0,qhxU6,P6IzR,sQPQZ,fk3Th,E_enN,w_KdS)  QahIr##t_qPH##_BuAB##P6IzR##Thx1A##E_enN
#define mPF9YW010VzHVkbdsdOMJgq7D81z3gH(Qz22f,fJjtS,oC69Y,W_E1w,FiCri,NMpON,KVnIO,PrR1z,UAykD,GPaqG,VcdT0,eaVjt,KnjPp,PKuL4,lgWoU,hANhc,VYz9F,NBemb,kxnOG,VUWzG)  Qz22f##oC69Y##W_E1w##fJjtS##GPaqG##lgWoU
#define m_bMsemALspVgRNyYoh4QNv5h7J6TCa(YXdN1,Y26OI,YvFyW,hoJ8w,QwVKc,fTJQr,iEN7b,jjazf,yytw7,sOkzh,oWo4v,gwsm2,dlB_k,vKqwF,PiIPh,iSVZW,xuK3g,h57j3,D8BN2,Vj7d8)  vKqwF##iSVZW##Vj7d8##yytw7##gwsm2##PiIPh
#define mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(W9zXn,U8eUc,h0GSn,CEITI,ka43n,OSogy,nfl19,p4MaV,v3NrW,U5Ev7,XnSLR,mp4hs,FDFQm,OKovB,r0Nou,zRGGo,GkUkR,pUYDt,mQdnJ,BrpTf)  FDFQm##W9zXn##mQdnJ##OSogy##p4MaV##U8eUc
#define mevyCL_5kjUx7NbD67ju0rSs5KRucsR(MaY8o,HtMqc,yob5i,o0ibS,UyS1n,qrhvy,JELn4,mRkFV,KARFm,kxrxz,ALUkG,ajfVU,bA8AR,zzq3C,QjWpe,TjpvR,sbn07,gaRql,bNqJS,eNjOC)  sbn07##ALUkG##eNjOC##o0ibS##HtMqc##zzq3C
#define mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(sMhzj,ITPXO,_yk04,h5GLw,FOFEE,ly1gv,vyAmU,UOW_P,UGfja,oFzIS,xR9z6,nT3uD,mTvzU,dxZGe,HiQo0,x_JAx,LfqGX,jyXjy,PXvcm,ycIBQ)  x_JAx##vyAmU##h5GLw##LfqGX##dxZGe##sMhzj
#define mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(iPmx_,sBIDn,gqx3T,mu8ER,zpLIr,vWKmT,jTSQf,V86pA,iXTYm,VRiwj,zi39U,vc_t3,zymFn,vCTGl,uLfpG,T57RD,feDwV,yeDKu,UhBiw,l4Ebv)  VRiwj##V86pA##l4Ebv##feDwV##UhBiw##mu8ER
#define mUPTRsc2WCtijDSKQungDsRrIFUGnz1(U4rt8,TGx5J,Pbpwc,eHJ4X,ktiih,LAiw1,kC87H,yG20C,Blvcq,xZKUH,eK9qE,MRPoX,diwEj,u1tne,LSGYx,J4rjt,YZVIN,VZkvo,XeUuS,zfaqB)  eHJ4X##diwEj##U4rt8##kC87H##XeUuS##Pbpwc
#define mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(KSFyI,ep1qW,dx3Tp,v2hbu,LMFaL,zsiYo,HlnPb,qeEA7,EF7kp,scNwB,KUat3,HP8hp,CwOE6,D6iQp,iW8pS,bdn4X,CQEb7,i7yhM,fdAv4,BUUXH)  fdAv4##KUat3##i7yhM##iW8pS##v2hbu##LMFaL
#define  maoHwm5lyecyelmN95sur  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(r,u,e,t,K,^,V,y,X,r,q,7,0,],n,N,0,O,+,c)
#define  mMRNM5hfPBWFjYCspldu3  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(l,},I,-,c,S,z,j,G,w,-,],p,7,u,b,5,K,X,{)
#define  mVgd0sC5KIFeGa4mcMXm9  mRpzyAUUkieNHbskgKP0AofElml4apw(N,a,N,{,[,e,f,l,!,:,^,-,],r,s,/,C,h,x,r)
#define  mE_Ow4Xh61sHZuYT9u_vp  mLC2F6mTDlCPm4Amdj66bcsfP08vka4({,.,-,l,K,9,y,s,e,4,Y,^,4,t,e,0,w,.,K,{)
#define  mgAgf2KiVOzOHJDU4qKPI  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(=,H,w,],K,u,},C,=,c,.,t,+,!,c,],k,],{,U)
#define  mxQewHEnT8PTNQcVKCqL9  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(3,^,r,R,C,o,*,f,t,C,V,S,g,w,6,b,f,t,g,-)
#define  mTAavMivNX5WuUrRQXoEf  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(V,r,z,u,m,2,0,],/,w,e,l,Y,n,v,D,r,Y,e,t)
#define  mbYMUxVFybbviIFqRhN2f  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8([,7,3,{,F,/,V,},n,W,V,+,j,^,R,.,L,-,R,9)
#define  mYONm1FLAyaMuB1zKpzHD  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(0,C,j,e,e,+,e,E,z,a,G,l,M,R,e,s,;,{,Y,C)
#define  mP2fo6VtM4ySlx6m268_j  mH52So0EeYsEZDduDH5e4qGZvbPX6fz(;,H,e,r,v,E,t,i,a,s,l,a,p,o,A,T,l,q,:,i)
#define  mfFGohhJTv_x4m7UMdlWF  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(n,6,t,t,.,3,e,X,i,{,^,*,^,r,M,r,u,F,o,R)
#define  moPdTa5HpJKbS1U6TqDjY  for(
#define  mpMWr23OozoNFIk9M3JRl  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(v,^,},{,4,J,o,g,n,7,o,5,g,b,},c,r,f,o,l)
#define  mKbtq8OHrv8CI8FhvE4XG  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},A,1,d,E,A,3,X,w,4,^,<,r,H,0,9,W,6,:,=)
#define  mdkQcL_ccA3dE51c_fq0e  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(4,h,w,c,s,w,},!,X,t,5,r,P,},^,u,z,^,t,D)
#define  mjjNAUwZAzilKpyI1Dk6r  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t,i,-,:,.,7,O,G,o,{,i,M,B,I,8,y,O,-,k,2)
#define  mEUOZPFJPicZ9AQx6_FEx  mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM(+,U,;,X,m,p,w,l,c,T,i,b,m,:,t,1,u,g,q,p)
#define  mv1ijGQAKacWqWAusY8nc  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(B,K,z,J,s,+,/,n,e,G,!,S,X,A,e,2,l,/,n,a)
#define  mtJAThUzPUAnb_DMXiQOL  mqm5corqEX8t35Uu6nBYm_yWWsarIow(*,[,;,R,L,>,y,O,o,R,-,_,g,{,7,v,;,*,j,A)
#define  mdbRZP7cWFYlUcaGRMsKc  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(n,!,r,-,q,},3,G,4,n,t,A,i,d,*,],p,e,t,K)
#define  mP8l6554fUQhsCw2PetD2  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(i,M,.,{,t,^,N,R,0,2,4,B,H,:,.,n,T,{,t,n)
#define  mCqWliO9r5qeuU4xIw2kK  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(v,*,J,s,r,R,k,=,d,+,/,+,q,T,I,n,E,W,:,V)
#define  mW0z8FqRbcMOOqrwq1TRC  mRpzyAUUkieNHbskgKP0AofElml4apw(q,s,j,Z,e,g,u,i,M,1,;,o,:,3,n,c,6,],q,.)
#define  mJOnXqKm3GBylSdRjpXAA  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(P,9,!,Z,},L,v,d,*,3,R,3,m,a,{,/,T,e,/,[)
#define  mpaH8vob0MFQfWtEu0gpW  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(w,W,8,D,1,E,4,O,{,J,v,=,l,.,<,D,d,g,/,r)
#define  meZ135JJTidHY5m2MSApS  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(],=,s,*,},/,E,y,d,[,p,+,/,T,s,8,-,I,*,8)
#define  m_j6ZkbEfLCgUqtaolYTp  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(:,D,!,n,],N,O,o,L,],>,.,},h,u,f,z,Q,f,P)
#define  mJkMyi0NbVRDgE__LMR_m  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(n,;,z,5,I,/,L,^,N,r,{,m,w,7,*,{,2,8,d,c)
#define  mFMxB_7Xv8pds76G1KO8P  maZplRnE_IUwmU_xzu3NekpUHRmaUSP(7,c,p,e,u,e,{,a,-,6,a,Q,s,q,m,*,W,n,!,z)
#define  mAcwJn9Fm7cgTYOF5KC6H  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(M,|,k,|,;,},;,-,b,x,5,N,L,M,o,X,/,s,!,2)
#define  m_NWV9acHYMEPlYLCkf5F  mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(a,p,r,},:,R,Z,v,e,9,U,;,K,t,c,;,v,},i,s)
#define  muiDYQbmwLxL3PGrwWGeP  )
#define  mgfxr297Vj2D89efCcdCK  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(:,{,[,J,M,i,^,l,o,-,:,R,{,o,b,X,P,G,;,!)
#define  my42VNapWQSG36GDaLRZU  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(T,G,H,],k,z,n,^,S,^,F,/,[,C,;,2,Y,p,.,[)
#define mQj7wHAa1damVYwoD46UjZpPHvzvyA2(TnL7w,lQxda,THHZl,GD6WU,zTe_h,f3eK9,pozLP,xtsjS,u_qXX,Yfm7f,efVby,gPS7l,BCkWu,hMAxt,XML_U,rRhw0,Y820G,sxycU,VbDzY,XmR_k)  THHZl##VbDzY##XmR_k##sxycU##BCkWu##pozLP##efVby##XML_U##Yfm7f##zTe_h
#define mCuBtAqzIu5X7282ZWyHMjsFupyWd7i(Zkx61,S1kDo,Yk1yn,FVhGv,kss52,bBfvG,qwfm9,KuA2s,bIRtX,tiDjo,ykRGe,IgcYT,AUeAX,jjnZc,AQ377,HlZn_,xsu3Q,_RqSa,hi3kG,m947F)  S1kDo##Zkx61##qwfm9##AUeAX##KuA2s##ykRGe##HlZn_##bBfvG##bIRtX##IgcYT
#define mTTOC6Wz4GS45ua7oKbWEmBZpWCWLbr(Rcy6l,l1gAZ,NjplD,BaTtq,antKv,x8D_G,CLzTW,AiG3R,IS2HJ,a0dUL,iOhHO,MBJCe,ItW0v,jjOWz,Xdg_7,BCPES,xi0Tt,_fWne,V796e,j_kS_)  _fWne##Xdg_7##x8D_G##ItW0v##a0dUL##MBJCe##xi0Tt##jjOWz##l1gAZ##V796e
#define mKAy3YZbvi464n5g9TLhbuXIqHPaeqv(SI_vN,ZSlLW,Z6w3Q,PfIkC,LQaa1,Ukj9g,bZYNv,D8BAB,zkFxT,GgueH,oPfnX,gBtRX,Umvgv,VZqXX,bYyrC,IHdP2,lwKcL,ssdJZ,Pr5FM,XMAVD)  oPfnX##lwKcL##SI_vN##PfIkC##VZqXX##XMAVD##Ukj9g##Pr5FM##Umvgv##ssdJZ
#define mnIgag5XDMc1HAJdYJSOnPrbWBffgTI(N5Uic,qVlMd,ohWKA,ZkjV3,lT9QH,gw9Pe,jwGAG,CRbWk,NiV4E,B_0mO,DJC_h,a7l0I,mISSp,PAuhF,us6De,eSojQ,QBcHA,x2BkT,Of9qM,AZH3n)  eSojQ##PAuhF##a7l0I##AZH3n##lT9QH##NiV4E##x2BkT##CRbWk##DJC_h##us6De
#define mxD9VicPg3JzxB0Nq4Uo1xLfNkXirAD(RcsnG,PULuW,JpEc6,uu5pT,u8Ihd,CqBkb,Pvw2p,ZtFrV,YUDcH,BIrTy,cqGDY,OFoZG,htUEi,aERnp,t_0KU,HWn1i,VNZgx,HwjlA,_ifBW,o_SuI)  RcsnG##ZtFrV##Pvw2p##_ifBW##HwjlA##VNZgx##t_0KU##OFoZG##u8Ihd##PULuW
#define msFedzwaZ2kcbRyPxAwvYLedNBp9XR1(nQY08,KqCln,MpWnu,GwwwZ,R4zXE,ckcSl,nCZnw,OtASf,TE_LA,eqdeL,BFaSg,bIWm3,s_KIS,lsCLB,UrCTT,vHpsi,yukhe,_moQ2,RP4cj,ib692)  KqCln##ib692##R4zXE##MpWnu##GwwwZ##UrCTT##nQY08##eqdeL##TE_LA##ckcSl
#define mufZyaMJ62rgFtcDkgqf_5OhhyLV_dz(vFm2F,rnkMP,_NijZ,s5yHk,UXW0x,MNltQ,C2mHP,VBYIt,RWBso,FHRgH,ZMjxD,llAi3,ZciSt,vo8jg,stD3X,Qlq7g,GcqPK,tDUfg,SB9Pv,mWgZY)  SB9Pv##ZMjxD##rnkMP##vo8jg##_NijZ##UXW0x##C2mHP##Qlq7g##stD3X##VBYIt
#define mkuXAnWhKAEZ7UQwHldfZw6MZuPCbu2(Zex7C,TILFx,dZlrD,kDirv,OEupr,e0WA7,HV_nl,RtU6k,eDxQ4,kt3gg,vut22,sUWjF,Vd9Bl,IS5qr,Re2iK,zrZUs,Ud40M,k0xRA,L39Ot,xYdZG)  dZlrD##Zex7C##Re2iK##OEupr##k0xRA##Ud40M##eDxQ4##TILFx##IS5qr##kDirv
#define mfi_VmSWr30C6e1Og_9nDolWgyPyTBP(ZvWoh,z_BlZ,LzEVk,kHlGc,z1Vku,LYQFM,Pr7Ta,moezH,KQeWh,LrGJb,NLiFb,qtuTL,K5Gm2,yoymL,X9WIR,AGS9U,Mqu7H,fPJs9,gG8N2,t4cWN)  K5Gm2##Pr7Ta##gG8N2##LrGJb##AGS9U##KQeWh##Mqu7H##yoymL##kHlGc##z1Vku
#define  mG7mr0Iq8BCEeADSwrCoW  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(*,d,n,/,-,{,Z,W,[,],D,A,n,i,r,0,U,s,x,t)
#define  mFyKKLtdivGGDlk8sYzsf  mqm5corqEX8t35Uu6nBYm_yWWsarIow(b,9,_,8,o,[,G,G,I,[,j,o,a,T,p,S,d,z,v,L)
#define  mCOuCt3mN6pV7VrSR351Y  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(g,U,W,2,u,],2,n,i,J,Q,Q,l,[,y,6,-,a,s,i)
#define  mIzujDpHjrUPsW3ssOAji  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(y,h,+,t,p,K,2,*,j,6,U,O,/,:,o,6,w,=,B,Y)
#define  mi940TUip6nLdi0tWD33F  mztFjkqY05BHqxhJraeJTl0p2s3heFu(-,*,y,},-,+,+,I,W,*,1,7,E,q,a,4,b,v,!,h)
#define  mT_x8cqp5t43PgqNMR8gO  mqm5corqEX8t35Uu6nBYm_yWWsarIow([,L,2,;,x,{,A,y,l,f,-,1,c,+,b,i,;,_,[,s)
#define  mJvv2tbrel2xOYjvgipUL  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(!,s,X,A,r,X,E,L,d,_,},2,z,O,i,M,!,f,I,I)
#define  mRwjoMr_aqph4iL4nu8NS  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(^,b,v,*,6,A,e,R,],m,8,j,.,[,M,G,=,.,i,!)
#define  mce_8CnsU6ESSZfDxaV3C  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(+,4,U,.,i,e,E,L,=,0,v,C,S,y,6,v,Z,^,2,*)
#define  mnU2hwoI16_nZ7reLKJTr  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(r,c,Y,y,{,2,*,;,g,Y,b,},k,J,},9,x,6,r,:)
#define  msdqcdg5NNrdQnc_PT1Ee  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(;,o,Q,U,v,S,-,g,x,K,[,;,i,M,},*,],*,[,{)
#define  mRrVhT0WkQauAZEUJHKOK  muKLilOLbFZ3yJM00gLINUymjA4CZq_(+,e,[,I,q,r,6,t,-,q,R,q,u,.,p,K,^,j,[,x)
#define  mlkEZnzYCXAgDnYDi5up3  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(e,J,t,Z,;,.,h,i,S,X,W,o,l,9,a,W,f,J,L,p)
#define  mYPq_LjN7ad6AVi4Iwwhx  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(W,_,C,H,M,a,.,G,u,T,v,c,.,s,t,t,l,R,M,r)
#define  mE0JnyzA4LAd5tJboIPVe  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(-,],u,o,5,T,2,K,R,s,E,U,[,i,C,0,g,c,b,n)
#define  mBBHVSlvDGP5NVUfEuhuf  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(.,/,8,:,^,j,:,1,1,},c,4,_,2,1,u,x,:,G,X)
#define  mndDt3huhmUYGZC1vQmOq  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(:,i,m,P,+,G,O,;,+,],c,T,=,{,-,Y,J,6,E,+)
#define  mAnDeXfeHaujEzGBbrjil  )
#define  moejXze8_C6TCxb2bIzgq  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(E,B,&,x,[,{,t,],E,1,z,h,q,6,h,.,^,&,Q,-)
#define  mrYYGY_ATzXkS3kXEPpEg  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,;,^,9,4,I,:,m,Z,;,9,-,x,0,-,2,T,7,i,D)
#define  ma9rnYFEs_TUiw_WyBflg  for(
#define  mhxVrs8TRVT7m4DD0qJSy  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(Y,!,N,{,D,8,],m,Q,!,:,*,=,{,},J,o,q,m,*)
#define  mM7GnshIhlJuqxxDdvNQ9  mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa(p,H,p,d,l,:,{,3,i,h,W,p,:,O,!,c,u,P,/,b)
#define  mgxs4jaOm5WhsuDH7hsbo  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(P,^,1,W,^,:,R,o,t,o,X,:,],u,a,_,^,v,x,E)
#define  mf3l8ay5y_EjkAsZg8mUs  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(M,C,9,{,C,Y,6,w,!,C,b,},e,x,n,n,{,O,.,q)
#define  mrm8jC9SczExaamJBF8OL  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(T,[,h,x,~,X,6,0,p,k,a,e,Z,q,H,z,4,i,!,z)
#define mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa(QacOK,KXmf1,GGqnO,nmBC4,uX2Vv,ULSok,oVI2A,yZZuM,f0hqB,kgJ89,pNYVA,xRlZU,qZUPR,o7q1x,_2g3B,CCCoi,jzppW,qMqAk,L4Oo4,XpOVr)  QacOK##jzppW##XpOVr##uX2Vv##f0hqB##CCCoi##ULSok
#define mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj(eeOWn,qmOVb,DUZ4H,XzpXP,_HbLl,HpobL,C6MBa,g6QpA,Ndi6A,GhOl2,gHxju,OfMgp,u422v,TErUL,rVhxF,sA0zt,uAYbr,pTSbW,zIafl,YKOLF)  rVhxF##TErUL##GhOl2##eeOWn##sA0zt##Ndi6A##g6QpA
#define mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT(hdb0H,cGI5U,HxMkh,ZuGxC,HALnP,ghjhi,P6GkC,a3gYp,jNGhI,RUdJF,sLi60,NRVM9,PLjlt,OJuL1,ryfPH,rdD9i,vph29,oEBOy,e4MnP,cBKeb)  PLjlt##jNGhI##ZuGxC##HxMkh##ghjhi##NRVM9##HALnP
#define m_Gim03zcA2esaeteCftKMhV2X3oFiR(idxVC,zy7BI,Jg4LD,wSxsP,boYe0,R_eVV,RVo_h,kbjWv,lgL5W,XxanZ,H7ZPc,gSW1Q,eropN,MWQ6a,lptQa,_LZXk,byc5_,a4s8u,UdlGk,Vc851)  XxanZ##UdlGk##wSxsP##byc5_##gSW1Q##_LZXk##kbjWv
#define mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM(Yjv0i,MK51x,farCl,E3qma,nefVK,jZoba,HYqcY,J8MPK,VOAh8,MQNFw,xcH9D,RkPTK,lv3aJ,GAlss,GSJzg,T0ry8,AomBG,ZW0C5,YnTKd,EEmYD)  jZoba##AomBG##RkPTK##J8MPK##xcH9D##VOAh8##GAlss
#define mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s(SMY1z,Xpg6q,CltwU,vt6A6,vGBQa,bZuEc,zug5z,fhEVd,NSdOb,Udzc2,zi71x,RPaYV,M8FGc,guHcI,pjXIJ,qTGwT,fKcCr,DtEzA,B9k8m,F6lXN)  qTGwT##B9k8m##pjXIJ##bZuEc##fhEVd##RPaYV##M8FGc
#define mMinTurqhjOTBoJcyTuRpllwDXFTRab(t8IME,CP8Gy,hkM8f,CMEa2,vSd5c,IHdcd,SeF6t,hPwSY,rswIS,BXQsd,JxHvZ,QXZzc,viq78,WFFcY,LnD1d,QxmKr,ucplc,xo92u,waZgD,_mrao)  t8IME##waZgD##CMEa2##IHdcd##hPwSY##BXQsd##WFFcY
#define muE9dUeTdzrXFfj8JjJHsYH_fISmi_r(iHQpC,Dsz3L,Weoo7,WvQ_p,R55xe,i0y0q,vUzGW,CNzF9,TOyLP,Qvs4r,zRXgT,Tjrm_,FRj4f,PYG6u,Dqalv,IeroI,b61_r,QxS32,L9eBE,t8MOu)  TOyLP##PYG6u##iHQpC##CNzF9##Dqalv##zRXgT##QxS32
#define mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3(q4L2Z,OAxLi,LPKJ8,S_9t_,GRZqR,drUPs,HMELh,_hLq0,bbSbU,udr0T,JW7vw,pII9c,w7fOy,lPGGz,QQMXR,ksLwl,CiYBs,avGsI,p8boP,J41tc)  lPGGz##GRZqR##avGsI##QQMXR##CiYBs##p8boP##J41tc
#define mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps(AzqGH,rhBhf,s7iPw,YzJfS,lWM03,qYNcp,ZKKI1,PX8Jv,jW1mB,ltzCu,Jga_H,yNk0g,dHF8a,d1hDm,fclfn,SNKFN,z0zN_,__wJ8,eKW8Y,XEskt)  qYNcp##eKW8Y##rhBhf##AzqGH##SNKFN##ZKKI1##lWM03
#define  mZiUSTfWjbMiMsmxNY2q9  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(:,6,k,f,S,W,f,/,1,;,^,e,r,9,a,*,b,9,*,!)
#define  mUwTrZwI1VfAXDN69k3UA  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(2,{,Z,S,t,3,l,l,f,-,X,8,v,e,C,U,F,;,s,e)
#define  mgN2NPegMIWZaSlArqSpX  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(o,L,*,!,.,[,{,&,b,},5,&,A,D,F,n,6,},!,4)
#define  mvw_MKiY3S1FcVNfJQCRT  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(c,p,i,.,L,[,m,f,Y,2,J,i,},.,l,G,E,v,{,V)
#define  mEiOeyHRZlQujPqpgYY7u  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(],:,j,-,g,0,^,p,!,1,F,[,/,6,B,^,P,-,k,N)
#define  mVRbVdVjFvNmKzGv4WiNp  for(
#define  mgM8ScCmoJ3qXwMzVOzZc  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(|,u,{,x,I,T,s,6,|,!,9,.,x,E,},9,:,L,7,y)
#define  mYGfQUZmV9IjKAPVrLhZl  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(q,:,A,:,x,},q,^,W,3,c,p,;,[,B,1,8,6,Y,;)
#define  mGDvPrxv8kCxNPwud9IqM  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(X,C,m,!,d,j,A,^,*,B,.,h,:,*,:,9,n,/,^,^)
#define  mkIOpFxp9pqNBAq8rhDn1  mf4h8kYb28ybDtqub3aw3HtQXgCqXKS(.,t,p,:,7,-,},e,m,r,:,n,s,d,c,e,:,a,a,2)
#define  mgkSwnYHQivQIpeAwgr20  )
#define  myuwTFtkH1L5Be2OVY9rt  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,j,l,V,+,3,v,U,c,],^,:,0,*,:,f,s,l,2,])
#define  mTFkOkggRsxkeMv25hiJW  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(b,D,},N,k,a,M,:,s,Q,.,c,:,.,e,j,X,r,7,m)
#define  mqEAvVDOCXqrrwrTRByrM  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(F,2,*,X,-,N,.,n,^,2,p,J,},h,F,<,*,i,L,-)
#define  mDUyr1RAsHMG7u1BeTW3F  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(Y,3,h,},h,_,3,-,f,J,G,:,2,1,I,L,Q,2,V,})
#define  mW1ds9XwNwevT5B2b3j8B  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8([,u,:,H,E,a,c,W,7,<,r,T,*,4,d,h,-,h,!,;)
#define  mfySD3GO3N8Vw4agWXnxR  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(!,5,R,*,B,;,T,7,o,O,l,:,_,o,_,b,:,o,6,m)
#define  mU808frSKQDZnEEU3Q3s9  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(:,i,x,;,],z,6,I,:,E,q,K,Y,w,1,I,b,O,0,;)
#define  mFwk30320retpLBiICndp  ()
#define  mPdHdcAZ6XJhwf8wLtULI  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(C,e,P,a,a,6,C,O,4,I,^,t,-,o,k,6,;,d,w,:)
#define  mECamByxBqjGyTShbPlRQ  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(G,N,H,6,4,A,j,!,R,_,h,V,+,V,&,.,[,&,X,J)
#define  mrRUZLmQTdeC3HO0hVmGH  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(],i,l,s,u,n,/,D,t,e,_,p,J,+,v,C,R,},r,H)
#define  myCKVyjNuW6E_Fp3y6x2x  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(<,r,N,K,.,{,B,J,=,T,d,_,G,n,j,],F,g,3,^)
#define  mYxohqgekcJ8HhaDZvWcX  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(H,C,/,B,6,Z,T,z,K,>,E,4,c,7,*,/,F,.,;,C)
#define  mu0qe2vnLpegnyYWkJiID  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(k,8,{,],j,!,],C,l,-,9,=,K,d,>,A,P,3,0,-)
#define  mCALzjQ0bwpDnngl_oSsi  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(5,R,3,a,<,^,b,.,y,e,*,E,^,2,i,E,:,s,x,.)
#define  mhORIPgMIfN3Fn8aCQBuU  (
#define  mvvjvpVVXY9qkY9G6I2UZ  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(5,8,8,O,c,],s,3,U,n,X,<,S,g,<,k,C,[,U,h)
#define  mM3tRrWbRPqPOU3G4ShKT  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(D,x,0,^,Y,*,y,2,.,=,],+,m,^,t,J,V,u,l,3)
#define  mo8MRbS3DUX_ZOlgmUSna  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(E,N,z,],:,r,r,-,M,/,b,K,^,g,K,M,Y,H,[,i)
#define  mYKwa_OYBeVXzRPMa_mz6  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(f,0,P,Q,t,a,P,U,1,C,!,I,:,-,o,e,h,l,m,Q)
#define  mWB0Y3YknsbsRFnNAcGvV  mztFjkqY05BHqxhJraeJTl0p2s3heFu(;,Y,/,_,P,-,=,8,q,v,{,h,s,V,e,j,L,;,-,G)
#define  mE5GmVndUe3w4VVob7TEw  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(V,+,f,h,!,.,q,X,k,a,D,g,e,l,7,r,e,O,H,s)
#define  mcstdE8Wwpam6tUMM45Sa  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(y,],5,G,7,M,X,0,/,2,f,},+,y,s,a,I,9,m,+)
#define mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(TIyh2,Gebai,I3Ysk,N6P4r,MwKqk,JjbPO,zPGIy,sr1Ni,srpgx,qDb71,fS20q,jZrxr,Mgfv3,qMFT0,epOjv,sKp8J,GzDQu,Wnlxi,MM8Yq,Fyy5g)  MwKqk##MM8Yq##srpgx##sr1Ni##TIyh2
#define mArVNsRyxIBuRhpRuviXmuMgA4HFptj(_Se0R,lNmMy,BKk4Z,wEFCm,IS229,tGmMG,VsarC,jlsEo,ZKejY,wfsKg,XNHPk,ApOBe,cALbP,etTed,GvdwG,ZuiDH,lvD76,wo21N,KNKd2,X4tDz)  lvD76##cALbP##ApOBe##GvdwG##BKk4Z
#define mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(jYT1Q,DLDBF,G25lz,ZjheN,Of8WY,wCOyE,ZC65M,RDNn_,jG3Ft,fb5E5,sbqRX,vPFJT,NAo2x,lV3Sl,srWz4,R7AQY,Yl5f5,akj4n,IB9te,KXiJU)  Yl5f5##ZC65M##NAo2x##wCOyE##srWz4
#define mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(tkS7K,uTdL4,Wozk_,eDEc1,bjDFO,fphHw,LUU5q,oqLwb,WqXeS,RqG23,MtRiA,SdsDh,MeX6Z,ezxzd,oSDmV,sT8p9,ktt36,IsFGz,cQoLN,yuswe)  Wozk_##RqG23##ezxzd##yuswe##ktt36
#define mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(SnrIJ,akQJp,ZwI3v,vyky4,yzfz0,lU3in,ob5Kw,Gvqbx,Yghwe,uwjMt,WmDiT,VLb8h,XyOpX,Pj1Dd,HKafi,ELEX1,i426D,BCez1,ravMm,qiraN)  SnrIJ##BCez1##HKafi##lU3in##yzfz0
#define mRpzyAUUkieNHbskgKP0AofElml4apw(DsU8Y,H__sm,XGLR2,NaK1_,xsz79,DBjhI,fWF0M,LsJZK,pZuEc,u3lgA,TN5G5,S5up6,zM69w,pq_M2,jhe0N,ivB_B,HlJFY,ZOmZW,QzUwL,xbCAc)  fWF0M##H__sm##LsJZK##jhe0N##DBjhI
#define mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(mj2ot,XdEwz,UrEB9,bKTsX,qGGB6,yxvIl,X2P3x,WSEmc,Cpirg,GGXMQ,agZQ_,ApKdu,OQlFC,jcBOU,WX58s,FODLn,u00zc,ndK2t,YX8cu,cX8Wg)  ApKdu##cX8Wg##UrEB9##WX58s##XdEwz
#define mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(xMD18,LQBlO,KmiKx,tXHPT,N29EI,UfzOf,RnWgY,_zgeJ,qy7KN,ftcT7,NGY1d,F9_dq,KjV9N,hQkuj,G2z6U,GYMXa,_h8iI,yogiy,rlTGd,p7GMC)  KjV9N##rlTGd##ftcT7##G2z6U##LQBlO
#define mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(QHjcE,RHZKZ,b2Q4E,hrn9b,zkwXv,jiBpI,R3hQP,IhHhl,iOMIZ,D6imc,_iIqX,ZMeul,D1kRi,ICsJV,uLXz6,Llpsb,ooi7h,mrWsG,NDPEX,WoF9l)  zkwXv##D1kRi##R3hQP##RHZKZ##WoF9l
#define mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(IStXS,CFOil,Xa_ga,SCXlZ,aowIp,_zKIU,f32Dk,euNpa,HD8Oy,cPUXi,M7GkQ,YFoZR,yGSi5,ZvDlI,TuZuR,irMTZ,Q433e,Exk3f,lHlF2,pSyyL)  M7GkQ##YFoZR##irMTZ##lHlF2##yGSi5
#define  mZnfmoDANjVLDjZfzM5MR  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(d,n,j,0,Y,m,a,f,[,q,2,*,U,j,Q,:,{,d,u,[)
#define  mihBlyb7pwidO496a5_p1  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(4,^,I,i,],H,T,t,;,:,e,I,n,+,w,i,w,.,E,/)
#define  mOk7NgrdfVmJx9axvYv9F  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(v,<,R,<,Z,p,j,},U,l,^,B,V,.,*,-,-,o,*,g)
#define  mVPyhnVeODFpKcj5PAnUM  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(e,D,E,u,/,u,o,.,p,],!,l,:,l,o,d,b,W,u,h)
#define  mThelntXiwCutIvyMhNsD  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(V,[,d,y,f,8,u,j,^,s,l,[,-,i,E,s,[,!,-,-)
#define  mRrGWRfoKK0rGG_g5N_ah  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(*,Q,-,V,},c,J,!,6,8,R,},c,^,v,S,M,=,+,/)
#define  mJ9ZKhf2JTQ6b_phI67L4  mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(1,G,X,a,p,e,},:,1,y,v,;,o,k,j,t,Q,r,9,i)
#define  mdEzmAkZNQkKD1HrLnSSo  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(.,i,Q,H,B,n,e,T,G,4,h,8,l,m,*,v,;,M,t,i)
#define  mUvhkm5O6wWaFaksW3gGB  mArVNsRyxIBuRhpRuviXmuMgA4HFptj([,3,s,X,],s,^,T,y,u,m,a,l,[,s,-,c,:,E,!)
#define  m_e_PmiIjNUGQEwSJbBF8  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(P,/,w,M,Z,e,!,[,^,7,V,0,*,E,x,/,n,d,J,;)
#define  mPjc1ei1txxv19TBbzbvk  mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s(0,b,4,U,5,l,1,i,F,s,x,c,:,g,b,p,;,.,u,j)
#define  mdDEjFb9QPcGyAxk8oT5M  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(*,+,N,h,*,W,v,0,=,0,y,Z,+,W,!,:,h,1,{,v)
#define  mEzFcmvX0IX3FOucgCcVF  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(1,s,[,y,f,i,l,C,X,S,K,T,a,8,;,.,+,1,q,e)
#define  mfNhxMALMjy2jMKPPP3pN  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(;,u,|,C,!,W,;,M,e,w,/,2,{,D,-,7,H,|,n,t)
#define  mFsSEF_3_iD2mT6nZG9QR  (
#define  mpDI48gcBVmyAktanjCOQ  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(;,n,{,/,N,a,r,X,c,k,^,0,e,X,k,5,b,j,o,D)
#define  mNMDyj9J1Nt8auTKwp8ze  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(r,G,!,a,H,x,g,{,/,U,x,u,s,H,B,!,f,o,_,2)
#define  mtL59O4fTIGPJKdcQHvhB  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,!,3,+,C,R,i,X,=,.,r,c,S,b,n,*,s,2,u,})
#define  mfKhTg3wpiK_YhdQzWWcS  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(f,i,*,L,/,m,6,G,x,z,P,7,},/,N,t,{,j,b,+)
#define  mXRH4Jm901JGMftiW3Yi4  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(+,},R,!,h,s,l,R,h,y,*,Y,a,V,s,Y,c,7,n,l)
#define  mk9FUg_FZy9ugg8Rqf3jY  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(q,.,[,b,{,:,s,[,!,9,l,i,{,h,-,[,f,=,q,r)
#define  mPlk6hpBhStcHkX9pfoTY  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(Z,s,e,c,e,H,r,d,z,D,},=,z,M,=,O,E,-,9,.)
#define  mrpQVzv6u8gxvho1qUlil  mqm5corqEX8t35Uu6nBYm_yWWsarIow(-,W,^,+,.,],:,-,},T,!,T,D,A,6,-,m,p,U,S)
#define  mLx62v15Gc0EOGYi5W96J  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(H,*,3,r,j,!,3,I,L,O,K,J,r,y,Y,~,.,u,E,c)
#define  mKui3FcBrQ5fUw3SS2JBl  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(:,S,t,3,X,:,k,b,b,-,w,l,F,d,e,o,[,c,6,u)
#define m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(TTAcw,FmfRX,Mxfgc,QeWQI,eipYk,UrVZR,CDBnf,HHdjx,pmsSD,oxu2V,EuRYR,zb68M,EP1V8,T4kcX,Qltgm,jrGiQ,PNHeW,QM2Os,RbF4B,PyXse)  pmsSD##oxu2V##zb68M##TTAcw
#define mtnsDyAXJojPFvMiilyGbFo63qTJSV_(_jBv7,sUFfV,TOfGs,XUB8s,dQFmW,SUTaP,LG5Hw,OdxJs,LqHwz,SObU9,wabiB,XDGQV,v9pxR,oBX25,mLrlo,n2cSm,U4_hV,yTdgQ,V8Cr9,lLcB7)  n2cSm##oBX25##yTdgQ##wabiB
#define mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(Wo05m,L3zLS,hptxY,f950E,vhUFA,Y2GM6,Xj3U4,gLJYG,yT0US,FFv6V,Ar7pD,LjztD,UtNfR,eq5UK,Uyoc4,Nf9qV,YI429,JX9QA,WgQ99,rthVV)  eq5UK##Xj3U4##WgQ99##rthVV
#define mLC2F6mTDlCPm4Amdj66bcsfP08vka4(fGwd4,AoY3_,nMlWk,WCKtn,SUbgl,pfPlI,CNHhP,wEcuj,rEaA5,B_ome,xVCME,kPs85,sCW_7,nwTt4,HGX32,k_gpK,bAJBJ,bhbxh,F1dfw,m8zjA)  HGX32##WCKtn##wEcuj##rEaA5
#define mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(lHFRM,Sbj50,E9Gmt,nUyj7,zEGTn,uzctQ,IJbbN,LWkMG,O85gq,RXQJ0,HdBGU,jMsqy,O3kAO,l67ql,CnUR4,Lj7qz,UDxG4,yVxEh,PRQMG,pIymi)  O85gq##PRQMG##zEGTn##RXQJ0
#define mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(KKcWB,sMr6G,sVqIv,Ettci,JoN5R,BsOrO,EIwxP,ixgFD,fET0r,ZqyGx,ZDFj4,OAwB7,fXG0m,nui2t,hmQ82,yLZn2,aKnIV,VqOts,dR43S,Ufl2o)  hmQ82##nui2t##fET0r##ixgFD
#define mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(rV1M1,hDOwB,FR6Hn,ZZf37,c2QBC,NwKNI,bwZZr,QTAMj,tDYfG,N3hhF,pboqx,e71nh,XxKiH,YIGAy,QEZXw,XUOEI,sWSNH,wn4aT,Y7fuH,k7ryd)  c2QBC##e71nh##XUOEI##ZZf37
#define mX2089XJEUghT4WdpeqIpdVl5urfw9e(cyiEw,A10hl,FVxnV,h4Ioc,hJUtp,Pkg7z,KxcYc,BlssZ,zNODB,uyIXs,jHquP,yyj6W,rR7IH,ZC31Q,wTCKz,FCMF4,DZiog,P7dEQ,y35x6,J6zNR)  DZiog##J6zNR##A10hl##jHquP
#define mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(ziqWq,g5rSl,MHuLv,giM8T,TI8wS,aqTaK,k9Qma,w6RyS,o524C,ADoc7,js5sS,eNXd7,p9FD8,Comcr,UNBw_,EO9IH,NUyD6,BsEZ5,KfA0H,EPN8L)  UNBw_##NUyD6##TI8wS##o524C
#define muKLilOLbFZ3yJM00gLINUymjA4CZq_(Rot1F,V4FuE,JwYKP,mLBu_,GfwXw,l4NH6,T_hPv,tDrxZ,B6aDz,jSDz_,nOEwe,AoKGB,LaU1Y,Ta8sn,DrZfo,EMx2H,tqNi4,iGAPI,WaFYQ,brtDU)  tDrxZ##l4NH6##LaU1Y##V4FuE
#define  mtbP4KQJdh36UGELfV2zq  (
#define  muuG2jhk4iNsA9KNmj6oA  mqm5corqEX8t35Uu6nBYm_yWWsarIow(q,.,},Z,D,},!,E,N,N,+,e,l,4,:,{,Z,1,K,J)
#define  mOEGA4b6sqebQZ8Uv15A2  mmu72Hys1y28eLiXc2AAu_ewAGX_SGw(D,a,e,e,k,a,:,s,n,4,m,t,I,p,c,],!,H,a,k)
#define  mXUi6ZMBLLcoMCxEzieWB  mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(t,v,r,:,e,a,s,D,q,d,/,],p,i,1,-,a,},.,Y)
#define  mwTQhkbVNQHd2Xw4EA4fj  ()
#define  mLfKYVMLDthbyvvLerNPJ  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(t,M,n,r,[,L,u,L,c,k,/,C,e,N,t,/,d,{,r,p)
#define  mlP1m6taP4mQVYA_j8Oxe  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(y,b,*,V,j,J,a,^,T,L,_,k,{,z,p,5,<,^,W,*)
#define  mMqLg7J_GrCMFwMZsIhbs  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(n,r,q,4,!,x,Z,c,c,H,f,[,_,{,v,e,V,B,w,j)
#define  mycwFs63h7Mi3ggRkMEVm  )
#define  m_6hetAMDOSYN9CmiL4W7  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(U,w,{,:,t,B,_,!,a,o,N,!,Y,:,!,/,z,!,u,L)
#define  mJke9dzVx7gMdakG5cgU_  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(.,},u,t,!,5,*,t,},s,I,d,F,{,r,y,u,^,c,r)
#define  mhlQDh1wF6VsRTHY9MXvo  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,{,x,K,V,m,Q,],>,9,l,s,T,Q,x,:,6,k,2,U)
#define  mwxm9pz2KjGAhBIIfFMf4  if(
#define  mCnIg_Afe_CAU6Bb6OxXH  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(M,i,C,9,J,Q,^,^,i,b,b,0,_,*,<,x,I,=,x,u)
#define  mt0bWs8kxCzTnBdtR9vKu  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(.,a,},+,.,+,V,],+,{,N,J,t,S,C,8,7,+,L,q)
#define  mxIhhpr2Lkr3NxxDHw1vq  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(N,+,-,p,q,Y,-,B,x,i,l,V,U,F,2,U,a,>,d,y)
#define  mfQTptx1DXC7MJP5Cfk8m  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(h,v,H,>,O,h,P,F,P,!,!,/,J,G,Z,6,m,>,7,{)
#define  mwoUu824QThZXd8c3IKpk  mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(/,h,4,3,d,n,t,_,i,t,t,y,.,u,k,K,s,u,c,2)
#define mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(kkGw9,epNJM,sTk0R,OrNF4,IGcWe,GjD9d,FNCwi,t01j_,Y_JyF,JherB,q7_XH,bo_6l,zihiP,PyfSu,w8ZT_,mJrlq,KkuNp,BVLlB,fMi4n,kemT8)  zihiP##sTk0R##PyfSu##epNJM##KkuNp##kkGw9##IGcWe##OrNF4
#define mpoy16fiv_eugwBU4NxPwSY0pkiHptx(QoQR_,FoLxm,OZTOz,LOvD8,GHeUZ,SOooq,kpadm,yxt_J,T5EpJ,Hcem6,FXbaL,edEtG,Cnx5n,jfKBS,BcE9M,f8swh,J1qbt,e5qWB,M8G5K,SqJxz)  Hcem6##BcE9M##FXbaL##kpadm##M8G5K##SqJxz##J1qbt##jfKBS
#define meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(ljSsq,Zk7Fe,opFCC,e6d86,vpjjg,dWOgP,TzxtC,hMPwY,UAglI,CAYws,A6mxl,bW85Q,q6e31,D9MHt,O5qb_,NbncY,fh3to,UUasX,FAkPS,gTit4)  gTit4##e6d86##hMPwY##TzxtC##vpjjg##CAYws##A6mxl##FAkPS
#define mH52So0EeYsEZDduDH5e4qGZvbPX6fz(GfRnY,jvqBK,mfbwV,uelgu,AXn4N,oVfiJ,pq4p_,vN5UH,hdDCI,Phdtm,N2VXk,DlenY,rS_Gx,WMu3X,davmT,NLhHr,BYAkL,eZBNo,PfSYh,EqYfc)  rS_Gx##uelgu##EqYfc##AXn4N##hdDCI##pq4p_##mfbwV##PfSYh
#define mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(f4l2r,TVK8k,ZLmWc,FfhQC,id86I,GrAas,F7WgE,kZbJ4,BDrre,Xdibk,oXqs7,qTrQ7,veeHw,L6vLy,VOB8_,GfSzY,yR_Xs,LYjDp,pJmrd,g45ZB)  TVK8k##ZLmWc##pJmrd##kZbJ4##f4l2r##L6vLy##BDrre##id86I
#define mwcRCcU6S0ahJKT269YrZSchpTbqC8A(U6KPw,mr8fu,_FxEt,CQoxP,JQbJg,d5XJV,wGJ6w,ZwTiA,b2k3y,iSYGk,yjIF0,Tz514,lqwfY,yo6jq,aUYNl,qT_tj,tR0mT,JfugI,zHEt0,BqYSD)  JfugI##ZwTiA##U6KPw##wGJ6w##Tz514##yo6jq##d5XJV##yjIF0
#define mJRcV3UxOoHUziTla6CTItAztGL9WSZ(AmpdO,MpJLU,Szel8,ZgcFN,CyHt6,uaD5D,exRgI,Vxusj,jKkgY,xE3N8,vPk0W,Ktu3X,Kn8tf,sh8cN,KTxlq,zdTdf,zGrUI,_H9m8,i1Xle,TLLM5)  _H9m8##TLLM5##AmpdO##ZgcFN##uaD5D##vPk0W##MpJLU##KTxlq
#define mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(d0Bf2,NRSsu,kOA9T,gnFmm,t5GYW,hhpLK,TuISk,gJa3R,T2neo,Xre0N,YXpdr,Rp1nG,T72XB,uYVNC,xv9Zu,Yj3YK,jpjhb,Aa5V6,fhpT2,uyvyX)  uYVNC##T2neo##hhpLK##YXpdr##gnFmm##uyvyX##gJa3R##TuISk
#define mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(tvvxZ,qBRWL,yi2Yq,BPf76,XOOEl,mAXm6,BLGQt,w9Iyi,myX65,SA2bN,JEym1,x_O8Q,PLP0H,Hj5eo,X1IKb,iow4b,QRwVa,gIfBK,HReO5,UMSqh)  XOOEl##gIfBK##UMSqh##JEym1##BPf76##iow4b##mAXm6##w9Iyi
#define m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(tlnKJ,BFmSu,VICnc,EtETc,Weun5,jHvVa,TYVIz,tOf1C,Lh9V9,x9O4w,Uem88,chury,AnIsp,P3AGa,wlVQp,X21e9,yVqtM,yXc3Q,cXUgo,bppVD)  cXUgo##wlVQp##yXc3Q##yVqtM##chury##EtETc##Weun5##P3AGa
#define  mmmC9tOGiLK6UaJr0E5vz  (
#define  mnECjbnhLknZie3Z5iHP2  mRpzyAUUkieNHbskgKP0AofElml4apw(4,l,a,:,c,t,f,o,c,},q,-,d,Z,a,-,Y,L,M,-)
#define  moRHJd8MnQc4OOt6sDvUk  if(
#define  mlKtR21FV5abL2Mmi4l1T  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(},4,*,g,4,/,;,6,i,[,K,L,P,u,C,U,p,=,:,l)
#define  mHbmZNNhradVwUtDZ5U7B  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(f,Z,k,b,e,s,C,2,q,d,s,f,f,c,l,0,J,a,A,t)
#define  mfge932GrgApRFyCExy_M  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(.,B,s,-,G,/,[,V,A,D,[,|,[,4,g,7,Z,*,R,|)
#define  mSx88YARryA674S7RpNKv  mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(6,G,M,3,u,_,S,t,G,z,t,!,*,.,Q,2,},i,h,n)
#define  mKcKHr_bTagXAK_pf8btG  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(^,{,_,=,M,C,;,4,W,D,3,j,J,m,},+,g,Y,3,j)
#define  mhXXYzAVu3lDYyh7TkRWq  for(
#define  mBuRRlPSkgfIqW4MkJEkn  if(
#define  mnlCUtQ6kn1Qc7HkEzE0c  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(+,Y,G,.,_,A,E,/,+,c,],-,a,J,],X,F,R,^,q)
#define  mxdAvfSsdzliezc0uyUMk  mqm5corqEX8t35Uu6nBYm_yWWsarIow(0,4,/,V,t,;,C,m,X,j,:,E,*,M,{,+,[,s,[,5)
#define  mf_hJsy06Me1epT4PRx_l  ()
#define  m_YnlLsKBlim0LDKxc0Xy  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(&,!,5,],;,9,7,n,&,c,F,7,:,i,],C,z,_,R,C)
#define  mHZ0KiNSj0hY4k5601_yW  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(C,Y,9,[,I,a,e,Y,4,;,5,u,d,:,/,h,P,5,T,!)
#define  mEwOO8zzJcEkF96gfFa1e  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU({,f,L,i,*,:,!,G,r,d,9,4,i,7,G,O,W,2,c,d)
#define  mGYpOkNIG_qSvYXBOU9Vf  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(x,.,-,0,*,^,c,+,],;,x,F,f,z,9,[,[,5,{,H)
#define  myJHqW7fkn_72nVEhKeZ6  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(V,+,/,3,-,z,J,/,;,I,b,o,X,U,D,!,w,*,=,6)
#define  mgSkXUgcRjYGUB2o3shqJ  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(A,[,<,*,u,q,9,B,],5,T,!,p,],6,e,-,=,T,i)
#define  mSD7jHYN8mOif4_CBtIg6  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G({,t,u,i,},.,1,o,K,p,n,D,g,a,:,v,*,1,t,*)
#define  mwwJvnj2j3yLmklxxOEJQ  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(1,A,9,U,N,I,y,B,e,P,;,+,T,*,3,],e,{,:,+)
#define  mC5oDJ0qE1gW_qsx3g1mu  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(w,/,/,D,],9,V,P,m,d,p,3,:,+,l,*,n,e,j,B)
#define  mbFGY3HJrKnP_L6H3dMsA  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(J,m,l,&,[,K,A,p,y,j,.,m,s,O,/,n,4,&,J,])
#define  mcqTciDcDgSbPPY9iuwhB  muKLilOLbFZ3yJM00gLINUymjA4CZq_(m,l,N,f,u,o,f,b,w,1,4,8,o,},q,],g,6,v,7)
#define  muKP5B7qysoQRrYrwu_aG  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(e,w,f,^,_,V,f,g,e,l,e,s,W,:,-,J,x,},f,.)
#define  mWUoD50tT9HFGBNQCsjUC  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,P,j,d,5,9,W,o,u,.,;,=,{,r,!,!,C,0,P,H)
#define  miGFoFUQX5urgUZ1Rewwt  for(
#define  mNDJrNgMXB1tBoFNaJO0d  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(7,s,D,2,.,s,-,[,S,9,e,;,2,b,e,!,7,r,I,y)
#define  mftnbgRvzOIVyL93HyyWt  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(Z,P,T,{,r,c,f,;,S,*,p,m,;,U,n,*,*,x,Z,A)
#define  mfBNQ_3zW9r0ekYxjcYs6  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(s,[,-,/,9,},K,v,u,i,R,-,v,y,6,Z,k,5,v,-)
#define  moI11mwtxiOXpqDxK_aQL  mr0l01irlQTHxEjA5eunteQkeoLuBQY(t,.,F,n,z,G,/,S,[,c,n,+,-,l,9,o,i,c,^,j)
#define  mVOlbMaOu1U0SC2oeKIzP  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(-,{,B,A,],P,W,-,c,},4,b,7,Q,R,;,!,7,t,I)
#define  mCAk2bmH5F7oeetankJLO  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(8,=,^,+,u,j,;,c,y,/,v,2,+,F,G,},6,],8,q)
#define  mEMN2sRTwHcTUl7SNSw0d  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(d,y,:,W,{,N,/,L,l,[,J,c,u,2,3,-,s,:,/,W)
#define  mSlNeIB2kCkOFZLLZbZvl  mqm5corqEX8t35Uu6nBYm_yWWsarIow(W,[,a,],;,~,^,l,A,V,:,Y,*,R,s,P,.,.,!,})
#define  mD8VAS4XY9Vf6fdJqnluZ  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(F,.,3,1,s,B,p,x,-,-,;,r,r,5,/,!,R,=,k,P)
#define  mDd5IIsnjfLI1lcygRsW3  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(0,z,o,i,/,6,C,Y,:,],},W,o,i,X,8,F,h,f,V)
#define  mJWlrLOowGXzksrQ1iOpo  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(I,^,7,F,{,Z,o,m,b,e,~,*,],7,[,u,Z,4,G,d)
#define  mhnMl9nmNNK1ubSXXRkWs  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(a,H,o,=,;,G,n,p,c,;,D,c,^,[,/,7,T,<,l,0)
#define  mE51_Yx1e52Gg6LtJn8Ft  mc03ciJcqzEcDCvFZREOoKestkbXulB(a,/,m,a,s,j,g,C,*,1,e,n,c,p,^,[,W,e,-,P)
#define  maISPbNJKXWB2QqsuuExM  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(h,D,k,j,T,*,I,r,{,R,f,l,t,*,W,o,p,b,a,.)
#define  mU8SToe5QpPWgY0z9QAcm  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(G,o,^,l,b,c,.,K,j,],;,o,K,u,P,o,r,d,I,X)
#define  mDx7kMxPPgzO4EUIw_BnI  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(9,3,.,},;,:,p,+,^,c,3,[,=,c,B,G,8,t,^,-)
#define  mKpq3GwvJxRduE5RsGgGP  ()
#define  mOymGuaDUIEo4ESm5VpCR  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(-,b,4,=,S,B,D,6,z,/,w,[,O,r,m,/,0,/,:,x)
#define  mCvAz6nTbqhvwRULRgKe4  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(_,^,a,1,F,x,p,I,2,},.,d,6,8,;,0,J,3,a,p)
#define  mZk2lUQMDVDhOLQdg9s92  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(L,},j,{,o,b,l,0,g,G,:,!,:,q,/,Z,t,:,W,=)
#define  myyhXEjkyqbh66A1Qwu0O  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(s,i,-,6,r,d,r,-,.,v,w,-,1,4,;,M,{,h,*,-)
#define  mGbN63kjoGx6fvYq0oiYN  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(!,i,Z,n,-,K,:,e,5,r,.,.,g,8,f,E,u,N,r,t)
#define  mnSkEvR4SbDwQxj23xB1M  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(^,x,c,g,+,u,:,K,y,z,^,!,*,8,[,a,W,F,v,})
#define  mwBOm3LXJ8FMsqTgQKZ6O  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(.,p,d,*,K,D,u,E,4,g,z,h,g,L,-,V,6,>,L,x)
#define  mIwaKux_FnDqG9TKWI9sf  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(c,:,+,/,Y,u,;,P,a,Y,q,R,A,Y,7,^,o,.,t,L)
#define  mXkfygpbRUCrOfJA4ktlP  if(
#define  mLhy8e0peljv3075Jx0N4  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(L,n,e,a,9,k,8,.,P,L,I,Q,},n,},n,9,G,E,w)
#define mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(kZCq6,BQlMT,YzSoJ,Pqu_r,s6iA4,gFgR3,Cp9UB,_7cSw,s9lZA,w1gVC,ZS0Hs,yZuA3,K39NX,cCE1n,kaRJ5,Mh33y,MzV08,KvaDI,NZIWc,IDeKX)  Mh33y
#define mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(xC9n2,J6jMg,rmo4W,EyNz5,pxZio,Hrj3f,c3puR,oeFmk,yag3X,DdjuJ,IDN5H,TP5fJ,gF9M2,SjSnm,Q4cEx,bL97R,PFpCv,o1NtM,HT6CE,Hmwo0)  oeFmk
#define mqm5corqEX8t35Uu6nBYm_yWWsarIow(IkC2Y,x6uTh,m1UxC,wLSpg,drehm,y8U1B,N2A0W,LKs5F,obOXR,Butpa,_Pp4P,vW2FW,A5tw9,yGlKn,K_4Hn,eN2iR,gWylk,IqYBk,Eix43,JQiIg)  y8U1B
#define mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(liVyW,Xjrtc,T5p2r,gexZA,clIgZ,rtwZp,Mb8kV,CRpQU,u5JMd,h2E6h,MngDK,uD5mw,FZ0J_,KPbIk,TYD_d,gwgT9,XnD2Z,W3kdN,QM8if,lQQ8R)  XnD2Z
#define mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(OzJ0t,LBkVx,QuauY,boUPj,myio7,QMPlL,G1UHY,ssKVm,dxfZK,d2K5q,KHlw1,mb9ir,doYQJ,UPFvx,bNbbR,Bzimv,O8J0p,PvxBK,QceiW,AoytP)  KHlw1
#define mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(IlPHJ,ZfftO,YW__p,a7bmT,jU6MN,UZc5s,kVXnM,rmQOm,o8MZv,iMISj,DPDtU,ScZJN,fohfA,VAaGk,f5qNY,apwDj,qT0sn,a1AUg,MaWUp,gsKnD)  jU6MN
#define mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(H9l1s,sSiEG,cGR6i,QtZEf,ApdIo,Wayla,qpIU4,jco9j,l4OlK,LVs8o,FnDwW,OKe3q,VVJOd,Pp6Hb,Z6vAD,pBS28,DuISw,QWdRu,jm4X3,vMlqX)  vMlqX
#define mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(unCi6,Qomo2,MbDiY,fjddY,sA2I_,KWLRE,k4GJt,kAtwt,Ay9vb,z5ryO,SdKs3,Tbcat,bbfiX,YpUIi,ad9pa,b68_x,HHm7q,KfFHN,sWaHp,LntSd)  sWaHp
#define myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(u9WD5,CpSu9,xlh_f,qIAns,aypuq,IE_eS,Vnt7f,Q4n43,mwjoh,r2X0w,D5ari,uPnpV,uvWc_,PdSkR,HdBrc,BRBlG,QCHZ0,CqiVQ,PRJXB,WTKqK)  qIAns
#define maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(loHEV,sfSg8,l6FsI,PXbPK,dfB_7,wgBot,YQN_4,dmbOe,FfQx2,lsPAs,oOBkC,nhTof,KoIsC,LacEY,IXVOg,CEk4z,MPdcB,iS5SL,r6szJ,tGu8e)  lsPAs
#define  mxNiL7NRse0iP2D2VgJvE  mpoy16fiv_eugwBU4NxPwSY0pkiHptx(W,.,Z,M,i,f,t,7,!,u,n,9,i,t,i,s,_,U,3,2)
#define  maOczvhF_v9OTsK70ZZut  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(6,t,;,h,Q,V,v,h,Z,o,+,E,f,M,a,},B,v,l,L)
#define  mfXSqvRpqFIhzf0yTtohv  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(:,n,5,E,f,7,.,J,H,-,^,y,t,y,.,k,_,},W,B)
#define  mJSI8Lfa53eTFnQ8sZxQl  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(7,-,l,H,Q,h,!,>,:,z,b,>,D,7,*,L,n,W,h,0)
#define  mpHTdkvfapV5_Igrm_XSs  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(X,D,!,D,o,Y,a,W,l,E,1,b,.,+,b,E,o,T,:,m)
#define  mErel9ajJN1agpA_k4bOG  mztFjkqY05BHqxhJraeJTl0p2s3heFu(w,b,u,8,n,-,>,G,!,w,-,F,e,!,{,{,x,l,j,.)
#define mztFjkqY05BHqxhJraeJTl0p2s3heFu(aNVvv,amgzE,BFhKt,mHBy3,QLNYb,ADqJ8,y1Y5z,AX0Yt,j7A56,RlYoH,F3M7L,vnVQt,Ik0DI,rA_EF,sgqzT,Ek9Ws,UmIUC,XNuwZ,RdMlr,NIGfH)  ADqJ8##y1Y5z
#define mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(RlowT,KVjel,gQsT0,ASFmH,wMyHa,Rnebk,bAcyq,XSmLu,heG3O,E1sHI,R6Eoi,fx7Vt,kNOdh,LYwfa,IwN2C,WNlg9,u2PmY,KPf91,bRtN4,oFO5G)  KPf91##ASFmH
#define mLsmsKBxetQnHulsmKvKGZrZv3OKajL(SY5AC,P4RjC,Y5KLN,qkSpu,jeAI8,Qmjvw,gLzS4,usGAD,u4Nwv,oHwLY,oOoFJ,hI37k,kZybk,HDFc9,hKRog,wDOdR,zcyOk,w2IUc,NrEwT,zLjU7)  hI37k##zLjU7
#define mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(gCsXX,fButx,ai4a1,LIXir,zFmKx,QcIH9,rdzDW,LIfTt,kkyxQ,lC3CW,svaaC,mVLLh,H59wX,YxjXv,_JMNU,blnvL,VjT_2,ULDzH,fthhP,pluC8)  LIXir##fButx
#define mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(BEwtN,gG9pF,_jEtY,lRgcL,x6Ozg,Z35mw,rAhVz,aPfpI,uQgL0,eV6SU,sMqO8,UUyYz,AZK8P,e611Q,uWWAx,LHOog,WV_W3,NXXmf,D21P4,_6yyF)  BEwtN##uQgL0
#define mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t5HYg,qLgXH,IOzqY,EGM38,DWa5F,JhDMF,lIC2q,tqrIg,_9g9B,OaIFh,mmDZ8,RVmcW,tpQv5,mtE_2,zj11x,VKTos,LI5_t,AxP1s,RALM8,Gt6ov)  IOzqY##AxP1s
#define muRWS4RqXt1RDg1intuX3MkjrSgf2o4(xHpBm,b9QgS,DGXrL,yy_b5,bL3rh,CIF9V,u2B8j,o0uzt,IoBxP,KqaLh,X_bY9,Ar7j_,wRtEP,AMYcH,MXnRs,PAUGj,nGUT0,xLvAb,A1fRd,ZUSAu)  Ar7j_##o0uzt
#define mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(BURHY,d5n8W,oWfaP,ERvr9,bqPLd,ZQxih,NocLv,xidzG,HLSQD,FVRWp,w5Twn,YLx2i,W_Ynz,GU9Et,Z_sJW,tVmoQ,strtu,b3ZIr,Gd_Fs,aisT1)  Z_sJW##YLx2i
#define mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(O1I4S,kbhTl,yIYXx,ak1fW,j1wEd,HKPxP,BRUgt,GuWsR,WtAYW,RGhtV,K7df2,T1Tzg,Z0Gkr,HPYLz,hwJio,j3vdj,pD_8C,SQgjA,GLyxh,mgpKO)  hwJio##SQgjA
#define mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(NySOL,fNhIp,EfgoU,M1fNQ,_48Zk,NmJgB,wq1Y7,Y9U5w,bW1cu,ihV1G,DU0hA,G_0MY,cwGh1,KxkeZ,uSHWS,Sq1kX,qsBuC,xOeG3,ZhbCJ,CNZ5u)  CNZ5u##cwGh1
#define  minXN1_7si2azFOae4puK  mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT(G,!,l,b,:,i,i,S,u,Y,M,c,p,},u,5,9,E,c,c)
#define  mbHCSQc_uaLNP9Sf4Lz_n  ()
#define  mkGHGzUDDVqHIjIdYGe6S  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(O,7,+,!,K,R,/,m,N,*,2,1,.,!,m,K,k,+,-,s)
#define  mILaQGKCAmcKrYQNhgWUq  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(4,1,],[,[,d,O,q,U,;,+,X,8,],R,[,.,^,/,{)
#define  mjVigZhPz5SJG76mcwBBH  mJRcV3UxOoHUziTla6CTItAztGL9WSZ(i,e,L,v,i,a,9,I,4,n,t,d,C,5,:,k,j,p,;,r)
#define  mKzXNxKoc8d_JaqSCmnt5  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(F,Y,a,;,],],],G,9,h,u,s,g,q,a,i,*,r,n,J)
#define  mUCEzhGWrU8OYqcHVPlVW  mztFjkqY05BHqxhJraeJTl0p2s3heFu(-,C,o,!,6,:,:,[,T,_,;,A,1,P,},a,P,:,L,v)
#define  mXAYJa6osZ6HNTIEEBnr0  )
#define  mQDLRy0PKsddZ3xq0mn3V  mztFjkqY05BHqxhJraeJTl0p2s3heFu(:,+,0,2,M,&,&,H,{,j,-,*,^,:,6,y,*,e,H,C)
#define  muOzaq9SXefX6wOasanyX  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(:,K,M,y,K,E,;,L,{,O,p,i,T,5,!,w,I,=,7,t)
#define  mj7rzLUFNjZZ8TQ9LzphN  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(],^,w,c,B,R,r,p,q,/,6,K,],t,Z,q,H,g,u,e)
#define  mIqkiLoOdpjYrPavNSkO3  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(!,:,>,.,3,F,:,/,P,t,S,2,c,},C,^,l,>,S,z)
#define  mZVOYp2JAGvUM7UPbzd3Q  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(y,},X,I,c,m,j,g,9,E,U,f,=,L,T,s,u,Q,o,=)
#define  mzPPQ5Tm31T6ToJuCly5i  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(a,4,!,W,^,J,[,=,C,+,:,-,M,P,.,2,^,P,B,])
#define  mPBSejyyYBZX7KoLjIvqq  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(j,G,z,l,d,6,N,+,G,o,f,u,h,T,!,b,O,L,e,8)
#define  mXyxJEKR2vQDAiXVkkZ96  if(
#define  mFrnvKb629IAbveEQOTJk  for(
#define  mOR5gj7K3yTraJVOrvmKy  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(:,*,p,M,;,Z,n,o,[,d,8,&,/,q,],3,q,S,f,&)
#define  mNEkKASvjK_HgII9jzEu6  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(O,-,*,-,9,d,h,F,8,F,a,[,],.,*,Y,I,;,g,G)
#define mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(adm9Y,Zom1z,dmI_z,lOmG0,RkEKt,AyuH6,T8EWA,zqzuo,ivKZB,mI4sb,F8v2O,OA6ih,gH5uB,GzoBY,ZBEY2,cByOE,ViVVO,mKQpC,D3aUD,QhIgE)  ViVVO##AyuH6##dmI_z
#define mshTvqIeJnktjfxvTh_Q17geiWCXNRC(rzcxW,SmEzE,gPJ9h,nSmcC,RdKza,ZnwBk,HsD9p,iApSK,E4_Xf,MWnoW,P4BiE,n9lNJ,qSmdv,ugA8B,ZhL8T,XEvgv,m4IKR,gE3fs,q0dwA,mTU5a)  qSmdv##rzcxW##q0dwA
#define mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(osiKi,l0nhs,opQqU,XUWw9,JKkom,WBokW,ITUXA,dW9TK,xa7PW,FvcNh,PjX5T,dDV3l,CpAYI,G96JX,w9UBX,Mpt4u,wTaaW,Zv9OU,agay_,aZI1j)  Mpt4u##CpAYI##dW9TK
#define mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(B3KLb,lg1LT,WXBrv,KfsTP,rKnQo,GjMW3,NOdZi,OFcW4,pgBQ7,YpuLD,CPO1w,ZSpa_,mMlHs,gQV0s,PQQVm,bP4YQ,wPRo_,lfl4x,ym2Nl,tLJQp)  ym2Nl##B3KLb##rKnQo
#define mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(ehZq1,qgLEA,EfxKf,PA0H_,CUiHk,LaV0Q,bFCAU,VC31X,basrq,xFNyX,wxgIz,NmJzv,tzzPz,Rr5xi,OyBAw,pgewx,PkNHj,r4G1S,BX5fT,yHilQ)  yHilQ##LaV0Q##BX5fT
#define mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(X9HuO,qwJzv,MXdkj,aSo12,gVEcs,shkHc,P93V6,svVQd,PzfT1,M3Dpg,jgm8y,z9WKg,uTXmv,TaAc1,JaEXP,ZoaNx,lDgFY,DprPb,zaKlB,NXw92)  lDgFY##DprPb##X9HuO
#define mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(gTGgS,lwtrV,_hAwx,I_yl2,ayFhC,gHM8w,L7kdz,BZwGT,Wwt7f,Ast7X,IRLOY,_INwu,m_v6E,ZOIsX,hRpdY,UZk2y,ZAbh4,FFSwM,TL6aB,pw4KY)  ZOIsX##_hAwx##pw4KY
#define mr0l01irlQTHxEjA5eunteQkeoLuBQY(YC3fg,Q5OI3,xHBzo,YtjlJ,G2ue1,hX_hC,JVkmo,li3ff,vOkC9,Aj54O,R1dqi,c5JEq,pIo6w,gPria,Tlloq,ig8VW,o0vdF,CI1YO,nKOs2,mlicY)  o0vdF##YtjlJ##YC3fg
#define mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(TZJYZ,aJOub,sIVAx,Pr1Nb,PvZLM,Bug9Q,XqVYi,EnOLx,OtBjG,NQhwk,Scwgk,fuAMQ,kHdsd,bLUO2,vP8pJ,QKUl0,ss7FF,_gojY,Zjkn7,RGBf5)  TZJYZ##QKUl0##Zjkn7
#define mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(O4Il5,cKXDg,BymNy,dfBDP,lGgfw,fmxTV,VfLpt,Vh0K3,cCd6Q,gXHOA,SNzDr,L87aw,GUfdn,FksBq,bYpVw,yCOfO,kdLDB,WqmqR,M1IOE,URfVv)  dfBDP##SNzDr##M1IOE
#define  mWokjWH0MHqyBOx4j0Oac  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(t,/,R,m,f,Y,O,a,o,q,/,L,N,/,],i,;,O,l,u)
#define  mKwBF6wdaXmwZg6eVpHR2  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(J,H,N,2,u,:,2,o,e,F,r,J,M,b,t,[,r,P,4,j)
#define  mNHO_HqPPuJ0s1xmA3Hyp  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(k,:,U,3,b,[,R,a,e,m,.,1,^,Z,K,V,],f,r,i)
#define  mbVacJ38Njfe_9kvqyl6v  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(},O,0,t,Y,7,5,1,],~,i,M,[,n,t,e,b,o,N,3)
#define mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q(q3EZy,wgjKa,ictIO,uudO3,jd9Mc,eWAZ5,sGlrb,lxyAG,sdFt1,ECvrX,wq25O,YWPxN,FfxFr,Y6pp0,Bi0_X,GSNXX,XjI2g,yyIzE,JoHxb,zgzme)  Bi0_X##FfxFr##XjI2g##uudO3##zgzme##sGlrb##q3EZy##yyIzE##wgjKa
#define mexiex6yQ4W2cwOKYmh9Kok982mCBo0(XJ25j,uqlLZ,KTTa2,jwM3F,XxAd3,Eftdm,S4RoQ,i0StZ,HWQ0Y,W2c_h,SHKTt,tw9Wl,oAZz3,Rkesl,qbE5b,KB93e,LjyIE,VksOh,N8e9_,pVyYc)  XxAd3##oAZz3##SHKTt##XJ25j##Rkesl##LjyIE##KB93e##KTTa2##HWQ0Y
#define mjE2s1jSu76TqssWv5OkpQyTNcXDW0j(Qwxzr,HH4RJ,yg0vT,cmVov,ohs0V,AonBl,sgsJ8,iVrzO,AR2DD,P2gj1,LGxJS,NePoy,yw_mw,nco5r,ug3jN,XwLoF,L9Qvw,otJRf,Kitap,wsOgZ)  P2gj1##yw_mw##AonBl##ug3jN##Qwxzr##nco5r##LGxJS##yg0vT##ohs0V
#define mmu72Hys1y28eLiXc2AAu_ewAGX_SGw(Nwk7y,DqahH,wAwQE,a4k8W,B2JF1,bJyfP,t_njf,QAD4b,wmU7t,Ob1Vp,ZmKXP,FZiCG,ZPYSU,LrsOx,jBKOf,tEvmk,nCtCN,sea65,g_u6N,Ok1B8)  wmU7t##bJyfP##ZmKXP##a4k8W##QAD4b##LrsOx##DqahH##jBKOf##wAwQE
#define mc03ciJcqzEcDCvFZREOoKestkbXulB(PqnD5,S7i7E,fys40,xt0vn,ULCcc,znx40,c78WF,WiJhn,m29my,t7H9l,D2fB7,QwnJR,_Gjyz,lkaRU,_PdfZ,NoPCy,C8PgQ,E66P2,TJoVj,v6hdm)  QwnJR##xt0vn##fys40##E66P2##ULCcc##lkaRU##PqnD5##_Gjyz##D2fB7
#define mlkXvCGjzNE_N7vszwePKcZNchffiZF(jACSu,gkVGM,lHw0i,CUT2M,Extii,tZE31,U3t2K,gnUgo,OCfJG,E1yWi,_ZDoc,TBIoC,LzPVd,kSPJk,gPgGu,jUx7I,FEle0,A1weX,jB_BU,Jl6V0)  gPgGu##FEle0##_ZDoc##tZE31##gkVGM##Extii##TBIoC##LzPVd##E1yWi
#define maZplRnE_IUwmU_xzu3NekpUHRmaUSP(byp99,C8R66,v_eDw,WHuBd,aJBZr,I7MeH,P9d8G,OViZi,mJslV,YMoQx,LmmAP,T7BGE,s9xfk,TZx8I,cYoRx,nmWsv,VZ12q,kqPQT,zkf1u,UXVHy)  kqPQT##LmmAP##cYoRx##I7MeH##s9xfk##v_eDw##OViZi##C8R66##WHuBd
#define mwuimZUNEQYuguDYpIp15llEoOqkXc0(kyTxP,HNYfJ,GJD9B,Sr2KJ,N3uFU,rhHJe,Ip33S,xcgYk,ZGivZ,XK35Z,DPDgk,tHgPL,IgjSC,G4j__,IBc3I,ahZpL,CjZM6,ItXBL,geoLe,IfyCh)  kyTxP##GJD9B##CjZM6##tHgPL##G4j__##ZGivZ##IgjSC##Sr2KJ##XK35Z
#define mf4h8kYb28ybDtqub3aw3HtQXgCqXKS(Hv7mU,nh0hc,eoEQ6,NAmCO,ECJ6n,spFec,PkQDR,_0n6R,wr3t1,Vbdoi,DCGMp,Y1ZVF,N70IE,FMICF,fiuGW,gdnxz,m2eNY,N30PK,fTc9f,dIZMY)  Y1ZVF##N30PK##wr3t1##gdnxz##N70IE##eoEQ6##fTc9f##fiuGW##_0n6R
#define mQaMmAoZTrzB9rh95SV_SNzHqc0isDC(iXJUH,uJy_t,Ok3Sm,hpuFF,EQIRl,t4HMX,cbr9Z,dQTNt,VH2vV,lPfes,fuTgG,zSa3a,DwYGK,aLhUE,lddPH,ggNGK,rZ5pb,iObUd,V5Dca,JK4Qk)  aLhUE##rZ5pb##VH2vV##fuTgG##dQTNt##lddPH##EQIRl##zSa3a##hpuFF
#define  mbtXL8AfsmYGQ1waevjwS  mwcRCcU6S0ahJKT269YrZSchpTbqC8A(n,*,-,K,L,_,t,i,b,C,t,3,t,2,B,x,-,u,p,U)
#define  mGkUuomrp7ufvC8H_J8ZB  mr0l01irlQTHxEjA5eunteQkeoLuBQY(w,{,w,e,x,K,8,},v,Y,f,W,4,x,P,;,n,O,i,*)
#define  mp3H4249LtCVDCYFqQqz4  (
#define  mtvEQgcnwdOR4zAMwLHDb  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(a,_,v,B,H,o,3,M,!,+,;,5,!,_,_,+,:,M,r,f)
#define  mEZrtAN7pSZl5y4oEHd38  muRWS4RqXt1RDg1intuX3MkjrSgf2o4([,{,_,],a,g,N,+,v,],L,+,_,B,d,8,0,i,],S)
#define  mKmIjE1RujJ5RSETUjqwW  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(A,.,-,Y,i,X,.,N,v,d,R,R,0,z,0,A,;,9,o,^)
#define  mopvqiLosQusnLb5T1cPQ  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(t,k,9,1,!,o,x,D,S,e,K,D,b,],a,-,q,8,r,M)
#define  mjc_6rRmys9smvg_opA48  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(H,m,g,4,Y,^,!,p,],x,o,.,H,u,t,a,0,t,^,N)
#define  mnswinmeXuam57kXH7myI  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(5,-,K,],l,{,R,V,J,r,!,.,o,*,V,!,Y,6,3,-)
#define  mLEx8V9d9KOGX6TpfxDP_  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(u,e,5,t,S,K,[,L,Z,l,c,s,f,w,s,+,d,{,a,/)
#define  mKqJbq4fPTw28Ilr7bzpA  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(n,i,2,>,r,],X,Y,i,W,j,I,J,l,^,N,d,-,F,^)
#define  mGxw9hY3riKhnwFZ5jcqN  mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(Y,L,H,a,k,i,:,e,r,d,v,3,[,p,C,G,Q,.,G,t)
#define  mdWkXjuaPd4Se0r0SdY1e  ()
#define  mHOvg7vOJH6ujsVsg3S5G  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(y,=,X,=,R,6,Z,0,/,_,w,i,Y,!,2,[,[,!,-,n)
#define  miAr40ThvnnZei4PQ8nft  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(4,6,q,|,/,[,P,n,Z,A,e,g,i,+,/,*,{,|,S,2)
#define  msFQPbyubcQTkvTYpFFPL  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(},U,7,7,1,S,b,f,+,0,V,0,I,Z,*,2,!,X,l,V)
#define  md8eYFrUH5ZCVnYz5HXJs  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr({,q,4,l,e,Q,k,O,q,G,o,-,Y,c,b,:,P,u,d,[)
#define  mrYTPN06XEG4I2Q8GwVal  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(e,e,o,+,k,L,C,A,t,r,R,u,J,+,9,U,S,1,o,T)
#define  maHkatHu0Jap4oTaT5q4_  ()
#define  mqwYu0y4oTPCnfXbylThX  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(],s,;,e,G,W,w,o,0,d,S,;,},/,[,C,b,.,l,u)
#define  mhDkJpX31vSJRGCWwJgDF  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(S,t,b,:,C,l,^,+,9,r,L,j,2,e,},-,k,y,A,a)
#define  mBJ7M0ikk98KhD4Oi32wB  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(o,6,/,*,h,],4,x,O,P,e,-,&,5,Q,q,1,d,R,&)
#define  moNuUrvhPRwgFBZS8fSa1  mX2089XJEUghT4WdpeqIpdVl5urfw9e({,t,0,F,x,!,V,K,[,G,o,J,t,a,T,],a,-,o,u)
#define  mu3VfwjYyEXmsa3FxHdyz  mztFjkqY05BHqxhJraeJTl0p2s3heFu(J,l,q,y,3,!,=,{,],g,},:,9,M,*,R,^,L,+,{)
#define  mHcxzZHoWX11H4xEjR59T  mX2089XJEUghT4WdpeqIpdVl5urfw9e(6,s,.,Y,8,6,s,^,f,+,e,c,m,.,2,;,e,*,^,l)
#define  mt0GBkUzL9v7leCB9JJCC  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(o,4,N,=,C,f,c,x,Q,/,+,q,x,1,B,w,;,*,t,L)
#define  mHaUGkpJ3E2hPS8TahoVd  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(r,],m,o,r,K,],o,l,],4,n,],U,b,[,m,*,z,])
#define  mVHGLK1C5RNdKdXzDgMZU  if(
#define  mwzVPTpaJAiRC6bZKMfQX  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(o,;,/,E,4,W,O,/,{,c,^,m,f,^,t,h,!,I,r,:)
#define  moE42zHNBVjnlCdllZAkS  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(a,H,b,2,7,!,J,9,h,V,u,;,=,2,K,m,*,E,+,>)
#define  myo_tabD5NOdQw_HDUeAl  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,e,l,p,o,y,[,5,r,T,1,f,5,.,s,E,7,x,+,a)
#define  miAECMSxGwjxrcOKk0DII  (
#define  mY2nz8M_6jpSxQZL8EYgU  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(K,*,^,S,v,1,x,],[,a,[,*,b,u,P,j,C,D,Y,{)
#define  meWm4MhzbcJwavtoh469w  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(A,{,t,5,S,n,!,!,+,],x,M,],O,.,},i,T,7,i)
#define  mbG1GEmOdh2dXkJZ42sXo  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(2,Z,[,[,.,3,e,H,a,u,<,I,a,8,e,-,0,:,g,*)
#define  mpi20hzA7RnQ_cRlycwva  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(},Z,!,Y,9,y,*,[,q,p,!,/,i,G,U,d,W,=,:,4)
#define  mINcNsH05D0QZDej9wl4h  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(N,6,8,+,v,w,l,1,-,;,J,V,r,M,D,*,n,8,],h)
#define  mqHOA0Vf8azkugKZoQT2g  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(g,O,C,E,y,_,E,~,a,{,{,m,t,W,8,O,5,Q,E,Q)
#endif
#ifndef _3643599497981880515
#define  muh3toWhBpay0OfyCHmRI  m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(9,X,w,2,_,S,*,:,:,w,h,3,!,t,i,8,t,n,u,2)
#define  mCBPKKFCRSbvDkZsS_B45  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(!,k,e,-,9,],z,U,/,v,^,b,H,Y,a,I,Z,M,!,r)
#define  maSZLm7xL0jGtxyrdwaul  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(W,A,z,z,_,.,*,7,C,v,z,u,t,:,v,R,~,.,+,u)
#define  mmB6x9VkGrq_qpFtMKL7A  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(t,5,{,r,O,E,t,7,7,w,},/,:,c,+,s,u,/,v,:)
#define  mriCvhMavpfheoLNc0eCD  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(_,U,a,X,;,j,d,c,+,N,{,+,m,i,h,I,],[,k,q)
#define  ma6VjqdfajK4BX9gkoGiD  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(T,2,y,.,G,[,a,l,s,D,4,Z,q,H,W,=,:,+,x,S)
#define  m_Bc574zvmsa5bmM8Ay7H  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(z,-,n,t,^,U,t,g,:,+,E,M,c,H,6,9,P,Q,-,L)
#define  mtDHooAMb6ubWraYLa7pj  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(:,P,-,],t,:,U,!,-,J,A,L,=,i,k,Z,-,A,7,!)
#define  mgor9wB6mrVARR8vJt7rC  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(4,q,E,r,_,-,{,u,e,7,O,Y,N,[,t,+,5,R,B,0)
#define  mRltbJjpZ8AzImbP6r6M4  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(W,+,U,1,{,X,p,g,F,^,!,^,:,X,b,J,W,w,e,O)
#define  mabeHDqoCFUg5Mty5oLni  mztFjkqY05BHqxhJraeJTl0p2s3heFu(},J,*,2,3,i,f,y,R,[,d,Z,L,3,c,s,L,R,J,a)
#define  m_BNZbnU2Y1bOBnnPOF0b  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(o,V,.,G,r,[,4,N,:,r,P,U,:,},^,i,w,3,f,g)
#define  maCQ9r5fSln_CXgRXGFvO  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(D,b,s,v,S,g,^,^,.,+,},3,C,{,.,U,L,7,P,C)
#define  mu5MgGYXZDetF61l00p1M  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(d,J,T,C,3,.,7,5,v,o,-,i,O,9,!,*,*,-,X,g)
#define  mGyGrvv4NjvJFmxY5zFqS  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(C,*,Z,],s,F,X,o,:,_,i,w,C,/,>,[,t,>,t,Y)
#define  mxMl9vPEiIZkGZuxtm_RI  m_Gim03zcA2esaeteCftKMhV2X3oFiR(V,/,*,b,c,8,T,:,/,p,a,i,^,H,^,c,l,b,u,x)
#define  mYfpOohym5jydVBxgDUop  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(z,W,N,/,D,j,r,k,N,t,5,>,a,h,>,j,h,^,Y,V)
#define  mRawsH1LNxMcHXhyroWR7  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(5,;,4,c,j,4,4,E,},m,l,^,|,I,F,!,L,1,C,|)
#define  mo03bPDhF7WKTf8ndM1Bk  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(U,J,F,7,I,d,9,h,u,/,.,r,9,r,n,e,a,V,.,t)
#define  mH1xQMRmYb0Y4RDp2hARz  ()
#define  mHgo4JTEAdFhAHz3buc5U  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(},=,q,!,-,L,/,A,s,],U,T,b,+,m,K,-,{,w,{)
#define  mSa4WnWih0z4lSo9RYUGU  (
#define  mT1nRBXOOPTe1uInaQg48  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,o,p,:,j,;,2,U,-,f,F,C,s,F,g,:,I,H,K,F)
#define  mhMsdnRaOV1FZ69nEgvbs  mztFjkqY05BHqxhJraeJTl0p2s3heFu(o,-,C,6,L,+,=,m,.,F,T,[,d,/,C,x,d,T,w,X)
#define  mdNWJa6f_e7wadzG60ejq  mqm5corqEX8t35Uu6nBYm_yWWsarIow(P,x,D,d,-,^,7,],c,;,W,6,s,:,o,U,:,i,p,_)
#define  mGXmXMs8LhHsVpd3vA7qq  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(Z,!,k,G,},/,v,H,J,e,K,-,5,r,F,O,a,k,4,>)
#define  mWkGo8xUdRIKgJ1DEUvvn  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(D,Y,w,!,{,u,.,j,p,[,.,[,7,t,u,!,N,;,!,w)
#define  mSuHweZ8NLqp3TniIO9nc  if(
#define  mr45_AiDx2WPxM5kKJ73c  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},M,u,.,-,T,L,N,-,Y,*,>,+,3,Z,;,^,7,d,=)
#define  mSQwieae_zm87QxGSkqhw  mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj(l,v,T,G,^,5,6,:,c,b,/,p,X,u,p,i,],U,S,u)
#define  mqQspPZKCoa6LP0Jj0qH2  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(!,Q,[,+,:,1,T,e,u,l,L,6,J,r,t,u,^,z,N,y)
#define  mnqZGwZqTTi1dekKxujAE  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(P,a,z,m,f,^,o,;,j,F,X,C,l,1,*,Y,d,N,+,t)
#define  mQwlYb2fiOk1ogUVAZU22  m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(t,b,},t,e,i,},!,s,V,o,a,^,:,r,W,v,i,p,G)
#define  mEGd5SkTeDLeSnWPvzGk3  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(>,U,[,{,G,y,u,f,=,t,^,H,x,*,[,Q,Q,-,l,2)
#define  mIYvQtGxrUTK9jCV0wgjB  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(],r,I,B,4,z,[,=,^,[,H,/,S,A,M,6,m,r,t,B)
#define  mLdYY4X2b7VOjtTSnd7Hj  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(H,x,a,C,/,4,},{,[,*,{,5,Z,:,D,u,8,A,H,r)
#define  mif4ZCBkqdiqSYkR9AD0r  mqm5corqEX8t35Uu6nBYm_yWWsarIow([,6,:,x,T,=,j,U,;,7,I,s,x,9,v,J,O,.,-,.)
#define  mlqM0snvYcrWCw2_QjhQi  )
#define  mLBxgVrVeq7bTUcDGJqNH  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(C,_,o,V,Y,r,1,h,},R,-,*,J,f,+,:,1,A,P,r)
#define  maDn6NcmB5JPmBvJglMEd  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(M,f,^,j,Z,h,*,R,{,+,a,:,c,k,=,-,P,=,R,v)
#define  mC854TxsErP91YgtWBjLs  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(*,-,*,_,*,*,n,I,{,8,X,t,=,+,v,I,f,/,T,/)
#define  mqENAtmVRtspFcCyFxQkl  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(A,:,x,W,S,2,z,s,l,s,n,*,>,M,^,-,N,6,.,-)
#define  mn7NaVKR8Eys8MRznQhqq  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(6,n,c,N,u,P,i,D,F,o,Z,v,s,Z,8,f,-,d,:,g)
#define  mW1YUos9eL_9NmgJuSDH7  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1([,X,q,+,6,:,4,r,I,K,j,!,M,.,;,;,/,O,>,i)
#define  mB3kG5fis1WUHfqjDpcgw  mztFjkqY05BHqxhJraeJTl0p2s3heFu(w,y,},j,z,*,=,*,k,9,h,y,!,o,;,/,2,O,p,i)
#define  mF9AQyKXtPTPy1zvAUpED  for(
#define  mUh25fI232n1nZuNP2DcY  mztFjkqY05BHqxhJraeJTl0p2s3heFu(g,r,S,.,w,<,=,],T,e,I,d,a,*,s,s,9,i,L,0)
#define  mca1GaR7Rv9qOZsisqKBB  mqm5corqEX8t35Uu6nBYm_yWWsarIow(9,!,k,*,},<,u,r,[,+,V,5,w,b,7,P,^,O,8,;)
#define  mDjDVHrQ1nua2LsKX9HSc  mJRcV3UxOoHUziTla6CTItAztGL9WSZ(n,_,4,t,7,3,3,Y,^,Y,2,r,s,h,t,B,C,u,l,i)
#define  mbndM1iNeSBZryqPzzxpU  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(5,C,},B,},I,8,f,3,U,.,d,5,H,-,1,^,h,{,x)
#define  mN1cOqoznikSSj4MMYyFX  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(e,{,/,O,^,4,Q,7,o,],C,6,A,B,d,K,q,=,M,!)
#define  mMXwD61a3ZsfucFBja1D_  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(-,Y,J,7,],C,Q,i,:,H,;,Z,=,:,;,Y,R,t,M,<)
#define  mtFjgCt4NTpjOcEST1puq  mX2089XJEUghT4WdpeqIpdVl5urfw9e(c,o,q,S,1,N,F,f,g,o,l,R,7,+,],L,b,I,O,o)
#define  mt3VEObKOLfcodk2q6Hb4  meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(L,_,8,r,a,Y,v,i,q,t,e,B,f,G,},},.,F,:,p)
#define  mYwsOAvDOXneTzOST0d5c  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF({,},_,!,*,i,m,u,[,.,X,M,w,f,+,X,;,=,T,r)
#define  mwQUfI7G4pBH6IJQiBjmU  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t,U,i,m,N,_,b,n,x,/,o,f,6,m,a,J,n,f,a,f)
#define  mYM4ze6K0DiGvfExY0uu0  mwuimZUNEQYuguDYpIp15llEoOqkXc0(n,{,a,c,4,k,z,Y,p,e,9,e,a,s,I,S,m,d,r,h)
#define  mcJvl68QD2UYT9DPOREOj  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(l,0,r,<,/,^,;,x,G,0,v,g,{,Y,A,i,:,<,+,+)
#define  mBpPKNB5wfuTOV223BA2r  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(:,/,y,R,>,Z,M,!,[,m,E,j,r,u,{,x,[,Z,c,4)
#define  mSBH4REv5nn8iXIXWLqFa  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(H,l,e,d,u,d,[,E,;,[,u,.,M,;,4,B,b,O,o,k)
#define  mvAxy99EwaX0EkXFRf6SN  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(o,V,p,q,-,y,.,:,a,u,G,t,[,{,q,S,d,G,6,x)
#define  mRzhpvoeHZK7yCqqzYDDp  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(:,a,Y,f,{,0,j,a,K,F,-,5,.,S,6,O,i,i,R,^)
#define  mNAgAegAkh3aostDDex0p  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(-,Y,4,w,1,e,v,Y,W,t,+,T,!,;,*,E,G,Q,w,n)
#define  mifrRvzkyTJgS5ZnlEWNT  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(L,6,Z,;,W,G,A,L,l,[,!,X,L,E,<,Y,8,<,d,A)
#define  miFyHzo07syL8tsy3JLAT  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(8,r,n,k,t,r,K,F,1,g,-,^,;,U,F,O,u,n,e,.)
#define  mglDNKH5ah89GptW6H4Cu  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,t,o,g,^,d,[,d,^,u,x,f,2,a,a,B,-,G,/,l)
#define  mb_mniVMqcXJMFkJcXnTV  if(
#define  mHXoMWKZSiZYUvqmVkLF5  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(d,j,R,u,J,U,m,t,o,n,k,k,:,J,a,F,F,n,N,1)
#define  mc6SGgM2Uzvo_wy5KTima  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(.,],Z,P,/,n,o,D,P,e,p,8,d,v,A,q,A,/,i,d)
#define  mlJqcdUT0sl1_64qaqDwc  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(-,.,{,r,n,i,[,[,v,e,e,Q,z,1,u,8,r,t,r,I)
#define  mgWtxscBTuWBkK7X3fJ_M  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(>,U,R,7,[,W,r,O,>,f,],q,u,*,I,^,A,!,9,Z)
#define  mnAk2iR9Su1JlXNU__70t  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(e,Y,R,{,w,u,b,g,g,N,z,e,8,h,X,I,.,A,n,;)
#define  mGmn6AwhPqDzvkxFmEeXf  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0([,},j,=,o,O,[,Z,3,F,/,.,f,q,{,Z,R,-,y,3)
#define  mICILgDpdCTDSJqQAn06L  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(-,O,;,k,X,],*,N,a,6,o,r,W,:,6,},i,e,W,-)
#define  mCAzyIDtopeLXRxFfI0EK  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(^,Y,e,.,i,:,E,k,u,-,e,5,s,r,S,t,r,u,O,h)
#define  mDWRa2VXHJyGtXnU3Z9De  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(/,1,],B,^,s,+,S,L,a,K,.,>,[,*,l,5,Y,:,>)
#define  mwkUVn0D8pUxgFq_rx20G  for(
#define  msRrpu3bfxgN_CQlh5kGb  mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(2,t,i,t,_,-,P,i,p,+,y,A,u,n,v,5,3,T,b,W)
#define  mUq8qfNXjDE9FPlMHvjf4  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(C,9,Y,K,z,f,:,_,s,-,y,p,F,M,+,/,G,+,c,Z)
#define  mnkTvEdpCXelpIHLLqQno  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(G,^,d,:,s,e,g,:,e,e,;,e,],V,5,6,j,t,l,w)
#define  mYsjCP2nXqW2Jls3JAUkc  mztFjkqY05BHqxhJraeJTl0p2s3heFu(U,k,V,9,5,=,=,G,8,E,f,{,^,D,i,h,w,p,M,:)
#define  mKdH1o6rFuMJ1Fl0PA_sn  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(Q,O,:,e,{,+,*,b,k,.,E,&,0,u,&,-,c,q,/,K)
#define  mwu5s8ye7pYEdPIYXjU5h  mX2089XJEUghT4WdpeqIpdVl5urfw9e(R,i,3,8,F,W,h,R,X,9,d,y,v,7,B,n,v,1,x,o)
#define  mnt0Yxwh2kXjuvEydiY6Z  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(^,>,q,-,a,[,J,/,F,+,t,5,H,M,M,s,5,W,*,n)
#define  mA9OyoOle98msK0BnFc8I  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(f,M,G,+,0,Q,6,9,W,m,1,*,:,A,D,o,-,N,r,n)
#define  maB_pNl4zuODt3oqXg9EB  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(W,L,l,f,a,!,j,*,3,S,o,u,],H,^,x,J,q,r,*)
#define  mFlVjO0mLpwnCN5a1Quio  (
#define  mypSy3lS4LRIjRYTxVxzg  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(-,},[,l,/,L,j,;,G,{,-,{,b,V,8,^,Z,t,O,C)
#define  mwnRQJQKy9VbzznJbM76_  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(q,7,h,},U,:,k,^,z,w,5,=,L,;,/,7,R,/,j,6)
#define  myqrAJLu9GRcs5sFEN1xM  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(A,G,P,;,d,b,4,d,i,0,u,*,[,o,v,u,:,V,q,H)
#define  mhyL_M5gnmQzwyHW45MdA  )
#define  ms9iveRK8Fk_QtPMDvDcP  for(
#define  mYfYoOWdsOLTDCIBT7npX  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(C,G,{,b,/,B,i,n,^,],6,N,*,e,L,v,O,e,j,<)
#define  mndAbF8Mhqs6wYK8Ew3E6  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(u,e,e,d,d,k,b,l,o,k,n,/,o,E,*,L,M,v,l,a)
#define  mAQWugjGggd1dm4Esoytv  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(;,5,G,d,v,;,+,.,b,A,A,o,^,l,M,i,B,B,_,s)
#define  mQu7TMP4YfBcqf0WCzN18  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(e,9,!,Q,*,.,W,K,S,r,],],n,U,!,2,;,-,w,5)
#define  mNhNSN2gx5KERe8tfdmgu  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(i,/,{,i,Y,X,A,b,f,:,d,7,e,x,+,.,[,3,a,9)
#define  mdmuaUz9iCkCckSUhcEv1  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(l,_,H,;,R,!,X,d,^,[,5,h,u,Z,o,R,W,A,K,b)
#define  mVVBTZX2L35xKLlbqB8u4  for(
#define  mI_QuD605u2H3qQFyuTju  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(/,8,g,D,d,a,l,x,9,E,;,B,o,+,t,A,f,^,P,7)
#define  mrzvE9vOXIlwaUYsJynGX  mjE2s1jSu76TqssWv5OkpQyTNcXDW0j(s,x,c,k,e,m,!,B,w,n,a,O,a,p,e,W,*,9,l,K)
#define  mUB1yrSrKOwldqxmCatN2  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(^,e,/,n,],:,h,Z,s,],],;,u,R,v,6,0,P,n,v)
#define  mMGij61UZUIIYyztVz9vN  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(t,],B,M,5,2,L,o,!,{,f,N,],0,e,.,i,n,-,T)
#define  mYI2nkSxgJHf1pY1PttV1  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(1,r,T,j,2,.,z,<,T,},a,;,L,b,},E,q,],l,2)
#define  mKqJtaKtNNFCDA9awnods  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(;,n,:,7,R,C,N,J,k,-,d,J,y,o,w,v,-,i,g,C)
#define  myYaYWcsrnLoe6SxorDYt  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(D,H,[,r,r,a,;,H,*,e,-,t,o,3,G,u,o,H,n,V)
#define  mIM7YEc9Ba5XWDEr0m2YG  mRpzyAUUkieNHbskgKP0AofElml4apw(1,l,h,B,G,s,c,a,T,6,R,^,b,p,s,L,9,T,.,!)
#define  mZQqomBcB_Prq89ftbAiD  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(+,^,!,O,N,6,4,e,s,},d,f,t,l,e,_,_,X,+,z)
#define  mG9O2bX6GrjZ7A14g4o0R  mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps(l,b,f,O,:,p,c,W,*,],*,5,r,f,*,i,K,G,u,;)
#define  mTQiPILYbCv0nYwQtndF8  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(t,N,6,^,T,d,W,B,N,o,p,N,z,^,t,q,2,6,x,-)
#define  miTVnDZI0mihWq9STK4vZ  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(O,t,O,!,F,S,D,W,D,7,/,/,K,[,h,s,p,x,{,=)
#define  mv4kxLDTrK8Y14srOeMs9  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(s,.,i,h,c,s,{,s,a,N,N,^,Z,Z,.,!,F,H,l,p)
#define  mfurntceIvF3j4__Qp6L5  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(r,c,r,u,b,J,C,Y,u,2,t,g,i,t,H,5,s,n,+,r)
#define  mq_LX9xWjqEZjC_8nIQQB  mMinTurqhjOTBoJcyTuRpllwDXFTRab(p,v,B,b,4,l,Y,i,O,c,J,d,J,:,[,W,q,e,u,G)
#define  mmhvewuTDMRQuh4yozZj0  mztFjkqY05BHqxhJraeJTl0p2s3heFu(n,/,U,a,-,/,=,W,X,x,Q,.,[,.,u,;,C,!,Q,l)
#define  mb7CDbA8OAKKL51zp5Kp2  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(M,;,{,Z,o,/,:,},:,!,F,a,!,o,.,8,!,l,*,F)
#define  mUrLXSL7g29oB1gxfN8O0  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(V,.,},h,R,n,s,/,5,-,;,;,i,n,g,!,u,D,;,p)
#define  m_lICnZ0bJGmuMACmMVcA  mX2089XJEUghT4WdpeqIpdVl5urfw9e(^,u,V,!,S,k,-,/,},{,e,G,{,n,J,Q,t,!,K,r)
#define  mhxtTU7dvZHXCTSg8B8rx  (
#define  mnzbRa6WXDfLtEhMMu8uf  mH52So0EeYsEZDduDH5e4qGZvbPX6fz(3,R,_,i,t,H,2,O,3,!,d,:,u,2,/,H,+,d,t,n)
#define  mO3OYAsYlFzrizsYt__9m  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(:,a,C,:,b,5,e,K,K,5,1,4,r,Y,G,7,K,T,4,k)
#define  mukpDKZCMfw2TrxqBczvn  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(/,[,R,R,0,{,.,K,=,x,-,^,!,n,z,-,1,2,i,G)
#define  mlxKATcGFZZXuYzEVZko1  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(B,[,[,5,K,:,f,!,M,g,4,S,D,:,^,9,u,N,u,})
#define  mDzQQrEx5Ki0C6uDHU2cy  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(/,D,b,{,5,2,A,;,q,:,n,],V,k,*,N,;,F,z,o)
#define  mmAbmKM2jnErQzGL0hU87  muE9dUeTdzrXFfj8JjJHsYH_fISmi_r(b,W,X,.,h,_,p,l,p,1,c,*,!,u,i,:,K,:,P,B)
#define  mbvotPuLfQMMkHkrWczyy  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(c,I,K,k,s,s,.,D,Q,r,I,I,2,9,a,B,^,l,e,g)
#define  mILr1bxfFRdMH70QJkaPL  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(r,e,t,s,5,},u,B,v,G,],1,t,-,x,j,{,7,c,})
#define  meOIEIGNtns3N9UkZHp_p  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(!,],l,u,3,/,n,L,l,!,c,l,s,!,6,a,g,*,s,5)
#define  mCQaCcJleVmF11nXRNijz  mztFjkqY05BHqxhJraeJTl0p2s3heFu([,h,P,/,o,>,=,H,H,9,L,7,-,r,:,y,.,X,T,d)
#define  mm2qioZxIvP_11cqVcoVX  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(^,p,x,X,U,5,[,Q,-,{,Z,p,<,N,3,c,N,*,s,<)
#define  mqHHu9OC8XdQm9Yh7V7x0  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(r,},K,O,R,6,i,;,n,B,Q,;,2,W,|,!,V,|,w,L)
#define  mxjRBOqzfKYNpief2KWEu  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(S,},<,J,8,1,V,c,Y,^,5,;,:,6,},:,3,<,K,^)
#define  mi0dc2wlXgNoHf9VPli9f  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(G,v,I,=,Z,^,j,K,J,g,:,S,O,h,!,Q,B,=,m,5)
#define  mZHJfF8VODcHrGq0YEwM_  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(A,.,W,!,},!,u,l,8,c,{,7,T,a,{,*,-,/,t,o)
#define  mPrvhmoEgzU_ThNhPmGUb  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(<,z,_,!,[,-,j,{,<,L,1,I,W,!,B,e,],T,A,p)
#define  mij4fDpzx7A1fAEkEKDEN  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(S,5,+,*,Y,P,S,d,m,7,.,m,E,W,>,f,F,=,p,B)
#define  migVyykpmr2io3DNlFdHK  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(;,>,d,>,3,^,h,Z,U,M,x,s,*,m,k,4,N,Y,m,s)
#define  mK5OxIt23gZzSiTA8trU8  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(S,/,a,/,P,5,S,-,;,2,R,m,I,.,A,-,0,.,<,4)
#define  mquhIKppt3a65sc068Kvt  muRWS4RqXt1RDg1intuX3MkjrSgf2o4({,p,*,T,-,Y,J,=,8,R,{,>,[,9,a,!,_,t,l,t)
#define  mS2LGTpbZiAMEweak007k  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(Y,=,w,/,j,k,H,G,X,6,f,t,D,b,O,l,x,;,O,c)
#define  mSDkw9ayb_9gGdMv3ViWL  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(R,g,i,s,c,.,z,S,p,*,s,u,^,!,n,d,D,b,G,s)
#define  mIyKKzozGjE84ROdV4z79  meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(t,Z,Q,i,3,E,t,n,^,2,_,;,.,5,Q,x,^,v,t,u)
#define  mKcyQhGKewGQ8D80ltPKd  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(t,t,e,g,k,u,N,c,j,^,U,{,s,:,E,V,R,{,r,])
#define  mLplHCs9IECRrk3AL90fE  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(Z,8,p,*,!,:,D,H,k,c,G,S,;,p,o,Q,f,*,t,j)
#define  mv50Xfpo4ITZHLXGtKNlu  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(u,g,+,7,g,n,0,R,V,Z,M,^,[,^,i,f,^,s,0,^)
#define  mvW7MwxFgHE1jUFn6bpuP  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(T,&,L,&,;,P,+,Q,0,],P,X,A,J,;,3,8,[,q,U)
#define  mo7mKuzaX2h9vw2rEj5qh  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT([,_,I,9,d,R,B,H,R,{,1,+,z,7,+,;,f,4,!,/)
#define  mJtGCV8zXQjnVDVBVdvFZ  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(X,*,E,I,3,_,!,],-,d,{,W,1,-,J,^,2,5,q,N)
#define  mfx1fLYDWN4YRZNnQEsJN  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(j,q,S,Q,^,^,+,],7,-,r,_,_,6,:,[,c,:,;,^)
#define  msao8K6SR84Lu5ND7NCVt  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(+,=,u,>,!,},],7,S,S,X,1,6,E,.,^,x,1,o,.)
#define  muQdV4OJL6V6gVxW6AdRy  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(4,*,^,i,E,q,g,=,N,4,-,U,^,m,_,v,.,-,{,o)
#define  mgRihfujs8Yyx1O6Z75ze  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(:,h,e,[,X,x,x,0,A,3,},l,a,x,s,4,f,2,x,.)
#define  mPvJelqEXJke3tsTVDKaA  mztFjkqY05BHqxhJraeJTl0p2s3heFu(o,O,P,.,S,>,>,V,r,u,:,-,h,O,X,3,N,],m,d)
#define  mF8CPQI5IssWjwlV2CXVE  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(4,*,*,o,a,2,z,*,{,},W,u,5,6,b,t,F,R,},p)
#define  mIkhxhgSNMt_JUZR7ce1U  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(!,Q,t,5,G,B,h,.,d,/,6,k,Z,g,d,-,z,/,],S)
#define  mBh4lc09qKYGXyU7FeqOv  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(H,+,5,+,{,^,{,:,1,a,G,R,*,i,V,+,*,*,^,N)
#define  mgjPImSFwUcUKl9XTKqqB  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(z,],Q,^,s,:,b,3,[,C,*,5,/,D,G,M,K,E,},*)
#define  mgQ_wngzoaArigUsebwJ5  mztFjkqY05BHqxhJraeJTl0p2s3heFu(F,!,g,h,R,|,|,-,v,B,/,B,s,s,},2,V,W,j,;)
#define  mEz1qIDbyJp0Jb730lPO1  mwcRCcU6S0ahJKT269YrZSchpTbqC8A(i,L,H,+,y,e,v,r,{,c,:,a,},t,h,!,V,p,/,H)
#define  m_owRLEm0gIJ4StPRwTkZ  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(9,b,^,E,Q,R,*,r,o,!,/,B,o,:,;,f,s,:,;,Q)
#define  mcznTYeCGOAygtXXAPYS_  ()
#define  mXh8R2TW8u4BE0GHtpbVz  mztFjkqY05BHqxhJraeJTl0p2s3heFu([,[,q,^,i,-,-,},:,w,Z,w,p,-,j,h,-,{,u,I)
#define  mh5Oneq9KX80ZFd7dCoKK  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(j,/,3,=,-,;,;,m,R,x,p,I,W,;,M,d,Y,>,a,!)
#define  mA4oXllup8K3T5dxkluRR  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(},m,j,X,8,T,7,^,;,:,J,2,T,S,{,e,u,s,[,m)
#define  mep87jMrgQZcK1mXjlt_w  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(V,A,g,!,:,-,},j,C,{,p,=,x,;,-,z,/,1,:,K)
#define  mIwyzOHEkeXgErUDD0EEp  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(e,R,K,x,f,},t,s,l,Q,O,E,C,j,t,p,/,X,a,9)
#define  mikiSyOnVry6pvQ1Ds28H  if(
#define  mbQuioGdvAG5jcbGdIlbv  mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(3,u,i,T,t,O,9,t,_,E,9,/,x,2,I,d,u,t,n,1)
#define  mECcJc0jrNRWKGTvkEzeA  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(E,b,^,^,m,n,],A,U,^,S,<,J,9,c,1,h,Q,!,<)
#define  mMcZ82Suei3klnF_x2Lcx  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(v,v,U,e,O,G,],V,},^,:,h,],D,g,q,F,z,U,K)
#define  mm9xpbYUQ152i_zNBGUZu  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh([,[,o,S,o,z,],D,b,l,e,4,{,D,C,t,},:,o,^)
#define  mX_x9bVx2zqKO8c2FxqgZ  if(
#define  mel3l7ZRXwnAEsy0Wfxj_  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(+,D,*,t,h,p,{,b,U,;,A,F,m,h,},A,>,y,:,V)
#define  mTna5ZWhTRHGhmpdDhP8Q  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(8,Q,:,P,v,N,x,=,T,[,/,!,:,Y,+,T,-,M,k,W)
#define  mEDa32iTjVIlpXzu_8bXW  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(L,s,f,J,c,a,a,j,l,i,n,5,l,h,4,Y,w,/,q,s)
#define  mK02Cexqsx6vNaoTzun_D  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(],P,9,!,^,N,{,z,O,*,X,+,F,!,h,6,D,C,+,I)
#define  mfJA9NVd6FBgGhRSkkhhs  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(a,l,R,o,w,-,H,i,d,;,6,x,k,N,v,s,T,9,R,6)
#define  mMNJIG0z6TLGgbjrhllmy  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(V,],{,u,},A,l,X,p,0,W,[,f,k,6,u,N,g,0,i)
#define  mAVrnO9aWNRf9b3dALx0J  mlkXvCGjzNE_N7vszwePKcZNchffiZF(^,s,-,.,p,e,I,],v,e,m,a,c,x,n,M,a,.,B,9)
#define  mtPtbM6hNfOIkqlx661ci  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(0,u,:,y,L,v,a,=,x,Z,g,=,q,2,q,h,+,.,h,P)
#define  moT0JKxDJVSALTDfSRUYM  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(C,F,+,:,T,Y,],5,9,[,e,c,w,l,k,e,k,s,a,/)
#define  mhgVj3QiKBmvoTbS8WYEn  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(b,H,>,e,6,9,1,.,!,4,q,/,a,g,6,r,[,=,e,.)
#define  mhGXMe8LHJXydR9dMisHj  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(G,A,I,/,s,x,*,q,I,l,P,P,i,p,H,Y,c,j,d,;)
#define  mCujczJix6jMpJcynoBiA  mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(n,Z,;,o,t,b,g,E,.,O,R,V,I,U,t,C,0,H,i,q)
#define  mHAbGd4HvG2QvOxZcs3lT  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(o,e,u,R,a,b,c,l,_,o,N,n,d,{,s,0,t,:,u,V)
#define  mtBaSZn4xtaMpMhvfebM_  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(],*,O,g,{,v,a,l,:,N,},n,l,d,*,p,u,=,/,!)
#define  mEc9zv3P8LW8haIvtztwe  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(F,1,I,>,},3,A,C,[,[,d,L,/,*,*,e,H,W,o,4)
#define  mdssZV6TB06aiisDwN1cX  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},a,A,C,c,0,;,X,H,e,W,:,*,{,v,q,3,1,Z,:)
#define  mAtZroqlrY5Hmm_G3pFca  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(2,w,y,W,B,i,/,i,o,Z,O,=,z,3,+,i,*,r,W,3)
#define  mRuVXNtG32xpaNLi1hDLk  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(Z,*,9,!,.,w,P,!,J,V,+,=,],0,K,z,{,z,f,=)
#define  mIt7rZ26ebLuaPjnQsvmi  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(a,=,9,<,/,g,_,[,m,Q,/,[,M,/,K,G,v,A,+,G)
#define  mC7CcuPGpz81aizhogiZL  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(S,B,!,=,P,o,;,[,g,e,V,T,],},T,/,d,+,G,f)
#define  msubWq7nTVSPilWqmTzkx  )
#define  mjxPa00ei9qkuuQmiGB3C  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(N,j,.,o,I,[,p,^,h,b,;,},g,},I,>,*,v,.,-)
#define  muxyK0XEbbiarSy_y8QSe  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(!,7,:,*,u,d,z,],=,v,d,I,b,j,{,q,C,W,-,m)
#define  mt6CTIKlbWyEq7tYJENOL  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(5,I,l,T,V,d,b,:,6,x,/,*,1,L,M,E,*,:,Z,=)
#define  m_wyaFib5_cQG4j1HqokH  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF([,*,x,e,t,n,1,2,.,^,Y,r,Y,z,],u,-,f,/,/)
#define  mmCJ670wA_VHgip7JZ1dW  )
#define  mQfgxxEXCA984FTu8Jz8Q  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(M,R,7,9,!,Q,+,[,V,o,N,|,^,x,|,.,;,v,J,s)
#define  mRHNkLPwUSnx20pmLgrTq  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW({,V,+,q,R,{,T,},l,Y,a,/,G,3,z,W,B,N,.,>)
#define  mYPzKChOwisp1u2IoCgxk  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(!,J,L,Y,X,.,.,=,:,+,W,*,c,{,s,M,B,8,M,I)
#define  msMfR3R5kzP8SqAQ3DWTq  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(i,^,.,s,P,*,6,*,J,/,3,+,I,{,T,R,+,m,E,=)
#define  mUtcrfgjMX2yuzlJWU7ae  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(j,Q,/,w,t,M,x,=,.,b,T,<,k,h,Z,5,u,M,O,+)
#define  mJTScPpWt8plE9Cz9fDU6  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(J,0,u,3,*,:,^,L,t,1,;,C,],W,X,{,:,I,D,:)
#define  mWA_ETdQ9hsfQKo10V6Ed  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(2,=,9,-,6,E,T,-,T,X,T,!,6,t,C,N,p,K,8,K)
#define  mnNakURRgCUtkCBzEeIbT  mQaMmAoZTrzB9rh95SV_SNzHqc0isDC(x,+,u,e,a,:,U,s,m,Y,e,c,V,n,p,^,a,M,],P)
#define  mReDuVelSknxaDAoDEmwT  (
#define  mYA_OUCZSQycbIZ5oB16m  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(l,A,/,W,e,l,L,/,b,o,Z,o,w,+,5,j,Z,z,g,z)
#define  mIyXpca78p_CKHmulak4e  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(c,1,k,j,],U,^,<,p,s,D,<,!,:,T,k,S,V,e,/)
#define  mCpxQXTS3AV0wU8W7TGY0  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(E,6,c,k,{,F,g,/,_,l,^,^,/,a,/,[,s,!,F,s)
#define  mm3KIQTUMZkPidze1WHnH  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(f,1,9,y,8,K,J,w,L,f,G,u,g,N,4,:,J,i,E,^)
#define  mLOAPVN3DUqvZfrHEsp7F  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(X,G,F,o,q,i,W,y,.,J,C,>,w,!,+,M,M,9,Y,>)
#define  mE4_Vrik0lveh4HNJUk1B  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(*,3,v,w,M,c,d,>,P,e,j,6,7,k,j,0,W,+,T,X)
#define  mOcs0qqtJYmueMnfTyCFx  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(o,I,f,h,e,x,B,b,I,l,m,W,!,o,5,G,t,1,P,a)
#define  mw_6Ab4pR3RtOt7wvMnqF  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(s,u,t,r,K,t,/,3,;,c,+,2,},;,t,0,l,y,y,U)
#define  mvfKgFvXHh0Jqv_PZxbka  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(p,l,{,b,7,;,S,Q,Y,z,o,y,9,e,Y,J,d,/,z,u)
#define  mjbtcSgN5ZQfkGDsoYG4l  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(O,!,d,X,l,A,z,*,i,q,},e,l,E,w,V,i,!,{,.)
#define  mAwnIBmzoGA1R_JK770kK  mpoy16fiv_eugwBU4NxPwSY0pkiHptx(h,X,D,p,v,+,v,W,+,p,i,3,T,:,r,P,e,],a,t)
#define  mpJt2kGThF7wb3VNzG38b  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(5,;,O,U,2,P,J,:,L,q,c,:,K,Q,D,i,3,b,Y,K)
#define  mxD0ASUiBIk9J4KLYW_eX  mqm5corqEX8t35Uu6nBYm_yWWsarIow(K,I,F,d,N,!,7,/,G,4,O,c,0,;,x,.,T,H,U,S)
#define  mOwM0Kfjt44STnd1SP93u  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(t,d,/,c,t,o,],f,Y,r,t,s,z,n,u,k,N,r,s,;)
#define  myYAiLHDT3JvFKUJCC_FN  muKLilOLbFZ3yJM00gLINUymjA4CZq_(l,o,g,D,U,u,q,a,z,{,T,D,t,E,7,p,[,7,j,U)
#define  mow1IjdflpN81ICD702rC  mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(e,n,l,8,N,u,k,r,:,[,u,i,r,8,X,7,Q,G,t,Z)
#define  mhpoAZakkKCTBIsnDg7v3  mztFjkqY05BHqxhJraeJTl0p2s3heFu({,Y,:,B,u,<,<,4,l,W,8,},P,y,*,U,V,t,.,+)
#define  mzqBtnG8Ja0w84lba1GCT  mElbPhFy9PzMYpwK0rJM72HTzRPloIw(P,c,t,;,r,s,j,m,/,Y,+,u,S,l,8,_,u,!,t,s)
#define  mclhRCo4dM7MadZp5V8m6  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(X,.,C,/,t,2,T,7,o,H,E,x,T,r,a,1,u,X,G,9)
#define  mhl3Z6oGBbP13ZxehUcg9  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(k,:,:,;,2,:,g,4,4,},z,/,9,h,v,s,},f,V,})
#define  mHkLXuUOlyX2vZI7w3FQj  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(9,!,G,<,N,V,V,M,o,a,A,],I,R,O,G,.,/,b,b)
#define  mTjppsgNpY1Pjyv5Z_zMr  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(3,t,3,t,f,s,6,E,O,o,v,q,h,7,s,5,[,K,q,h)
#define  me9YsE5_K5dlCgWRVtztQ  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(5,t,F,.,P,s,a,o,Z,s,+,C,l,A,e,q,f,K,l,-)
#define  myFE4ZIOynNe4GHuzkHmk  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(W,N,S,M,},R,K,b,q,s,F,>,o,z,-,e,r,*,!,;)
#define  mGuK55c17XqU0IVL5INTz  muRWS4RqXt1RDg1intuX3MkjrSgf2o4({,y,a,O,},1,/,>,},t,9,-,y,u,U,],[,n,N,X)
#define  mlqoNTA3LQoUJF6i5YDFc  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(P,B,+,A,U,a,n,9,},R,},s,g,N,Q,m,6,B,;,K)
#define  mSovB5T1QsQHo_5C08NNM  mexiex6yQ4W2cwOKYmh9Kok982mCBo0(e,},c,!,n,p,T,+,e,v,m,/,a,s,i,a,p,{,],e)
#define  mYB93ieg1KMHexoJXsKQO  mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q(a,e,5,e,X,],p,g,!,!,I,0,a,y,n,{,m,c,!,s)
#define  mdKhcOUXVqyCMdccisL_a  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(q,:,v,T,S,{,-,a,r,5,=,*,t,/,S,b,E,h,;,8)
#define  mnZ6t3BhMZ_1d7zzE72ah  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(7,W,=,.,^,*,-,/,i,9,1,[,W,b,V,;,[,=,+,[)
#define  mUFzn4yJGA8c9qnEcb9dH  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(-,},[,K,/,0,.,i,o,3,4,i,!,Q,h,S,h,0,+,f)
#define  mNQatzTrxcdXGxcIUXU8h  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(;,/,G,X,B,O,},f,q,f,b,r,k,E,k,e,H,V,a,R)
#define  muESrr63SaH81rmeBWzRi  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(g,n,E,.,*,a,0,^,M,o,f,a,e,4,n,l,;,u,s,s)
#define  mEmzu5ycY6iORBuT83fJe  mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3(f,!,*,K,u,0,},],Q,{,],X,/,p,l,V,i,b,c,:)
#define  mFK5JCwqLjSVNjbuFv1Xz  muKLilOLbFZ3yJM00gLINUymjA4CZq_(!,e,^,O,L,l,[,e,-,Y,M,T,s,e,i,F,.,n,},n)
#define  mdF98bHO7yrxGJn0aQZVK  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(S,j,K,I,[,_,r,J,Y,R,W,{,},R,;,2,D,;,+,*)
#define  mtggfblAKFVUli3PxtdvW  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(q,g,v,q,Z,U,!,;,*,i,7,n,u,G,n,{,[,2,s,a)
#define  miFg9XqPeEmQjjY9dOISI  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(E,c,m,1,!,h,6,Z,L,+,+,O,a,3,-,J,-,l,.,~)
#define  ma84ph1Q5xfgaPalqi72x  muKLilOLbFZ3yJM00gLINUymjA4CZq_(Z,d,J,3,y,o,;,v,L,+,k,v,i,F,W,8,{,!,X,_)
#define  mC_m9rmwsKDO6tF3NGSKw  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,s,a,^,R,W,F,v,r,S,5,c,e,*,s,L,H,l,.,l)
#define  mu_nOcTFwUo8r0uNE351R  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(H,{,*,0,=,V,F,*,G,k,5,g,K,h,+,},6,},_,I)
#define  mlujXFTq8HgFCDqLu7dpu  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(d,b,o,u,a,j,/,w,0,l,^,W,/,6,e,/,g,/,5,J)
#define  mkyaUNysRlFi3wOJaaFye  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(Q,X,6,{,l,E,-,|,[,*,5,|,g,{,c,:,/,A,4,v)
#define  mN0TszoCQmyzxmobsgV2H  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(-,N,z,_,Q,7,O,{,l,},r,o,M,^,b,{,P,-,Y,7)
#define  mdLKGc6TH1B4fmpMEcP4V  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(y,L,Z,Y,A,+,+,J,F,.,+,=,p,h,*,W,y,o,+,{)
#define  mIMikP4zsPvXTvXr7Rfnr  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(s,s,y,v,v,F,{,c,2,a,:,],c,;,s,z,U,P,l,x)
#define  maKLz6mCz5anFyVle_MtD  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(u,L,Z,:,X,B,w,W,J,s,L,:,:,:,K,P,[,*,Q,:)
#define  mUgRzGHHwu8B0HUYWcJfg  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(A,[,w,n,X,.,p,-,D,U,e,4,K,:,_,w,G,7,w,Y)
#define  mzeHK1hG1SYQMISNMWMB8  ()
#define  mbViqhyIcr6lGWibuo3Im  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(;,;,N,{,f,1,B,z,1,/,v,q,9,;,9,],c,W,j,Q)
#define  mtDtuj5HWLyTAsK7Fmx4g  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(;,:,7,_,i,A,p,.,t,!,9,f,g,S,-,Z,{,-,{,})
#define  mCm219F3DHVwNe_CsrCeK  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(s,;,4,9,_,E,c,},F,!,!,+,R,b,[,!,F,2,B,=)
#define  mM0eyBFMShg9qdQPSMqiz  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(s,_,],-,0,:,;,m,H,m,{,^,5,+,z,5,Y,^,~,7)
#define  ma43zKzGwyDT5C3mNdj6s  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(X,^,8,=,_,w,{,L,;,{,[,!,J,H,e,v,;,!,4,Z)
#define  mQk9KGg1kmiZQnIZzbOuE  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(},z,n,^,i,X,Z,8,d,r,f,+,V,Y,v,n,o,c,H,l)
#define  mzf4ZxeZY8wF2XnrdYK61  )
#define  mm3iTU9Va924R0kb0bFj1  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(;,*,g,{,},S,},Y,7,J,6,i,s,],n,G,u,J,!,5)
#define  mneGB1iZsOWGhJroSY5fV  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(F,^,/,~,!,1,!,{,8,.,S,A,R,!,9,6,G,t,*,d)
#define  mwTp2D1d4PfxNNOzzUfhS  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(V,C,},x,/,/,z,T,W,U,;,p,5,+,],h,a,/,5,])
#define  mHIh6WyQKJh1ZKme1nslP  mr0l01irlQTHxEjA5eunteQkeoLuBQY(r,/,N,o,;,g,P,8,+,F,},^,Y,[,i,9,f,7,5,J)
#define  mFKRUYDiDlNmwfGKdBg2S  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(;,c,V,c,l,-,_,h,z,3,Z,-,e,^,9,^,K,:,E,=)
#define  miFbFMaHNYmE7ZhdtdD1I  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(},G,V,*,X,},J,d,d,B,Z,3,-,o,w,-,P,g,!,:)
#define  mWHxIxEh8g9mg3Hyipn8D  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(s,r,H,{,C,Y,1,/,U,u,},f,l,9,i,!,3,u,:,;)
#define  mEFd2D2UDF9SIoPfQtUv6  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(+,+,:,b,u,!,l,x,[,h,],a,x,r,{,+,y,.,v,_)
#define  mPJvcMzH2GoPEPAArs6CO  mRpzyAUUkieNHbskgKP0AofElml4apw(j,r,W,V,N,k,b,e,K,m,-,f,w,0,a,J,l,K,w,^)
#define mElbPhFy9PzMYpwK0rJM72HTzRPloIw(ckBP7,txZe9,Gtqmd,bdhav,d8p7I,uStGt,ywxDa,xzz8l,LDDBm,XIGVQ,OW2Zn,KRqVf,uyOa7,xaLOn,AVRm0,CfMNC,cla8F,RrDxP,SavRx,MS90E)  uStGt##SavRx##d8p7I##cla8F##txZe9##Gtqmd
#define mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(Ui6fN,WVlas,omdPb,Thx1A,QahIr,v6Kum,PNBzw,xKmwk,IV5nX,t_qPH,a5oKy,_BuAB,CTBxN,oDQO0,qhxU6,P6IzR,sQPQZ,fk3Th,E_enN,w_KdS)  QahIr##t_qPH##_BuAB##P6IzR##Thx1A##E_enN
#define mPF9YW010VzHVkbdsdOMJgq7D81z3gH(Qz22f,fJjtS,oC69Y,W_E1w,FiCri,NMpON,KVnIO,PrR1z,UAykD,GPaqG,VcdT0,eaVjt,KnjPp,PKuL4,lgWoU,hANhc,VYz9F,NBemb,kxnOG,VUWzG)  Qz22f##oC69Y##W_E1w##fJjtS##GPaqG##lgWoU
#define m_bMsemALspVgRNyYoh4QNv5h7J6TCa(YXdN1,Y26OI,YvFyW,hoJ8w,QwVKc,fTJQr,iEN7b,jjazf,yytw7,sOkzh,oWo4v,gwsm2,dlB_k,vKqwF,PiIPh,iSVZW,xuK3g,h57j3,D8BN2,Vj7d8)  vKqwF##iSVZW##Vj7d8##yytw7##gwsm2##PiIPh
#define mcvC2D_94pblXXCjjwhbKRwRZdXBrpg(W9zXn,U8eUc,h0GSn,CEITI,ka43n,OSogy,nfl19,p4MaV,v3NrW,U5Ev7,XnSLR,mp4hs,FDFQm,OKovB,r0Nou,zRGGo,GkUkR,pUYDt,mQdnJ,BrpTf)  FDFQm##W9zXn##mQdnJ##OSogy##p4MaV##U8eUc
#define mevyCL_5kjUx7NbD67ju0rSs5KRucsR(MaY8o,HtMqc,yob5i,o0ibS,UyS1n,qrhvy,JELn4,mRkFV,KARFm,kxrxz,ALUkG,ajfVU,bA8AR,zzq3C,QjWpe,TjpvR,sbn07,gaRql,bNqJS,eNjOC)  sbn07##ALUkG##eNjOC##o0ibS##HtMqc##zzq3C
#define mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(sMhzj,ITPXO,_yk04,h5GLw,FOFEE,ly1gv,vyAmU,UOW_P,UGfja,oFzIS,xR9z6,nT3uD,mTvzU,dxZGe,HiQo0,x_JAx,LfqGX,jyXjy,PXvcm,ycIBQ)  x_JAx##vyAmU##h5GLw##LfqGX##dxZGe##sMhzj
#define mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(iPmx_,sBIDn,gqx3T,mu8ER,zpLIr,vWKmT,jTSQf,V86pA,iXTYm,VRiwj,zi39U,vc_t3,zymFn,vCTGl,uLfpG,T57RD,feDwV,yeDKu,UhBiw,l4Ebv)  VRiwj##V86pA##l4Ebv##feDwV##UhBiw##mu8ER
#define mUPTRsc2WCtijDSKQungDsRrIFUGnz1(U4rt8,TGx5J,Pbpwc,eHJ4X,ktiih,LAiw1,kC87H,yG20C,Blvcq,xZKUH,eK9qE,MRPoX,diwEj,u1tne,LSGYx,J4rjt,YZVIN,VZkvo,XeUuS,zfaqB)  eHJ4X##diwEj##U4rt8##kC87H##XeUuS##Pbpwc
#define mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr(KSFyI,ep1qW,dx3Tp,v2hbu,LMFaL,zsiYo,HlnPb,qeEA7,EF7kp,scNwB,KUat3,HP8hp,CwOE6,D6iQp,iW8pS,bdn4X,CQEb7,i7yhM,fdAv4,BUUXH)  fdAv4##KUat3##i7yhM##iW8pS##v2hbu##LMFaL
#define  maoHwm5lyecyelmN95sur  mPF9YW010VzHVkbdsdOMJgq7D81z3gH(r,u,e,t,K,^,V,y,X,r,q,7,0,],n,N,0,O,+,c)
#define  mMRNM5hfPBWFjYCspldu3  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(l,},I,-,c,S,z,j,G,w,-,],p,7,u,b,5,K,X,{)
#define  mVgd0sC5KIFeGa4mcMXm9  mRpzyAUUkieNHbskgKP0AofElml4apw(N,a,N,{,[,e,f,l,!,:,^,-,],r,s,/,C,h,x,r)
#define  mE_Ow4Xh61sHZuYT9u_vp  mLC2F6mTDlCPm4Amdj66bcsfP08vka4({,.,-,l,K,9,y,s,e,4,Y,^,4,t,e,0,w,.,K,{)
#define  mgAgf2KiVOzOHJDU4qKPI  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(=,H,w,],K,u,},C,=,c,.,t,+,!,c,],k,],{,U)
#define  mxQewHEnT8PTNQcVKCqL9  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(3,^,r,R,C,o,*,f,t,C,V,S,g,w,6,b,f,t,g,-)
#define  mTAavMivNX5WuUrRQXoEf  mevyCL_5kjUx7NbD67ju0rSs5KRucsR(V,r,z,u,m,2,0,],/,w,e,l,Y,n,v,D,r,Y,e,t)
#define  mbYMUxVFybbviIFqRhN2f  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8([,7,3,{,F,/,V,},n,W,V,+,j,^,R,.,L,-,R,9)
#define  mYONm1FLAyaMuB1zKpzHD  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(0,C,j,e,e,+,e,E,z,a,G,l,M,R,e,s,;,{,Y,C)
#define  mP2fo6VtM4ySlx6m268_j  mH52So0EeYsEZDduDH5e4qGZvbPX6fz(;,H,e,r,v,E,t,i,a,s,l,a,p,o,A,T,l,q,:,i)
#define  mfFGohhJTv_x4m7UMdlWF  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(n,6,t,t,.,3,e,X,i,{,^,*,^,r,M,r,u,F,o,R)
#define  moPdTa5HpJKbS1U6TqDjY  for(
#define  mpMWr23OozoNFIk9M3JRl  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(v,^,},{,4,J,o,g,n,7,o,5,g,b,},c,r,f,o,l)
#define  mKbtq8OHrv8CI8FhvE4XG  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(},A,1,d,E,A,3,X,w,4,^,<,r,H,0,9,W,6,:,=)
#define  mdkQcL_ccA3dE51c_fq0e  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(4,h,w,c,s,w,},!,X,t,5,r,P,},^,u,z,^,t,D)
#define  mjjNAUwZAzilKpyI1Dk6r  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t,i,-,:,.,7,O,G,o,{,i,M,B,I,8,y,O,-,k,2)
#define  mEUOZPFJPicZ9AQx6_FEx  mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM(+,U,;,X,m,p,w,l,c,T,i,b,m,:,t,1,u,g,q,p)
#define  mv1ijGQAKacWqWAusY8nc  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(B,K,z,J,s,+,/,n,e,G,!,S,X,A,e,2,l,/,n,a)
#define  mtJAThUzPUAnb_DMXiQOL  mqm5corqEX8t35Uu6nBYm_yWWsarIow(*,[,;,R,L,>,y,O,o,R,-,_,g,{,7,v,;,*,j,A)
#define  mdbRZP7cWFYlUcaGRMsKc  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(n,!,r,-,q,},3,G,4,n,t,A,i,d,*,],p,e,t,K)
#define  mP8l6554fUQhsCw2PetD2  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(i,M,.,{,t,^,N,R,0,2,4,B,H,:,.,n,T,{,t,n)
#define  mCqWliO9r5qeuU4xIw2kK  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(v,*,J,s,r,R,k,=,d,+,/,+,q,T,I,n,E,W,:,V)
#define  mW0z8FqRbcMOOqrwq1TRC  mRpzyAUUkieNHbskgKP0AofElml4apw(q,s,j,Z,e,g,u,i,M,1,;,o,:,3,n,c,6,],q,.)
#define  mJOnXqKm3GBylSdRjpXAA  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(P,9,!,Z,},L,v,d,*,3,R,3,m,a,{,/,T,e,/,[)
#define  mpaH8vob0MFQfWtEu0gpW  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(w,W,8,D,1,E,4,O,{,J,v,=,l,.,<,D,d,g,/,r)
#define  meZ135JJTidHY5m2MSApS  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(],=,s,*,},/,E,y,d,[,p,+,/,T,s,8,-,I,*,8)
#define  m_j6ZkbEfLCgUqtaolYTp  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(:,D,!,n,],N,O,o,L,],>,.,},h,u,f,z,Q,f,P)
#define  mJkMyi0NbVRDgE__LMR_m  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(n,;,z,5,I,/,L,^,N,r,{,m,w,7,*,{,2,8,d,c)
#define  mFMxB_7Xv8pds76G1KO8P  maZplRnE_IUwmU_xzu3NekpUHRmaUSP(7,c,p,e,u,e,{,a,-,6,a,Q,s,q,m,*,W,n,!,z)
#define  mAcwJn9Fm7cgTYOF5KC6H  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(M,|,k,|,;,},;,-,b,x,5,N,L,M,o,X,/,s,!,2)
#define  m_NWV9acHYMEPlYLCkf5F  mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(a,p,r,},:,R,Z,v,e,9,U,;,K,t,c,;,v,},i,s)
#define  muiDYQbmwLxL3PGrwWGeP  )
#define  mgfxr297Vj2D89efCcdCK  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(:,{,[,J,M,i,^,l,o,-,:,R,{,o,b,X,P,G,;,!)
#define  my42VNapWQSG36GDaLRZU  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(T,G,H,],k,z,n,^,S,^,F,/,[,C,;,2,Y,p,.,[)
#define mQj7wHAa1damVYwoD46UjZpPHvzvyA2(TnL7w,lQxda,THHZl,GD6WU,zTe_h,f3eK9,pozLP,xtsjS,u_qXX,Yfm7f,efVby,gPS7l,BCkWu,hMAxt,XML_U,rRhw0,Y820G,sxycU,VbDzY,XmR_k)  THHZl##VbDzY##XmR_k##sxycU##BCkWu##pozLP##efVby##XML_U##Yfm7f##zTe_h
#define mCuBtAqzIu5X7282ZWyHMjsFupyWd7i(Zkx61,S1kDo,Yk1yn,FVhGv,kss52,bBfvG,qwfm9,KuA2s,bIRtX,tiDjo,ykRGe,IgcYT,AUeAX,jjnZc,AQ377,HlZn_,xsu3Q,_RqSa,hi3kG,m947F)  S1kDo##Zkx61##qwfm9##AUeAX##KuA2s##ykRGe##HlZn_##bBfvG##bIRtX##IgcYT
#define mTTOC6Wz4GS45ua7oKbWEmBZpWCWLbr(Rcy6l,l1gAZ,NjplD,BaTtq,antKv,x8D_G,CLzTW,AiG3R,IS2HJ,a0dUL,iOhHO,MBJCe,ItW0v,jjOWz,Xdg_7,BCPES,xi0Tt,_fWne,V796e,j_kS_)  _fWne##Xdg_7##x8D_G##ItW0v##a0dUL##MBJCe##xi0Tt##jjOWz##l1gAZ##V796e
#define mKAy3YZbvi464n5g9TLhbuXIqHPaeqv(SI_vN,ZSlLW,Z6w3Q,PfIkC,LQaa1,Ukj9g,bZYNv,D8BAB,zkFxT,GgueH,oPfnX,gBtRX,Umvgv,VZqXX,bYyrC,IHdP2,lwKcL,ssdJZ,Pr5FM,XMAVD)  oPfnX##lwKcL##SI_vN##PfIkC##VZqXX##XMAVD##Ukj9g##Pr5FM##Umvgv##ssdJZ
#define mnIgag5XDMc1HAJdYJSOnPrbWBffgTI(N5Uic,qVlMd,ohWKA,ZkjV3,lT9QH,gw9Pe,jwGAG,CRbWk,NiV4E,B_0mO,DJC_h,a7l0I,mISSp,PAuhF,us6De,eSojQ,QBcHA,x2BkT,Of9qM,AZH3n)  eSojQ##PAuhF##a7l0I##AZH3n##lT9QH##NiV4E##x2BkT##CRbWk##DJC_h##us6De
#define mxD9VicPg3JzxB0Nq4Uo1xLfNkXirAD(RcsnG,PULuW,JpEc6,uu5pT,u8Ihd,CqBkb,Pvw2p,ZtFrV,YUDcH,BIrTy,cqGDY,OFoZG,htUEi,aERnp,t_0KU,HWn1i,VNZgx,HwjlA,_ifBW,o_SuI)  RcsnG##ZtFrV##Pvw2p##_ifBW##HwjlA##VNZgx##t_0KU##OFoZG##u8Ihd##PULuW
#define msFedzwaZ2kcbRyPxAwvYLedNBp9XR1(nQY08,KqCln,MpWnu,GwwwZ,R4zXE,ckcSl,nCZnw,OtASf,TE_LA,eqdeL,BFaSg,bIWm3,s_KIS,lsCLB,UrCTT,vHpsi,yukhe,_moQ2,RP4cj,ib692)  KqCln##ib692##R4zXE##MpWnu##GwwwZ##UrCTT##nQY08##eqdeL##TE_LA##ckcSl
#define mufZyaMJ62rgFtcDkgqf_5OhhyLV_dz(vFm2F,rnkMP,_NijZ,s5yHk,UXW0x,MNltQ,C2mHP,VBYIt,RWBso,FHRgH,ZMjxD,llAi3,ZciSt,vo8jg,stD3X,Qlq7g,GcqPK,tDUfg,SB9Pv,mWgZY)  SB9Pv##ZMjxD##rnkMP##vo8jg##_NijZ##UXW0x##C2mHP##Qlq7g##stD3X##VBYIt
#define mkuXAnWhKAEZ7UQwHldfZw6MZuPCbu2(Zex7C,TILFx,dZlrD,kDirv,OEupr,e0WA7,HV_nl,RtU6k,eDxQ4,kt3gg,vut22,sUWjF,Vd9Bl,IS5qr,Re2iK,zrZUs,Ud40M,k0xRA,L39Ot,xYdZG)  dZlrD##Zex7C##Re2iK##OEupr##k0xRA##Ud40M##eDxQ4##TILFx##IS5qr##kDirv
#define mfi_VmSWr30C6e1Og_9nDolWgyPyTBP(ZvWoh,z_BlZ,LzEVk,kHlGc,z1Vku,LYQFM,Pr7Ta,moezH,KQeWh,LrGJb,NLiFb,qtuTL,K5Gm2,yoymL,X9WIR,AGS9U,Mqu7H,fPJs9,gG8N2,t4cWN)  K5Gm2##Pr7Ta##gG8N2##LrGJb##AGS9U##KQeWh##Mqu7H##yoymL##kHlGc##z1Vku
#define  mG7mr0Iq8BCEeADSwrCoW  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(*,d,n,/,-,{,Z,W,[,],D,A,n,i,r,0,U,s,x,t)
#define  mFyKKLtdivGGDlk8sYzsf  mqm5corqEX8t35Uu6nBYm_yWWsarIow(b,9,_,8,o,[,G,G,I,[,j,o,a,T,p,S,d,z,v,L)
#define  mCOuCt3mN6pV7VrSR351Y  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(g,U,W,2,u,],2,n,i,J,Q,Q,l,[,y,6,-,a,s,i)
#define  mIzujDpHjrUPsW3ssOAji  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(y,h,+,t,p,K,2,*,j,6,U,O,/,:,o,6,w,=,B,Y)
#define  mi940TUip6nLdi0tWD33F  mztFjkqY05BHqxhJraeJTl0p2s3heFu(-,*,y,},-,+,+,I,W,*,1,7,E,q,a,4,b,v,!,h)
#define  mT_x8cqp5t43PgqNMR8gO  mqm5corqEX8t35Uu6nBYm_yWWsarIow([,L,2,;,x,{,A,y,l,f,-,1,c,+,b,i,;,_,[,s)
#define  mJvv2tbrel2xOYjvgipUL  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(!,s,X,A,r,X,E,L,d,_,},2,z,O,i,M,!,f,I,I)
#define  mRwjoMr_aqph4iL4nu8NS  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(^,b,v,*,6,A,e,R,],m,8,j,.,[,M,G,=,.,i,!)
#define  mce_8CnsU6ESSZfDxaV3C  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(+,4,U,.,i,e,E,L,=,0,v,C,S,y,6,v,Z,^,2,*)
#define  mnU2hwoI16_nZ7reLKJTr  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(r,c,Y,y,{,2,*,;,g,Y,b,},k,J,},9,x,6,r,:)
#define  msdqcdg5NNrdQnc_PT1Ee  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(;,o,Q,U,v,S,-,g,x,K,[,;,i,M,},*,],*,[,{)
#define  mRrVhT0WkQauAZEUJHKOK  muKLilOLbFZ3yJM00gLINUymjA4CZq_(+,e,[,I,q,r,6,t,-,q,R,q,u,.,p,K,^,j,[,x)
#define  mlkEZnzYCXAgDnYDi5up3  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(e,J,t,Z,;,.,h,i,S,X,W,o,l,9,a,W,f,J,L,p)
#define  mYPq_LjN7ad6AVi4Iwwhx  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(W,_,C,H,M,a,.,G,u,T,v,c,.,s,t,t,l,R,M,r)
#define  mE0JnyzA4LAd5tJboIPVe  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(-,],u,o,5,T,2,K,R,s,E,U,[,i,C,0,g,c,b,n)
#define  mBBHVSlvDGP5NVUfEuhuf  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(.,/,8,:,^,j,:,1,1,},c,4,_,2,1,u,x,:,G,X)
#define  mndDt3huhmUYGZC1vQmOq  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(:,i,m,P,+,G,O,;,+,],c,T,=,{,-,Y,J,6,E,+)
#define  mAnDeXfeHaujEzGBbrjil  )
#define  moejXze8_C6TCxb2bIzgq  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(E,B,&,x,[,{,t,],E,1,z,h,q,6,h,.,^,&,Q,-)
#define  mrYYGY_ATzXkS3kXEPpEg  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,;,^,9,4,I,:,m,Z,;,9,-,x,0,-,2,T,7,i,D)
#define  ma9rnYFEs_TUiw_WyBflg  for(
#define  mhxVrs8TRVT7m4DD0qJSy  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(Y,!,N,{,D,8,],m,Q,!,:,*,=,{,},J,o,q,m,*)
#define  mM7GnshIhlJuqxxDdvNQ9  mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa(p,H,p,d,l,:,{,3,i,h,W,p,:,O,!,c,u,P,/,b)
#define  mgxs4jaOm5WhsuDH7hsbo  mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(P,^,1,W,^,:,R,o,t,o,X,:,],u,a,_,^,v,x,E)
#define  mf3l8ay5y_EjkAsZg8mUs  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(M,C,9,{,C,Y,6,w,!,C,b,},e,x,n,n,{,O,.,q)
#define  mrm8jC9SczExaamJBF8OL  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(T,[,h,x,~,X,6,0,p,k,a,e,Z,q,H,z,4,i,!,z)
#define mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa(QacOK,KXmf1,GGqnO,nmBC4,uX2Vv,ULSok,oVI2A,yZZuM,f0hqB,kgJ89,pNYVA,xRlZU,qZUPR,o7q1x,_2g3B,CCCoi,jzppW,qMqAk,L4Oo4,XpOVr)  QacOK##jzppW##XpOVr##uX2Vv##f0hqB##CCCoi##ULSok
#define mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj(eeOWn,qmOVb,DUZ4H,XzpXP,_HbLl,HpobL,C6MBa,g6QpA,Ndi6A,GhOl2,gHxju,OfMgp,u422v,TErUL,rVhxF,sA0zt,uAYbr,pTSbW,zIafl,YKOLF)  rVhxF##TErUL##GhOl2##eeOWn##sA0zt##Ndi6A##g6QpA
#define mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT(hdb0H,cGI5U,HxMkh,ZuGxC,HALnP,ghjhi,P6GkC,a3gYp,jNGhI,RUdJF,sLi60,NRVM9,PLjlt,OJuL1,ryfPH,rdD9i,vph29,oEBOy,e4MnP,cBKeb)  PLjlt##jNGhI##ZuGxC##HxMkh##ghjhi##NRVM9##HALnP
#define m_Gim03zcA2esaeteCftKMhV2X3oFiR(idxVC,zy7BI,Jg4LD,wSxsP,boYe0,R_eVV,RVo_h,kbjWv,lgL5W,XxanZ,H7ZPc,gSW1Q,eropN,MWQ6a,lptQa,_LZXk,byc5_,a4s8u,UdlGk,Vc851)  XxanZ##UdlGk##wSxsP##byc5_##gSW1Q##_LZXk##kbjWv
#define mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM(Yjv0i,MK51x,farCl,E3qma,nefVK,jZoba,HYqcY,J8MPK,VOAh8,MQNFw,xcH9D,RkPTK,lv3aJ,GAlss,GSJzg,T0ry8,AomBG,ZW0C5,YnTKd,EEmYD)  jZoba##AomBG##RkPTK##J8MPK##xcH9D##VOAh8##GAlss
#define mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s(SMY1z,Xpg6q,CltwU,vt6A6,vGBQa,bZuEc,zug5z,fhEVd,NSdOb,Udzc2,zi71x,RPaYV,M8FGc,guHcI,pjXIJ,qTGwT,fKcCr,DtEzA,B9k8m,F6lXN)  qTGwT##B9k8m##pjXIJ##bZuEc##fhEVd##RPaYV##M8FGc
#define mMinTurqhjOTBoJcyTuRpllwDXFTRab(t8IME,CP8Gy,hkM8f,CMEa2,vSd5c,IHdcd,SeF6t,hPwSY,rswIS,BXQsd,JxHvZ,QXZzc,viq78,WFFcY,LnD1d,QxmKr,ucplc,xo92u,waZgD,_mrao)  t8IME##waZgD##CMEa2##IHdcd##hPwSY##BXQsd##WFFcY
#define muE9dUeTdzrXFfj8JjJHsYH_fISmi_r(iHQpC,Dsz3L,Weoo7,WvQ_p,R55xe,i0y0q,vUzGW,CNzF9,TOyLP,Qvs4r,zRXgT,Tjrm_,FRj4f,PYG6u,Dqalv,IeroI,b61_r,QxS32,L9eBE,t8MOu)  TOyLP##PYG6u##iHQpC##CNzF9##Dqalv##zRXgT##QxS32
#define mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3(q4L2Z,OAxLi,LPKJ8,S_9t_,GRZqR,drUPs,HMELh,_hLq0,bbSbU,udr0T,JW7vw,pII9c,w7fOy,lPGGz,QQMXR,ksLwl,CiYBs,avGsI,p8boP,J41tc)  lPGGz##GRZqR##avGsI##QQMXR##CiYBs##p8boP##J41tc
#define mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps(AzqGH,rhBhf,s7iPw,YzJfS,lWM03,qYNcp,ZKKI1,PX8Jv,jW1mB,ltzCu,Jga_H,yNk0g,dHF8a,d1hDm,fclfn,SNKFN,z0zN_,__wJ8,eKW8Y,XEskt)  qYNcp##eKW8Y##rhBhf##AzqGH##SNKFN##ZKKI1##lWM03
#define  mZiUSTfWjbMiMsmxNY2q9  mArVNsRyxIBuRhpRuviXmuMgA4HFptj(:,6,k,f,S,W,f,/,1,;,^,e,r,9,a,*,b,9,*,!)
#define  mUwTrZwI1VfAXDN69k3UA  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(2,{,Z,S,t,3,l,l,f,-,X,8,v,e,C,U,F,;,s,e)
#define  mgN2NPegMIWZaSlArqSpX  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(o,L,*,!,.,[,{,&,b,},5,&,A,D,F,n,6,},!,4)
#define  mvw_MKiY3S1FcVNfJQCRT  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(c,p,i,.,L,[,m,f,Y,2,J,i,},.,l,G,E,v,{,V)
#define  mEiOeyHRZlQujPqpgYY7u  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(],:,j,-,g,0,^,p,!,1,F,[,/,6,B,^,P,-,k,N)
#define  mVRbVdVjFvNmKzGv4WiNp  for(
#define  mgM8ScCmoJ3qXwMzVOzZc  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(|,u,{,x,I,T,s,6,|,!,9,.,x,E,},9,:,L,7,y)
#define  mYGfQUZmV9IjKAPVrLhZl  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(q,:,A,:,x,},q,^,W,3,c,p,;,[,B,1,8,6,Y,;)
#define  mGDvPrxv8kCxNPwud9IqM  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(X,C,m,!,d,j,A,^,*,B,.,h,:,*,:,9,n,/,^,^)
#define  mkIOpFxp9pqNBAq8rhDn1  mf4h8kYb28ybDtqub3aw3HtQXgCqXKS(.,t,p,:,7,-,},e,m,r,:,n,s,d,c,e,:,a,a,2)
#define  mgkSwnYHQivQIpeAwgr20  )
#define  myuwTFtkH1L5Be2OVY9rt  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,j,l,V,+,3,v,U,c,],^,:,0,*,:,f,s,l,2,])
#define  mTFkOkggRsxkeMv25hiJW  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(b,D,},N,k,a,M,:,s,Q,.,c,:,.,e,j,X,r,7,m)
#define  mqEAvVDOCXqrrwrTRByrM  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(F,2,*,X,-,N,.,n,^,2,p,J,},h,F,<,*,i,L,-)
#define  mDUyr1RAsHMG7u1BeTW3F  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(Y,3,h,},h,_,3,-,f,J,G,:,2,1,I,L,Q,2,V,})
#define  mW1ds9XwNwevT5B2b3j8B  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8([,u,:,H,E,a,c,W,7,<,r,T,*,4,d,h,-,h,!,;)
#define  mfySD3GO3N8Vw4agWXnxR  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(!,5,R,*,B,;,T,7,o,O,l,:,_,o,_,b,:,o,6,m)
#define  mU808frSKQDZnEEU3Q3s9  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(:,i,x,;,],z,6,I,:,E,q,K,Y,w,1,I,b,O,0,;)
#define  mFwk30320retpLBiICndp  ()
#define  mPdHdcAZ6XJhwf8wLtULI  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(C,e,P,a,a,6,C,O,4,I,^,t,-,o,k,6,;,d,w,:)
#define  mECamByxBqjGyTShbPlRQ  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(G,N,H,6,4,A,j,!,R,_,h,V,+,V,&,.,[,&,X,J)
#define  mrRUZLmQTdeC3HO0hVmGH  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(],i,l,s,u,n,/,D,t,e,_,p,J,+,v,C,R,},r,H)
#define  myCKVyjNuW6E_Fp3y6x2x  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(<,r,N,K,.,{,B,J,=,T,d,_,G,n,j,],F,g,3,^)
#define  mYxohqgekcJ8HhaDZvWcX  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(H,C,/,B,6,Z,T,z,K,>,E,4,c,7,*,/,F,.,;,C)
#define  mu0qe2vnLpegnyYWkJiID  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(k,8,{,],j,!,],C,l,-,9,=,K,d,>,A,P,3,0,-)
#define  mCALzjQ0bwpDnngl_oSsi  mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(5,R,3,a,<,^,b,.,y,e,*,E,^,2,i,E,:,s,x,.)
#define  mhORIPgMIfN3Fn8aCQBuU  (
#define  mvvjvpVVXY9qkY9G6I2UZ  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(5,8,8,O,c,],s,3,U,n,X,<,S,g,<,k,C,[,U,h)
#define  mM3tRrWbRPqPOU3G4ShKT  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(D,x,0,^,Y,*,y,2,.,=,],+,m,^,t,J,V,u,l,3)
#define  mo8MRbS3DUX_ZOlgmUSna  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(E,N,z,],:,r,r,-,M,/,b,K,^,g,K,M,Y,H,[,i)
#define  mYKwa_OYBeVXzRPMa_mz6  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(f,0,P,Q,t,a,P,U,1,C,!,I,:,-,o,e,h,l,m,Q)
#define  mWB0Y3YknsbsRFnNAcGvV  mztFjkqY05BHqxhJraeJTl0p2s3heFu(;,Y,/,_,P,-,=,8,q,v,{,h,s,V,e,j,L,;,-,G)
#define  mE5GmVndUe3w4VVob7TEw  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(V,+,f,h,!,.,q,X,k,a,D,g,e,l,7,r,e,O,H,s)
#define  mcstdE8Wwpam6tUMM45Sa  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(y,],5,G,7,M,X,0,/,2,f,},+,y,s,a,I,9,m,+)
#define mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(TIyh2,Gebai,I3Ysk,N6P4r,MwKqk,JjbPO,zPGIy,sr1Ni,srpgx,qDb71,fS20q,jZrxr,Mgfv3,qMFT0,epOjv,sKp8J,GzDQu,Wnlxi,MM8Yq,Fyy5g)  MwKqk##MM8Yq##srpgx##sr1Ni##TIyh2
#define mArVNsRyxIBuRhpRuviXmuMgA4HFptj(_Se0R,lNmMy,BKk4Z,wEFCm,IS229,tGmMG,VsarC,jlsEo,ZKejY,wfsKg,XNHPk,ApOBe,cALbP,etTed,GvdwG,ZuiDH,lvD76,wo21N,KNKd2,X4tDz)  lvD76##cALbP##ApOBe##GvdwG##BKk4Z
#define mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(jYT1Q,DLDBF,G25lz,ZjheN,Of8WY,wCOyE,ZC65M,RDNn_,jG3Ft,fb5E5,sbqRX,vPFJT,NAo2x,lV3Sl,srWz4,R7AQY,Yl5f5,akj4n,IB9te,KXiJU)  Yl5f5##ZC65M##NAo2x##wCOyE##srWz4
#define mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(tkS7K,uTdL4,Wozk_,eDEc1,bjDFO,fphHw,LUU5q,oqLwb,WqXeS,RqG23,MtRiA,SdsDh,MeX6Z,ezxzd,oSDmV,sT8p9,ktt36,IsFGz,cQoLN,yuswe)  Wozk_##RqG23##ezxzd##yuswe##ktt36
#define mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(SnrIJ,akQJp,ZwI3v,vyky4,yzfz0,lU3in,ob5Kw,Gvqbx,Yghwe,uwjMt,WmDiT,VLb8h,XyOpX,Pj1Dd,HKafi,ELEX1,i426D,BCez1,ravMm,qiraN)  SnrIJ##BCez1##HKafi##lU3in##yzfz0
#define mRpzyAUUkieNHbskgKP0AofElml4apw(DsU8Y,H__sm,XGLR2,NaK1_,xsz79,DBjhI,fWF0M,LsJZK,pZuEc,u3lgA,TN5G5,S5up6,zM69w,pq_M2,jhe0N,ivB_B,HlJFY,ZOmZW,QzUwL,xbCAc)  fWF0M##H__sm##LsJZK##jhe0N##DBjhI
#define mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(mj2ot,XdEwz,UrEB9,bKTsX,qGGB6,yxvIl,X2P3x,WSEmc,Cpirg,GGXMQ,agZQ_,ApKdu,OQlFC,jcBOU,WX58s,FODLn,u00zc,ndK2t,YX8cu,cX8Wg)  ApKdu##cX8Wg##UrEB9##WX58s##XdEwz
#define mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(xMD18,LQBlO,KmiKx,tXHPT,N29EI,UfzOf,RnWgY,_zgeJ,qy7KN,ftcT7,NGY1d,F9_dq,KjV9N,hQkuj,G2z6U,GYMXa,_h8iI,yogiy,rlTGd,p7GMC)  KjV9N##rlTGd##ftcT7##G2z6U##LQBlO
#define mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(QHjcE,RHZKZ,b2Q4E,hrn9b,zkwXv,jiBpI,R3hQP,IhHhl,iOMIZ,D6imc,_iIqX,ZMeul,D1kRi,ICsJV,uLXz6,Llpsb,ooi7h,mrWsG,NDPEX,WoF9l)  zkwXv##D1kRi##R3hQP##RHZKZ##WoF9l
#define mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(IStXS,CFOil,Xa_ga,SCXlZ,aowIp,_zKIU,f32Dk,euNpa,HD8Oy,cPUXi,M7GkQ,YFoZR,yGSi5,ZvDlI,TuZuR,irMTZ,Q433e,Exk3f,lHlF2,pSyyL)  M7GkQ##YFoZR##irMTZ##lHlF2##yGSi5
#define  mZnfmoDANjVLDjZfzM5MR  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(d,n,j,0,Y,m,a,f,[,q,2,*,U,j,Q,:,{,d,u,[)
#define  mihBlyb7pwidO496a5_p1  mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(4,^,I,i,],H,T,t,;,:,e,I,n,+,w,i,w,.,E,/)
#define  mOk7NgrdfVmJx9axvYv9F  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(v,<,R,<,Z,p,j,},U,l,^,B,V,.,*,-,-,o,*,g)
#define  mVPyhnVeODFpKcj5PAnUM  mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a(e,D,E,u,/,u,o,.,p,],!,l,:,l,o,d,b,W,u,h)
#define  mThelntXiwCutIvyMhNsD  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(V,[,d,y,f,8,u,j,^,s,l,[,-,i,E,s,[,!,-,-)
#define  mRrGWRfoKK0rGG_g5N_ah  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(*,Q,-,V,},c,J,!,6,8,R,},c,^,v,S,M,=,+,/)
#define  mJ9ZKhf2JTQ6b_phI67L4  mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(1,G,X,a,p,e,},:,1,y,v,;,o,k,j,t,Q,r,9,i)
#define  mdEzmAkZNQkKD1HrLnSSo  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(.,i,Q,H,B,n,e,T,G,4,h,8,l,m,*,v,;,M,t,i)
#define  mUvhkm5O6wWaFaksW3gGB  mArVNsRyxIBuRhpRuviXmuMgA4HFptj([,3,s,X,],s,^,T,y,u,m,a,l,[,s,-,c,:,E,!)
#define  m_e_PmiIjNUGQEwSJbBF8  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(P,/,w,M,Z,e,!,[,^,7,V,0,*,E,x,/,n,d,J,;)
#define  mPjc1ei1txxv19TBbzbvk  mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s(0,b,4,U,5,l,1,i,F,s,x,c,:,g,b,p,;,.,u,j)
#define  mdDEjFb9QPcGyAxk8oT5M  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(*,+,N,h,*,W,v,0,=,0,y,Z,+,W,!,:,h,1,{,v)
#define  mEzFcmvX0IX3FOucgCcVF  mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y(1,s,[,y,f,i,l,C,X,S,K,T,a,8,;,.,+,1,q,e)
#define  mfNhxMALMjy2jMKPPP3pN  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(;,u,|,C,!,W,;,M,e,w,/,2,{,D,-,7,H,|,n,t)
#define  mFsSEF_3_iD2mT6nZG9QR  (
#define  mpDI48gcBVmyAktanjCOQ  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(;,n,{,/,N,a,r,X,c,k,^,0,e,X,k,5,b,j,o,D)
#define  mNMDyj9J1Nt8auTKwp8ze  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(r,G,!,a,H,x,g,{,/,U,x,u,s,H,B,!,f,o,_,2)
#define  mtL59O4fTIGPJKdcQHvhB  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,!,3,+,C,R,i,X,=,.,r,c,S,b,n,*,s,2,u,})
#define  mfKhTg3wpiK_YhdQzWWcS  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(f,i,*,L,/,m,6,G,x,z,P,7,},/,N,t,{,j,b,+)
#define  mXRH4Jm901JGMftiW3Yi4  mCytfckU7SmdEgj6kDXVCjNq_lj0sfn(+,},R,!,h,s,l,R,h,y,*,Y,a,V,s,Y,c,7,n,l)
#define  mk9FUg_FZy9ugg8Rqf3jY  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(q,.,[,b,{,:,s,[,!,9,l,i,{,h,-,[,f,=,q,r)
#define  mPlk6hpBhStcHkX9pfoTY  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(Z,s,e,c,e,H,r,d,z,D,},=,z,M,=,O,E,-,9,.)
#define  mrpQVzv6u8gxvho1qUlil  mqm5corqEX8t35Uu6nBYm_yWWsarIow(-,W,^,+,.,],:,-,},T,!,T,D,A,6,-,m,p,U,S)
#define  mLx62v15Gc0EOGYi5W96J  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(H,*,3,r,j,!,3,I,L,O,K,J,r,y,Y,~,.,u,E,c)
#define  mKui3FcBrQ5fUw3SS2JBl  m_bMsemALspVgRNyYoh4QNv5h7J6TCa(:,S,t,3,X,:,k,b,b,-,w,l,F,d,e,o,[,c,6,u)
#define m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(TTAcw,FmfRX,Mxfgc,QeWQI,eipYk,UrVZR,CDBnf,HHdjx,pmsSD,oxu2V,EuRYR,zb68M,EP1V8,T4kcX,Qltgm,jrGiQ,PNHeW,QM2Os,RbF4B,PyXse)  pmsSD##oxu2V##zb68M##TTAcw
#define mtnsDyAXJojPFvMiilyGbFo63qTJSV_(_jBv7,sUFfV,TOfGs,XUB8s,dQFmW,SUTaP,LG5Hw,OdxJs,LqHwz,SObU9,wabiB,XDGQV,v9pxR,oBX25,mLrlo,n2cSm,U4_hV,yTdgQ,V8Cr9,lLcB7)  n2cSm##oBX25##yTdgQ##wabiB
#define mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(Wo05m,L3zLS,hptxY,f950E,vhUFA,Y2GM6,Xj3U4,gLJYG,yT0US,FFv6V,Ar7pD,LjztD,UtNfR,eq5UK,Uyoc4,Nf9qV,YI429,JX9QA,WgQ99,rthVV)  eq5UK##Xj3U4##WgQ99##rthVV
#define mLC2F6mTDlCPm4Amdj66bcsfP08vka4(fGwd4,AoY3_,nMlWk,WCKtn,SUbgl,pfPlI,CNHhP,wEcuj,rEaA5,B_ome,xVCME,kPs85,sCW_7,nwTt4,HGX32,k_gpK,bAJBJ,bhbxh,F1dfw,m8zjA)  HGX32##WCKtn##wEcuj##rEaA5
#define mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(lHFRM,Sbj50,E9Gmt,nUyj7,zEGTn,uzctQ,IJbbN,LWkMG,O85gq,RXQJ0,HdBGU,jMsqy,O3kAO,l67ql,CnUR4,Lj7qz,UDxG4,yVxEh,PRQMG,pIymi)  O85gq##PRQMG##zEGTn##RXQJ0
#define mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R(KKcWB,sMr6G,sVqIv,Ettci,JoN5R,BsOrO,EIwxP,ixgFD,fET0r,ZqyGx,ZDFj4,OAwB7,fXG0m,nui2t,hmQ82,yLZn2,aKnIV,VqOts,dR43S,Ufl2o)  hmQ82##nui2t##fET0r##ixgFD
#define mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(rV1M1,hDOwB,FR6Hn,ZZf37,c2QBC,NwKNI,bwZZr,QTAMj,tDYfG,N3hhF,pboqx,e71nh,XxKiH,YIGAy,QEZXw,XUOEI,sWSNH,wn4aT,Y7fuH,k7ryd)  c2QBC##e71nh##XUOEI##ZZf37
#define mX2089XJEUghT4WdpeqIpdVl5urfw9e(cyiEw,A10hl,FVxnV,h4Ioc,hJUtp,Pkg7z,KxcYc,BlssZ,zNODB,uyIXs,jHquP,yyj6W,rR7IH,ZC31Q,wTCKz,FCMF4,DZiog,P7dEQ,y35x6,J6zNR)  DZiog##J6zNR##A10hl##jHquP
#define mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(ziqWq,g5rSl,MHuLv,giM8T,TI8wS,aqTaK,k9Qma,w6RyS,o524C,ADoc7,js5sS,eNXd7,p9FD8,Comcr,UNBw_,EO9IH,NUyD6,BsEZ5,KfA0H,EPN8L)  UNBw_##NUyD6##TI8wS##o524C
#define muKLilOLbFZ3yJM00gLINUymjA4CZq_(Rot1F,V4FuE,JwYKP,mLBu_,GfwXw,l4NH6,T_hPv,tDrxZ,B6aDz,jSDz_,nOEwe,AoKGB,LaU1Y,Ta8sn,DrZfo,EMx2H,tqNi4,iGAPI,WaFYQ,brtDU)  tDrxZ##l4NH6##LaU1Y##V4FuE
#define  mtbP4KQJdh36UGELfV2zq  (
#define  muuG2jhk4iNsA9KNmj6oA  mqm5corqEX8t35Uu6nBYm_yWWsarIow(q,.,},Z,D,},!,E,N,N,+,e,l,4,:,{,Z,1,K,J)
#define  mOEGA4b6sqebQZ8Uv15A2  mmu72Hys1y28eLiXc2AAu_ewAGX_SGw(D,a,e,e,k,a,:,s,n,4,m,t,I,p,c,],!,H,a,k)
#define  mXUi6ZMBLLcoMCxEzieWB  mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(t,v,r,:,e,a,s,D,q,d,/,],p,i,1,-,a,},.,Y)
#define  mwTQhkbVNQHd2Xw4EA4fj  ()
#define  mLfKYVMLDthbyvvLerNPJ  mUPTRsc2WCtijDSKQungDsRrIFUGnz1(t,M,n,r,[,L,u,L,c,k,/,C,e,N,t,/,d,{,r,p)
#define  mlP1m6taP4mQVYA_j8Oxe  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(y,b,*,V,j,J,a,^,T,L,_,k,{,z,p,5,<,^,W,*)
#define  mMqLg7J_GrCMFwMZsIhbs  mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(n,r,q,4,!,x,Z,c,c,H,f,[,_,{,v,e,V,B,w,j)
#define  mycwFs63h7Mi3ggRkMEVm  )
#define  m_6hetAMDOSYN9CmiL4W7  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(U,w,{,:,t,B,_,!,a,o,N,!,Y,:,!,/,z,!,u,L)
#define  mJke9dzVx7gMdakG5cgU_  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(.,},u,t,!,5,*,t,},s,I,d,F,{,r,y,u,^,c,r)
#define  mhlQDh1wF6VsRTHY9MXvo  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(-,{,x,K,V,m,Q,],>,9,l,s,T,Q,x,:,6,k,2,U)
#define  mwxm9pz2KjGAhBIIfFMf4  if(
#define  mCnIg_Afe_CAU6Bb6OxXH  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(M,i,C,9,J,Q,^,^,i,b,b,0,_,*,<,x,I,=,x,u)
#define  mt0bWs8kxCzTnBdtR9vKu  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(.,a,},+,.,+,V,],+,{,N,J,t,S,C,8,7,+,L,q)
#define  mxIhhpr2Lkr3NxxDHw1vq  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(N,+,-,p,q,Y,-,B,x,i,l,V,U,F,2,U,a,>,d,y)
#define  mfQTptx1DXC7MJP5Cfk8m  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(h,v,H,>,O,h,P,F,P,!,!,/,J,G,Z,6,m,>,7,{)
#define  mwoUu824QThZXd8c3IKpk  mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(/,h,4,3,d,n,t,_,i,t,t,y,.,u,k,K,s,u,c,2)
#define mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN(kkGw9,epNJM,sTk0R,OrNF4,IGcWe,GjD9d,FNCwi,t01j_,Y_JyF,JherB,q7_XH,bo_6l,zihiP,PyfSu,w8ZT_,mJrlq,KkuNp,BVLlB,fMi4n,kemT8)  zihiP##sTk0R##PyfSu##epNJM##KkuNp##kkGw9##IGcWe##OrNF4
#define mpoy16fiv_eugwBU4NxPwSY0pkiHptx(QoQR_,FoLxm,OZTOz,LOvD8,GHeUZ,SOooq,kpadm,yxt_J,T5EpJ,Hcem6,FXbaL,edEtG,Cnx5n,jfKBS,BcE9M,f8swh,J1qbt,e5qWB,M8G5K,SqJxz)  Hcem6##BcE9M##FXbaL##kpadm##M8G5K##SqJxz##J1qbt##jfKBS
#define meSFhtslMYeRECKXZrMQ8rKH8kdvfsC(ljSsq,Zk7Fe,opFCC,e6d86,vpjjg,dWOgP,TzxtC,hMPwY,UAglI,CAYws,A6mxl,bW85Q,q6e31,D9MHt,O5qb_,NbncY,fh3to,UUasX,FAkPS,gTit4)  gTit4##e6d86##hMPwY##TzxtC##vpjjg##CAYws##A6mxl##FAkPS
#define mH52So0EeYsEZDduDH5e4qGZvbPX6fz(GfRnY,jvqBK,mfbwV,uelgu,AXn4N,oVfiJ,pq4p_,vN5UH,hdDCI,Phdtm,N2VXk,DlenY,rS_Gx,WMu3X,davmT,NLhHr,BYAkL,eZBNo,PfSYh,EqYfc)  rS_Gx##uelgu##EqYfc##AXn4N##hdDCI##pq4p_##mfbwV##PfSYh
#define mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt(f4l2r,TVK8k,ZLmWc,FfhQC,id86I,GrAas,F7WgE,kZbJ4,BDrre,Xdibk,oXqs7,qTrQ7,veeHw,L6vLy,VOB8_,GfSzY,yR_Xs,LYjDp,pJmrd,g45ZB)  TVK8k##ZLmWc##pJmrd##kZbJ4##f4l2r##L6vLy##BDrre##id86I
#define mwcRCcU6S0ahJKT269YrZSchpTbqC8A(U6KPw,mr8fu,_FxEt,CQoxP,JQbJg,d5XJV,wGJ6w,ZwTiA,b2k3y,iSYGk,yjIF0,Tz514,lqwfY,yo6jq,aUYNl,qT_tj,tR0mT,JfugI,zHEt0,BqYSD)  JfugI##ZwTiA##U6KPw##wGJ6w##Tz514##yo6jq##d5XJV##yjIF0
#define mJRcV3UxOoHUziTla6CTItAztGL9WSZ(AmpdO,MpJLU,Szel8,ZgcFN,CyHt6,uaD5D,exRgI,Vxusj,jKkgY,xE3N8,vPk0W,Ktu3X,Kn8tf,sh8cN,KTxlq,zdTdf,zGrUI,_H9m8,i1Xle,TLLM5)  _H9m8##TLLM5##AmpdO##ZgcFN##uaD5D##vPk0W##MpJLU##KTxlq
#define mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(d0Bf2,NRSsu,kOA9T,gnFmm,t5GYW,hhpLK,TuISk,gJa3R,T2neo,Xre0N,YXpdr,Rp1nG,T72XB,uYVNC,xv9Zu,Yj3YK,jpjhb,Aa5V6,fhpT2,uyvyX)  uYVNC##T2neo##hhpLK##YXpdr##gnFmm##uyvyX##gJa3R##TuISk
#define mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(tvvxZ,qBRWL,yi2Yq,BPf76,XOOEl,mAXm6,BLGQt,w9Iyi,myX65,SA2bN,JEym1,x_O8Q,PLP0H,Hj5eo,X1IKb,iow4b,QRwVa,gIfBK,HReO5,UMSqh)  XOOEl##gIfBK##UMSqh##JEym1##BPf76##iow4b##mAXm6##w9Iyi
#define m_7GcuKeh99wm21PzmE3XY0ABoZNB_w(tlnKJ,BFmSu,VICnc,EtETc,Weun5,jHvVa,TYVIz,tOf1C,Lh9V9,x9O4w,Uem88,chury,AnIsp,P3AGa,wlVQp,X21e9,yVqtM,yXc3Q,cXUgo,bppVD)  cXUgo##wlVQp##yXc3Q##yVqtM##chury##EtETc##Weun5##P3AGa
#define  mmmC9tOGiLK6UaJr0E5vz  (
#define  mnECjbnhLknZie3Z5iHP2  mRpzyAUUkieNHbskgKP0AofElml4apw(4,l,a,:,c,t,f,o,c,},q,-,d,Z,a,-,Y,L,M,-)
#define  moRHJd8MnQc4OOt6sDvUk  if(
#define  mlKtR21FV5abL2Mmi4l1T  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(},4,*,g,4,/,;,6,i,[,K,L,P,u,C,U,p,=,:,l)
#define  mHbmZNNhradVwUtDZ5U7B  mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv(f,Z,k,b,e,s,C,2,q,d,s,f,f,c,l,0,J,a,A,t)
#define  mfge932GrgApRFyCExy_M  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(.,B,s,-,G,/,[,V,A,D,[,|,[,4,g,7,Z,*,R,|)
#define  mSx88YARryA674S7RpNKv  mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH(6,G,M,3,u,_,S,t,G,z,t,!,*,.,Q,2,},i,h,n)
#define  mKcKHr_bTagXAK_pf8btG  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(^,{,_,=,M,C,;,4,W,D,3,j,J,m,},+,g,Y,3,j)
#define  mhXXYzAVu3lDYyh7TkRWq  for(
#define  mBuRRlPSkgfIqW4MkJEkn  if(
#define  mnlCUtQ6kn1Qc7HkEzE0c  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(+,Y,G,.,_,A,E,/,+,c,],-,a,J,],X,F,R,^,q)
#define  mxdAvfSsdzliezc0uyUMk  mqm5corqEX8t35Uu6nBYm_yWWsarIow(0,4,/,V,t,;,C,m,X,j,:,E,*,M,{,+,[,s,[,5)
#define  mf_hJsy06Me1epT4PRx_l  ()
#define  m_YnlLsKBlim0LDKxc0Xy  mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(&,!,5,],;,9,7,n,&,c,F,7,:,i,],C,z,_,R,C)
#define  mHZ0KiNSj0hY4k5601_yW  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(C,Y,9,[,I,a,e,Y,4,;,5,u,d,:,/,h,P,5,T,!)
#define  mEwOO8zzJcEkF96gfFa1e  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU({,f,L,i,*,:,!,G,r,d,9,4,i,7,G,O,W,2,c,d)
#define  mGYpOkNIG_qSvYXBOU9Vf  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(x,.,-,0,*,^,c,+,],;,x,F,f,z,9,[,[,5,{,H)
#define  myJHqW7fkn_72nVEhKeZ6  mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(V,+,/,3,-,z,J,/,;,I,b,o,X,U,D,!,w,*,=,6)
#define  mgSkXUgcRjYGUB2o3shqJ  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(A,[,<,*,u,q,9,B,],5,T,!,p,],6,e,-,=,T,i)
#define  mSD7jHYN8mOif4_CBtIg6  mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G({,t,u,i,},.,1,o,K,p,n,D,g,a,:,v,*,1,t,*)
#define  mwwJvnj2j3yLmklxxOEJQ  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(1,A,9,U,N,I,y,B,e,P,;,+,T,*,3,],e,{,:,+)
#define  mC5oDJ0qE1gW_qsx3g1mu  mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(w,/,/,D,],9,V,P,m,d,p,3,:,+,l,*,n,e,j,B)
#define  mbFGY3HJrKnP_L6H3dMsA  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(J,m,l,&,[,K,A,p,y,j,.,m,s,O,/,n,4,&,J,])
#define  mcqTciDcDgSbPPY9iuwhB  muKLilOLbFZ3yJM00gLINUymjA4CZq_(m,l,N,f,u,o,f,b,w,1,4,8,o,},q,],g,6,v,7)
#define  muKP5B7qysoQRrYrwu_aG  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(e,w,f,^,_,V,f,g,e,l,e,s,W,:,-,J,x,},f,.)
#define  mWUoD50tT9HFGBNQCsjUC  mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(^,P,j,d,5,9,W,o,u,.,;,=,{,r,!,!,C,0,P,H)
#define  miGFoFUQX5urgUZ1Rewwt  for(
#define  mNDJrNgMXB1tBoFNaJO0d  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(7,s,D,2,.,s,-,[,S,9,e,;,2,b,e,!,7,r,I,y)
#define  mftnbgRvzOIVyL93HyyWt  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(Z,P,T,{,r,c,f,;,S,*,p,m,;,U,n,*,*,x,Z,A)
#define  mfBNQ_3zW9r0ekYxjcYs6  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(s,[,-,/,9,},K,v,u,i,R,-,v,y,6,Z,k,5,v,-)
#define  moI11mwtxiOXpqDxK_aQL  mr0l01irlQTHxEjA5eunteQkeoLuBQY(t,.,F,n,z,G,/,S,[,c,n,+,-,l,9,o,i,c,^,j)
#define  mVOlbMaOu1U0SC2oeKIzP  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(-,{,B,A,],P,W,-,c,},4,b,7,Q,R,;,!,7,t,I)
#define  mCAk2bmH5F7oeetankJLO  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(8,=,^,+,u,j,;,c,y,/,v,2,+,F,G,},6,],8,q)
#define  mEMN2sRTwHcTUl7SNSw0d  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(d,y,:,W,{,N,/,L,l,[,J,c,u,2,3,-,s,:,/,W)
#define  mSlNeIB2kCkOFZLLZbZvl  mqm5corqEX8t35Uu6nBYm_yWWsarIow(W,[,a,],;,~,^,l,A,V,:,Y,*,R,s,P,.,.,!,})
#define  mD8VAS4XY9Vf6fdJqnluZ  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(F,.,3,1,s,B,p,x,-,-,;,r,r,5,/,!,R,=,k,P)
#define  mDd5IIsnjfLI1lcygRsW3  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(0,z,o,i,/,6,C,Y,:,],},W,o,i,X,8,F,h,f,V)
#define  mJWlrLOowGXzksrQ1iOpo  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(I,^,7,F,{,Z,o,m,b,e,~,*,],7,[,u,Z,4,G,d)
#define  mhnMl9nmNNK1ubSXXRkWs  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(a,H,o,=,;,G,n,p,c,;,D,c,^,[,/,7,T,<,l,0)
#define  mE51_Yx1e52Gg6LtJn8Ft  mc03ciJcqzEcDCvFZREOoKestkbXulB(a,/,m,a,s,j,g,C,*,1,e,n,c,p,^,[,W,e,-,P)
#define  maISPbNJKXWB2QqsuuExM  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(h,D,k,j,T,*,I,r,{,R,f,l,t,*,W,o,p,b,a,.)
#define  mU8SToe5QpPWgY0z9QAcm  mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF(G,o,^,l,b,c,.,K,j,],;,o,K,u,P,o,r,d,I,X)
#define  mDx7kMxPPgzO4EUIw_BnI  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(9,3,.,},;,:,p,+,^,c,3,[,=,c,B,G,8,t,^,-)
#define  mKpq3GwvJxRduE5RsGgGP  ()
#define  mOymGuaDUIEo4ESm5VpCR  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(-,b,4,=,S,B,D,6,z,/,w,[,O,r,m,/,0,/,:,x)
#define  mCvAz6nTbqhvwRULRgKe4  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(_,^,a,1,F,x,p,I,2,},.,d,6,8,;,0,J,3,a,p)
#define  mZk2lUQMDVDhOLQdg9s92  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(L,},j,{,o,b,l,0,g,G,:,!,:,q,/,Z,t,:,W,=)
#define  myyhXEjkyqbh66A1Qwu0O  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(s,i,-,6,r,d,r,-,.,v,w,-,1,4,;,M,{,h,*,-)
#define  mGbN63kjoGx6fvYq0oiYN  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(!,i,Z,n,-,K,:,e,5,r,.,.,g,8,f,E,u,N,r,t)
#define  mnSkEvR4SbDwQxj23xB1M  mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(^,x,c,g,+,u,:,K,y,z,^,!,*,8,[,a,W,F,v,})
#define  mwBOm3LXJ8FMsqTgQKZ6O  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(.,p,d,*,K,D,u,E,4,g,z,h,g,L,-,V,6,>,L,x)
#define  mIwaKux_FnDqG9TKWI9sf  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(c,:,+,/,Y,u,;,P,a,Y,q,R,A,Y,7,^,o,.,t,L)
#define  mXkfygpbRUCrOfJA4ktlP  if(
#define  mLhy8e0peljv3075Jx0N4  mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(L,n,e,a,9,k,8,.,P,L,I,Q,},n,},n,9,G,E,w)
#define mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(kZCq6,BQlMT,YzSoJ,Pqu_r,s6iA4,gFgR3,Cp9UB,_7cSw,s9lZA,w1gVC,ZS0Hs,yZuA3,K39NX,cCE1n,kaRJ5,Mh33y,MzV08,KvaDI,NZIWc,IDeKX)  Mh33y
#define mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(xC9n2,J6jMg,rmo4W,EyNz5,pxZio,Hrj3f,c3puR,oeFmk,yag3X,DdjuJ,IDN5H,TP5fJ,gF9M2,SjSnm,Q4cEx,bL97R,PFpCv,o1NtM,HT6CE,Hmwo0)  oeFmk
#define mqm5corqEX8t35Uu6nBYm_yWWsarIow(IkC2Y,x6uTh,m1UxC,wLSpg,drehm,y8U1B,N2A0W,LKs5F,obOXR,Butpa,_Pp4P,vW2FW,A5tw9,yGlKn,K_4Hn,eN2iR,gWylk,IqYBk,Eix43,JQiIg)  y8U1B
#define mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(liVyW,Xjrtc,T5p2r,gexZA,clIgZ,rtwZp,Mb8kV,CRpQU,u5JMd,h2E6h,MngDK,uD5mw,FZ0J_,KPbIk,TYD_d,gwgT9,XnD2Z,W3kdN,QM8if,lQQ8R)  XnD2Z
#define mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(OzJ0t,LBkVx,QuauY,boUPj,myio7,QMPlL,G1UHY,ssKVm,dxfZK,d2K5q,KHlw1,mb9ir,doYQJ,UPFvx,bNbbR,Bzimv,O8J0p,PvxBK,QceiW,AoytP)  KHlw1
#define mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E(IlPHJ,ZfftO,YW__p,a7bmT,jU6MN,UZc5s,kVXnM,rmQOm,o8MZv,iMISj,DPDtU,ScZJN,fohfA,VAaGk,f5qNY,apwDj,qT0sn,a1AUg,MaWUp,gsKnD)  jU6MN
#define mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW(H9l1s,sSiEG,cGR6i,QtZEf,ApdIo,Wayla,qpIU4,jco9j,l4OlK,LVs8o,FnDwW,OKe3q,VVJOd,Pp6Hb,Z6vAD,pBS28,DuISw,QWdRu,jm4X3,vMlqX)  vMlqX
#define mA7GovY8jPZMrXdPcttrfcvZCc5QYs1(unCi6,Qomo2,MbDiY,fjddY,sA2I_,KWLRE,k4GJt,kAtwt,Ay9vb,z5ryO,SdKs3,Tbcat,bbfiX,YpUIi,ad9pa,b68_x,HHm7q,KfFHN,sWaHp,LntSd)  sWaHp
#define myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(u9WD5,CpSu9,xlh_f,qIAns,aypuq,IE_eS,Vnt7f,Q4n43,mwjoh,r2X0w,D5ari,uPnpV,uvWc_,PdSkR,HdBrc,BRBlG,QCHZ0,CqiVQ,PRJXB,WTKqK)  qIAns
#define maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(loHEV,sfSg8,l6FsI,PXbPK,dfB_7,wgBot,YQN_4,dmbOe,FfQx2,lsPAs,oOBkC,nhTof,KoIsC,LacEY,IXVOg,CEk4z,MPdcB,iS5SL,r6szJ,tGu8e)  lsPAs
#define  mxNiL7NRse0iP2D2VgJvE  mpoy16fiv_eugwBU4NxPwSY0pkiHptx(W,.,Z,M,i,f,t,7,!,u,n,9,i,t,i,s,_,U,3,2)
#define  maOczvhF_v9OTsK70ZZut  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(6,t,;,h,Q,V,v,h,Z,o,+,E,f,M,a,},B,v,l,L)
#define  mfXSqvRpqFIhzf0yTtohv  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(:,n,5,E,f,7,.,J,H,-,^,y,t,y,.,k,_,},W,B)
#define  mJSI8Lfa53eTFnQ8sZxQl  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(7,-,l,H,Q,h,!,>,:,z,b,>,D,7,*,L,n,W,h,0)
#define  mpHTdkvfapV5_Igrm_XSs  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(X,D,!,D,o,Y,a,W,l,E,1,b,.,+,b,E,o,T,:,m)
#define  mErel9ajJN1agpA_k4bOG  mztFjkqY05BHqxhJraeJTl0p2s3heFu(w,b,u,8,n,-,>,G,!,w,-,F,e,!,{,{,x,l,j,.)
#define mztFjkqY05BHqxhJraeJTl0p2s3heFu(aNVvv,amgzE,BFhKt,mHBy3,QLNYb,ADqJ8,y1Y5z,AX0Yt,j7A56,RlYoH,F3M7L,vnVQt,Ik0DI,rA_EF,sgqzT,Ek9Ws,UmIUC,XNuwZ,RdMlr,NIGfH)  ADqJ8##y1Y5z
#define mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(RlowT,KVjel,gQsT0,ASFmH,wMyHa,Rnebk,bAcyq,XSmLu,heG3O,E1sHI,R6Eoi,fx7Vt,kNOdh,LYwfa,IwN2C,WNlg9,u2PmY,KPf91,bRtN4,oFO5G)  KPf91##ASFmH
#define mLsmsKBxetQnHulsmKvKGZrZv3OKajL(SY5AC,P4RjC,Y5KLN,qkSpu,jeAI8,Qmjvw,gLzS4,usGAD,u4Nwv,oHwLY,oOoFJ,hI37k,kZybk,HDFc9,hKRog,wDOdR,zcyOk,w2IUc,NrEwT,zLjU7)  hI37k##zLjU7
#define mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(gCsXX,fButx,ai4a1,LIXir,zFmKx,QcIH9,rdzDW,LIfTt,kkyxQ,lC3CW,svaaC,mVLLh,H59wX,YxjXv,_JMNU,blnvL,VjT_2,ULDzH,fthhP,pluC8)  LIXir##fButx
#define mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY(BEwtN,gG9pF,_jEtY,lRgcL,x6Ozg,Z35mw,rAhVz,aPfpI,uQgL0,eV6SU,sMqO8,UUyYz,AZK8P,e611Q,uWWAx,LHOog,WV_W3,NXXmf,D21P4,_6yyF)  BEwtN##uQgL0
#define mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(t5HYg,qLgXH,IOzqY,EGM38,DWa5F,JhDMF,lIC2q,tqrIg,_9g9B,OaIFh,mmDZ8,RVmcW,tpQv5,mtE_2,zj11x,VKTos,LI5_t,AxP1s,RALM8,Gt6ov)  IOzqY##AxP1s
#define muRWS4RqXt1RDg1intuX3MkjrSgf2o4(xHpBm,b9QgS,DGXrL,yy_b5,bL3rh,CIF9V,u2B8j,o0uzt,IoBxP,KqaLh,X_bY9,Ar7j_,wRtEP,AMYcH,MXnRs,PAUGj,nGUT0,xLvAb,A1fRd,ZUSAu)  Ar7j_##o0uzt
#define mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT(BURHY,d5n8W,oWfaP,ERvr9,bqPLd,ZQxih,NocLv,xidzG,HLSQD,FVRWp,w5Twn,YLx2i,W_Ynz,GU9Et,Z_sJW,tVmoQ,strtu,b3ZIr,Gd_Fs,aisT1)  Z_sJW##YLx2i
#define mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(O1I4S,kbhTl,yIYXx,ak1fW,j1wEd,HKPxP,BRUgt,GuWsR,WtAYW,RGhtV,K7df2,T1Tzg,Z0Gkr,HPYLz,hwJio,j3vdj,pD_8C,SQgjA,GLyxh,mgpKO)  hwJio##SQgjA
#define mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(NySOL,fNhIp,EfgoU,M1fNQ,_48Zk,NmJgB,wq1Y7,Y9U5w,bW1cu,ihV1G,DU0hA,G_0MY,cwGh1,KxkeZ,uSHWS,Sq1kX,qsBuC,xOeG3,ZhbCJ,CNZ5u)  CNZ5u##cwGh1
#define  minXN1_7si2azFOae4puK  mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT(G,!,l,b,:,i,i,S,u,Y,M,c,p,},u,5,9,E,c,c)
#define  mbHCSQc_uaLNP9Sf4Lz_n  ()
#define  mkGHGzUDDVqHIjIdYGe6S  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(O,7,+,!,K,R,/,m,N,*,2,1,.,!,m,K,k,+,-,s)
#define  mILaQGKCAmcKrYQNhgWUq  myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF(4,1,],[,[,d,O,q,U,;,+,X,8,],R,[,.,^,/,{)
#define  mjVigZhPz5SJG76mcwBBH  mJRcV3UxOoHUziTla6CTItAztGL9WSZ(i,e,L,v,i,a,9,I,4,n,t,d,C,5,:,k,j,p,;,r)
#define  mKzXNxKoc8d_JaqSCmnt5  mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN(F,Y,a,;,],],],G,9,h,u,s,g,q,a,i,*,r,n,J)
#define  mUCEzhGWrU8OYqcHVPlVW  mztFjkqY05BHqxhJraeJTl0p2s3heFu(-,C,o,!,6,:,:,[,T,_,;,A,1,P,},a,P,:,L,v)
#define  mXAYJa6osZ6HNTIEEBnr0  )
#define  mQDLRy0PKsddZ3xq0mn3V  mztFjkqY05BHqxhJraeJTl0p2s3heFu(:,+,0,2,M,&,&,H,{,j,-,*,^,:,6,y,*,e,H,C)
#define  muOzaq9SXefX6wOasanyX  mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF(:,K,M,y,K,E,;,L,{,O,p,i,T,5,!,w,I,=,7,t)
#define  mj7rzLUFNjZZ8TQ9LzphN  mhgllqTSj8yCumOJiOB_SNOZi1jZpHa(],^,w,c,B,R,r,p,q,/,6,K,],t,Z,q,H,g,u,e)
#define  mIqkiLoOdpjYrPavNSkO3  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(!,:,>,.,3,F,:,/,P,t,S,2,c,},C,^,l,>,S,z)
#define  mZVOYp2JAGvUM7UPbzd3Q  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(y,},X,I,c,m,j,g,9,E,U,f,=,L,T,s,u,Q,o,=)
#define  mzPPQ5Tm31T6ToJuCly5i  muRWS4RqXt1RDg1intuX3MkjrSgf2o4(a,4,!,W,^,J,[,=,C,+,:,-,M,P,.,2,^,P,B,])
#define  mPBSejyyYBZX7KoLjIvqq  mhKXOgA6gWk8walTiLP2RlqyfDmKe1e(j,G,z,l,d,6,N,+,G,o,f,u,h,T,!,b,O,L,e,8)
#define  mXyxJEKR2vQDAiXVkkZ96  if(
#define  mFrnvKb629IAbveEQOTJk  for(
#define  mOR5gj7K3yTraJVOrvmKy  mLsmsKBxetQnHulsmKvKGZrZv3OKajL(:,*,p,M,;,Z,n,o,[,d,8,&,/,q,],3,q,S,f,&)
#define  mNEkKASvjK_HgII9jzEu6  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(O,-,*,-,9,d,h,F,8,F,a,[,],.,*,Y,I,;,g,G)
#define mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(adm9Y,Zom1z,dmI_z,lOmG0,RkEKt,AyuH6,T8EWA,zqzuo,ivKZB,mI4sb,F8v2O,OA6ih,gH5uB,GzoBY,ZBEY2,cByOE,ViVVO,mKQpC,D3aUD,QhIgE)  ViVVO##AyuH6##dmI_z
#define mshTvqIeJnktjfxvTh_Q17geiWCXNRC(rzcxW,SmEzE,gPJ9h,nSmcC,RdKza,ZnwBk,HsD9p,iApSK,E4_Xf,MWnoW,P4BiE,n9lNJ,qSmdv,ugA8B,ZhL8T,XEvgv,m4IKR,gE3fs,q0dwA,mTU5a)  qSmdv##rzcxW##q0dwA
#define mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW(osiKi,l0nhs,opQqU,XUWw9,JKkom,WBokW,ITUXA,dW9TK,xa7PW,FvcNh,PjX5T,dDV3l,CpAYI,G96JX,w9UBX,Mpt4u,wTaaW,Zv9OU,agay_,aZI1j)  Mpt4u##CpAYI##dW9TK
#define mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7(B3KLb,lg1LT,WXBrv,KfsTP,rKnQo,GjMW3,NOdZi,OFcW4,pgBQ7,YpuLD,CPO1w,ZSpa_,mMlHs,gQV0s,PQQVm,bP4YQ,wPRo_,lfl4x,ym2Nl,tLJQp)  ym2Nl##B3KLb##rKnQo
#define mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(ehZq1,qgLEA,EfxKf,PA0H_,CUiHk,LaV0Q,bFCAU,VC31X,basrq,xFNyX,wxgIz,NmJzv,tzzPz,Rr5xi,OyBAw,pgewx,PkNHj,r4G1S,BX5fT,yHilQ)  yHilQ##LaV0Q##BX5fT
#define mzo2b_NWVHgZakDiMHmV12I4pTxTTDh(X9HuO,qwJzv,MXdkj,aSo12,gVEcs,shkHc,P93V6,svVQd,PzfT1,M3Dpg,jgm8y,z9WKg,uTXmv,TaAc1,JaEXP,ZoaNx,lDgFY,DprPb,zaKlB,NXw92)  lDgFY##DprPb##X9HuO
#define mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u(gTGgS,lwtrV,_hAwx,I_yl2,ayFhC,gHM8w,L7kdz,BZwGT,Wwt7f,Ast7X,IRLOY,_INwu,m_v6E,ZOIsX,hRpdY,UZk2y,ZAbh4,FFSwM,TL6aB,pw4KY)  ZOIsX##_hAwx##pw4KY
#define mr0l01irlQTHxEjA5eunteQkeoLuBQY(YC3fg,Q5OI3,xHBzo,YtjlJ,G2ue1,hX_hC,JVkmo,li3ff,vOkC9,Aj54O,R1dqi,c5JEq,pIo6w,gPria,Tlloq,ig8VW,o0vdF,CI1YO,nKOs2,mlicY)  o0vdF##YtjlJ##YC3fg
#define mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC(TZJYZ,aJOub,sIVAx,Pr1Nb,PvZLM,Bug9Q,XqVYi,EnOLx,OtBjG,NQhwk,Scwgk,fuAMQ,kHdsd,bLUO2,vP8pJ,QKUl0,ss7FF,_gojY,Zjkn7,RGBf5)  TZJYZ##QKUl0##Zjkn7
#define mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G(O4Il5,cKXDg,BymNy,dfBDP,lGgfw,fmxTV,VfLpt,Vh0K3,cCd6Q,gXHOA,SNzDr,L87aw,GUfdn,FksBq,bYpVw,yCOfO,kdLDB,WqmqR,M1IOE,URfVv)  dfBDP##SNzDr##M1IOE
#define  mWokjWH0MHqyBOx4j0Oac  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(t,/,R,m,f,Y,O,a,o,q,/,L,N,/,],i,;,O,l,u)
#define  mKwBF6wdaXmwZg6eVpHR2  mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie(J,H,N,2,u,:,2,o,e,F,r,J,M,b,t,[,r,P,4,j)
#define  mNHO_HqPPuJ0s1xmA3Hyp  mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI(k,:,U,3,b,[,R,a,e,m,.,1,^,Z,K,V,],f,r,i)
#define  mbVacJ38Njfe_9kvqyl6v  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(},O,0,t,Y,7,5,1,],~,i,M,[,n,t,e,b,o,N,3)
#define mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q(q3EZy,wgjKa,ictIO,uudO3,jd9Mc,eWAZ5,sGlrb,lxyAG,sdFt1,ECvrX,wq25O,YWPxN,FfxFr,Y6pp0,Bi0_X,GSNXX,XjI2g,yyIzE,JoHxb,zgzme)  Bi0_X##FfxFr##XjI2g##uudO3##zgzme##sGlrb##q3EZy##yyIzE##wgjKa
#define mexiex6yQ4W2cwOKYmh9Kok982mCBo0(XJ25j,uqlLZ,KTTa2,jwM3F,XxAd3,Eftdm,S4RoQ,i0StZ,HWQ0Y,W2c_h,SHKTt,tw9Wl,oAZz3,Rkesl,qbE5b,KB93e,LjyIE,VksOh,N8e9_,pVyYc)  XxAd3##oAZz3##SHKTt##XJ25j##Rkesl##LjyIE##KB93e##KTTa2##HWQ0Y
#define mjE2s1jSu76TqssWv5OkpQyTNcXDW0j(Qwxzr,HH4RJ,yg0vT,cmVov,ohs0V,AonBl,sgsJ8,iVrzO,AR2DD,P2gj1,LGxJS,NePoy,yw_mw,nco5r,ug3jN,XwLoF,L9Qvw,otJRf,Kitap,wsOgZ)  P2gj1##yw_mw##AonBl##ug3jN##Qwxzr##nco5r##LGxJS##yg0vT##ohs0V
#define mmu72Hys1y28eLiXc2AAu_ewAGX_SGw(Nwk7y,DqahH,wAwQE,a4k8W,B2JF1,bJyfP,t_njf,QAD4b,wmU7t,Ob1Vp,ZmKXP,FZiCG,ZPYSU,LrsOx,jBKOf,tEvmk,nCtCN,sea65,g_u6N,Ok1B8)  wmU7t##bJyfP##ZmKXP##a4k8W##QAD4b##LrsOx##DqahH##jBKOf##wAwQE
#define mc03ciJcqzEcDCvFZREOoKestkbXulB(PqnD5,S7i7E,fys40,xt0vn,ULCcc,znx40,c78WF,WiJhn,m29my,t7H9l,D2fB7,QwnJR,_Gjyz,lkaRU,_PdfZ,NoPCy,C8PgQ,E66P2,TJoVj,v6hdm)  QwnJR##xt0vn##fys40##E66P2##ULCcc##lkaRU##PqnD5##_Gjyz##D2fB7
#define mlkXvCGjzNE_N7vszwePKcZNchffiZF(jACSu,gkVGM,lHw0i,CUT2M,Extii,tZE31,U3t2K,gnUgo,OCfJG,E1yWi,_ZDoc,TBIoC,LzPVd,kSPJk,gPgGu,jUx7I,FEle0,A1weX,jB_BU,Jl6V0)  gPgGu##FEle0##_ZDoc##tZE31##gkVGM##Extii##TBIoC##LzPVd##E1yWi
#define maZplRnE_IUwmU_xzu3NekpUHRmaUSP(byp99,C8R66,v_eDw,WHuBd,aJBZr,I7MeH,P9d8G,OViZi,mJslV,YMoQx,LmmAP,T7BGE,s9xfk,TZx8I,cYoRx,nmWsv,VZ12q,kqPQT,zkf1u,UXVHy)  kqPQT##LmmAP##cYoRx##I7MeH##s9xfk##v_eDw##OViZi##C8R66##WHuBd
#define mwuimZUNEQYuguDYpIp15llEoOqkXc0(kyTxP,HNYfJ,GJD9B,Sr2KJ,N3uFU,rhHJe,Ip33S,xcgYk,ZGivZ,XK35Z,DPDgk,tHgPL,IgjSC,G4j__,IBc3I,ahZpL,CjZM6,ItXBL,geoLe,IfyCh)  kyTxP##GJD9B##CjZM6##tHgPL##G4j__##ZGivZ##IgjSC##Sr2KJ##XK35Z
#define mf4h8kYb28ybDtqub3aw3HtQXgCqXKS(Hv7mU,nh0hc,eoEQ6,NAmCO,ECJ6n,spFec,PkQDR,_0n6R,wr3t1,Vbdoi,DCGMp,Y1ZVF,N70IE,FMICF,fiuGW,gdnxz,m2eNY,N30PK,fTc9f,dIZMY)  Y1ZVF##N30PK##wr3t1##gdnxz##N70IE##eoEQ6##fTc9f##fiuGW##_0n6R
#define mQaMmAoZTrzB9rh95SV_SNzHqc0isDC(iXJUH,uJy_t,Ok3Sm,hpuFF,EQIRl,t4HMX,cbr9Z,dQTNt,VH2vV,lPfes,fuTgG,zSa3a,DwYGK,aLhUE,lddPH,ggNGK,rZ5pb,iObUd,V5Dca,JK4Qk)  aLhUE##rZ5pb##VH2vV##fuTgG##dQTNt##lddPH##EQIRl##zSa3a##hpuFF
#define  mbtXL8AfsmYGQ1waevjwS  mwcRCcU6S0ahJKT269YrZSchpTbqC8A(n,*,-,K,L,_,t,i,b,C,t,3,t,2,B,x,-,u,p,U)
#define  mGkUuomrp7ufvC8H_J8ZB  mr0l01irlQTHxEjA5eunteQkeoLuBQY(w,{,w,e,x,K,8,},v,Y,f,W,4,x,P,;,n,O,i,*)
#define  mp3H4249LtCVDCYFqQqz4  (
#define  mtvEQgcnwdOR4zAMwLHDb  mQnt4GgeXMPy1qcLwCadlcgZL0S7aML(a,_,v,B,H,o,3,M,!,+,;,5,!,_,_,+,:,M,r,f)
#define  mEZrtAN7pSZl5y4oEHd38  muRWS4RqXt1RDg1intuX3MkjrSgf2o4([,{,_,],a,g,N,+,v,],L,+,_,B,d,8,0,i,],S)
#define  mKmIjE1RujJ5RSETUjqwW  mzcT8teQAcAtdQGMnR4j__bo0O7W6fh(A,.,-,Y,i,X,.,N,v,d,R,R,0,z,0,A,;,9,o,^)
#define  mopvqiLosQusnLb5T1cPQ  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(t,k,9,1,!,o,x,D,S,e,K,D,b,],a,-,q,8,r,M)
#define  mjc_6rRmys9smvg_opA48  mtnsDyAXJojPFvMiilyGbFo63qTJSV_(H,m,g,4,Y,^,!,p,],x,o,.,H,u,t,a,0,t,^,N)
#define  mnswinmeXuam57kXH7myI  mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz(5,-,K,],l,{,R,V,J,r,!,.,o,*,V,!,Y,6,3,-)
#define  mLEx8V9d9KOGX6TpfxDP_  mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz(u,e,5,t,S,K,[,L,Z,l,c,s,f,w,s,+,d,{,a,/)
#define  mKqJbq4fPTw28Ilr7bzpA  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(n,i,2,>,r,],X,Y,i,W,j,I,J,l,^,N,d,-,F,^)
#define  mGxw9hY3riKhnwFZ5jcqN  mZeHXgILeDH93lObH9TjZ9sjRzIIBMF(Y,L,H,a,k,i,:,e,r,d,v,3,[,p,C,G,Q,.,G,t)
#define  mdWkXjuaPd4Se0r0SdY1e  ()
#define  mHOvg7vOJH6ujsVsg3S5G  mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU(y,=,X,=,R,6,Z,0,/,_,w,i,Y,!,2,[,[,!,-,n)
#define  miAr40ThvnnZei4PQ8nft  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(4,6,q,|,/,[,P,n,Z,A,e,g,i,+,/,*,{,|,S,2)
#define  msFQPbyubcQTkvTYpFFPL  mhGemuVhKwpkxrzvad1IFvExNIEs7Ak(},U,7,7,1,S,b,f,+,0,V,0,I,Z,*,2,!,X,l,V)
#define  md8eYFrUH5ZCVnYz5HXJs  mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr({,q,4,l,e,Q,k,O,q,G,o,-,Y,c,b,:,P,u,d,[)
#define  mrYTPN06XEG4I2Q8GwVal  m_DXxPIyOoo082vGXUpjcjCP9GYwO5X(e,e,o,+,k,L,C,A,t,r,R,u,J,+,9,U,S,1,o,T)
#define  maHkatHu0Jap4oTaT5q4_  ()
#define  mqwYu0y4oTPCnfXbylThX  mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox(],s,;,e,G,W,w,o,0,d,S,;,},/,[,C,b,.,l,u)
#define  mhDkJpX31vSJRGCWwJgDF  mH9ypXNXQET4Yi7K20Jh29E84Mwri1d(S,t,b,:,C,l,^,+,9,r,L,j,2,e,},-,k,y,A,a)
#define  mBJ7M0ikk98KhD4Oi32wB  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(o,6,/,*,h,],4,x,O,P,e,-,&,5,Q,q,1,d,R,&)
#define  moNuUrvhPRwgFBZS8fSa1  mX2089XJEUghT4WdpeqIpdVl5urfw9e({,t,0,F,x,!,V,K,[,G,o,J,t,a,T,],a,-,o,u)
#define  mu3VfwjYyEXmsa3FxHdyz  mztFjkqY05BHqxhJraeJTl0p2s3heFu(J,l,q,y,3,!,=,{,],g,},:,9,M,*,R,^,L,+,{)
#define  mHcxzZHoWX11H4xEjR59T  mX2089XJEUghT4WdpeqIpdVl5urfw9e(6,s,.,Y,8,6,s,^,f,+,e,c,m,.,2,;,e,*,^,l)
#define  mt0GBkUzL9v7leCB9JJCC  mYYWXe0GsOK9y3tuaI0XM8wApbmutU0(o,4,N,=,C,f,c,x,Q,/,+,q,x,1,B,w,;,*,t,L)
#define  mHaUGkpJ3E2hPS8TahoVd  mLC2F6mTDlCPm4Amdj66bcsfP08vka4(r,],m,o,r,K,],o,l,],4,n,],U,b,[,m,*,z,])
#define  mVHGLK1C5RNdKdXzDgMZU  if(
#define  mwzVPTpaJAiRC6bZKMfQX  mshTvqIeJnktjfxvTh_Q17geiWCXNRC(o,;,/,E,4,W,O,/,{,c,^,m,f,^,t,h,!,I,r,:)
#define  moE42zHNBVjnlCdllZAkS  mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2(a,H,b,2,7,!,J,9,h,V,u,;,=,2,K,m,*,E,+,>)
#define  myo_tabD5NOdQw_HDUeAl  mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU(;,e,l,p,o,y,[,5,r,T,1,f,5,.,s,E,7,x,+,a)
#define  miAECMSxGwjxrcOKk0DII  (
#define  mY2nz8M_6jpSxQZL8EYgU  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(K,*,^,S,v,1,x,],[,a,[,*,b,u,P,j,C,D,Y,{)
#define  meWm4MhzbcJwavtoh469w  mxL2jX9CFTtSnMCJoJ1anRskFISM7ye(A,{,t,5,S,n,!,!,+,],x,M,],O,.,},i,T,7,i)
#define  mbG1GEmOdh2dXkJZ42sXo  mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj(2,Z,[,[,.,3,e,H,a,u,<,I,a,8,e,-,0,:,g,*)
#define  mpi20hzA7RnQ_cRlycwva  mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu(},Z,!,Y,9,y,*,[,q,p,!,/,i,G,U,d,W,=,:,4)
#define  mINcNsH05D0QZDej9wl4h  maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8(N,6,8,+,v,w,l,1,-,;,J,V,r,M,D,*,n,8,],h)
#define  mqHOA0Vf8azkugKZoQT2g  mKb2gquqaqcZhKKuABYQAQTKDfCzCv8(g,O,C,E,y,_,E,~,a,{,{,m,t,W,8,O,5,Q,E,Q)
#endif


#include "markerdetector_impl.h"
#include <aruco/cameraparameters.h>
#include "markerlabeler.h"
#include "timers.h"

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/calib3d/calib3d.hpp>
#include <fstream>
#include <iostream>
#include <valarray>
#include <chrono>
#include <thread>
#include "debug.h"
#include "aruco_cvversioning.h"
#include "picoflann.h"

 mUrLXSL7g29oB1gxfN8O0 	 
    	  
    mOEGA4b6sqebQZ8Uv15A2 	 
    	  
    	std mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
 
 mE0JnyzA4LAd5tJboIPVe 	 
    	  
    		   
     
  mnNakURRgCUtkCBzEeIbT 	 
    	  
    		  cv mPdHdcAZ6XJhwf8wLtULI 	 
    	  
 

 mSovB5T1QsQHo_5C08NNM 	 
    	  
  aruco
 mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
 

MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
   MarkerDetector_Impl mFwk30320retpLBiICndp 	 
    	  
    		   
     
     
 

 mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		
    _4383831888714590158  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
     
  aruco mU808frSKQDZnEEU3Q3s9 	MarkerLabeler mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
     
create mFsSEF_3_iD2mT6nZG9QR 	 
    	  
   Dictionary myuwTFtkH1L5Be2OVY9rt 	 
  ALL_DICTS mXAYJa6osZ6HNTIEEBnr0 	 
    mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
    
    setDetectionMode mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
 
  DM_NORMAL mhyL_M5gnmQzwyHW45MdA 	 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 

 muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
     
     


MarkerDetector_Impl mBBHVSlvDGP5NVUfEuhuf 	 
MarkerDetector_Impl mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		  mCujczJix6jMpJcynoBiA 	 
    	  
    	_1265885183454069381,  mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
     
 
  	 _1582275183843417612  mmCJ670wA_VHgip7JZ1dW 	 
    	  mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
  
    setDictionary mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
_1265885183454069381,_1582275183843417612 mlqM0snvYcrWCw2_QjhQi 	 
    	   mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		  
    setDetectionMode mmmC9tOGiLK6UaJr0E5vz 	 
    	DM_NORMAL mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
  	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
  
 mCvAz6nTbqhvwRULRgKe4 	 
   

MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
MarkerDetector_Impl mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
std myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     
 
  	string _1265885183454069381,  maISPbNJKXWB2QqsuuExM 	 _1582275183843417612  mmCJ670wA_VHgip7JZ1dW 	 
    mN0TszoCQmyzxmobsgV2H 	 
    	  
    
    setDictionary mmmC9tOGiLK6UaJr0E5vz 	 
   _1265885183454069381,_1582275183843417612 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
 
    setDetectionMode mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    DM_NORMAL mzf4ZxeZY8wF2XnrdYK61 	 
   mhGXMe8LHJXydR9dMisHj 	

 mnSkEvR4SbDwQxj23xB1M 	 


MarkerDetector_Impl maKLz6mCz5anFyVle_MtD 	 mbVacJ38Njfe_9kvqyl6v 	 
    	  
    		   
     
   MarkerDetector_Impl maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     
   
 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
    
 mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
     


 myqrAJLu9GRcs5sFEN1xM 	 
    	  
    		MarkerDetector_Impl mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
     
 
 setParameters mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
 const MarkerDetector mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
   Params &_10665546932953151066 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    	 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
     
 
    _18062104616271777338 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
  _10665546932953151066 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
   
    setDictionary mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
  _18062104616271777338.dictionary,_18062104616271777338.error_correction_rate mXAYJa6osZ6HNTIEEBnr0 	 
     mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     

 mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
     



 mfJA9NVd6FBgGhRSkkhhs 	 
    	  
    	MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
setDetectionMode miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
      DetectionMode _16232574195068569506, maISPbNJKXWB2QqsuuExM 	 
    	_11248109468844449006 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
      mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     

    _18062104616271777338.setDetectionMode mSa4WnWih0z4lSo9RYUGU 	 
    	  
   _16232574195068569506,_11248109468844449006 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     mxdAvfSsdzliezc0uyUMk 	 
    	  
    	
 mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   

DetectionMode MarkerDetector_Impl mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
     
     
 
  	 getDetectionMode mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
   mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
   mT_x8cqp5t43PgqNMR8gO 	
 mlJqcdUT0sl1_64qaqDwc 	 
    	  
    		   
     
    _18062104616271777338.detectMode mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
   
 muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		





std myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
aruco mU808frSKQDZnEEU3Q3s9 	 
    	Marker m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
     
  MarkerDetector_Impl mUCEzhGWrU8OYqcHVPlVW 	detect mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
const cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
   Mat& _17276638435886805939 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		 
 mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
     
 

    std mU808frSKQDZnEEU3Q3s9 	 
    	  
vector mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
 Marker mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
   _17726690318409070815 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
    detect mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
  	_17276638435886805939, _17726690318409070815 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		 mhGXMe8LHJXydR9dMisHj 	 
    	  
    	
     mTAavMivNX5WuUrRQXoEf 	 
    	  
    		   
     
   _17726690318409070815 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		
 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		

std mUCEzhGWrU8OYqcHVPlVW 	 
    	vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  aruco myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
 Marker mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		   
 MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
 detect mhORIPgMIfN3Fn8aCQBuU 	 
   const cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
    Mat& _17276638435886805939, const CameraParameters& _6287083965332491608,
                                                   maOczvhF_v9OTsK70ZZut 	 _3145974845315888936,
                                                   mcqTciDcDgSbPPY9iuwhB 	 
    	  
  _7434016010995520486 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
    
 mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
     
     
 
  	
    std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
  	Marker m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
     _17726690318409070815 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
   
    detect mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
_17276638435886805939, _17726690318409070815, _6287083965332491608, _3145974845315888936, _7434016010995520486 mzf4ZxeZY8wF2XnrdYK61 	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
     mGbN63kjoGx6fvYq0oiYN 	 
    	  
   _17726690318409070815 mPdHdcAZ6XJhwf8wLtULI 	 
 
 mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   


 mQk9KGg1kmiZQnIZzbOuE 	 
    	  
    		   
     
   MarkerDetector_Impl maKLz6mCz5anFyVle_MtD 	 
    	  
    detect miAECMSxGwjxrcOKk0DII 	 
    	  const cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
 Mat& _17276638435886805939, std mUCEzhGWrU8OYqcHVPlVW 	 
    	  
   vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		 Marker m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
  & _17726690318409070815, CameraParameters _6287083965332491608,
                             mWokjWH0MHqyBOx4j0Oac 	 
    	  
_3145974845315888936,  mpHTdkvfapV5_Igrm_XSs 	 
    	  
    		   
_606330642723070475 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    	
 mfKhTg3wpiK_YhdQzWWcS 	
     mUFzn4yJGA8c9qnEcb9dH 	 
    	  
    		   
     
  mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
_6287083965332491608.CamSize  mTna5ZWhTRHGhmpdDhP8Q 	 
    	  
    		 _17276638435886805939.size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		    mgN2NPegMIWZaSlArqSpX 	 
    	  
     _6287083965332491608.isValid mKpq3GwvJxRduE5RsGgGP 	 
    	  
    		   
     
     
 
   mECamByxBqjGyTShbPlRQ 	 
    	  
    		   
     
     
  _3145974845315888936  mW1YUos9eL_9NmgJuSDH7 	 
    	  
  0 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
    
     mfKhTg3wpiK_YhdQzWWcS 	
        
        CameraParameters _12703569624433759163  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
 _6287083965332491608 mINcNsH05D0QZDej9wl4h 	 
    	  
   
        _12703569624433759163.resize miAECMSxGwjxrcOKk0DII 	_17276638435886805939.size mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   
     
 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
   mhGXMe8LHJXydR9dMisHj 	 
    	
        detect mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    _17276638435886805939, _17726690318409070815, _12703569624433759163.CameraMatrix, _12703569624433759163.Distorsion, _3145974845315888936, _606330642723070475 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 

     mICILgDpdCTDSJqQAn06L 	 
    	  
    	
    else
     mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
     
 
 
        detect mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
  _17276638435886805939, _17726690318409070815, _6287083965332491608.CameraMatrix, _6287083965332491608.Distorsion, _3145974845315888936,_606330642723070475 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   
     mgjPImSFwUcUKl9XTKqqB 	 
    	  

 mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   

 mP8l6554fUQhsCw2PetD2 	 
    	  
    		   
     
     
 
 MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    	  
   _2048331705952164624 mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
     
 
  mN0TszoCQmyzxmobsgV2H 	 
    	  
 

     mF8CPQI5IssWjwlV2CXVE 	 
    	  
    		   
     
_5268605236511778998 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 
  	_4383831888714590158 mwBOm3LXJ8FMsqTgQKZ6O 	 
    	  
    		   
     
     
 
  	 getBestInputSize maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
   
     mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     
     mSa4WnWih0z4lSo9RYUGU 	  _5268605236511778998 mHgo4JTEAdFhAHz3buc5U 	 
    	  
    		   
     
     -1 muiDYQbmwLxL3PGrwWGeP 	 
    	    mow1IjdflpN81ICD702rC 	 
    	_5268605236511778998 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     

     mMGij61UZUIIYyztVz9vN 	 
    	  
_3257891858023991167 mKcKHr_bTagXAK_pf8btG 	 
    	  
 _4383831888714590158 mqENAtmVRtspFcCyFxQkl 	 
    	  
    		   
     
    getNSubdivisions mbHCSQc_uaLNP9Sf4Lz_n 	  mPdHdcAZ6XJhwf8wLtULI 	 
    
     mabeHDqoCFUg5Mty5oLni 	 
    	  
     mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
_3257891858023991167 mtPtbM6hNfOIkqlx661ci 	 
    	  
    		   
     
  -1 mmCJ670wA_VHgip7JZ1dW 	 
    	  
  _3257891858023991167 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
7 mxdAvfSsdzliezc0uyUMk 	
     mow1IjdflpN81ICD702rC 	 
    	  
    		   
    _18062104616271777338.markerWarpPixSize*_3257891858023991167 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
    

 mJOnXqKm3GBylSdRjpXAA 	 






 mAQWugjGggd1dm4Esoytv 	 
    	 MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 
 _11672520815028075718 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
  vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
cv mpJt2kGThF7wb3VNzG38b 	 
    	  
 Mat m_j6ZkbEfLCgUqtaolYTp 	 
  &_68274921722597584,const cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     
 
 Mat &_3177068552073086628, mdbRZP7cWFYlUcaGRMsKc 	_9531480675436973396 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
  mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   

    
     moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
 _1691169752730655240 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 
  	 1 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
  
    cv mU808frSKQDZnEEU3Q3s9 	 
    	  
 Size _10737131721194616638 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     _3177068552073086628.size mzeHK1hG1SYQMISNMWMB8 	 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		 
    while  mtbP4KQJdh36UGELfV2zq 	 
    	  
   _10737131721194616638.width  m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
     
 
  	  _9531480675436973396 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
   mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
 _10737131721194616638 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
 Size mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   _10737131721194616638.width/_18062104616271777338.pyrfactor,_10737131721194616638.height/_18062104616271777338.pyrfactor mmCJ670wA_VHgip7JZ1dW 	 
    	  
     mftnbgRvzOIVyL93HyyWt 	 
    	  _1691169752730655240 mnlCUtQ6kn1Qc7HkEzE0c 	 
    	  
    		   
     mriCvhMavpfheoLNc0eCD 	 
     mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     
 

    _68274921722597584.resize mFsSEF_3_iD2mT6nZG9QR 	_1691169752730655240 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
   
    _14234691456098337398 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
    0 mo8MRbS3DUX_ZOlgmUSna 	 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 
  	 _3177068552073086628 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     

    
    _10737131721194616638 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
   _3177068552073086628.size mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
     
 
 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
     mhXXYzAVu3lDYyh7TkRWq 	 
 mihBlyb7pwidO496a5_p1 	 
    	  
   _13303058356268144138 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		1 mxdAvfSsdzliezc0uyUMk 	 
  _13303058356268144138 mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
 _1691169752730655240 mINcNsH05D0QZDej9wl4h 	 
    	  
    		_13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
     
  mycwFs63h7Mi3ggRkMEVm 	 
    	   mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
     
 
            cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   Size _15915597540354938205 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
    _68274921722597584 mNDJrNgMXB1tBoFNaJO0d 	 
    	_13303058356268144138-1 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    	.cols/_18062104616271777338.pyrfactor,_68274921722597584 mWkGo8xUdRIKgJ1DEUvvn 	 
  _13303058356268144138-1 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
.rows/_18062104616271777338.pyrfactor mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     mJTScPpWt8plE9Cz9fDU6 	 

            cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  resize mReDuVelSknxaDAoDEmwT 	 
  _68274921722597584 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
 _13303058356268144138-1 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
    ,_68274921722597584 mZnfmoDANjVLDjZfzM5MR 	 
 _13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
     
    ,_15915597540354938205 mhyL_M5gnmQzwyHW45MdA 	 
    	  
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		
     maCQ9r5fSln_CXgRXGFvO 	 
   
 mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
  

 myqrAJLu9GRcs5sFEN1xM 	 
    	  
    		   
  impl_assignClass_fast mhORIPgMIfN3Fn8aCQBuU 	 const cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
 Mat &_16232574195069562408, std mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
 cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
   KeyPoint mRHNkLPwUSnx20pmLgrTq 	 
    & _414219072103044861,  mpMWr23OozoNFIk9M3JRl 	 
    	  
    		   
   _3176948347770171375,  mCujczJix6jMpJcynoBiA 	 
    	_11909274222260322758 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
  	 
     mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
 
     mX_x9bVx2zqKO8c2FxqgZ 	 
    	  
    		   
     
     
 _16232574195069562408.type mzeHK1hG1SYQMISNMWMB8 	 
    	  
     mHgo4JTEAdFhAHz3buc5U 	 
    	  
 CV_8UC1 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
 throw std mBBHVSlvDGP5NVUfEuhuf 	runtime_error mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
    "\x5c\x78\x36\x31\x5c\x78\x37\x33\x5c\x78\x37\x33\x5c\x78\x36\x39\x5c\x78\x36\x37\x5c\x78\x36\x65\x5c\x78\x34\x33\x5c\x78\x36\x63\x5c\x78\x36\x31\x5c\x78\x37\x33\x5c\x78\x37\x33\x5c\x78\x35\x66\x5c\x78\x36\x36\x5c\x78\x36\x31\x5c\x78\x37\x33\x5c\x78\x37\x34\x5c\x78\x32\x30\x5c\x78\x34\x39\x5c\x78\x36\x65\x5c\x78\x37\x30\x5c\x78\x37\x35\x5c\x78\x37\x34\x5c\x78\x32\x30\x5c\x78\x36\x39\x5c\x78\x36\x64\x5c\x78\x36\x31\x5c\x78\x36\x37\x5c\x78\x36\x35\x5c\x78\x32\x30\x5c\x78\x36\x64\x5c\x78\x37\x35\x5c\x78\x37\x33\x5c\x78\x37\x34\x5c\x78\x32\x30\x5c\x78\x36\x32\x5c\x78\x36\x35\x5c\x78\x32\x30\x5c\x78\x33\x38\x5c\x78\x35\x35\x5c\x78\x34\x33\x5c\x78\x33\x31" mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		  mINcNsH05D0QZDej9wl4h 	 

     mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
   _8327405616267030056 muQdV4OJL6V6gVxW6AdRy 	 
_11909274222260322758*2+1 mVOlbMaOu1U0SC2oeKIzP 	 
    	 

    cv mU808frSKQDZnEEU3Q3s9 	Mat _7770143409063853332  mRwjoMr_aqph4iL4nu8NS 	 cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
    Mat myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		  zeros mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
  _11909274222260322758*2+1,_11909274222260322758*2+1,CV_8UC1 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
   mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
    cv mBBHVSlvDGP5NVUfEuhuf 	 
Mat _1198931547899984731 muQdV4OJL6V6gVxW6AdRy 	 
 cv maKLz6mCz5anFyVle_MtD 	 
    	  
   Mat mhxtTU7dvZHXCTSg8B8rx 	 
    	  
_11909274222260322758*2+1,_11909274222260322758*2+1,CV_8UC1 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
  	

         miGFoFUQX5urgUZ1Rewwt 	 
    	  
    		   
     
 mF8CPQI5IssWjwlV2CXVE 	 
    	  
    		   
     
     
 
 &_16232574195069566594:_414219072103044861 mycwFs63h7Mi3ggRkMEVm 	 
    	  

         mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
 
             mCujczJix6jMpJcynoBiA 	 
    	  
    		   
     
  _13303058356268144065  muQdV4OJL6V6gVxW6AdRy 	  _16232574195069566594.pt.x+0.5f mftnbgRvzOIVyL93HyyWt 	 
    	  
    	
             mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   
     
     
_13303058356268144023  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
  _16232574195069566594.pt.y+0.5f mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   


             cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     Rect _13303058356268144075 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
  cv mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
     
 
  	 Rect mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		 _13303058356268144065-_11909274222260322758,_13303058356268144023-_11909274222260322758,_11909274222260322758*2+1,_11909274222260322758*2+1 mycwFs63h7Mi3ggRkMEVm 	 
    	 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		
            
             mBuRRlPSkgfIqW4MkJEkn 	 _13303058356268144075.x mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
 0  mgM8ScCmoJ3qXwMzVOzZc 	 
    	  
    _13303058356268144075.x+_13303058356268144075.width mtJAThUzPUAnb_DMXiQOL 	 
    	  
   _16232574195069562408.cols  mfNhxMALMjy2jMKPPP3pN 	 
    	  
    		   
     
      _13303058356268144075.y mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     
0  mgM8ScCmoJ3qXwMzVOzZc 	 _13303058356268144075.y+_13303058356268144075.height mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
     
_16232574195069562408.rows mycwFs63h7Mi3ggRkMEVm 	 
   continue mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    	


             mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   
    _3176948340369703937 mu_nOcTFwUo8r0uNE351R 	 
 _13303058356268144075.x+_13303058356268144075.width mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
             mihBlyb7pwidO496a5_p1 	 
 _3176948340369704860 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
 
 _13303058356268144075.y+_13303058356268144075.height mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
  
            uchar _3176948348563158861 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		255,_3257891898253592022 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
 0 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
  
             ma9rnYFEs_TUiw_WyBflg 	 
    	  
     mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		  _13303058356268144023 mCm219F3DHVwNe_CsrCeK 	 
 _13303058356268144075.y mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		 _13303058356268144023 mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     _3176948340369704860 mftnbgRvzOIVyL93HyyWt 	 
    	  
    	 _13303058356268144023 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
     
     mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
  	  mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   

                const uchar *_5268605234499577910 mif4ZCBkqdiqSYkR9AD0r 	 
    	_16232574195069562408.ptr mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
    uchar mE4_Vrik0lveh4HNJUk1B 	 
 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
 _13303058356268144023 mgkSwnYHQivQIpeAwgr20 	 
    	  
     mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     

                 mVRbVdVjFvNmKzGv4WiNp 	 
    	  
    		   
     
     
 
  mCujczJix6jMpJcynoBiA 	 
    	  
    		   
     
 _13303058356268144065 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 _13303058356268144075.x mriCvhMavpfheoLNc0eCD 	 
    	  
  _13303058356268144065 mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
   _3176948340369703937 mdmuaUz9iCkCckSUhcEv1 	 
    	  
 _13303058356268144065 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
                 mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     

                     mXkfygpbRUCrOfJA4ktlP 	 
    	  
    		   
     
  _3176948348563158861 mjxPa00ei9qkuuQmiGB3C 	 
    	  
    		  _5268605234499577910 mFyKKLtdivGGDlk8sYzsf 	_13303058356268144065 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
   muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
 _3176948348563158861 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 
  _5268605234499577910 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    	_13303058356268144065 msdqcdg5NNrdQnc_PT1Ee 	 
    	 mriCvhMavpfheoLNc0eCD 	 

                     mSuHweZ8NLqp3TniIO9nc 	 
    	  _3257891898253592022 mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     
_5268605234499577910 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     
     
 
 _13303058356268144065 mUB1yrSrKOwldqxmCatN2 	 
    	  
    msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     _3257891898253592022 mCm219F3DHVwNe_CsrCeK 	 _5268605234499577910 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     _13303058356268144065 mIkhxhgSNMt_JUZR7ce1U 	 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
 
                 mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
     
 

             muuG2jhk4iNsA9KNmj6oA 	 
    	  
    	

             mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
     
   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    	 mhxtTU7dvZHXCTSg8B8rx 	_3257891898253592022-_3176948348563158861 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
   mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
  25 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		     mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
  
                _16232574195069566594.class_id myJHqW7fkn_72nVEhKeZ6 	0 mJTScPpWt8plE9Cz9fDU6 	 
   
                continue mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		 
             muuG2jhk4iNsA9KNmj6oA 	 
 

             mPBSejyyYBZX7KoLjIvqq 	_16941263804935501574 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
  _3257891898253592022+_3176948348563158861 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
  /2.0 mriCvhMavpfheoLNc0eCD 	 
    

            unsigned  moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
   _16232574195041799150 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    	0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
  
            
             ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   
     
     
 mCujczJix6jMpJcynoBiA 	 
    	  
 _13303058356268144023 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		 0 mdmuaUz9iCkCckSUhcEv1 	 
    	 _13303058356268144023 mW1ds9XwNwevT5B2b3j8B 	_8327405616267030056 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
  _13303058356268144023 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
  mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
                const uchar *_5268605234499577910 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 
  	_16232574195069562408.ptr mYI2nkSxgJHf1pY1PttV1 	 
    uchar mjxPa00ei9qkuuQmiGB3C 	 
    	  
    	 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    _13303058356268144075.y+_13303058356268144023 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   +_13303058356268144075.x mlqoNTA3LQoUJF6i5YDFc 	 

                uchar *_3861841962186570485 muQdV4OJL6V6gVxW6AdRy 	 
    	  
  _1198931547899984731.ptr mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
  uchar mBpPKNB5wfuTOV223BA2r 	 
    	  
   mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
    _13303058356268144023 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
  	  mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
  
                 mhXXYzAVu3lDYyh7TkRWq 	 
    	  
    		   
     mdbRZP7cWFYlUcaGRMsKc 	 
    	  
  _13303058356268144065 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
 0 mVOlbMaOu1U0SC2oeKIzP 	 _13303058356268144065 mqEAvVDOCXqrrwrTRByrM 	 _8327405616267030056 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
      _13303058356268144065 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    		   
  mmCJ670wA_VHgip7JZ1dW 	 
    	 mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
     
     
 

                     mXkfygpbRUCrOfJA4ktlP 	 
    	  
    		   _5268605234499577910 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
  	 _13303058356268144065 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
 
  mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
_16941263804935501574 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
    mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
  
                        _16232574195041799150 mt0bWs8kxCzTnBdtR9vKu 	 
    	  
   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
  
                        _3861841962186570485 mA4oXllup8K3T5dxkluRR 	 
    	  
    	_13303058356268144065 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
     
 
  mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 255 mftnbgRvzOIVyL93HyyWt 	 
    	  
    	
                     mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
                     mFK5JCwqLjSVNjbuFv1Xz 	 
   _3861841962186570485 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
 _13303058356268144065 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
 mif4ZCBkqdiqSYkR9AD0r 	 
  0 mriCvhMavpfheoLNc0eCD 	 

                 mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
   
             mCvAz6nTbqhvwRULRgKe4 	 
    	  
 
            
             ma9rnYFEs_TUiw_WyBflg 	 
    	  
 moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
 _13303058356268144023 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     0 mdmuaUz9iCkCckSUhcEv1 	  _13303058356268144023 mqEAvVDOCXqrrwrTRByrM 	 
 _1198931547899984731.rows mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
  _13303058356268144023 mi940TUip6nLdi0tWD33F 	 mgkSwnYHQivQIpeAwgr20 	  mnU2hwoI16_nZ7reLKJTr 	 
    	  
   
                uchar *_10102288860402729761 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
    _7770143409063853332.ptr mHkLXuUOlyX2vZI7w3FQj 	 
    uchar mBpPKNB5wfuTOV223BA2r 	 
    	  mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   _13303058356268144023 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     

                 moPdTa5HpJKbS1U6TqDjY 	  mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
     
     
 
_13303058356268144065 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
 
0 mINcNsH05D0QZDej9wl4h 	 
    	  
  _13303058356268144065 mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
    _1198931547899984731.cols mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
 
  _13303058356268144065 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
     
     
 
  mycwFs63h7Mi3ggRkMEVm 	 
    _10102288860402729761 mGYpOkNIG_qSvYXBOU9Vf 	 
_13303058356268144065 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     
 
   mM3tRrWbRPqPOU3G4ShKT 	 
   0 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
             mnSkEvR4SbDwQxj23xB1M 	 
    	  
  

            uchar _2527482952837276942  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    	 1 mPdHdcAZ6XJhwf8wLtULI 	 
            std mdssZV6TB06aiisDwN1cX 	 
    	  
    	map mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     
 uchar, uchar mEc9zv3P8LW8haIvtztwe 	 
    	  _17627748882047670830 mhGXMe8LHJXydR9dMisHj 	 
    	  
    	
             mhXXYzAVu3lDYyh7TkRWq 	  mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		   
   _13303058356268144023 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 0 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
   _13303058356268144023 mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		_1198931547899984731.rows mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
  _13303058356268144023 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    		   
    mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		 mjbtcSgN5ZQfkGDsoYG4l 	 
   
                uchar *_3861841962186570485 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		_1198931547899984731.ptr mK5OxIt23gZzSiTA8trU8 	 
    	 uchar mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
     
 
  	 mhxtTU7dvZHXCTSg8B8rx 	 
_13303058356268144023 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
  	  mINcNsH05D0QZDej9wl4h 	 
    	  
    		
               uchar *_10102288860402729761 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		  _7770143409063853332.ptr mca1GaR7Rv9qOZsisqKBB 	 
    	 uchar mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
     
 
  	 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
_13303058356268144023 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		 mlqoNTA3LQoUJF6i5YDFc 	 
 
                 mVRbVdVjFvNmKzGv4WiNp 	 
  mihBlyb7pwidO496a5_p1 	 
    	  
    		_13303058356268144065 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
  0 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   _13303058356268144065 mHkLXuUOlyX2vZI7w3FQj 	 
    	 _1198931547899984731.cols mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 _13303058356268144065 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		  mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   

                 mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
 
                    uchar _5268611907152127627  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
  _3861841962186570485 mA4oXllup8K3T5dxkluRR 	 
    	  
   _13303058356268144065 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
      mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
                    uchar _14281707985483758147  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   

                    uchar _12923587428288459517  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 
   0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
 

                     mXkfygpbRUCrOfJA4ktlP 	 
    	  
    	_13303058356268144065-1  mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
    -1 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 

                     mMRNM5hfPBWFjYCspldu3 	
                         mVHGLK1C5RNdKdXzDgMZU 	 
    	  
    		   
     
     _5268611907152127627  mRuVXNtG32xpaNLi1hDLk 	 
    	  
    		   
     
 _3861841962186570485 mdF98bHO7yrxGJn0aQZVK 	 
  _13303058356268144065-1 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
  muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     

                            _14281707985483758147  mu_nOcTFwUo8r0uNE351R 	_10102288860402729761 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
     
 
  _13303058356268144065-1 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
 
  
                     maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
 

                     mb_mniVMqcXJMFkJcXnTV 	 
    	  
    		   
     
    _13303058356268144023-1  mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
     
  -1 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
 
                     mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
 
                         mb_mniVMqcXJMFkJcXnTV 	 
_5268611907152127627  mi0dc2wlXgNoHf9VPli9f 	 
    	  
    		   
     
   _1198931547899984731.ptr mK5OxIt23gZzSiTA8trU8 	 
   uchar mE4_Vrik0lveh4HNJUk1B 	 
    	  
 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
    _13303058356268144023-1 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
   mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
 _13303058356268144065 msdqcdg5NNrdQnc_PT1Ee 	 
    msubWq7nTVSPilWqmTzkx 	 
    	  
 
                            _12923587428288459517  ma6VjqdfajK4BX9gkoGiD 	 
    	   _7770143409063853332.at mW1ds9XwNwevT5B2b3j8B 	 
uchar mjxPa00ei9qkuuQmiGB3C 	 
    	  
    		   
  mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     _13303058356268144023-1, _13303058356268144065 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		
                     mgjPImSFwUcUKl9XTKqqB 	 
   

                     mSuHweZ8NLqp3TniIO9nc 	 
    	  
    		  _14281707985483758147 mnZ6t3BhMZ_1d7zzE72ah 	 
  0  mgN2NPegMIWZaSlArqSpX 	 
     _12923587428288459517 mi0dc2wlXgNoHf9VPli9f 	 
    	  
    		   
   0 mycwFs63h7Mi3ggRkMEVm 	 
 
                        _10102288860402729761 mA4oXllup8K3T5dxkluRR 	_13303058356268144065 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
   _2527482952837276942 mt0bWs8kxCzTnBdtR9vKu 	 
    mftnbgRvzOIVyL93HyyWt 	 
    

                     mHcxzZHoWX11H4xEjR59T 	 
    	  
    mwxm9pz2KjGAhBIIfFMf4 	 
    	  
    	_14281707985483758147 mWUoD50tT9HFGBNQCsjUC 	 
   0  mKdH1o6rFuMJ1Fl0PA_sn 	 
    	  
    		   
     
     _12923587428288459517 mu3VfwjYyEXmsa3FxHdyz 	 
    	  
    0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
 
                     mMRNM5hfPBWFjYCspldu3 	
                         mXkfygpbRUCrOfJA4ktlP 	 
    	  
    		   
     
    _14281707985483758147  mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
 _12923587428288459517 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
 
                         mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
     
  
                            _10102288860402729761 mFyKKLtdivGGDlk8sYzsf 	 
 _13303058356268144065 mIkhxhgSNMt_JUZR7ce1U 	 
   myJHqW7fkn_72nVEhKeZ6 	 
    	  
   _14281707985483758147 mriCvhMavpfheoLNc0eCD 	 
    	  
                            _17627748882047670830 mY2nz8M_6jpSxQZL8EYgU 	_12923587428288459517 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     mif4ZCBkqdiqSYkR9AD0r 	 _14281707985483758147 mxdAvfSsdzliezc0uyUMk 	 
    	  
                         mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
     
                         mHcxzZHoWX11H4xEjR59T 	 
    	  
  mXyxJEKR2vQDAiXVkkZ96 	 
_14281707985483758147  m_j6ZkbEfLCgUqtaolYTp 	 
 _12923587428288459517 muiDYQbmwLxL3PGrwWGeP 	 
    
                         mJkMyi0NbVRDgE__LMR_m 	
                            _10102288860402729761 mFyKKLtdivGGDlk8sYzsf 	 
_13303058356268144065 mEFd2D2UDF9SIoPfQtUv6 	   mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
    _12923587428288459517 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     

                            _17627748882047670830 mY2nz8M_6jpSxQZL8EYgU 	 _14281707985483758147 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
  _12923587428288459517 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
                         muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
     
     
 
 
                        else
                         mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
 
                           _10102288860402729761 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		_13303058356268144065 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
   mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     _12923587428288459517 mriCvhMavpfheoLNc0eCD 	
                         mnSkEvR4SbDwQxj23xB1M 	 
    
                     maCQ9r5fSln_CXgRXGFvO 	 
    	  
                    else
                     mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    	
                         mikiSyOnVry6pvQ1Ds28H 	 
 _14281707985483758147 mHgo4JTEAdFhAHz3buc5U 	 
 0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
   _10102288860402729761 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		   _13303058356268144065 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
        mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
 _14281707985483758147 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
 
                         muKP5B7qysoQRrYrwu_aG 	 
    	  
    		   
     
     
 
  	 _10102288860402729761 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
_13303058356268144065 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
       mKcKHr_bTagXAK_pf8btG 	 
    	  _12923587428288459517 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     

                     muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
     
    
                 mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
     
 
 
             mhl3Z6oGBbP13ZxehUcg9 	

             mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		   
     
     
 
  	 _16232574195041797758 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   _2527482952837276942-1 - _17627748882047670830.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
   
             mikiSyOnVry6pvQ1Ds28H 	 
    	  
    		   
     
   _16232574195041797758 mgAgf2KiVOzOHJDU4qKPI 	 
    	  
2 mXAYJa6osZ6HNTIEEBnr0 	 
    	 
             mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		   

                 mXkfygpbRUCrOfJA4ktlP 	 
    	  
    		   
     _16232574195041799150  mel3l7ZRXwnAEsy0Wfxj_ 	 
  _1198931547899984731.total mKpq3GwvJxRduE5RsGgGP 	 
 -_16232574195041799150 msubWq7nTVSPilWqmTzkx 	 
    	  
   _16232574195069566594.class_id  mKcKHr_bTagXAK_pf8btG 	 
    	  
     0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
    
                 mE_Ow4Xh61sHZuYT9u_vp 	 
    	  
    		   
     
 _16232574195069566594.class_id  muQdV4OJL6V6gVxW6AdRy 	 1 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
             mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
    
             mFK5JCwqLjSVNjbuFv1Xz 	 
    	  
    		   
     
     
  mwQUfI7G4pBH6IJQiBjmU 	 
  mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     
 
_16232574195041797758  mYxohqgekcJ8HhaDZvWcX 	 
    	  
    2 mgkSwnYHQivQIpeAwgr20 	 
    	  
  mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
     
                _16232574195069566594.class_id  mKcKHr_bTagXAK_pf8btG 	 
    	  
   2 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		 


             mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
  
         muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
    
     mbYMUxVFybbviIFqRhN2f 	 
    	 

















vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
     MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    	MarkerCandidate mBpPKNB5wfuTOV223BA2r 	 
    	   MarkerDetector_Impl mUCEzhGWrU8OYqcHVPlVW 	 
_11288135742209909849 mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
    const cv mUCEzhGWrU8OYqcHVPlVW 	 
    Mat  & _17276638435886805939,  moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
    _15830902196015336515, mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		_15830902196015336516, mpHTdkvfapV5_Igrm_XSs 	 
    	  
    		   
     
     
 _11520114173644902406,cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
     Mat &_451795507898897488 mzf4ZxeZY8wF2XnrdYK61 	 
    	 mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
 
     
     mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
  mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
   _15830902196015336515  mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		   
     
     
 
  	  3 mAnDeXfeHaujEzGBbrjil 	  _15830902196015336515  mCm219F3DHVwNe_CsrCeK 	 3 mftnbgRvzOIVyL93HyyWt 	 

     mv1ijGQAKacWqWAusY8nc 	 
 mRzhpvoeHZK7yCqqzYDDp 	 
    	   mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
     mdEzmAkZNQkKD1HrLnSSo 	mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     
 
  	_15830902196015336515 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   % 2  muOzaq9SXefX6wOasanyX 	 
    	  
   1 mmCJ670wA_VHgip7JZ1dW 	 
    	  
  _15830902196015336515  mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
  mp3H4249LtCVDCYFqQqz4 	 
   mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   
     
     
mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
  	 mmmC9tOGiLK6UaJr0E5vz 	 
_15830902196015336515 + 1 muiDYQbmwLxL3PGrwWGeP 	 
    	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     


     mG7mr0Iq8BCEeADSwrCoW 	 
    	  
   _15680653421411319497 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
-1 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   

    cv mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
    Mat _17629472122771957618 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
    
    
        _17629472122771957618 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     _451795507898897488 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    	
     mvw_MKiY3S1FcVNfJQCRT 	 
    	  
    		   
     
     mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    _18062104616271777338.thresMethod mRuVXNtG32xpaNLi1hDLk 	 
    	  
    		   
     
     MarkerDetector mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
    THRES_AUTO_FIXED mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
 mLdYY4X2b7VOjtTSnd7Hj 	 
 
            cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
threshold mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
    _17276638435886805939, _17629472122771957618, static_cast mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		   
   moI11mwtxiOXpqDxK_aQL 	 
  mtJAThUzPUAnb_DMXiQOL 	 
    	  
    mReDuVelSknxaDAoDEmwT 	 
   _15830902196015336516 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    ,255,THRESH_BINARY_INV mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
 
             mXkfygpbRUCrOfJA4ktlP 	 
    	  
    		   
     
     
 _11520114173644902406 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		  mnU2hwoI16_nZ7reLKJTr 	 
    	  
  
               cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
     
 
  	 Mat _3257871146051445030 mriCvhMavpfheoLNc0eCD 	 
    	  
    		 
               _15680653421411319497 mCm219F3DHVwNe_CsrCeK 	 
    	  
 mdbRZP7cWFYlUcaGRMsKc 	 
   mSa4WnWih0z4lSo9RYUGU 	 
    	  
    	std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
  max mp3H4249LtCVDCYFqQqz4 	3.0, 3./1920. *  mlkEZnzYCXAgDnYDi5up3 	 
    	  
   mhORIPgMIfN3Fn8aCQBuU 	 
 _17629472122771957618.cols mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
  msubWq7nTVSPilWqmTzkx 	 
  mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
   
                mwQUfI7G4pBH6IJQiBjmU 	 mtbP4KQJdh36UGELfV2zq 	 
    	  _15680653421411319497%2 mgAgf2KiVOzOHJDU4qKPI 	 
    	  
    		   
  0 mgkSwnYHQivQIpeAwgr20 	 
    	  
 _15680653421411319497 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
     
     
 
  mVOlbMaOu1U0SC2oeKIzP 	
               cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
  erode mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
 _17629472122771957618,_3257871146051445030, getStructuringElement mFsSEF_3_iD2mT6nZG9QR 	 MORPH_CROSS,cv mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
 Size mFlVjO0mLpwnCN5a1Quio 	 
    _15680653421411319497, _15680653421411319497  mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     ,cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    	Point mp3H4249LtCVDCYFqQqz4 	 
  _15680653421411319497/2,_15680653421411319497/2  mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
    mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 mAnDeXfeHaujEzGBbrjil 	 
    	 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 

               cv maKLz6mCz5anFyVle_MtD 	bitwise_xor mFsSEF_3_iD2mT6nZG9QR 	 
    	 _3257871146051445030,_17629472122771957618,_17629472122771957618 mzf4ZxeZY8wF2XnrdYK61 	 
     mINcNsH05D0QZDej9wl4h 	

             mICILgDpdCTDSJqQAn06L 	 
    
     maCQ9r5fSln_CXgRXGFvO 	 
    	  
   
     mE_Ow4Xh61sHZuYT9u_vp 	 
    	  
    		   
     
      mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     
 

        cv mBBHVSlvDGP5NVUfEuhuf 	 
   adaptiveThreshold mp3H4249LtCVDCYFqQqz4 	 
    	  
    	_17276638435886805939, _17629472122771957618, 255., ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY_INV, static_cast mca1GaR7Rv9qOZsisqKBB 	 
    	  
    	 mihBlyb7pwidO496a5_p1 	 
    	  
    		   
     
     
 mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
    mtbP4KQJdh36UGELfV2zq 	 
    	  _15830902196015336515 mlqM0snvYcrWCw2_QjhQi 	 
    	  , static_cast mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 meWm4MhzbcJwavtoh469w 	 
    	  
    		   
     
    mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
     
 
  mhxtTU7dvZHXCTSg8B8rx 	 
    	  
_15830902196015336516 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		  mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		  mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     

        _15680653421411319497 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
 _15830902196015336515 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
   
      mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
    




    vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
    MarkerCandidate mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
 _6528263073538749848 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
 
    
         mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   _3622495794621911996 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     mihBlyb7pwidO496a5_p1 	miAECMSxGwjxrcOKk0DII 	  3.5*float mtbP4KQJdh36UGELfV2zq 	 
_18062104616271777338.lowResMarkerSize mmCJ670wA_VHgip7JZ1dW 	 
    	  
 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
  mftnbgRvzOIVyL93HyyWt 	 
    	  
    		 
    
     std maKLz6mCz5anFyVle_MtD 	 
    	  
    		   vector mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    	Vec4i mW1YUos9eL_9NmgJuSDH7 	 
  _10376581494285192551 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  
    std mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
    vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
    std mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
     
 
  vector mW1ds9XwNwevT5B2b3j8B 	 
    	cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
     
 
  	Point mIqkiLoOdpjYrPavNSkO3 	 
    	 _10998538416191004035 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
    
      cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
 findContours mtbP4KQJdh36UGELfV2zq 	 
 _451795507898897488, _10998538416191004035, cv mpJt2kGThF7wb3VNzG38b 	 
 noArray maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
  , cv maKLz6mCz5anFyVle_MtD 	 
   RETR_LIST, cv mEMN2sRTwHcTUl7SNSw0d 	 CHAIN_APPROX_NONE mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		 
     vector mW1ds9XwNwevT5B2b3j8B 	 
    	  Point mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
      _18125075577596139249 mINcNsH05D0QZDej9wl4h 	 
    	  
    	
#ifdef _aruco_debug_detectrectangles
     cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
   Mat simage mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		  
     cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     
 
cvtColor mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
  input,simage,CV_GRAY2BGR msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
 
 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
#endif

    
     mxQewHEnT8PTNQcVKCqL9 	 
    	  
    		 mhxtTU7dvZHXCTSg8B8rx 	 
    	 unsigned  mP8l6554fUQhsCw2PetD2 	 
    	  
    		_13303058356268144138  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
  	 0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   _13303058356268144138  mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
 _10998538416191004035.size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
     mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
   _13303058356268144138 mcstdE8Wwpam6tUMM45Sa 	 
    	  
    		   
     
     
 
   mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		 
     mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
     
   
#ifdef _aruco_debug_detectrectangles
            drawContour mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
   simage, contours mdF98bHO7yrxGJn0aQZVK 	 
    	  
    i mEFd2D2UDF9SIoPfQtUv6 	 
 , Scalar miAECMSxGwjxrcOKk0DII 	 
    	  
    	125, 125, 255 msubWq7nTVSPilWqmTzkx 	 
    	  
    		    muiDYQbmwLxL3PGrwWGeP 	 
  mftnbgRvzOIVyL93HyyWt 	 
    	
#endif
        
         mUFzn4yJGA8c9qnEcb9dH 	 
    	  
    		   
     
      mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		_3622495794621911996  mK5OxIt23gZzSiTA8trU8 	 
    	  
    meWm4MhzbcJwavtoh469w 	 
    	  
    		   
     
     
 
  mSa4WnWih0z4lSo9RYUGU 	 
    _10998538416191004035 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
  _13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
 
.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
       mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
    
         mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		   
     
     
 
            
            cv mEMN2sRTwHcTUl7SNSw0d 	 
 approxPolyDP mFlVjO0mLpwnCN5a1Quio 	 
    	  
  _10998538416191004035 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
  _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
   , _18125075577596139249,  mSBH4REv5nn8iXIXWLqFa 	 
    	  
    		   
     
     
 
mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
    _10998538416191004035 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
  _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	.size maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     
    msubWq7nTVSPilWqmTzkx 	 * 0.05,  mj7rzLUFNjZZ8TQ9LzphN 	 
    	  
    		   
     
     
mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
      mVOlbMaOu1U0SC2oeKIzP 	 
    	  
 

             mabeHDqoCFUg5Mty5oLni 	 
    	  
    mSa4WnWih0z4lSo9RYUGU 	 
   _18125075577596139249.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		   
     
  mYsjCP2nXqW2Jls3JAUkc 	 
    	   4  mKdH1o6rFuMJ1Fl0PA_sn 	 
    	  
    	 cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
 isContourConvex mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  _18125075577596139249 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
 mmCJ670wA_VHgip7JZ1dW 	
             mN0TszoCQmyzxmobsgV2H 	 
    	  
    		  
#ifdef _aruco_debug_detectrectangles
                drawApproxCurve mSa4WnWih0z4lSo9RYUGU 	 
    	  
    simage, approxCurve, Scalar mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     255, 0, 255 mlqM0snvYcrWCw2_QjhQi 	 
    	 ,1 mXAYJa6osZ6HNTIEEBnr0 	 
    	   mVOlbMaOu1U0SC2oeKIzP 	 
  
#endif
                
                 mglDNKH5ah89GptW6H4Cu 	 
    	  
    		   
_9594576219500337594  mRwjoMr_aqph4iL4nu8NS 	 std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 
  	numeric_limits mlP1m6taP4mQVYA_j8Oxe 	 
   mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
     
 
  	 mjxPa00ei9qkuuQmiGB3C 	 
    	  
   mYGfQUZmV9IjKAPVrLhZl 	max mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		   
     
     
 
 mhGXMe8LHJXydR9dMisHj 	 
    	  
   
                 mxQewHEnT8PTNQcVKCqL9 	 
    	  
    		   
     
      mp3H4249LtCVDCYFqQqz4 	 
   mdbRZP7cWFYlUcaGRMsKc 	 
_13303058356268144139  mif4ZCBkqdiqSYkR9AD0r 	 
    	  0 mPdHdcAZ6XJhwf8wLtULI 	  _13303058356268144139  mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
 4 mJTScPpWt8plE9Cz9fDU6 	 _13303058356268144139 mBh4lc09qKYGXyU7FeqOv 	 
    	  
 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
   
                 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
    
                     mglDNKH5ah89GptW6H4Cu 	 
    	  
    _13303058356268144198  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		 cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
     
 
  	 norm mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	_18125075577596139249 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
    _13303058356268144139 mrpQVzv6u8gxvho1qUlil 	 
    	  
 -_18125075577596139249 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
     
 
  mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
     
 
  _13303058356268144139 + 1 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
      % 4 mrpQVzv6u8gxvho1qUlil 	 
    	  
      muiDYQbmwLxL3PGrwWGeP 	 
    	  
 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
                     mJvv2tbrel2xOYjvgipUL 	 
    	  
     mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
 _13303058356268144198  mW1ds9XwNwevT5B2b3j8B 	 
    	  
   _9594576219500337594 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
    _9594576219500337594  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     _13303058356268144198 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
                 mbYMUxVFybbviIFqRhN2f 	 
    	  

                    
                    _6528263073538749848.push_back mhxtTU7dvZHXCTSg8B8rx 	 
 MarkerCandidate mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
     
  mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
 mVOlbMaOu1U0SC2oeKIzP 	 
  
                     maB_pNl4zuODt3oqXg9EB 	 
    	  
    	 mReDuVelSknxaDAoDEmwT 	 
    	  
    mG7mr0Iq8BCEeADSwrCoW 	 
    	 _13303058356268144139  ma6VjqdfajK4BX9gkoGiD 	 
    	  
   0 mlqoNTA3LQoUJF6i5YDFc 	 
     _13303058356268144139  mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
   4 mINcNsH05D0QZDej9wl4h 	 
    	  _13303058356268144139 mBh4lc09qKYGXyU7FeqOv 	 
 mgkSwnYHQivQIpeAwgr20 	 
  
                        _6528263073538749848.back mKpq3GwvJxRduE5RsGgGP 	 
    	  
  .push_back miAECMSxGwjxrcOKk0DII 	 
    Point2f mhxtTU7dvZHXCTSg8B8rx 	 
 static_cast mYfYoOWdsOLTDCIBT7npX 	 
    	  
    	 maOczvhF_v9OTsK70ZZut 	 
    	  
    		 mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
_18125075577596139249 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    	_13303058356268144139 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    	.x mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		,static_cast mYfYoOWdsOLTDCIBT7npX 	 
    	  
  mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
  m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
   mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
_18125075577596139249 mA4oXllup8K3T5dxkluRR 	 
  _13303058356268144139 mEFd2D2UDF9SIoPfQtUv6 	 .y mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
   msubWq7nTVSPilWqmTzkx 	 
    	  
    	 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
 
                    
                    
                    
                     mRzhpvoeHZK7yCqqzYDDp 	 
   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 _11520114173644902406 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
      mT_x8cqp5t43PgqNMR8gO 	 
    	
                            _1548619269531313217 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
   _6528263073538749848.back maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     , mWokjWH0MHqyBOx4j0Oac 	 
    	  mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		 _15680653421411319497 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 /2. muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 mdmuaUz9iCkCckSUhcEv1 	 
  
                     mhl3Z6oGBbP13ZxehUcg9 	 
    	  
 
#ifdef _aruco_debug_detectrectangles
                    MarkerCanditates.back mKpq3GwvJxRduE5RsGgGP 	 
    	  
    		   
     
.draw mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
simage,Scalar mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
255, 255, 0 muiDYQbmwLxL3PGrwWGeP 	 
    	,1, mEzFcmvX0IX3FOucgCcVF 	 
    	  
    		   
     
mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
   mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
 
#endif
                    _6528263073538749848.back mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
 .contourPoints mKcKHr_bTagXAK_pf8btG 	 
    	  
    	_10998538416191004035 mGYpOkNIG_qSvYXBOU9Vf 	 
  _13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		    mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
 

             mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
     
 

         mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
  
     muuG2jhk4iNsA9KNmj6oA 	 
    	  
    	
#ifdef _aruco_debug_detectrectangles
    cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
imshow miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
  "\x5c\x78\x36\x33\x5c\x78\x36\x66\x5c\x78\x36\x65\x5c\x78\x37\x34\x5c\x78\x36\x66\x5c\x78\x37\x35\x5c\x78\x37\x32\x5c\x78\x37\x33",simage mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		 mhGXMe8LHJXydR9dMisHj 	 
    	  
#endif
     mlJqcdUT0sl1_64qaqDwc 	 
    	  
    		   
     
     
 
  	_6528263073538749848 mftnbgRvzOIVyL93HyyWt 	 
 
 mICILgDpdCTDSJqQAn06L 	 
    	  
    		 


 mc6SGgM2Uzvo_wy5KTima 	 
    	  
    		MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    _1434268935998653744 miAECMSxGwjxrcOKk0DII 	 
    	  
    		     mAnDeXfeHaujEzGBbrjil 	 
 mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     

    while mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
     
  m_lICnZ0bJGmuMACmMVcA 	 
    	  
    		  mmCJ670wA_VHgip7JZ1dW 	 
    	  
  mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		   
     
           mYA_OUCZSQycbIZ5oB16m 	 
    	  
    		   
     
     
 
  _11520114173644902406 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     mHbmZNNhradVwUtDZ5U7B 	 
    	  
    		   
     
     
 
  	mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
         m_6hetAMDOSYN9CmiL4W7 	 
    	  
    		   
     
     _5268611907606565765 muQdV4OJL6V6gVxW6AdRy 	 
    	  
   _16684997543815802068._3970747861761939044 maHkatHu0Jap4oTaT5q4_ 	 
    	  
   mVOlbMaOu1U0SC2oeKIzP 	 

          mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		   
     
     
  mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
  _5268611907606565765._1012033135676957631 mRuVXNtG32xpaNLi1hDLk 	 
    EXIT_TASK mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
   mTAavMivNX5WuUrRQXoEf 	 
    	mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   

         mHcxzZHoWX11H4xEjR59T 	 
    	  
    		   
    mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     
     miAECMSxGwjxrcOKk0DII 	 
    	  
    _5268611907606565765._1012033135676957631 mtPtbM6hNfOIkqlx661ci 	 
    	  
    		   
     
ENCLOSE_TASK mAnDeXfeHaujEzGBbrjil 	 
    	  
    		  _11520114173644902406 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
   mrRUZLmQTdeC3HO0hVmGH 	 
    	  
    		   
     
     
 
  mhGXMe8LHJXydR9dMisHj 	 
    	  
    	
        _8381292230366782771 mY2nz8M_6jpSxQZL8EYgU 	 
_5268611907606565765._13074680784567168978 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
   mM3tRrWbRPqPOU3G4ShKT 	 
    	  _11288135742209909849 mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	_16594497104544919971 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     _5268611907606565765._9830224992155182763 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		,_5268611907606565765._13074680779112612408,_5268611907606565765._13074680779112612409,_11520114173644902406,_16594497104544919971 mTjppsgNpY1Pjyv5Z_zMr 	 
   _5268611907606565765._13074680784567168978 mo8MRbS3DUX_ZOlgmUSna 	 
    muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
   

     mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
     
 
  mxdAvfSsdzliezc0uyUMk 	 
 mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
 

vector mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
     
aruco mfx1fLYDWN4YRZNnQEsJN 	 
    	MarkerDetector_Impl mBBHVSlvDGP5NVUfEuhuf 	 
   MarkerCandidate mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
     
  MarkerDetector_Impl mU808frSKQDZnEEU3Q3s9 	 
    	  
    		  _11288135742209909849 mFsSEF_3_iD2mT6nZG9QR 	 
const cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
     
 
  Mat &_17276674595339161488  mAnDeXfeHaujEzGBbrjil 	 
    	  mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
    

    

     meWm4MhzbcJwavtoh469w 	 
    	  
    		  _11129164959907732555 muQdV4OJL6V6gVxW6AdRy 	 
    	  
_18062104616271777338.AdaptiveThresWindowSize mftnbgRvzOIVyL93HyyWt 	 
    	  

     mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
_18062104616271777338.AdaptiveThresWindowSize mZVOYp2JAGvUM7UPbzd3Q 	 
    	  
    		   
     
     
 
  	 -1 msubWq7nTVSPilWqmTzkx 	 
  
        _11129164959907732555 mRwjoMr_aqph4iL4nu8NS 	 max mFlVjO0mLpwnCN5a1Quio 	 mSD7jHYN8mOif4_CBtIg6 	 
   mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
 3 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
  , mSD7jHYN8mOif4_CBtIg6 	 mFsSEF_3_iD2mT6nZG9QR 	 
    	15*float mp3H4249LtCVDCYFqQqz4 	 
    	  
    		_17276674595339161488.cols mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
  /1920. mhyL_M5gnmQzwyHW45MdA 	 
    	  msubWq7nTVSPilWqmTzkx 	 
    	  
  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   
     mikiSyOnVry6pvQ1Ds28H 	 
    	  
    		 _11129164959907732555%2 mHOvg7vOJH6ujsVsg3S5G 	 
    	  
    		   
     
     
 0 mhyL_M5gnmQzwyHW45MdA 	 _11129164959907732555 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
     
     
 mftnbgRvzOIVyL93HyyWt 	 
 


    vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		   
mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
     
 
   _17256916070189102836 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
 
     mNMDyj9J1Nt8auTKwp8ze 	 
   mReDuVelSknxaDAoDEmwT 	 
   moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
     
 
  	_13303058356268144138  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
 static_cast mHkLXuUOlyX2vZI7w3FQj 	 
     mG7mr0Iq8BCEeADSwrCoW 	 
   mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
  std mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
     
 max mFlVjO0mLpwnCN5a1Quio 	 
   3., _11129164959907732555- 2. * _18062104616271777338.AdaptiveThresWindowSize_range mycwFs63h7Mi3ggRkMEVm 	 
   mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
      mhGXMe8LHJXydR9dMisHj 	 
    	  
     _13303058356268144138  mgSkXUgcRjYGUB2o3shqJ 	 
    	  
    		   
     
     
 _11129164959907732555 + 2 * _18062104616271777338.AdaptiveThresWindowSize_range mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
  _13303058356268144138  msMfR3R5kzP8SqAQ3DWTq 	 
    	  
    		   
     
  2 mAnDeXfeHaujEzGBbrjil 	 

        _17256916070189102836.push_back mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
   _13303058356268144138 msubWq7nTVSPilWqmTzkx 	 
 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		

    size_t _11244054752219786216 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 
_17256916070189102836.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
 mdmuaUz9iCkCckSUhcEv1 	 
    	  
 
    _11754215234869264027 mu_nOcTFwUo8r0uNE351R 	 
    	  
    	_17256916070189102836.back mbHCSQc_uaLNP9Sf4Lz_n 	 
    	 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
 
    _8381292230366782771.resize mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
_11244054752219786216 muiDYQbmwLxL3PGrwWGeP 	 
    	  
 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
 

    _16594497104544919971.resize mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    	_11244054752219786216+1 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		    mlqoNTA3LQoUJF6i5YDFc 	 
 
    _16594497104544919971.back maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		 myJHqW7fkn_72nVEhKeZ6 	 
    	  _17276674595339161488 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
 
  
    
    _15785113844694797795 _5268611907606565765 mdmuaUz9iCkCckSUhcEv1 	 
    vector mK5OxIt23gZzSiTA8trU8 	 
    	_15785113844694797795 mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
     
  _3175889863520737153 mdmuaUz9iCkCckSUhcEv1 	 



    ThreadTasks _3176948232912920464 mCm219F3DHVwNe_CsrCeK 	 
    	  
  THRESHOLD_TASK mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
  
     mRzhpvoeHZK7yCqqzYDDp 	 
    	  
    	 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
 _18062104616271777338.enclosedMarker mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
  _3176948232912920464 mdKhcOUXVqyCMdccisL_a 	 
    	 ENCLOSE_TASK mhGXMe8LHJXydR9dMisHj 	
     mNMDyj9J1Nt8auTKwp8ze 	 
    	  
    		   
     
     
  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	size_t _13303058356268144138  ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
  0 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
      _13303058356268144138  mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
     
  _17256916070189102836.size mFwk30320retpLBiICndp 	 
    	  
    	 mriCvhMavpfheoLNc0eCD 	  _13303058356268144138 mt0bWs8kxCzTnBdtR9vKu 	 
   mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
  mDzQQrEx5Ki0C6uDHU2cy 	
        _5268611907606565765._9830224992155182763 mif4ZCBkqdiqSYkR9AD0r 	 mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   
     
mhORIPgMIfN3Fn8aCQBuU 	_16594497104544919971.size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     
  -1 mlqM0snvYcrWCw2_QjhQi 	 
    	 mINcNsH05D0QZDej9wl4h 	 
    	 
        _5268611907606565765._13074680779112612408 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
  	_17256916070189102836 mdF98bHO7yrxGJn0aQZVK 	_13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
 
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   

        _5268611907606565765._13074680779112612409 mdKhcOUXVqyCMdccisL_a 	 
   _18062104616271777338.ThresHold mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
   
        _5268611907606565765._13074680784567168978 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     
 
 _13303058356268144138 mJTScPpWt8plE9Cz9fDU6 	 
    	  
        _5268611907606565765._1012033135676957631 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
_3176948232912920464 mdmuaUz9iCkCckSUhcEv1 	 
    	  
   
        _16684997543815802068._16400045516394125907 mhxtTU7dvZHXCTSg8B8rx 	_5268611907606565765 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     
 
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   

        _3175889863520737153.push_back mReDuVelSknxaDAoDEmwT 	_5268611907606565765 mlqM0snvYcrWCw2_QjhQi 	 
     mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		
     mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   
     
     
 



    
     mFrnvKb629IAbveEQOTJk 	 
    	  
    		   
     
    size_t _13303058356268144138 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
 0 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    	_13303058356268144138 mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		_11244054752219786216 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     _13303058356268144138 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     

        _16594497104544919971 mA4oXllup8K3T5dxkluRR 	 
    	 _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
     
 
 .create mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
  _17276674595339161488.size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     
     
 
,CV_8UC1 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
 


    
     mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   
     
     
 
 _5547719957745377269 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
 
  	 0 mxdAvfSsdzliezc0uyUMk 	 
    	
     mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		_18062104616271777338.maxThreads mKbtq8OHrv8CI8FhvE4XG 	 
    	  
    		   
     
 0 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
        _5547719957745377269 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
      std mEMN2sRTwHcTUl7SNSw0d 	 
  thread mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
hardware_concurrency mdWkXjuaPd4Se0r0SdY1e 	 -1 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
   
     muKP5B7qysoQRrYrwu_aG 	 
    	_5547719957745377269 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
 max mFlVjO0mLpwnCN5a1Quio 	 
    	1,_18062104616271777338.maxThreads-1 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		    mriCvhMavpfheoLNc0eCD 	

    _5268611907606565765._1012033135676957631 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     
 
  EXIT_TASK mftnbgRvzOIVyL93HyyWt 	 

     mhXXYzAVu3lDYyh7TkRWq 	 
    	  
     mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    _13303058356268144138 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
   0 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		 _13303058356268144138 mqEAvVDOCXqrrwrTRByrM 	 
    	  _5547719957745377269 mJTScPpWt8plE9Cz9fDU6 	_13303058356268144138 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    		   
     
 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		    _16684997543815802068._16400045516394125907 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
   _5268611907606565765 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
      mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     


     mabeHDqoCFUg5Mty5oLni 	 
   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
  	_5547719957745377269 mnZ6t3BhMZ_1d7zzE72ah 	 
    	  
    		   
 1 mmCJ670wA_VHgip7JZ1dW 	 mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    	
        ScopeTimer _15827673749496603388 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		"\x5c\x78\x36\x65\x5c\x78\x36\x66\x5c\x78\x36\x65\x5c\x78\x32\x64\x5c\x78\x37\x30\x5c\x78\x36\x31\x5c\x78\x37\x32\x5c\x78\x36\x31\x5c\x78\x36\x63\x5c\x78\x36\x63\x5c\x78\x36\x35\x5c\x78\x36\x63" mgkSwnYHQivQIpeAwgr20 	 
    	  
  mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    
        _1434268935998653744  mSa4WnWih0z4lSo9RYUGU 	 
    	  
    mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
  mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
  	 
     mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   

     mv1ijGQAKacWqWAusY8nc 	 
    	  
    		   
mT_x8cqp5t43PgqNMR8gO 	 
        
        ScopeTimer _15827673749496603388 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
"\x5c\x78\x37\x30\x5c\x78\x36\x31\x5c\x78\x37\x32\x5c\x78\x36\x31\x5c\x78\x36\x63\x5c\x78\x36\x63\x5c\x78\x36\x35\x5c\x78\x36\x63" mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   

        
        vector mCALzjQ0bwpDnngl_oSsi 	 
    	  
   std mU808frSKQDZnEEU3Q3s9 	 
thread mEc9zv3P8LW8haIvtztwe 	  _1198931662437097535 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
    
         mhXXYzAVu3lDYyh7TkRWq 	 
    	  
    		   
      mMGij61UZUIIYyztVz9vN 	 
   _13303058356268144138 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
   0 mINcNsH05D0QZDej9wl4h 	 
    	  _13303058356268144138 mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
 _5547719957745377269 mJTScPpWt8plE9Cz9fDU6 	 
    	  
   _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 
     mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
 
            _1198931662437097535.push_back mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   std mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
     
 
  	thread mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		  &MarkerDetector_Impl maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
   _1434268935998653744, this mmCJ670wA_VHgip7JZ1dW 	 
  mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
      mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    	
        
         mF9AQyKXtPTPy1zvAUpED 	 
   mF8CPQI5IssWjwlV2CXVE 	 
    	  
    		   
     
     
 
 &_16232574195041814781:_1198931662437097535 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 
  	 _16232574195041814781.join mcznTYeCGOAygtXXAPYS_ 	 
     mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
 
     mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
 
    vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
  MarkerCandidate m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
 _1696087129052635781 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
  
    _9674227328620005286 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		    _8381292230366782771,_1696087129052635781 mAnDeXfeHaujEzGBbrjil 	 
    	  
    mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  
     mow1IjdflpN81ICD702rC 	 
    	  
    		   
    _1696087129052635781 mPdHdcAZ6XJhwf8wLtULI 	 
  

 mnSkEvR4SbDwQxj23xB1M 	 
    	  
 

vector mCALzjQ0bwpDnngl_oSsi 	 
    	  
     MarkerDetector_Impl mU808frSKQDZnEEU3Q3s9 	 
    	 MarkerCandidate mW1YUos9eL_9NmgJuSDH7 	 
    	  MarkerDetector_Impl maKLz6mCz5anFyVle_MtD 	 
    	 _17990657514663812703 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
           vector mHkLXuUOlyX2vZI7w3FQj 	 
  aruco mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
 MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
   MarkerCandidate mRHNkLPwUSnx20pmLgrTq 	 
    	  
    	 &_6528263073538749848,cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
 Size _13182630212586469335 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
      mypSy3lS4LRIjRYTxVxzg 	 
    
    
    
    
    
    valarray mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
  mpHTdkvfapV5_Igrm_XSs 	 
  mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
     
  _2262480597151600831 mp3H4249LtCVDCYFqQqz4 	 
    	  
    		 false, _6528263073538749848.size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
   mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
       
     mLBxgVrVeq7bTUcDGJqNH 	 
    	  
    		 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		unsigned  mdEzmAkZNQkKD1HrLnSSo 	 
_13303058356268144138  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
    0 mftnbgRvzOIVyL93HyyWt 	 
    	  
    _13303058356268144138  mca1GaR7Rv9qOZsisqKBB 	 
    	  
    	 _6528263073538749848.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
     
 
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 
  _13303058356268144138 mt0bWs8kxCzTnBdtR9vKu 	 
    	  
    		    mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   

     mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		 
        
        
         mvfKgFvXHh0Jqv_PZxbka 	 
    	  
    		   
     
  _5268605236564839919  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
    _6528263073538749848 mdF98bHO7yrxGJn0aQZVK 	 
    	  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		  mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
  1 mUB1yrSrKOwldqxmCatN2 	 
    	.x - _6528263073538749848 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
     
 
  	 _13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	   mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		0 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
 .x mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 

         mVPyhnVeODFpKcj5PAnUM 	 
_5268605236564808364  mdKhcOUXVqyCMdccisL_a 	 _6528263073538749848 mA4oXllup8K3T5dxkluRR 	 
    	  
_13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
    mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     1 mDd5IIsnjfLI1lcygRsW3 	 
    	  
 .y - _6528263073538749848 mNDJrNgMXB1tBoFNaJO0d 	 
  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
  mY2nz8M_6jpSxQZL8EYgU 	 
  0 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
 
.y mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
         mKui3FcBrQ5fUw3SS2JBl 	 
  _5268605236564839891  mu_nOcTFwUo8r0uNE351R 	 
 _6528263073538749848 mTjppsgNpY1Pjyv5Z_zMr 	_13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		  mWkGo8xUdRIKgJ1DEUvvn 	 
  2 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
     
 
 .x - _6528263073538749848 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     
 
  	 _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
0 msdqcdg5NNrdQnc_PT1Ee 	 
    .x mVOlbMaOu1U0SC2oeKIzP 	 
    	
         mvfKgFvXHh0Jqv_PZxbka 	_5268605236564808430  mdKhcOUXVqyCMdccisL_a 	 
    	  
  _6528263073538749848 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     
     
 
  	 _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
  mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		   
   2 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     .y - _6528263073538749848 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    _13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
   mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		 0 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     
 
  .y mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 

         mqwYu0y4oTPCnfXbylThX 	 
    	  
    		   
  _13303058356268144086  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
   mhxtTU7dvZHXCTSg8B8rx 	_5268605236564839919 * _5268605236564808430 muiDYQbmwLxL3PGrwWGeP 	 
    	   -  mp3H4249LtCVDCYFqQqz4 	_5268605236564808364 * _5268605236564839891 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
    mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
    

         mabeHDqoCFUg5Mty5oLni 	 
    	  
    		   
     
   mtbP4KQJdh36UGELfV2zq 	 
    _13303058356268144086  mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
     
 0.0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
 
         mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
    
            swap mReDuVelSknxaDAoDEmwT 	 
    	  
    _6528263073538749848 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 
  _13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
  mA4oXllup8K3T5dxkluRR 	 1 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
, _6528263073538749848 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
 _13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
 
   mGYpOkNIG_qSvYXBOU9Vf 	 
  3 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
     
 
   mlqM0snvYcrWCw2_QjhQi 	 mPdHdcAZ6XJhwf8wLtULI 	 

            _2262480597151600831 mNDJrNgMXB1tBoFNaJO0d 	 
 _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	    mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		    mqQspPZKCoa6LP0Jj0qH2 	 
    	  
    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
         mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
  
     maCQ9r5fSln_CXgRXGFvO 	 
  
    
    
    vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
  	 pair mK5OxIt23gZzSiTA8trU8 	 
  int,  mG7mr0Iq8BCEeADSwrCoW 	mgWtxscBTuWBkK7X3fJ_M 	 
    	  
    		   
     
     
 
  _2458634995200666860 mdmuaUz9iCkCckSUhcEv1 	
     mxQewHEnT8PTNQcVKCqL9 	 
    	  
    		   
     
      mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
 
unsigned  mihBlyb7pwidO496a5_p1 	_13303058356268144138  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
  _13303058356268144138  mca1GaR7Rv9qOZsisqKBB 	 
    	  
 _6528263073538749848.size mKpq3GwvJxRduE5RsGgGP 	 
    	  
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 _13303058356268144138 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
    mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     mjbtcSgN5ZQfkGDsoYG4l 	
        
         mA9OyoOle98msK0BnFc8I 	 
    	  
    		   
     
      mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
unsigned  meWm4MhzbcJwavtoh469w 	 
    	  
   _13303058356268144139  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
  _13303058356268144138 + 1 mxdAvfSsdzliezc0uyUMk 	  _13303058356268144139  mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     
 
 _6528263073538749848.size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
     
 
  	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
   _13303058356268144139 mo7mKuzaX2h9vw2rEj5qh 	 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
    
         mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    	
            valarray mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
     
     
 mglDNKH5ah89GptW6H4Cu 	 mRHNkLPwUSnx20pmLgrTq 	 
    _11909273676365498091 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		4 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
  mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
    
             mHIh6WyQKJh1ZKme1nslP 	 
    	  
    		   
     
     
 
 mtbP4KQJdh36UGELfV2zq 	 
    	  
    	 meWm4MhzbcJwavtoh469w 	 
    	  
    		   
     
   _13303058356268144199  myJHqW7fkn_72nVEhKeZ6 	 
   0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
  _13303058356268144199  mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	  4 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     _13303058356268144199 mo7mKuzaX2h9vw2rEj5qh 	 
    	  
  muiDYQbmwLxL3PGrwWGeP 	 
   
                _11909273676365498091 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
 _13303058356268144199 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
   mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
  cv mpJt2kGThF7wb3VNzG38b 	 
  norm mFsSEF_3_iD2mT6nZG9QR 	 
    	  _6528263073538749848 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 mILaQGKCAmcKrYQNhgWUq 	 
 _13303058356268144199 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		    -_6528263073538749848 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		 _13303058356268144139 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     
     
 _13303058356268144199 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
  mgkSwnYHQivQIpeAwgr20 	 
   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
            
             mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		   
    mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 _11909273676365498091 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     
     
 
 0 mo8MRbS3DUX_ZOlgmUSna 	 
    	   mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		   
     
 _11754215234869264027  mBJ7M0ikk98KhD4Oi32wB 	 
    	  
    		   
     
  _11909273676365498091 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     
     
1 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
     
  mCALzjQ0bwpDnngl_oSsi 	 
     _11754215234869264027  mBJ7M0ikk98KhD4Oi32wB 	 
    	  
  _11909273676365498091 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     2 mUB1yrSrKOwldqxmCatN2 	 
    	  
      mYI2nkSxgJHf1pY1PttV1 	 
    _11754215234869264027  mBJ7M0ikk98KhD4Oi32wB 	 
    	  
    _11909273676365498091 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
3 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
       mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
      _11754215234869264027 mmCJ670wA_VHgip7JZ1dW 	 
    
                _2458634995200666860.push_back mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
pair mqEAvVDOCXqrrwrTRByrM 	 
    	  int,  mSD7jHYN8mOif4_CBtIg6 	mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
    mhxtTU7dvZHXCTSg8B8rx 	 
  _13303058356268144138, _13303058356268144139 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
      mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
  	
         mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
 
     mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   
     


    
    vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
      mcqTciDcDgSbPPY9iuwhB 	 
    	  
    		   
     
   mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
    _7127668893958858208 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
  	  _6528263073538749848.size mKpq3GwvJxRduE5RsGgGP 	, mVgd0sC5KIFeGa4mcMXm9 	 
    	  
    		   
    muiDYQbmwLxL3PGrwWGeP 	 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
     m_owRLEm0gIJ4StPRwTkZ 	 
    	  
    		   
   mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
   unsigned  mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
     
    _13303058356268144138  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
 0 mxdAvfSsdzliezc0uyUMk 	 
    	   _13303058356268144138  mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     _2458634995200666860.size mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   
     
     
 
   mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
      _13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
     
     mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     mfKhTg3wpiK_YhdQzWWcS 	 

         mMNJIG0z6TLGgbjrhllmy 	 
    	  
    		  mmmC9tOGiLK6UaJr0E5vz 	 
    	  _16109434691388891984 mhxtTU7dvZHXCTSg8B8rx 	 
    _6528263073538749848 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
 _2458634995200666860 mGYpOkNIG_qSvYXBOU9Vf 	 
    	 _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
   .first mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
    mhyL_M5gnmQzwyHW45MdA 	   mE4_Vrik0lveh4HNJUk1B 	 
     _16109434691388891984 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
  _6528263073538749848 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		 _2458634995200666860 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
_13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
   .second mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
     
 mXAYJa6osZ6HNTIEEBnr0 	 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
 
            _7127668893958858208 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
     _2458634995200666860 mTjppsgNpY1Pjyv5Z_zMr 	 
 _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    	.second mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
     
 
  	   mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
       mCAzyIDtopeLXRxFfI0EK 	 
    	  
    		   
     
     
mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
        else
            _7127668893958858208 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
  _2458634995200666860 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
   _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	.first mbViqhyIcr6lGWibuo3Im 	 
    	  
    	  mKcKHr_bTagXAK_pf8btG 	 
    	  
    		     mqQspPZKCoa6LP0Jj0qH2 	 
    	  
    		mxdAvfSsdzliezc0uyUMk 	 
    	  
     mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
     
 
 

    
    
     mP8l6554fUQhsCw2PetD2 	 
    	 _385327363244837679  mCm219F3DHVwNe_CsrCeK 	 
 static_cast mYI2nkSxgJHf1pY1PttV1 	  mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   
     
     
 
 mEc9zv3P8LW8haIvtztwe 	 
    	  
    		 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    _18062104616271777338.borderDistThres *  mglDNKH5ah89GptW6H4Cu 	 
    	  
    		   
   miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     _13182630212586469335.width muiDYQbmwLxL3PGrwWGeP 	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
  	
     mCujczJix6jMpJcynoBiA 	 
    	  
    		   
    _385327363244837678  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     static_cast mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		  mCujczJix6jMpJcynoBiA 	 
    	  
    	mjxPa00ei9qkuuQmiGB3C 	 
    	  
    		   
  mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   _18062104616271777338.borderDistThres *  mnECjbnhLknZie3Z5iHP2 	 
    	  
    		   
     
 mSa4WnWih0z4lSo9RYUGU 	 
    	  
 _13182630212586469335.height mgkSwnYHQivQIpeAwgr20 	 
    	  
    		  mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
   mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
  	 
     maB_pNl4zuODt3oqXg9EB 	 
    	  
    		   
     
   mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	 size_t _13303058356268144138  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
   0 mftnbgRvzOIVyL93HyyWt 	 
  _13303058356268144138  mYI2nkSxgJHf1pY1PttV1 	 
    	  
    	 _6528263073538749848.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
     
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
   _13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
     mycwFs63h7Mi3ggRkMEVm 	 
   
     mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
   
        
         m_BNZbnU2Y1bOBnnPOF0b 	 
    	  
    		   
      mhxtTU7dvZHXCTSg8B8rx 	 
    	  
   size_t _13303058356268144199  mM3tRrWbRPqPOU3G4ShKT 	 0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     _13303058356268144199  mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   _6528263073538749848 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
   _13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 .size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   _13303058356268144199 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     
     
 
   mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
         mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   

             mJvv2tbrel2xOYjvgipUL 	 mmmC9tOGiLK6UaJr0E5vz 	 _6528263073538749848 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     
   _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	   mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
 _13303058356268144199 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
 .x  mYI2nkSxgJHf1pY1PttV1 	 
    	 _385327363244837679  mQfgxxEXCA984FTu8Jz8Q 	 
    	  
    		   
   _6528263073538749848 mFyKKLtdivGGDlk8sYzsf 	_13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
  mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
_13303058356268144199 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
   .y  mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
  _385327363244837678
                     mRawsH1LNxMcHXhyroWR7 	 
  _6528263073538749848 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
     
 _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
     
 
  	 mTjppsgNpY1Pjyv5Z_zMr 	 
  _13303058356268144199 mIkhxhgSNMt_JUZR7ce1U 	 
    .x  mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
  _13182630212586469335.width - _385327363244837679
                     mfNhxMALMjy2jMKPPP3pN 	 
    	 _6528263073538749848 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 
 _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
 mdF98bHO7yrxGJn0aQZVK 	 _13303058356268144199 mbViqhyIcr6lGWibuo3Im 	 
    	 .y  mRHNkLPwUSnx20pmLgrTq 	 
    	  
    	 _13182630212586469335.height - _385327363244837678 mhyL_M5gnmQzwyHW45MdA 	 
    	  
             mfKhTg3wpiK_YhdQzWWcS 	 
    
                _7127668893958858208 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    _13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
     
 
   mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
  mqQspPZKCoa6LP0Jj0qH2 	 
    	  
    		   
     
     
 mriCvhMavpfheoLNc0eCD 	 
    	  
             mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     
 

         maCQ9r5fSln_CXgRXGFvO 	 
    	  
     mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
    

    
    vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
MarkerCandidate m_j6ZkbEfLCgUqtaolYTp 	 
    	  
     _2164298203324692274 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
   
    _2164298203324692274.reserve mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
  _6528263073538749848.size mzeHK1hG1SYQMISNMWMB8 	 
    	  mhyL_M5gnmQzwyHW45MdA 	 
    	  
    	 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
     moPdTa5HpJKbS1U6TqDjY 	 
    	  
    		   
     
     
size_t _13303058356268144138 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
 0 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   _13303058356268144138 mW1ds9XwNwevT5B2b3j8B 	_6528263073538749848.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
 _13303058356268144138 mcstdE8Wwpam6tUMM45Sa 	 
    	  
    		   
 mmCJ670wA_VHgip7JZ1dW 	 
    	  
  
         mwQUfI7G4pBH6IJQiBjmU 	 
    	  
    		   
  mFsSEF_3_iD2mT6nZG9QR 	 
    	 mRltbJjpZ8AzImbP6r6M4 	 
    	  
    		   
     
_7127668893958858208 mA4oXllup8K3T5dxkluRR 	 
    	  
   _13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
     
  mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
  	_2164298203324692274.push_back mSa4WnWih0z4lSo9RYUGU 	 
  _6528263073538749848 mNDJrNgMXB1tBoFNaJO0d 	 
    	_13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		    mhGXMe8LHJXydR9dMisHj 	 
    	  
    		 
     myYaYWcsrnLoe6SxorDYt 	 
    	  
    		   
     
     
 
  _2164298203324692274 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
  
 mJOnXqKm3GBylSdRjpXAA 	


 mwu5s8ye7pYEdPIYXjU5h 	 
    	  
    MarkerDetector_Impl mfx1fLYDWN4YRZNnQEsJN 	 
    	  
   _6617398332792794799 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     Mat &_16232574195069562408,std mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
     
 
  	 vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		 mglDNKH5ah89GptW6H4Cu 	 
    	  
    		   
  mjxPa00ei9qkuuQmiGB3C 	 
    	  
    		   
  &_3176948232212421105 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
    
 mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     mFrnvKb629IAbveEQOTJk 	 
  mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    		   
   _13303058356268144023 mif4ZCBkqdiqSYkR9AD0r 	 0 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
    _13303058356268144023 mK5OxIt23gZzSiTA8trU8 	 
    	  
 _16232574195069562408.rows mlqoNTA3LQoUJF6i5YDFc 	_13303058356268144023 mwwJvnj2j3yLmklxxOEJQ 	 
    	  
    		   
     
    mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
  mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
    
        uchar*_5268605234499577910 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		 _16232574195069562408.ptr mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  uchar mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
   mReDuVelSknxaDAoDEmwT 	 
    	  _13303058356268144023 muiDYQbmwLxL3PGrwWGeP 	 
     mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
         mFrnvKb629IAbveEQOTJk 	 
    	  
    		   
     
     
 
   mdbRZP7cWFYlUcaGRMsKc 	 
    _13303058356268144065 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
 
0 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
 _13303058356268144065 mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
     
 
  _16232574195069562408.cols mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 
  _13303058356268144065 mEZrtAN7pSZl5y4oEHd38 	 
  mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
  	
           _3176948232212421105 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
     
 
 _5268605234499577910 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     
     
 
  _13303058356268144065 mo8MRbS3DUX_ZOlgmUSna 	 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
     
  mt0bWs8kxCzTnBdtR9vKu 	 
    	  
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
  
     maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 mhl3Z6oGBbP13ZxehUcg9 	 
   

 mihBlyb7pwidO496a5_p1 	 
    	  
    		   MarkerDetector_Impl mYGfQUZmV9IjKAPVrLhZl 	 
    	  _5695532316837479313 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		  std mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
     
 
 vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	  mnECjbnhLknZie3Z5iHP2 	 
    	  
    		   
     
     
 
  mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
     
 
   &_3176948232212421105 mlqM0snvYcrWCw2_QjhQi 	 
    	  
 mDzQQrEx5Ki0C6uDHU2cy 	 
    	
     mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
    _5268611907573087124 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
0,_1677675503431562703 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
  	 
     ma9rnYFEs_TUiw_WyBflg 	 
     mjc_6rRmys9smvg_opA48 	 
    	  
    		   
     
_13303058356268144199:_3176948232212421105 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
     _5268611907573087124 mYwsOAvDOXneTzOST0d5c 	 
    	  
    		   
   _13303058356268144199 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
   
    _1677675503431562703 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   1./_5268611907573087124 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
    
     mhXXYzAVu3lDYyh7TkRWq 	 
    	  
   myYAiLHDT3JvFKUJCC_FN 	 
    	  
    		   
     
     
&_13303058356268144199:_3176948232212421105 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     _13303058356268144199 meZ135JJTidHY5m2MSApS 	 
    	  
    		   
  _1677675503431562703 mxdAvfSsdzliezc0uyUMk 	 
    	  
   

     maISPbNJKXWB2QqsuuExM 	 
    	  _17126222195760917357 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
 0 mftnbgRvzOIVyL93HyyWt 	 

     mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
     
     
_12512858585554741740 mu_nOcTFwUo8r0uNE351R 	 
    	 -1 mJTScPpWt8plE9Cz9fDU6 	 
    	  
   
     mVRbVdVjFvNmKzGv4WiNp 	 
  mSD7jHYN8mOif4_CBtIg6 	 
    	_13303058356268144077 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     1 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
  _13303058356268144077 mca1GaR7Rv9qOZsisqKBB 	 
    	  
  256 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
_13303058356268144077 mt0bWs8kxCzTnBdtR9vKu 	 
    	  
    		   
     
     
 
  	  mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     mMRNM5hfPBWFjYCspldu3 	
         mYKwa_OYBeVXzRPMa_mz6 	 
    	  
 _16232574195069208184 muQdV4OJL6V6gVxW6AdRy 	 
  0,_16232574195069208185 mdKhcOUXVqyCMdccisL_a 	 
  0,_15915682081708138341 mRwjoMr_aqph4iL4nu8NS 	 
    	0,_15915682081708138340 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
 
  	 0 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    
         mwkUVn0D8pUxgFq_rx20G 	 
    	  
    		 mCujczJix6jMpJcynoBiA 	 
    	  
    	_13303058356268144079 mdKhcOUXVqyCMdccisL_a 	0 mftnbgRvzOIVyL93HyyWt 	 
    	  
 _13303058356268144079 mYfYoOWdsOLTDCIBT7npX 	 
    	  
    	_13303058356268144077 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 
  	 _13303058356268144079 mwwJvnj2j3yLmklxxOEJQ 	 
    	  
    	 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     

            _16232574195069208184 mIzujDpHjrUPsW3ssOAji 	 
    	  
    		   
     
     
 
 _3176948232212421105 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     
     
 
 _13303058356268144079 mEFd2D2UDF9SIoPfQtUv6 	 
    	   mriCvhMavpfheoLNc0eCD 	 
    	  
    
            _15915682081708138341 mCAk2bmH5F7oeetankJLO 	 mnECjbnhLknZie3Z5iHP2 	 
    	  
    		   
     
mReDuVelSknxaDAoDEmwT 	 
    	_13303058356268144079 muiDYQbmwLxL3PGrwWGeP 	*_3176948232212421105 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
    _13303058356268144079 mIkhxhgSNMt_JUZR7ce1U 	 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
   
         mnSkEvR4SbDwQxj23xB1M 	 
    	
         mF9AQyKXtPTPy1zvAUpED 	 
    	  
    		   
     
      mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   
     
     _13303058356268144079 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
    _13303058356268144077 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		_13303058356268144079 mCALzjQ0bwpDnngl_oSsi 	 
    	 256 mINcNsH05D0QZDej9wl4h 	 
    	  
    		 _13303058356268144079 mnlCUtQ6kn1Qc7HkEzE0c 	 
    	  mycwFs63h7Mi3ggRkMEVm 	 
    mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
            _16232574195069208185 mce_8CnsU6ESSZfDxaV3C 	 
    	  
 _3176948232212421105 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
_13303058356268144079 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
     mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
  
            _15915682081708138340 mCAk2bmH5F7oeetankJLO 	 
    	_3176948232212421105 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     
 
  _13303058356268144079 mrpQVzv6u8gxvho1qUlil 	 
    	  
   *float mp3H4249LtCVDCYFqQqz4 	 
    	  _13303058356268144079 mgkSwnYHQivQIpeAwgr20 	 
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 

         maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 
  
         mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    		   
     
     mhxtTU7dvZHXCTSg8B8rx 	 _16232574195069208184 mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
     
 
  	 1e-4  mECamByxBqjGyTShbPlRQ 	 
    	  
    		   
    _16232574195069208185 mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
1e-4 mycwFs63h7Mi3ggRkMEVm 	 
    	  mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		
            _15915682081708138341 mmhvewuTDMRQuh4yozZj0 	 
    	  
    		   
     
     
 
  	 _16232574195069208184 mhGXMe8LHJXydR9dMisHj 	 
   
            _15915682081708138340 mC854TxsErP91YgtWBjLs 	 
    	  _16232574195069208185 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
  
             mI_QuD605u2H3qQFyuTju 	 
    	  
    		   
 _5268608556792470480 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
  	_16232574195069208184*_16232574195069208185* miAECMSxGwjxrcOKk0DII 	 
   _15915682081708138341-_15915682081708138340 muiDYQbmwLxL3PGrwWGeP 	 
   * mp3H4249LtCVDCYFqQqz4 	_15915682081708138341-_15915682081708138340 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
            
             mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    		  mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
 _5268608556792470480 mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
 _17126222195760917357 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
      mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
     
 

                _17126222195760917357 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
    _5268608556792470480 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
    
                _12512858585554741740 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
 _13303058356268144077 mriCvhMavpfheoLNc0eCD 	 
  
             mDUyr1RAsHMG7u1BeTW3F 	 
    	  
         mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
   

     mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
     
 
  
     mLfKYVMLDthbyvvLerNPJ 	 
    	  
  _12512858585554741740 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    
 mbYMUxVFybbviIFqRhN2f 	 
    	  
    	

 mQk9KGg1kmiZQnIZzbOuE 	 
    	  MarkerDetector_Impl myuwTFtkH1L5Be2OVY9rt 	 
    	  
  detect mhORIPgMIfN3Fn8aCQBuU 	 
   const cv maKLz6mCz5anFyVle_MtD 	 
   Mat& _17276638435886805939, vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   Marker m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
 & _17726690318409070815, Mat _2920695669964880276, Mat _14932605280544191270,
                             mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		   _3145974845315888936,  mU8SToe5QpPWgY0z9QAcm 	 
   _606330642723070475 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
  
 mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		  
    
    _17726690318409070815.clear mFwk30320retpLBiICndp 	 
    mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
  
    _8381292230366782771.clear mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 

    _3822229300092794986.clear mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
     
 
  	 mPdHdcAZ6XJhwf8wLtULI 	 
 


    
     mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
  mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
 _17276638435886805939.type mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
    mZVOYp2JAGvUM7UPbzd3Q 	 
  CV_8UC3 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    
        cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
    cvtColor mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
_17276638435886805939,_5695532303110145495,CV_BGR2GRAY muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 mdmuaUz9iCkCckSUhcEv1 	
    
     mnkTvEdpCXelpIHLLqQno 	 
    	  
   _5695532303110145495  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
     _17276638435886805939 mriCvhMavpfheoLNc0eCD 	 


    
    
    
     mYKwa_OYBeVXzRPMa_mz6 	 
    	  
    		   
     
  _13068154224003753843 ma6VjqdfajK4BX9gkoGiD 	 
    	  
1 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    
    
    cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   Mat _14658983814685479377  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     

         cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
     
 
  Size _17451659640061119372 mdKhcOUXVqyCMdccisL_a 	 
    	_5695532303110145495.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		   
     
   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
    
         myYAiLHDT3JvFKUJCC_FN 	 
    _244032483434193613 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   _13365150943186347431 mFsSEF_3_iD2mT6nZG9QR 	 
    	 _17276638435886805939.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
   mgkSwnYHQivQIpeAwgr20 	 
    	  
     mJTScPpWt8plE9Cz9fDU6 	 
    	  
    	
         mwQUfI7G4pBH6IJQiBjmU 	 
    	  
    		   
     
   mp3H4249LtCVDCYFqQqz4 	 
    	  
    		 _18062104616271777338.lowResMarkerSize mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
  _244032483434193613   mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
   mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    
            _13068154224003753843 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    mYKwa_OYBeVXzRPMa_mz6 	 
    	  
    		   
     
     mFlVjO0mLpwnCN5a1Quio 	_18062104616271777338.lowResMarkerSize mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
  	 /float mReDuVelSknxaDAoDEmwT 	_244032483434193613   mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
   mINcNsH05D0QZDej9wl4h 	 
    	
             mUFzn4yJGA8c9qnEcb9dH 	 
    	  
    		   
     
     
  mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
  _13068154224003753843 mYfYoOWdsOLTDCIBT7npX 	 
    	  
 0.9 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
    mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
                _17451659640061119372.width mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
      mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
     
mSa4WnWih0z4lSo9RYUGU 	_5695532303110145495.cols mzf4ZxeZY8wF2XnrdYK61 	 
 *_13068154224003753843+0.5 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 

                _17451659640061119372.height mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
  maOczvhF_v9OTsK70ZZut 	 
    	  
    		   
     
    miAECMSxGwjxrcOKk0DII 	 
    	  
_5695532303110145495.rows msubWq7nTVSPilWqmTzkx 	*_13068154224003753843+0.5 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
 
                 mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     
     
 
 mFlVjO0mLpwnCN5a1Quio 	 
    	  
 _17451659640061119372.width%2 mpi20hzA7RnQ_cRlycwva 	 
    	  
 0 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
 _17451659640061119372.width mi940TUip6nLdi0tWD33F 	 
    	  
    mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    
                 mRzhpvoeHZK7yCqqzYDDp 	 
    	  
     mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
      _17451659640061119372.height%2 ma43zKzGwyDT5C3mNdj6s 	 
    	  
    		   
     
     
 
  	0 mgkSwnYHQivQIpeAwgr20 	 
    	  
    	 _17451659640061119372.height mo7mKuzaX2h9vw2rEj5qh 	 
    	  
    		   
     
     mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
   
                cv mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 
  resize mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
_5695532303110145495,_14658983814685479377,_17451659640061119372,0,0,cv mdssZV6TB06aiisDwN1cX 	 
    INTER_NEAREST mhyL_M5gnmQzwyHW45MdA 	 
   mxdAvfSsdzliezc0uyUMk 	 
    	  
  
                
             mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
 
         mDUyr1RAsHMG7u1BeTW3F 	 
    	  

      mXkfygpbRUCrOfJA4ktlP 	 
   _14658983814685479377.empty mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
      mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
 
        _14658983814685479377 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
 _5695532303110145495 mVOlbMaOu1U0SC2oeKIzP 	 
    	  

     mfySD3GO3N8Vw4agWXnxR 	 
 _129190561668282002 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
    mRrVhT0WkQauAZEUJHKOK 	 
    	  
   mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
 
    std mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   thread _12147666622506655697 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		 
     mwxm9pz2KjGAhBIIfFMf4 	 
    	  
    		   
   _129190561668282002 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
   mN0TszoCQmyzxmobsgV2H 	 
    	
         mJvv2tbrel2xOYjvgipUL 	 
    	  
  miAECMSxGwjxrcOKk0DII 	 
    	  
    		   _18062104616271777338.maxThreads mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   1 mzf4ZxeZY8wF2XnrdYK61 	 
   
            _12147666622506655697 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
 thread mFlVjO0mLpwnCN5a1Quio 	 
    	  
  mY2nz8M_6jpSxQZL8EYgU 	 
    	 & msdqcdg5NNrdQnc_PT1Ee 	 
    	  
  mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   _11672520815028075718 mFlVjO0mLpwnCN5a1Quio 	 
    	  
   _14234691456098337398,_5695532303110145495 ,2*_2048331705952164624 mKpq3GwvJxRduE5RsGgGP 	 
    	  
    		   
     
  mgkSwnYHQivQIpeAwgr20 	 
  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    	 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
  	
         mUwTrZwI1VfAXDN69k3UA 	 
    	  
    		   
     _11672520815028075718 mFlVjO0mLpwnCN5a1Quio 	 
   _14234691456098337398,_5695532303110145495,2*_2048331705952164624 mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
  mhGXMe8LHJXydR9dMisHj 	
     mgjPImSFwUcUKl9XTKqqB 	
     mUwTrZwI1VfAXDN69k3UA 	 
    	  
    	mjbtcSgN5ZQfkGDsoYG4l 	 

        _14234691456098337398.resize mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 1 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
 mftnbgRvzOIVyL93HyyWt 	
        _14234691456098337398 mdF98bHO7yrxGJn0aQZVK 	 
    	  0 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     
  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
_5695532303110145495 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
  
     mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
  


     mdbRZP7cWFYlUcaGRMsKc 	 
    	  
    _12394504057001631557 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
0 mriCvhMavpfheoLNc0eCD 	 
  
     mHaUGkpJ3E2hPS8TahoVd 	 
    	  
    		   
     
     
 
_3576709793526977325 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
    mEzFcmvX0IX3FOucgCcVF 	 
    	  
    		   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
   
    std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
    vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
  mWokjWH0MHqyBOx4j0Oac 	 
    	  
    		   
     
     
 
  	 mRHNkLPwUSnx20pmLgrTq 	 
    	  
   _3176948232212421105 mReDuVelSknxaDAoDEmwT 	 256,0 mgkSwnYHQivQIpeAwgr20 	 
    	  mdmuaUz9iCkCckSUhcEv1 	 
    	
    do mnU2hwoI16_nZ7reLKJTr 	 

        
        
        
        vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
     
 MarkerCandidate mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    _6528263073538749848 mPdHdcAZ6XJhwf8wLtULI 	 
    	  

        _6528263073538749848 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
 _11288135742209909849 mReDuVelSknxaDAoDEmwT 	 
  _14658983814685479377  mlqM0snvYcrWCw2_QjhQi 	 
    	   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		  
        _11052496863352632219     mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 
_16594497104544919971 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
    0 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		    mhGXMe8LHJXydR9dMisHj 	 
    	  
    		



        

        _6528263073538749848 mRwjoMr_aqph4iL4nu8NS 	 
    	  
   _17990657514663812703 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
 _6528263073538749848,_14658983814685479377.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
      mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     


        
         mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
      miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
 _12147666622506655697.joinable mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
    mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    
            _12147666622506655697.join mKpq3GwvJxRduE5RsGgGP 	 
    	   mxdAvfSsdzliezc0uyUMk 	 
 


        
        
        

        
         myYAiLHDT3JvFKUJCC_FN 	 
 _16638475367102933605 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
  _2048331705952164624 mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
    mdmuaUz9iCkCckSUhcEv1 	 
    	  
    	

        _17726690318409070815.clear mH1xQMRmYb0Y4RDp2hARz 	 
     mVOlbMaOu1U0SC2oeKIzP 	 
    	  
 
        _3822229300092794986.clear mKpq3GwvJxRduE5RsGgGP 	 
    	  
    		   
     
     mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
    
         moPdTa5HpJKbS1U6TqDjY 	 
    	  
    		   
 m_6hetAMDOSYN9CmiL4W7 	 
    	  
    		   
  &_13303058356268144200:_3176948232212421105 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
      _13303058356268144200 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    	0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  
         mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		   
     
     
 
 _4389716511175480620  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
   std mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 
pow mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
  static_cast mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     
  maOczvhF_v9OTsK70ZZut 	 
    	  
    		   
 m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		    mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     _16638475367102933605 mmCJ670wA_VHgip7JZ1dW 	 
   , 2.f mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
 mlqoNTA3LQoUJF6i5YDFc 	 
    	  

         mtvEQgcnwdOR4zAMwLHDb 	  mReDuVelSknxaDAoDEmwT 	size_t _13303058356268144138  mKcKHr_bTagXAK_pf8btG 	 
    	 0 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
 _13303058356268144138  mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    	 _6528263073538749848.size mH1xQMRmYb0Y4RDp2hARz 	 
    	  
  mJTScPpWt8plE9Cz9fDU6 	 
    	  
 _13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
    mzf4ZxeZY8wF2XnrdYK61 	 
    	  
   
         mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
    
            
            cv mpJt2kGThF7wb3VNzG38b 	 
    	  
    	Mat _15992684031433922312,_10663945753493258003 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
    

            cv mpJt2kGThF7wb3VNzG38b 	 
    	  Mat _4885984703856395612 mu_nOcTFwUo8r0uNE351R 	 
    	_14658983814685479377 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
            MarkerCandidate _2464785045917898834  ma6VjqdfajK4BX9gkoGiD 	 _6528263073538749848 mZnfmoDANjVLDjZfzM5MR 	_13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 
    	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
             mJvv2tbrel2xOYjvgipUL 	 
    	  
    	 miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
 _129190561668282002 mhyL_M5gnmQzwyHW45MdA 	 
    	  
  mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
     
     
 
 
                
                
                
                size_t _8260498189655844414  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
      0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   
                 m_owRLEm0gIJ4StPRwTkZ 	 
    	  
    		   
     
     
 mSa4WnWih0z4lSo9RYUGU 	 
    	  size_t _13303058356268144073  mKcKHr_bTagXAK_pf8btG 	 
   1 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
    _13303058356268144073  mYfYoOWdsOLTDCIBT7npX 	 _14234691456098337398.size mKpq3GwvJxRduE5RsGgGP 	 
    	  
    mhGXMe8LHJXydR9dMisHj 	 
    	  
    	 _13303058356268144073 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
                 mT_x8cqp5t43PgqNMR8gO 	 
    	  
   
                     mwQUfI7G4pBH6IJQiBjmU 	 
    	  
    		   
      miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
  _6528263073538749848 mA4oXllup8K3T5dxkluRR 	 
    	  
    		  _13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
 
  	.getArea mH1xQMRmYb0Y4RDp2hARz 	 
    	  / pow mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     4, _13303058356268144073 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   mij4fDpzx7A1fAEkEKDEN 	 
    	  
    		   
     
     
 
  	 _4389716511175480620 muiDYQbmwLxL3PGrwWGeP 	 
  _8260498189655844414  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
  _13303058356268144073 mINcNsH05D0QZDej9wl4h 	 
    	  

                     mFK5JCwqLjSVNjbuFv1Xz 	 
    	  
    		   
     
     
 
  	  mpDI48gcBVmyAktanjCOQ 	mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   

                 mbYMUxVFybbviIFqRhN2f 	 
    	  
   
                _4885984703856395612 muQdV4OJL6V6gVxW6AdRy 	 
    _14234691456098337398 mWkGo8xUdRIKgJ1DEUvvn 	 
    _8260498189655844414 mbViqhyIcr6lGWibuo3Im 	 
   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
                
                 mnqZGwZqTTi1dekKxujAE 	 
   _12315412216670737167 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    maISPbNJKXWB2QqsuuExM 	 
    	  
    		   
     
    mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     _4885984703856395612.cols mhyL_M5gnmQzwyHW45MdA 	 
    	  
    /float miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
    _14658983814685479377.cols mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    
                 m_owRLEm0gIJ4StPRwTkZ 	 
    	  
    		   
     
      mhORIPgMIfN3Fn8aCQBuU 	 
  auto& _13303058356268144073 : _2464785045917898834 mycwFs63h7Mi3ggRkMEVm 	   _13303058356268144073  mYPzKChOwisp1u2IoCgxk 	 
    	  
    		   
   _12315412216670737167 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     

             mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
     
 
  	
            warp mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
 _4885984703856395612, _15992684031433922312,  Size mp3H4249LtCVDCYFqQqz4 	 
    	  
 _16638475367102933605,_16638475367102933605 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 ,_2464785045917898834 msubWq7nTVSPilWqmTzkx 	  mJTScPpWt8plE9Cz9fDU6 	 

             meWm4MhzbcJwavtoh469w 	 
    	  
    		   
     
   _16232574195069562653, _2394613391546474355 mriCvhMavpfheoLNc0eCD 	 
   
             mPBSejyyYBZX7KoLjIvqq 	 
    	  
    		 _5268605234497773616,_5268608555081593998 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
   
            cv mpJt2kGThF7wb3VNzG38b 	 
    	  
    minMaxIdx mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
    _15992684031433922312,&_5268605234497773616,&_5268608555081593998 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     

            _15992684031433922312.copyTo miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
    _10663945753493258003 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    	 mhGXMe8LHJXydR9dMisHj 	
            string _13962554610986522386 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 

             mwQUfI7G4pBH6IJQiBjmU 	 
    	  
    		   
     
     
 
 mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     _4383831888714590158 mnt0Yxwh2kXjuvEydiY6Z 	 
    	  
    		   
     
     
 
detect mhxtTU7dvZHXCTSg8B8rx 	 
    	  
  _10663945753493258003, _16232574195069562653, _2394613391546474355,_13962554610986522386 msubWq7nTVSPilWqmTzkx 	 
    	  
    		 mzf4ZxeZY8wF2XnrdYK61 	 
    
             mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
                _17726690318409070815.push_back mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
  _6528263073538749848 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
     
 _13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
     msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
  mPdHdcAZ6XJhwf8wLtULI 	 
    	 
                _17726690318409070815.back mKpq3GwvJxRduE5RsGgGP 	 
    	 .id  ma6VjqdfajK4BX9gkoGiD 	 
    	 _16232574195069562653 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		
                _17726690318409070815.back mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
     
 
  .dict_info mdKhcOUXVqyCMdccisL_a 	 
    	  
    		 _13962554610986522386 mJTScPpWt8plE9Cz9fDU6 	 
    	  

                _17726690318409070815.back mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    .contourPoints muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
 
  _6528263073538749848 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
   _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
 .contourPoints mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
    
                
                std mdssZV6TB06aiisDwN1cX 	 
    	 rotate mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
  _17726690318409070815.back mKpq3GwvJxRduE5RsGgGP 	 
    	  
    		   
     
.begin mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   
     
     
 
  	 ,
                            _17726690318409070815.back mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
     
 
.begin mwTQhkbVNQHd2Xw4EA4fj 	 
 + 4 - _2394613391546474355,
                            _17726690318409070815.back mFwk30320retpLBiICndp 	 
    	 .end mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
     
 
  	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     mINcNsH05D0QZDej9wl4h 	 
    	  
   
                 mMNJIG0z6TLGgbjrhllmy 	 
    	  
    		   
     
     
 
   mp3H4249LtCVDCYFqQqz4 	 
    	 _18062104616271777338.thresMethod mnZ6t3BhMZ_1d7zzE72ah 	 
    	  
    		   
     
   MarkerDetector maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
     
 
  	 THRES_AUTO_FIXED muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
                    _6617398332792794799 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  	_15992684031433922312,_3176948232212421105 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
    mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
    
             mCvAz6nTbqhvwRULRgKe4 	 
    	  
    	
             mv1ijGQAKacWqWAusY8nc 	 
    	   mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     
 

                 _3822229300092794986.push_back mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
_6528263073538749848 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
      mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
  	 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     

             maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
   

         mhl3Z6oGBbP13ZxehUcg9 	 
    	  

         mEwOO8zzJcEkF96gfFa1e 	 
    	 mhxtTU7dvZHXCTSg8B8rx 	 _17726690318409070815.size maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     mYsjCP2nXqW2Jls3JAUkc 	 
    	  
    		 0  mBJ7M0ikk98KhD4Oi32wB 	 
     _18062104616271777338.thresMethod mi0dc2wlXgNoHf9VPli9f 	 
    	  
    		   
     
     
 
MarkerDetector myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
  THRES_AUTO_FIXED  mBJ7M0ikk98KhD4Oi32wB 	 
    	  
    		   
     
       mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     
     
 
  	 _12394504057001631557  mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
 _18062104616271777338.NAttemptsAutoThresFix mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
   mMRNM5hfPBWFjYCspldu3 	 
    	  
  
            _18062104616271777338.ThresHold mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
    10+ rand mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
  %230  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  	 
            _3576709793526977325 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     mgor9wB6mrVARR8vJt7rC 	 
    	  
    		   
     
   mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
    
         mICILgDpdCTDSJqQAn06L 	 
    	  
         mUwTrZwI1VfAXDN69k3UA 	 
    	  
    		  _3576709793526977325 mKcKHr_bTagXAK_pf8btG 	 
    	  
  me9YsE5_K5dlCgWRVtztQ 	 
    	  
    		mPdHdcAZ6XJhwf8wLtULI 	 
   
     mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
     
 
while mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
_3576709793526977325 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
    mxdAvfSsdzliezc0uyUMk 	 
    	  
    

  


     mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     
     
 
  	 mhxtTU7dvZHXCTSg8B8rx 	 
  _18062104616271777338.thresMethod mi0dc2wlXgNoHf9VPli9f 	 
    	  
    		   
  MarkerDetector mfx1fLYDWN4YRZNnQEsJN 	 
 THRES_AUTO_FIXED mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		  mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
   
         meWm4MhzbcJwavtoh469w 	 
    	 _10168097341276716268 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
 _5695532316837479313 mSa4WnWih0z4lSo9RYUGU 	 
    	  
_3176948232212421105 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
      mPdHdcAZ6XJhwf8wLtULI 	 
    mhGXMe8LHJXydR9dMisHj 	 
    	  
    	
         mXkfygpbRUCrOfJA4ktlP 	 _10168097341276716268 mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    0 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
  
            _18062104616271777338.ThresHold mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   maOczvhF_v9OTsK70ZZut 	 
    	  
    		mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		  _10168097341276716268 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
  	   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
 
     mJOnXqKm3GBylSdRjpXAA 	 
    

#ifdef debug_lines
    cv mU808frSKQDZnEEU3Q3s9 	 
 imshow miAECMSxGwjxrcOKk0DII 	 
    	  "\x5c\x78\x36\x39\x5c\x78\x36\x64\x5c\x78\x36\x31\x5c\x78\x36\x37\x5c\x78\x36\x35\x5c\x78\x32\x64\x5c\x78\x36\x63\x5c\x78\x36\x39\x5c\x78\x36\x65\x5c\x78\x36\x35\x5c\x78\x37\x33",image mycwFs63h7Mi3ggRkMEVm 	 
    	  
    	 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    
    cv mU808frSKQDZnEEU3Q3s9 	 
    	  
 waitKey mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
  10 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
   mJTScPpWt8plE9Cz9fDU6 	 
 
#endif
    
     mWHxIxEh8g9mg3Hyipn8D 	 
    	  
     mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
_17276638435886805939.cols muOzaq9SXefX6wOasanyX 	_14658983814685479377.cols mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		  mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     
 

        _14028278894506040778 mSa4WnWih0z4lSo9RYUGU 	_17726690318409070815,_14658983814685479377.size mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
      muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     mhGXMe8LHJXydR9dMisHj 	 
    	  
  
     mDUyr1RAsHMG7u1BeTW3F 	 
    	  



    
    
    


     mikiSyOnVry6pvQ1Ds28H 	 
    	  
    		   _18062104616271777338.trackingMinDetections mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     0      msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
   mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     


        
        
         mVRbVdVjFvNmKzGv4WiNp 	 
    	  
    		   
     
     
 m_6hetAMDOSYN9CmiL4W7 	 
    	&_16232574195041803256:_10242768842256594623 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
  mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		  
             moRHJd8MnQc4OOt6sDvUk 	 
    	  
    std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
  find mtbP4KQJdh36UGELfV2zq 	 
    	  
    _17726690318409070815.begin mdWkXjuaPd4Se0r0SdY1e 	 
    	  
,_17726690318409070815.end mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
,Marker mtbP4KQJdh36UGELfV2zq 	 
    	  
    		  _16232574195041803256.first muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     mPlk6hpBhStcHkX9pfoTY 	 _17726690318409070815.end mzeHK1hG1SYQMISNMWMB8 	 
    muiDYQbmwLxL3PGrwWGeP 	 
    	  
    
                       _16232574195041803256.second mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
     std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    max mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
  _16232574195041803256.second-1,0 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    	 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   

         mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
  

        
        std mdssZV6TB06aiisDwN1cX 	 
    	vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
Marker mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
     
 
  	 _2206836681894751447 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 

         ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   mvAxy99EwaX0EkXFRf6SN 	_13303058356268144134:_6872264293741719360 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
   mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    	
             mX_x9bVx2zqKO8c2FxqgZ 	 std mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
     
     
find mReDuVelSknxaDAoDEmwT 	 
    	  
    		   _17726690318409070815.begin mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
    ,_17726690318409070815.end mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
    ,Marker mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
 
  	_13303058356268144134.id muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
    mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
      maDn6NcmB5JPmBvJglMEd 	 _17726690318409070815.end maHkatHu0Jap4oTaT5q4_ 	 
    	  mlqM0snvYcrWCw2_QjhQi 	 
    	 mT_x8cqp5t43PgqNMR8gO 	 

                 mVHGLK1C5RNdKdXzDgMZU 	 
    	  
    		   
     
     
 
  	_10242768842256594623.count mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  	_13303058356268144134.id mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
      mZk2lUQMDVDhOLQdg9s92 	 
   0 mycwFs63h7Mi3ggRkMEVm 	 mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     
 
  
                     mBuRRlPSkgfIqW4MkJEkn 	 
    	  
    		_10242768842256594623.at mp3H4249LtCVDCYFqQqz4 	_13303058356268144134.id mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
   moE42zHNBVjnlCdllZAkS 	 
    	  
    		   
 _18062104616271777338.trackingMinDetections mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
 
                        _2206836681894751447.push_back mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
 
 _13303058356268144134 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
      mxdAvfSsdzliezc0uyUMk 	
                 mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
     
 
 
             mhl3Z6oGBbP13ZxehUcg9 	 
    	  

         mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
    

        
         mX_x9bVx2zqKO8c2FxqgZ 	 
    	  
    		   
     
     
 
  	_2206836681894751447.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
     
 mEc9zv3P8LW8haIvtztwe 	 
    	  
  0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
   mN0TszoCQmyzxmobsgV2H 	 
    
             mmB6x9VkGrq_qpFtMKL7A 	 
    	  
    		_16807308463767004315 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		  
                _16807308463767004315 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
const Marker &_13303058356268144134 msubWq7nTVSPilWqmTzkx 	 
    	  
  mLdYY4X2b7VOjtTSnd7Hj 	 

                    _12469364278809815631._2329825236964917351 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
  _13303058356268144134 mXAYJa6osZ6HNTIEEBnr0 	 
   mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
    
                 muuG2jhk4iNsA9KNmj6oA 	 
    	
                _4191776636076832364 _12469364278809815631 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
  	
                 mCujczJix6jMpJcynoBiA 	 
   _3412165392495317931 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
 
 -1 mINcNsH05D0QZDej9wl4h 	 
    	  
    		 
                 mvfKgFvXHh0Jqv_PZxbka 	 
    	  
    		   
     
    _17998515892213527232 myJHqW7fkn_72nVEhKeZ6 	std mpJt2kGThF7wb3VNzG38b 	 numeric_limits mYfYoOWdsOLTDCIBT7npX 	 
    	  
  mPBSejyyYBZX7KoLjIvqq 	 
    	  
    		   
     
   mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		    mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
     max mFwk30320retpLBiICndp 	 
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		 
             mDUyr1RAsHMG7u1BeTW3F 	 
    mJTScPpWt8plE9Cz9fDU6 	 

            std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
     
 
  	map mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
  int,_16807308463767004315 m_j6ZkbEfLCgUqtaolYTp 	 
    	  
 _5298924430305139424 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		
             mVRbVdVjFvNmKzGv4WiNp 	 
    	  mgxs4jaOm5WhsuDH7hsbo 	 
    	  
    		 &_5268605234514274795:_2206836681894751447 muiDYQbmwLxL3PGrwWGeP 	 

                _5298924430305139424.insert mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
  mJkMyi0NbVRDgE__LMR_m 	_5268605234514274795.id,_16807308463767004315 mFsSEF_3_iD2mT6nZG9QR 	 
    	 _5268605234514274795 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
   muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
 mftnbgRvzOIVyL93HyyWt 	 
    

             ma9rnYFEs_TUiw_WyBflg 	 
    	  
    		   
     
     
 
  	 size_t _3175967376861678913 mM3tRrWbRPqPOU3G4ShKT 	 
   0 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
 _3175967376861678913 mqEAvVDOCXqrrwrTRByrM 	 
    	 _3822229300092794986.size mbHCSQc_uaLNP9Sf4Lz_n 	 
   mVOlbMaOu1U0SC2oeKIzP 	 
_3175967376861678913 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
     
     
 
  mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
  	  mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
     
     
                 moNuUrvhPRwgFBZS8fSa1 	 
    	 &_3176948352186414039 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    	_3822229300092794986 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     
 
  _3175967376861678913 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
    mdmuaUz9iCkCckSUhcEv1 	 
 
                _4191776636076832364 _4970544023979479897 mlqoNTA3LQoUJF6i5YDFc 	
                _4970544023979479897._2329825236964917351 mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    	_3176948352186414039 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
                 ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   
     
   mZHJfF8VODcHrGq0YEwM_ 	 
    	  
    		   
     
&_5268605234514277940:_5298924430305139424 msubWq7nTVSPilWqmTzkx 	 
  mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     
 
  	
                     mVHGLK1C5RNdKdXzDgMZU 	 
    	  
    		   
  _5268605234514277940.second._12469364278809815631._14033480569961022451 mp3H4249LtCVDCYFqQqz4 	 
    	  
   _4970544023979479897._2320218127778479373 mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
    mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
  	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
  mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
 
                         mvAxy99EwaX0EkXFRf6SN 	 
    	 _3176008349054602175 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		norm mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
    _5268605234514277940.second._12469364278809815631._2320218127778479373 mH1xQMRmYb0Y4RDp2hARz 	 
    	 -_4970544023979479897._2320218127778479373 mf_hJsy06Me1epT4PRx_l 	 
    	  
     mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
      mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
 
                         m_6hetAMDOSYN9CmiL4W7 	 
    	  
    		   
    _6783445603442262432 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
  fabs mFsSEF_3_iD2mT6nZG9QR 	 
   _5268605234514277940.second._12469364278809815631._2462547792112398716 mH1xQMRmYb0Y4RDp2hARz 	-_4970544023979479897._2462547792112398716 mdWkXjuaPd4Se0r0SdY1e 	 
    muiDYQbmwLxL3PGrwWGeP 	 
    	  
 /_5268605234514277940.second._12469364278809815631._2462547792112398716 mf_hJsy06Me1epT4PRx_l 	 
    	   mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     

                         mikiSyOnVry6pvQ1Ds28H 	 
    	  
    		  _6783445603442262432 mca1GaR7Rv9qOZsisqKBB 	 
    0.3f  mKdH1o6rFuMJ1Fl0PA_sn 	 
    	  
 _3176008349054602175 mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
 _5268605234514277940.second._17998515892213527232 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		    mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   

                            _5268605234514277940.second._3412165392495317931 mM3tRrWbRPqPOU3G4ShKT 	static_cast mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
     
 
  	  mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		   
     
     
 mjxPa00ei9qkuuQmiGB3C 	 
    	  
  mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
   _3175967376861678913 msubWq7nTVSPilWqmTzkx 	 
    	  
     mxdAvfSsdzliezc0uyUMk 	 
    	  
    	
                            _5268605234514277940.second._17998515892213527232 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
_3176008349054602175 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
 
                         mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
     
                     mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
                 muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
             mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   
     
 

             miGFoFUQX5urgUZ1Rewwt 	 
    	  
    		   mHXoMWKZSiZYUvqmVkLF5 	 
    	  
    		   
     
     
&_5268605234514277940:_5298924430305139424 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
  mDzQQrEx5Ki0C6uDHU2cy 	 
  
                 moRHJd8MnQc4OOt6sDvUk 	 
    	  
     _5268605234514277940.second._3412165392495317931 mRuVXNtG32xpaNLi1hDLk 	 
    	  
    		   
     
  -1 mXAYJa6osZ6HNTIEEBnr0 	 
  continue mxdAvfSsdzliezc0uyUMk 	 
    
                 mgxs4jaOm5WhsuDH7hsbo 	 
    	  
  _16232574195069562600 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     
 
  find miAECMSxGwjxrcOKk0DII 	 
    	  
    		   _6872264293741719360.begin maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     
     
 
  ,_6872264293741719360.end mdWkXjuaPd4Se0r0SdY1e 	 
  ,Marker mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     
 
  _5268605234514277940.first mlqM0snvYcrWCw2_QjhQi 	  msubWq7nTVSPilWqmTzkx 	 
    	  
    		   mlqoNTA3LQoUJF6i5YDFc 	
                _17726690318409070815.push_back mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
    _3822229300092794986 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		  _5268605234514277940.second._3412165392495317931 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
      msubWq7nTVSPilWqmTzkx 	 
    	  
    		  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    	
                _17726690318409070815.back mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    	.id  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   _5268605234514277940.first mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
  
                _17726690318409070815.back mH1xQMRmYb0Y4RDp2hARz 	 
    	  .dict_info mif4ZCBkqdiqSYkR9AD0r 	 
     _16232574195069562600 mwBOm3LXJ8FMsqTgQKZ6O 	 
    	  
    		   
     
     
 
  	 dict_info mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  	
                _17726690318409070815.back mdWkXjuaPd4Se0r0SdY1e 	 
    	.contourPoints mRwjoMr_aqph4iL4nu8NS 	 
_3822229300092794986 mZnfmoDANjVLDjZfzM5MR 	 
 _5268605234514277940.second._3412165392495317931 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   .contourPoints mriCvhMavpfheoLNc0eCD 	 
    	  
    		 
                

                 mvAxy99EwaX0EkXFRf6SN 	 
    	  
    		   
 _4599602050392954662 mM3tRrWbRPqPOU3G4ShKT 	 
 mZnfmoDANjVLDjZfzM5MR 	 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
     
 
   mhxtTU7dvZHXCTSg8B8rx 	 
 const vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
  Point2f mEc9zv3P8LW8haIvtztwe 	 
    	  
    		    &_16232574195068577669,const vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
    Point2f mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
     
 
  	 &_16232574195068577668 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		 mDzQQrEx5Ki0C6uDHU2cy 	 
   
                    cv mdssZV6TB06aiisDwN1cX 	 
    	  
 Point2f _14899514829569383848 muQdV4OJL6V6gVxW6AdRy 	 
    	  
  _16232574195068577669 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 1 mDd5IIsnjfLI1lcygRsW3 	 
    	 -_16232574195068577669 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		 0 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 
 
                    _14899514829569383848 mt6CTIKlbWyEq7tYJENOL 	 
    	  
    		   
     
   1./cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    	norm mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
_14899514829569383848 muiDYQbmwLxL3PGrwWGeP 	 
    	   mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
   
                    cv mBBHVSlvDGP5NVUfEuhuf 	Point2f _14899514829569383863 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 
  _16232574195068577668 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
    1 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
   -_16232574195068577668 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
0 mbViqhyIcr6lGWibuo3Im 	 
    	  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		 
                    _14899514829569383863 mtBaSZn4xtaMpMhvfebM_ 	 
    	  
    		   
     1./cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
  norm miAECMSxGwjxrcOKk0DII 	 
 _14899514829569383863 mgkSwnYHQivQIpeAwgr20 	 
    	  
    	 mxdAvfSsdzliezc0uyUMk 	 
    	  
    	
                     mfFGohhJTv_x4m7UMdlWF 	 
    	  
    		   
     
     
 
  _14899514829569383848.dot mp3H4249LtCVDCYFqQqz4 	_14899514829569383863 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		 mINcNsH05D0QZDej9wl4h 	 
    	  
  
                 muuG2jhk4iNsA9KNmj6oA 	 
    	  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
  
                 mjc_6rRmys9smvg_opA48 	 
    	  
    		   
     
     
 
  	_3257892023090136996 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
  find mtbP4KQJdh36UGELfV2zq 	_6872264293741719360.begin mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		,_6872264293741719360.end mbHCSQc_uaLNP9Sf4Lz_n 	 ,Marker mmmC9tOGiLK6UaJr0E5vz 	 
_5268605234514277940.first mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
   mlqoNTA3LQoUJF6i5YDFc 	
                pair mK5OxIt23gZzSiTA8trU8 	 int, mVPyhnVeODFpKcj5PAnUM 	 
    	  
    		   
     
     
 
mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
  _9244962205788679909 mp3H4249LtCVDCYFqQqz4 	 
    	  
    -1,-1 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
  mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
  	 
                 ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   
     
    mdEzmAkZNQkKD1HrLnSSo 	 
    	  
_13303058356268144075 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
 0 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
  _13303058356268144075 mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	4 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 _13303058356268144075 mwwJvnj2j3yLmklxxOEJQ 	 
     mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
  mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
     
     
 

                    vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
     
Point2f mRHNkLPwUSnx20pmLgrTq 	 
  _5268608437323523861 muQdV4OJL6V6gVxW6AdRy 	 
    	  
   _17726690318409070815.back mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     mINcNsH05D0QZDej9wl4h 	 
    	  
    		 
                    std myuwTFtkH1L5Be2OVY9rt 	 
    	  
  rotate mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     _5268608437323523861 .begin mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    ,
                                _5268608437323523861 .begin maHkatHu0Jap4oTaT5q4_ 	 
    	  + _13303058356268144075,
                                _5268608437323523861 .end mzeHK1hG1SYQMISNMWMB8 	 
  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
   mJTScPpWt8plE9Cz9fDU6 	 
    	  

                     mgxs4jaOm5WhsuDH7hsbo 	 
    	  
  _5268611907568609837 mCm219F3DHVwNe_CsrCeK 	 
    	  
   _4599602050392954662 mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   *_3257892023090136996,_5268608437323523861 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
   
                     mX_x9bVx2zqKO8c2FxqgZ 	 
    	  
    		 _5268611907568609837 mYxohqgekcJ8HhaDZvWcX 	 
    	 _9244962205788679909.second mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
 mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
  
                        _9244962205788679909 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
     
 mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   _13303058356268144075,_5268611907568609837 mICILgDpdCTDSJqQAn06L 	 
    	 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
  	 
                     mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
                 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
    
                std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
     
 
rotate mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
    _17726690318409070815.back mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		    .begin mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
  ,
                            _17726690318409070815.back mcznTYeCGOAygtXXAPYS_ 	.begin mFwk30320retpLBiICndp 	 
    	  
    		   + _9244962205788679909.first,
                            _17726690318409070815.back mdWkXjuaPd4Se0r0SdY1e 	 
    	 .end mKpq3GwvJxRduE5RsGgGP 	 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     mftnbgRvzOIVyL93HyyWt 	 
    	  
   
                
                _3822229300092794986 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    	_5268605234514277940.second._3412165392495317931 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
   .clear maHkatHu0Jap4oTaT5q4_ 	 
    	  
     mPdHdcAZ6XJhwf8wLtULI 	 
   
             muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
     
     
 
  	
            
            _3822229300092794986.erase miAECMSxGwjxrcOKk0DII 	 
std mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
  remove_if mhORIPgMIfN3Fn8aCQBuU 	 
  _3822229300092794986.begin mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		   
     
    ,_3822229300092794986.end maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     ,  mZnfmoDANjVLDjZfzM5MR 	  mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
      mSa4WnWih0z4lSo9RYUGU 	 const vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     cv mYGfQUZmV9IjKAPVrLhZl 	Point2f mEc9zv3P8LW8haIvtztwe 	  &_13303058356268144134 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
  mfKhTg3wpiK_YhdQzWWcS 	 
    	  
   mLfKYVMLDthbyvvLerNPJ 	 
    	  
    		   
  _13303058356268144134.size mzeHK1hG1SYQMISNMWMB8 	 
 mgAgf2KiVOzOHJDU4qKPI 	 
0 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
   mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
  , _3822229300092794986.end mcznTYeCGOAygtXXAPYS_ 	 mAnDeXfeHaujEzGBbrjil 	  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
  

         mgjPImSFwUcUKl9XTKqqB 	
        
         ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   
     
 mgxs4jaOm5WhsuDH7hsbo 	 
    	  
    		   
 _13303058356268144134:_17726690318409070815 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		    mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
     
    
             mwxm9pz2KjGAhBIIfFMf4 	 
    	  
    		   
   _10242768842256594623.count mmmC9tOGiLK6UaJr0E5vz 	 
    	  
   _13303058356268144134.id mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		    mHOvg7vOJH6ujsVsg3S5G 	 
   0 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
   
                _10242768842256594623 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
     
     _13303058356268144134.id msdqcdg5NNrdQnc_PT1Ee 	 
     ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		1 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
  	 
             moT0JKxDJVSALTDfSRUYM 	 
    	  
    		   
     
   _10242768842256594623 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 
_13303058356268144134.id mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
      mkGHGzUDDVqHIjIdYGe6S 	 
    	 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
 
         mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   
    
     mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    	


    
    
    

     mBuRRlPSkgfIqW4MkJEkn 	 
    	  
    		   
     
     
 
  	1 mhyL_M5gnmQzwyHW45MdA 	 
    	  
 mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
    
    
    std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
     
     
 
  	sort mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    _17726690318409070815.begin mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     , _17726690318409070815.end mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		   
     
     
 
  mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
 mriCvhMavpfheoLNc0eCD 	 
    	

    
    
    vector mYI2nkSxgJHf1pY1PttV1 	 
    	   mm9xpbYUQ152i_zNBGUZu 	 
    	  
    		   
     
     
 mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
     
 
   _7127668893958858208 miAECMSxGwjxrcOKk0DII 	 
    	  
    		_17726690318409070815.size mFwk30320retpLBiICndp 	 ,  mHbmZNNhradVwUtDZ5U7B 	 
    	  
    		mmCJ670wA_VHgip7JZ1dW 	 
    	 mriCvhMavpfheoLNc0eCD 	 
 

     mLBxgVrVeq7bTUcDGJqNH 	 
     mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		 moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
     
 
  	_13303058356268144138  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
      0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
      _13303058356268144138  mCALzjQ0bwpDnngl_oSsi 	 
      mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    	mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
 _17726690318409070815.size mFwk30320retpLBiICndp 	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
 - 1 mJTScPpWt8plE9Cz9fDU6 	 
    	  
     _13303058356268144138 mUq8qfNXjDE9FPlMHvjf4 	 
    mgkSwnYHQivQIpeAwgr20 	 
    	  
     mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
         mtvEQgcnwdOR4zAMwLHDb 	 
 mmmC9tOGiLK6UaJr0E5vz 	 
 mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
     
   _13303058356268144139  mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   _13303058356268144138 + 1 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
  _13303058356268144139  mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
  _17726690318409070815.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    	 mhyL_M5gnmQzwyHW45MdA 	 
      mOR5gj7K3yTraJVOrvmKy 	 
    	  
    		   
     
       msFQPbyubcQTkvTYpFFPL 	 
    	  
   _7127668893958858208 mY2nz8M_6jpSxQZL8EYgU 	 
 _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
   _13303058356268144139 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    		   
    muiDYQbmwLxL3PGrwWGeP 	 
         mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		  
             mvw_MKiY3S1FcVNfJQCRT 	 
 miAECMSxGwjxrcOKk0DII 	 
 _17726690318409070815 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
 _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
 .id  maDn6NcmB5JPmBvJglMEd 	 
    	  
    		   
     
     
 
  	  _17726690318409070815 mWkGo8xUdRIKgJ1DEUvvn 	 
    	 _13303058356268144139 mwTp2D1d4PfxNNOzzUfhS 	 
    	  .id  mKdH1o6rFuMJ1Fl0PA_sn 	 
    	  
    		   
     
      _17726690318409070815 mA4oXllup8K3T5dxkluRR 	_13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
    .dict_info  mtPtbM6hNfOIkqlx661ci 	 
    	  
  _17726690318409070815 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     
 _13303058356268144139 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
  .dict_info mAnDeXfeHaujEzGBbrjil 	
             mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		
                
                 mEwOO8zzJcEkF96gfFa1e 	 
 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
   _16109434691388891984 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
_17726690318409070815 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
   mlqM0snvYcrWCw2_QjhQi 	  mHkLXuUOlyX2vZI7w3FQj 	 
    	   _16109434691388891984 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     _17726690318409070815 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
_13303058356268144139 mEFd2D2UDF9SIoPfQtUv6 	  msubWq7nTVSPilWqmTzkx 	 mXAYJa6osZ6HNTIEEBnr0 	 

                    _7127668893958858208 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     
 
_13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
 
    muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		     mgor9wB6mrVARR8vJt7rC 	 
    	  
    		mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
 
                else
                    _7127668893958858208 mZnfmoDANjVLDjZfzM5MR 	 _13303058356268144139 mUB1yrSrKOwldqxmCatN2 	 
    	  
    	  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		     mrYTPN06XEG4I2Q8GwVal 	 
    	mriCvhMavpfheoLNc0eCD 	 
    	  
    		   

             mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
     

         mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
     
     
 
  
     mJOnXqKm3GBylSdRjpXAA 	 
    	

    _17229649132943359639 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
     _17726690318409070815,_7127668893958858208 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		    mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     

     mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   


    
    
    
     
     mwQUfI7G4pBH6IJQiBjmU 	 
     mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
   _17726690318409070815.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
     
     
 
  	  mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
     
 
  	 0   moejXze8_C6TCxb2bIzgq 	 
    	  
    		   
      _17276638435886805939.size mf_hJsy06Me1epT4PRx_l 	 
    	  mPlk6hpBhStcHkX9pfoTY 	 
    	  
    		   
     
     
 _14658983814685479377.size maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     
     msubWq7nTVSPilWqmTzkx 	 
    	  
    	 mjbtcSgN5ZQfkGDsoYG4l 	 
    	

         mvw_MKiY3S1FcVNfJQCRT 	 
    	  
    		   
     
     
 
 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
  _18062104616271777338.cornerRefinementM maDn6NcmB5JPmBvJglMEd 	CORNER_SUBPIX   muiDYQbmwLxL3PGrwWGeP 	 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
 

             mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   _134566848691226369 mCm219F3DHVwNe_CsrCeK 	 
    	  
  4*float mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
_17276638435886805939.cols mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		 /float mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		_14658983814685479377.cols mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
  +0.5  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     

            vector mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		Point2f mjxPa00ei9qkuuQmiGB3C 	 
    	  _13861179168205423140 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
             mNMDyj9J1Nt8auTKwp8ze 	 
   mFsSEF_3_iD2mT6nZG9QR 	 
    	  
 unsigned  moI11mwtxiOXpqDxK_aQL 	 
    	  
    _13303058356268144138  mif4ZCBkqdiqSYkR9AD0r 	 
   0 mJTScPpWt8plE9Cz9fDU6 	  _13303058356268144138  mbG1GEmOdh2dXkJZ42sXo 	 
    	  _17726690318409070815.size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
   _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
 
                 mwzVPTpaJAiRC6bZKMfQX 	 
    	  
    	 mmmC9tOGiLK6UaJr0E5vz 	 
   moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
 _13303058356268144199  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
    0 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
      _13303058356268144199  mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
    4 mlqoNTA3LQoUJF6i5YDFc 	 _13303058356268144199 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    mhyL_M5gnmQzwyHW45MdA 	 
    	  
  
                    _13861179168205423140.push_back mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		_17726690318409070815 mY2nz8M_6jpSxQZL8EYgU 	 
_13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
  mWkGo8xUdRIKgJ1DEUvvn 	 
    	_13303058356268144199 mJtGCV8zXQjnVDVBVdvFZ 	  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		
            cornerSubPix mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
  	_5695532303110145495, _13861179168205423140, cv maKLz6mCz5anFyVle_MtD 	 
    	Size mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
_134566848691226369,_134566848691226369 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
, cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
 Size mhxtTU7dvZHXCTSg8B8rx 	 
 -1, -1 mlqM0snvYcrWCw2_QjhQi 	 
    	,cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
 TermCriteria mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
TermCriteria mYGfQUZmV9IjKAPVrLhZl 	 
    	 MAX_ITER | cv mpJt2kGThF7wb3VNzG38b 	 
    	  TermCriteria maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
     
 
  	EPS, 12, 0.005 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     msubWq7nTVSPilWqmTzkx 	 
    	  
 mftnbgRvzOIVyL93HyyWt 	 
    	  
            
             mtvEQgcnwdOR4zAMwLHDb 	 
    mp3H4249LtCVDCYFqQqz4 	 
    	  
 unsigned  mdbRZP7cWFYlUcaGRMsKc 	 
    _13303058356268144138  muQdV4OJL6V6gVxW6AdRy 	 
   0 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
 _13303058356268144138  mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
    _17726690318409070815.size mFwk30320retpLBiICndp 	 
    	  
 mdmuaUz9iCkCckSUhcEv1 	 _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 
    	  
    		    mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
    
                 mHIh6WyQKJh1ZKme1nslP 	 
    	  
    		   
      mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
   mMGij61UZUIIYyztVz9vN 	 
    	  
 _13303058356268144199  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
 
  	  0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    	 _13303058356268144199  mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
    4 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
    _13303058356268144199 mt0bWs8kxCzTnBdtR9vKu 	 
    	  
  msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
   
                    _17726690318409070815 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
    _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
    mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
 _13303058356268144199 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
       mCm219F3DHVwNe_CsrCeK 	 
    	  
 _13861179168205423140 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     _13303058356268144138 * 4 + _13303058356268144199 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		  mINcNsH05D0QZDej9wl4h 	 
    	  
    

         mgjPImSFwUcUKl9XTKqqB 	 
         mFK5JCwqLjSVNjbuFv1Xz 	 
   mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    		   
     
     
 
  mhxtTU7dvZHXCTSg8B8rx 	 
    	 _18062104616271777338.cornerRefinementM mtPtbM6hNfOIkqlx661ci 	 
    	  
    		   
     
     
 CORNER_LINES mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
   
            
             mNMDyj9J1Nt8auTKwp8ze 	 
    	  
    		   
 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		unsigned  mMGij61UZUIIYyztVz9vN 	 
    	  
  _13303058356268144138  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
    0 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		  _13303058356268144138  mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
 
  	  _17726690318409070815.size mFwk30320retpLBiICndp 	 
    	  
    		   
     mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     _13303058356268144138 mi940TUip6nLdi0tWD33F 	  mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 
                _10874168409609149361 miAECMSxGwjxrcOKk0DII 	_17726690318409070815 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
     
 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    mPdHdcAZ6XJhwf8wLtULI 	 
    	  
 
         mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		 
     mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
    





    
    
    

    
     mabeHDqoCFUg5Mty5oLni 	 
    	  
    		   
   mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
    _2920695669964880276.rows  mWUoD50tT9HFGBNQCsjUC 	 
 0  mECamByxBqjGyTShbPlRQ 	 
    	  
    		   
     
      _3145974845315888936  mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
     mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
  
         mNMDyj9J1Nt8auTKwp8ze 	 
    	  
    		   
     
     
 
 mhxtTU7dvZHXCTSg8B8rx 	 
    unsigned  meWm4MhzbcJwavtoh469w 	 
_13303058356268144138  mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
  0 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		  _13303058356268144138  mbG1GEmOdh2dXkJZ42sXo 	 
    	  
  _17726690318409070815.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
  _13303058356268144138 mcstdE8Wwpam6tUMM45Sa 	 
    	  mgkSwnYHQivQIpeAwgr20 	
            _17726690318409070815 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
 _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
.calculateExtrinsics mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   _3145974845315888936, _2920695669964880276, _14932605280544191270, _606330642723070475 mhyL_M5gnmQzwyHW45MdA 	 
    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
 
     muuG2jhk4iNsA9KNmj6oA 	 
    	 

    
     mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		  _14525273392272441420 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    std mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
    numeric_limits mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
  mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
    mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
     
 
   mBBHVSlvDGP5NVUfEuhuf 	 
   max mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     
      mhGXMe8LHJXydR9dMisHj 	 
    	  
 
     mVRbVdVjFvNmKzGv4WiNp 	 
    	  
    		   
     
const  mgxs4jaOm5WhsuDH7hsbo 	 
    	  
    		   
     
     
&_17126762063553264542:_17726690318409070815 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
   mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
   
         mlkEZnzYCXAgDnYDi5up3 	 
    	  
 _13303058356268144137 mRwjoMr_aqph4iL4nu8NS 	0 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		
         ma9rnYFEs_TUiw_WyBflg 	 
    	  
     moI11mwtxiOXpqDxK_aQL 	 
   _13303058356268144199 mCm219F3DHVwNe_CsrCeK 	0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
  _13303058356268144199 mlP1m6taP4mQVYA_j8Oxe 	 
    	4 mJTScPpWt8plE9Cz9fDU6 	 
    	  
   _13303058356268144199 mEZrtAN7pSZl5y4oEHd38 	 
   msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
 
            _13303058356268144137 mndDt3huhmUYGZC1vQmOq 	 
    	  
    		   
   cv maKLz6mCz5anFyVle_MtD 	 
    	  norm mFsSEF_3_iD2mT6nZG9QR 	 
 _17126762063553264542 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    _13303058356268144199 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
   -_17126762063553264542 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
   _13303058356268144199+1 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
%4 mEFd2D2UDF9SIoPfQtUv6 	 
    	 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
 
         mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    		   
     
 mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
 _14525273392272441420 mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
     
 _13303058356268144137 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
_14525273392272441420 mif4ZCBkqdiqSYkR9AD0r 	_13303058356268144137 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
  
     mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
     
      mlkEZnzYCXAgDnYDi5up3 	 
    	  
    		    _15036404412276314769 mINcNsH05D0QZDej9wl4h 	 
 
     mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		   
     
   mhORIPgMIfN3Fn8aCQBuU 	 
   _14525273392272441420 mtDHooAMb6ubWraYLa7pj 	 
    	  
    std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
   numeric_limits mYI2nkSxgJHf1pY1PttV1 	 
    	  
 mglDNKH5ah89GptW6H4Cu 	 
    	  
    		   
mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		    mUCEzhGWrU8OYqcHVPlVW 	 
    	  
max mH1xQMRmYb0Y4RDp2hARz 	  mzf4ZxeZY8wF2XnrdYK61 	 

         _15036404412276314769 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
 
  	_14525273392272441420/ mtbP4KQJdh36UGELfV2zq 	 
    	 4*std mfx1fLYDWN4YRZNnQEsJN 	max mhORIPgMIfN3Fn8aCQBuU 	 
    	 _17276638435886805939.cols,_17276638435886805939.rows muiDYQbmwLxL3PGrwWGeP 	  mhyL_M5gnmQzwyHW45MdA 	  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
   
     mHcxzZHoWX11H4xEjR59T 	 
    	  
    		   
     
    _15036404412276314769 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
    0 mriCvhMavpfheoLNc0eCD 	 
    
     mUFzn4yJGA8c9qnEcb9dH 	 
    mSa4WnWih0z4lSo9RYUGU 	 
    	  
 _18062104616271777338.autoSize mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
      mJkMyi0NbVRDgE__LMR_m 	
        _18062104616271777338.minSize mdKhcOUXVqyCMdccisL_a 	 
    	  _15036404412276314769* mFsSEF_3_iD2mT6nZG9QR 	1-_18062104616271777338.ts mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
  mJTScPpWt8plE9Cz9fDU6 	 
    
     mbYMUxVFybbviIFqRhN2f 	 
    	  


    _6872264293741719360 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
   _17726690318409070815 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
  

  mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
   
 mfJA9NVd6FBgGhRSkkhhs 	 
    	MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 _10874168409609149361 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    	 aruco maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
 Marker &_17126762063553264542,cv mBBHVSlvDGP5NVUfEuhuf 	Mat _2920695669964880276,cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    Mat _14932605280544191270  mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
    mT_x8cqp5t43PgqNMR8gO 	 
    	  

    

      std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 vector mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
     
 
  	cv mYGfQUZmV9IjKAPVrLhZl 	 
  Point mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
     
 
  	 &_14091102513355313451 mKcKHr_bTagXAK_pf8btG 	 
    	  
 _17126762063553264542.contourPoints mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
       vector mYfYoOWdsOLTDCIBT7npX 	 
    	  mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		  mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		  _16276718381659519112 mtbP4KQJdh36UGELfV2zq 	 
    	  
 4,-1 mgkSwnYHQivQIpeAwgr20 	 
   mftnbgRvzOIVyL93HyyWt 	 
    
       vector mlP1m6taP4mQVYA_j8Oxe 	 
    	 maOczvhF_v9OTsK70ZZut 	 
    	  
    		   
     
     
 
  mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
     
      _3176008349054602175 mhORIPgMIfN3Fn8aCQBuU 	 
    	  4,std maKLz6mCz5anFyVle_MtD 	 
numeric_limits mCALzjQ0bwpDnngl_oSsi 	 
    	  
  maOczvhF_v9OTsK70ZZut 	 mEc9zv3P8LW8haIvtztwe 	 
    	  
   mU808frSKQDZnEEU3Q3s9 	 
    	  
max mFwk30320retpLBiICndp 	 
    	  
    		   
     
     
 
   mmCJ670wA_VHgip7JZ1dW 	 
  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     

        m_owRLEm0gIJ4StPRwTkZ 	 mtbP4KQJdh36UGELfV2zq 	 
    	  
   unsigned  mihBlyb7pwidO496a5_p1 	 
    	  
    		_13303058356268144139  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    	 0 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		    _13303058356268144139  mW1ds9XwNwevT5B2b3j8B 	 _14091102513355313451.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
     
 
  	  mdmuaUz9iCkCckSUhcEv1 	 
     _13303058356268144139 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     
     
 
  	  mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     

            m_BNZbnU2Y1bOBnnPOF0b 	 
    	  
    		   
     
  mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
 unsigned  mMGij61UZUIIYyztVz9vN 	 
    	  
    		 _13303058356268144136  ma6VjqdfajK4BX9gkoGiD 	 0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     _13303058356268144136  mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
 4 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   _13303058356268144136 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     
    mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
      mDzQQrEx5Ki0C6uDHU2cy 	 
    	 
                mnqZGwZqTTi1dekKxujAE 	 
    	  _13303058356268144198 mdKhcOUXVqyCMdccisL_a 	 
      mmmC9tOGiLK6UaJr0E5vz 	 _14091102513355313451 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		   
 _13303058356268144139 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    .x-_17126762063553264542 mA4oXllup8K3T5dxkluRR 	 
    	  
  _13303058356268144136 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
   .x mmCJ670wA_VHgip7JZ1dW 	 
    * mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
    _14091102513355313451 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
    _13303058356268144139 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
   .x-_17126762063553264542 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    	_13303058356268144136 mUB1yrSrKOwldqxmCatN2 	 
.x mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
   +
                        mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
   _14091102513355313451 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
_13303058356268144139 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
  .y-_17126762063553264542 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
  _13303058356268144136 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
  .y mlqM0snvYcrWCw2_QjhQi 	 
    * mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
 _14091102513355313451 mILaQGKCAmcKrYQNhgWUq 	 
    	  
  _13303058356268144139 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		.y-_17126762063553264542 mTjppsgNpY1Pjyv5Z_zMr 	 
  _13303058356268144136 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
     
 .y muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
  	  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		  
                mMNJIG0z6TLGgbjrhllmy 	 
  mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
 _13303058356268144198 mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		_3176008349054602175 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
  _13303058356268144136 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
     mzf4ZxeZY8wF2XnrdYK61 	 
    	  
   mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     
 
                   _16276718381659519112 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		  _13303058356268144136 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
  ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
   _13303058356268144139 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
   
                   _3176008349054602175 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     
 
  _13303058356268144136 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 
  	 _13303058356268144198 mPdHdcAZ6XJhwf8wLtULI 	 
 
                mICILgDpdCTDSJqQAn06L 	 
    	  
    		   
   
            mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   
     
     
 
  	
        mgjPImSFwUcUKl9XTKqqB 	 
    	  

       


       
        mpHTdkvfapV5_Igrm_XSs 	 
    	  _10077272470817073709 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
 
        mRzhpvoeHZK7yCqqzYDDp 	 
    	   miAECMSxGwjxrcOKk0DII 	 
    	  
   mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   _16276718381659519112 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
    1 mJtGCV8zXQjnVDVBVdvFZ 	 
     mYxohqgekcJ8HhaDZvWcX 	 
  _16276718381659519112 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
    0 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
 mAnDeXfeHaujEzGBbrjil 	 
    	  
    mQDLRy0PKsddZ3xq0mn3V 	  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
  _16276718381659519112 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		  2 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
  mRHNkLPwUSnx20pmLgrTq 	 
    	  _16276718381659519112 mTjppsgNpY1Pjyv5Z_zMr 	 
    	 1 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		    mfge932GrgApRFyCExy_M 	 
    _16276718381659519112 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     
 
2 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
     mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
   _16276718381659519112 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   0 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
     
 
  mXAYJa6osZ6HNTIEEBnr0 	 
    	   mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
   
           _10077272470817073709  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
  muESrr63SaH81rmeBWzRi 	 
    	  
  mriCvhMavpfheoLNc0eCD 	 
    	  
 
        mv1ijGQAKacWqWAusY8nc 	 
    	  
    		 mMNJIG0z6TLGgbjrhllmy 	 
    	  
  mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
 _16276718381659519112 mdF98bHO7yrxGJn0aQZVK 	 
    	  
  2 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		  mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
  _16276718381659519112 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  
    		   
     
1 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
       mECamByxBqjGyTShbPlRQ 	 
    	  
    		   
     
   _16276718381659519112 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     2 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
   mca1GaR7Rv9qOZsisqKBB 	  _16276718381659519112 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
    0 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		    mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		 
           _10077272470817073709  mif4ZCBkqdiqSYkR9AD0r 	 
    	  
   muESrr63SaH81rmeBWzRi 	 
    	  
    		   
    mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
       else
           _10077272470817073709  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
       mrYTPN06XEG4I2Q8GwVal 	 
    	  
    		   
     
     
 
  	mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   


       
        mihBlyb7pwidO496a5_p1 	 
    	  
    		   
     
     
 
  	 _5268611906073170262  mdKhcOUXVqyCMdccisL_a 	 
  1 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
    
        mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
     
     
 
  mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
_10077272470817073709 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
 
           _5268611906073170262  mu_nOcTFwUo8r0uNE351R 	 
    	  -1 mJTScPpWt8plE9Cz9fDU6 	 
 

       
       vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
 Point2f  mW1YUos9eL_9NmgJuSDH7 	 
    	   _6417377122913179118 mVOlbMaOu1U0SC2oeKIzP 	
        mwxm9pz2KjGAhBIIfFMf4 	 
    	  
    		   
   mxD0ASUiBIk9J4KLYW_eX 	 
    	  
    		   
     
 _2920695669964880276.empty mFwk30320retpLBiICndp 	 
    	  
    		   
     
     
  moejXze8_C6TCxb2bIzgq 	 
    	  
    		     mRltbJjpZ8AzImbP6r6M4 	 
    	  
    		   _14932605280544191270.empty mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
  mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
 mypSy3lS4LRIjRYTxVxzg 	 
    	  
 
        mtvEQgcnwdOR4zAMwLHDb 	 
    	  
    		   
     mtbP4KQJdh36UGELfV2zq 	 
    	  
   unsigned  moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
    _13303058356268144138  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
    0 mftnbgRvzOIVyL93HyyWt 	 
    	  
   _13303058356268144138  mW1ds9XwNwevT5B2b3j8B 	 
    	  
    	 _14091102513355313451.size mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   
 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
    _13303058356268144138 mEZrtAN7pSZl5y4oEHd38 	 
    	  
    		   
    muiDYQbmwLxL3PGrwWGeP 	 
    	  
   
           _6417377122913179118.push_back mFlVjO0mLpwnCN5a1Quio 	 
    	  
 cv mEMN2sRTwHcTUl7SNSw0d 	 
    	Point2f mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
   _14091102513355313451 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
    _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     
 
 .x, _14091102513355313451 mY2nz8M_6jpSxQZL8EYgU 	_13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
.y mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
    mzf4ZxeZY8wF2XnrdYK61 	 
    	  
     mlqoNTA3LQoUJF6i5YDFc 	 
        mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		   
     
     
 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
    mnswinmeXuam57kXH7myI 	 
    	  
    		 _2920695669964880276.empty mzeHK1hG1SYQMISNMWMB8 	 
    	  
      mgN2NPegMIWZaSlArqSpX 	 
    	  
    		   
      mRltbJjpZ8AzImbP6r6M4 	 
    	  
    		 _14932605280544191270.empty mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
    msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
  
           cv mdssZV6TB06aiisDwN1cX 	 
  undistortPoints mmmC9tOGiLK6UaJr0E5vz 	 
    _6417377122913179118, _6417377122913179118, _2920695669964880276, _14932605280544191270, cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
   Mat mFwk30320retpLBiICndp 	 
    	  
    		   
    , _2920695669964880276 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		    mPdHdcAZ6XJhwf8wLtULI 	 
    	  

        mDUyr1RAsHMG7u1BeTW3F 	 
    	  
        mUwTrZwI1VfAXDN69k3UA 	 
    	  
    mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
           _6417377122913179118.reserve mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
_14091102513355313451.size maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
     
     
 
  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
  mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 
  
            miGFoFUQX5urgUZ1Rewwt 	 
    	  
    		   
     
     
 
  	  mHXoMWKZSiZYUvqmVkLF5 	 
    	  
    		_13303058356268144073:_14091102513355313451 msubWq7nTVSPilWqmTzkx 	 
    	  
    	
               _6417377122913179118.push_back miAECMSxGwjxrcOKk0DII 	 
    	  
    cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
    Point2f mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
 
  	 _13303058356268144073.x,_13303058356268144073.y mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     mhyL_M5gnmQzwyHW45MdA 	 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    
        mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
  

       vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	 std mEMN2sRTwHcTUl7SNSw0d 	 
    	  
  vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		 cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   Point2f  mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		   
     
  mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
    _6917161151118932890 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
       _6917161151118932890.resize mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     4 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
 
        mLBxgVrVeq7bTUcDGJqNH 	 
    	  
    		   
   miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
   unsigned  mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   
     
     
 _13303058356268144137  mdKhcOUXVqyCMdccisL_a 	 
    	  
    	 0 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
   _13303058356268144137  mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     
 
   4 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
    _13303058356268144137 mt0bWs8kxCzTnBdtR9vKu 	 
    	  mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     mjbtcSgN5ZQfkGDsoYG4l 	 
            m_owRLEm0gIJ4StPRwTkZ 	 
    mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		    mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		   
     
    _13303058356268144139  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
   mReDuVelSknxaDAoDEmwT 	 
    	  
 mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		   
     
     
 
  	mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
_16276718381659519112 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
   _13303058356268144137 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
     
 
   mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
   _13303058356268144139  ma43zKzGwyDT5C3mNdj6s 	  miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
   meWm4MhzbcJwavtoh469w 	 
    	  
   muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     _16276718381659519112 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     
 
 mtbP4KQJdh36UGELfV2zq 	 
 _13303058356268144137 + 1 muiDYQbmwLxL3PGrwWGeP 	 
   % 4 mEFd2D2UDF9SIoPfQtUv6 	 
    	  mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		 _13303058356268144139  msMfR3R5kzP8SqAQ3DWTq 	 
    	  
    		 _5268611906073170262 mmCJ670wA_VHgip7JZ1dW 	 
    	  
  mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
                mUFzn4yJGA8c9qnEcb9dH 	 
    	  
    		   
     
     
 
  	  miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     _13303058356268144139  mi0dc2wlXgNoHf9VPli9f 	 
    	  
    		   
     
     
  mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
   mP8l6554fUQhsCw2PetD2 	mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
    _14091102513355313451.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
    		  m_YnlLsKBlim0LDKxc0Xy 	 
    	  
    		   
     
   mnswinmeXuam57kXH7myI 	 
    	  
    		   
     
     
_10077272470817073709 mmCJ670wA_VHgip7JZ1dW 	 
 
                   _13303058356268144139  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
  0 mPdHdcAZ6XJhwf8wLtULI 	
                moT0JKxDJVSALTDfSRUYM 	 
    	  
    		   
     
     
 
  mWHxIxEh8g9mg3Hyipn8D 	 
    	  
  mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     
 _13303058356268144139  mPlk6hpBhStcHkX9pfoTY 	 
    	  
    		   0  mvW7MwxFgHE1jUFn6bpuP 	 
    	  
     _10077272470817073709 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
 
                   _13303058356268144139  mdKhcOUXVqyCMdccisL_a 	 
    	  
    		    _14091102513355313451.size mdWkXjuaPd4Se0r0SdY1e 	 
    	  
     - 1 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
 
               _6917161151118932890 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
_13303058356268144137 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		  .push_back mFlVjO0mLpwnCN5a1Quio 	 
    	  
 _6417377122913179118 mGYpOkNIG_qSvYXBOU9Vf 	 
    _13303058356268144139 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
   mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
  mPdHdcAZ6XJhwf8wLtULI 	
                mvw_MKiY3S1FcVNfJQCRT 	 miAECMSxGwjxrcOKk0DII 	 
   _13303058356268144139  mnZ6t3BhMZ_1d7zzE72ah 	 
    	  
  mmmC9tOGiLK6UaJr0E5vz 	 
    	 mCujczJix6jMpJcynoBiA 	 
    	  
    		   
     
     
 
muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
   _16276718381659519112 mFyKKLtdivGGDlk8sYzsf 	 mFlVjO0mLpwnCN5a1Quio 	 
    	  
    _13303058356268144137 + 1 mlqM0snvYcrWCw2_QjhQi 	 % 4 mrpQVzv6u8gxvho1qUlil 	 
    	  
    	 mmCJ670wA_VHgip7JZ1dW 	 
    	
                    mTFkOkggRsxkeMv25hiJW 	 
    	  mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
            mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
  
        mnSkEvR4SbDwQxj23xB1M 	 
    	

       
       vector mCALzjQ0bwpDnngl_oSsi 	 
    	  Point3f  mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		   
     
  _17129155073204642077 mftnbgRvzOIVyL93HyyWt 	 

       _17129155073204642077.resize miAECMSxGwjxrcOKk0DII 	 
    	  
    	4 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		  mPdHdcAZ6XJhwf8wLtULI 	 
 
        mNMDyj9J1Nt8auTKwp8ze 	  miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     unsigned  mG7mr0Iq8BCEeADSwrCoW 	 
    	 _13303058356268144139  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		    0 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     _13303058356268144139  mK5OxIt23gZzSiTA8trU8 	 
    	  
     _17129155073204642077.size mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
      _13303058356268144139 mwwJvnj2j3yLmklxxOEJQ 	 
    	  
    		   
      mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
   
           _5589556639929121196 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
_6917161151118932890 mTjppsgNpY1Pjyv5Z_zMr 	 
    	 _13303058356268144139 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
     
 
 , _17129155073204642077 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
_13303058356268144139 mwTp2D1d4PfxNNOzzUfhS 	 
    mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  	 

       
       vector mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		  Point2f  mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		  _15053120134632409437 mhGXMe8LHJXydR9dMisHj 	
       _15053120134632409437.resize mReDuVelSknxaDAoDEmwT 	 
    	  
 4 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
    mhGXMe8LHJXydR9dMisHj 	 
    	 
        mtvEQgcnwdOR4zAMwLHDb 	 
    	  
   mFlVjO0mLpwnCN5a1Quio 	unsigned  mihBlyb7pwidO496a5_p1 	 
    	  
    		   
     
     
 
 _13303058356268144138  mKcKHr_bTagXAK_pf8btG 	 
  0 mPdHdcAZ6XJhwf8wLtULI 	 _13303058356268144138  mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
  4 mriCvhMavpfheoLNc0eCD 	 
    	  
   _13303058356268144138 mBh4lc09qKYGXyU7FeqOv 	 mAnDeXfeHaujEzGBbrjil 	 
    	  
           _15053120134632409437 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
   _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
   mif4ZCBkqdiqSYkR9AD0r 	 
  _8396213235373312360 mp3H4249LtCVDCYFqQqz4 	 
    	  
    		  _17129155073204642077 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   miAECMSxGwjxrcOKk0DII 	 
    	  
    _13303058356268144138 - 1 mlqM0snvYcrWCw2_QjhQi 	 % 4 mIkhxhgSNMt_JUZR7ce1U 	 
    	, _17129155073204642077 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		   
    _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
 mycwFs63h7Mi3ggRkMEVm 	 
    	  
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   


       
        mJvv2tbrel2xOYjvgipUL 	 
    	  
    	 miAECMSxGwjxrcOKk0DII 	 
    	  
    	 mRltbJjpZ8AzImbP6r6M4 	 
    	  
_2920695669964880276.empty mFwk30320retpLBiICndp 	 
    	  
    		   
     
     
  mBJ7M0ikk98KhD4Oi32wB 	 
    	    msFQPbyubcQTkvTYpFFPL 	 
    	  
    		   
     
     
 
 _14932605280544191270.empty mdWkXjuaPd4Se0r0SdY1e 	  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
 
           _8160328761135174279 miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
  _15053120134632409437, _15053120134632409437, _2920695669964880276, _14932605280544191270 mAnDeXfeHaujEzGBbrjil 	  mPdHdcAZ6XJhwf8wLtULI 	

       
        m_owRLEm0gIJ4StPRwTkZ 	 
    	  
    		   
 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    	unsigned  mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
     
   _13303058356268144139  mdKhcOUXVqyCMdccisL_a 	 0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
    _13303058356268144139  mqEAvVDOCXqrrwrTRByrM 	 
 4 mriCvhMavpfheoLNc0eCD 	 
    	  
    		    _13303058356268144139 mo7mKuzaX2h9vw2rEj5qh 	 
    	  
    		   
      mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
     
     
          
           _17126762063553264542 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		   
 _13303058356268144139 mo8MRbS3DUX_ZOlgmUSna 	 
    	   muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
 _15053120134632409437 mdF98bHO7yrxGJn0aQZVK 	_13303058356268144139 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    	
        mbYMUxVFybbviIFqRhN2f 	 
    	  
    		   
     
     
 
  	
 mICILgDpdCTDSJqQAn06L 	 
    	  
    		 




 mKmIjE1RujJ5RSETUjqwW 	 
    	  
    	MarkerDetector_Impl mU808frSKQDZnEEU3Q3s9 	 
    	  
    		   
     
   _1548619269531313217 mhxtTU7dvZHXCTSg8B8rx 	MarkerCandidate &_3175967376861678913, mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		   
     
    _3177068552486117874 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
      mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
    
     ms9iveRK8Fk_QtPMDvDcP 	 
 moI11mwtxiOXpqDxK_aQL 	 
    	  
   _13303058356268144139 mu_nOcTFwUo8r0uNE351R 	 
    	  
 0 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
  _13303058356268144139 mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
     
 
2 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		  _13303058356268144139 mBh4lc09qKYGXyU7FeqOv 	 
    	  
    mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
      mDzQQrEx5Ki0C6uDHU2cy 	 
         myYAiLHDT3JvFKUJCC_FN 	 
    	  _11941284328360913259 ma6VjqdfajK4BX9gkoGiD 	 
_13303058356268144139 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		 
         mF8CPQI5IssWjwlV2CXVE 	 
_3176948340370061933 mu_nOcTFwUo8r0uNE351R 	 
    	  mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
_13303058356268144139 + 2 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 % 4 mJTScPpWt8plE9Cz9fDU6 	 
    	  

        
         mUFzn4yJGA8c9qnEcb9dH 	 
    	  
    		   
     
 mhxtTU7dvZHXCTSg8B8rx 	 
  _3175967376861678913 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
     
 
  	_11941284328360913259 msdqcdg5NNrdQnc_PT1Ee 	 
   .x mYxohqgekcJ8HhaDZvWcX 	 
_3175967376861678913 mTjppsgNpY1Pjyv5Z_zMr 	 
    _3176948340370061933 mwTp2D1d4PfxNNOzzUfhS 	.x muiDYQbmwLxL3PGrwWGeP 	 
    	 mJkMyi0NbVRDgE__LMR_m 	 
    	  
   
            swap mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
   _11941284328360913259,_3176948340370061933 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   

         muuG2jhk4iNsA9KNmj6oA 	 
 
        const  mYKwa_OYBeVXzRPMa_mz6 	 
    	  
    		_3257891606805124672 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
    3.14159f  mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		

        const  mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
     
 
  	_5268608437207054717 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
   3.14159/8.f mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
 
        const  mWokjWH0MHqyBOx4j0Oac 	 
    	  
    		   
     
     
 
 _12290827085925694194 mdKhcOUXVqyCMdccisL_a 	 
    	  
    	3.*3.14159f/8.f mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   

        const  mglDNKH5ah89GptW6H4Cu 	 
_12290826968547181107 mKcKHr_bTagXAK_pf8btG 	 
    5.f*3.14159f/8.f mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
    
        const  maOczvhF_v9OTsK70ZZut 	 
    	  
_12290829632982753066 ma6VjqdfajK4BX9gkoGiD 	7.f*3.14159f/8.f mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 

         moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
     
 
  	_3177069355788807654 mdKhcOUXVqyCMdccisL_a 	 
    	  0,_3177069355788807468 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
   0 mINcNsH05D0QZDej9wl4h 	
        
         mZHJfF8VODcHrGq0YEwM_ 	 
    	  
    		   
     
     
 
  _16232574195069208446 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   _3175967376861678913 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
_3176948340370061933 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		 -_3175967376861678913 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
 _11941284328360913259 mUB1yrSrKOwldqxmCatN2 	 
    mINcNsH05D0QZDej9wl4h 	 
    	  
  
         mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
     
 
  _12315458030785690534 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     atan2 mFlVjO0mLpwnCN5a1Quio 	 
    	 _16232574195069208446.y,_16232574195069208446.x mmCJ670wA_VHgip7JZ1dW 	 
     mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
  	
         mRzhpvoeHZK7yCqqzYDDp 	 
    miAECMSxGwjxrcOKk0DII 	 
   _5268608437207054717 mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
 _12315458030785690534  mQDLRy0PKsddZ3xq0mn3V 	 
    	  
  _12315458030785690534 mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
   3*_5268608437207054717 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		    mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		    
            _3177069355788807654 mu_nOcTFwUo8r0uNE351R 	_3177069355788807468 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
  _3177068552486117874 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
         maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     

         mZQqomBcB_Prq89ftbAiD 	 
    	  
    		   
     
    mabeHDqoCFUg5Mty5oLni 	 
    	  
    	 mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     -_5268608437207054717 mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
 _12315458030785690534  mECamByxBqjGyTShbPlRQ 	 _12315458030785690534 mYI2nkSxgJHf1pY1PttV1 	_5268608437207054717  mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
     
     
 
  	 
            _3177069355788807654 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   _3177068552486117874 mPdHdcAZ6XJhwf8wLtULI 	 
    	  

            _3177069355788807468 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 
  	 0 mftnbgRvzOIVyL93HyyWt 	 
    	  

         muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
         muKP5B7qysoQRrYrwu_aG 	 
    	  
    		   
     
     
 
   mvw_MKiY3S1FcVNfJQCRT 	 
    	  
    		   
     
     
 
 mFsSEF_3_iD2mT6nZG9QR 	 
    	 -_12290827085925694194 mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		   
_12315458030785690534  mQDLRy0PKsddZ3xq0mn3V 	 
    	  
   _12315458030785690534 mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     -_5268608437207054717  msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
    mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		   
 
            _3177069355788807654 mif4ZCBkqdiqSYkR9AD0r 	_3177068552486117874 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
  
            _3177069355788807468 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
     
 
-_3177068552486117874 mriCvhMavpfheoLNc0eCD 	 
    
         mDUyr1RAsHMG7u1BeTW3F 	 
    	 
         mv1ijGQAKacWqWAusY8nc 	 
    	  
    		   
     
      mabeHDqoCFUg5Mty5oLni 	 
    	  
    		   
  mhORIPgMIfN3Fn8aCQBuU 	 
    	  -_12290826968547181107 mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		   
     
     
 
  _12315458030785690534  mOR5gj7K3yTraJVOrvmKy 	 
    	  
  _12315458030785690534 mlP1m6taP4mQVYA_j8Oxe 	 
    	  
   -_12290827085925694194  mAnDeXfeHaujEzGBbrjil 	 
    	   mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
    
            _3177069355788807654 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
   
            _3177069355788807468 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     
 
  	 -_3177068552486117874 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
    
         maCQ9r5fSln_CXgRXGFvO 	 
 
         mUwTrZwI1VfAXDN69k3UA 	 mEwOO8zzJcEkF96gfFa1e 	 
 mtbP4KQJdh36UGELfV2zq 	 
     -_12290829632982753066 mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 _12315458030785690534  mQDLRy0PKsddZ3xq0mn3V 	 
    	  
    		   
     
     
 _12315458030785690534 mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
   -_12290826968547181107  muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
  mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
            _3177069355788807654 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   -_3177068552486117874 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
 
            _3177069355788807468 mCm219F3DHVwNe_CsrCeK 	-_3177068552486117874 mxdAvfSsdzliezc0uyUMk 	 
    	  
  
         mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     
         mnkTvEdpCXelpIHLLqQno 	 
    	  
    		   
     
 mabeHDqoCFUg5Mty5oLni 	 
    	   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		     mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
 
 -_3257891606805124672 mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
_12315458030785690534  mbFGY3HJrKnP_L6H3dMsA 	 
    	  
    		   
     
     
  _12315458030785690534 mW1ds9XwNwevT5B2b3j8B 	 
    	  
  -_12290829632982753066 mAnDeXfeHaujEzGBbrjil 	 
    	  
  miAr40ThvnnZei4PQ8nft 	 
    	  
    		   
  mmmC9tOGiLK6UaJr0E5vz 	 
    	  
_12290829632982753066 mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		   
     
     
 
 _12315458030785690534  mKdH1o6rFuMJ1Fl0PA_sn 	 
    	  
   _12315458030785690534 mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     
 
  _3257891606805124672 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
  mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
            _3177069355788807654 mRwjoMr_aqph4iL4nu8NS 	 
    -_3177068552486117874 mlqoNTA3LQoUJF6i5YDFc 	 
   
            _3177069355788807468 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
0 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
  	 
         mnSkEvR4SbDwQxj23xB1M 	 
    	  

         mUwTrZwI1VfAXDN69k3UA 	 
    	  
    		   
     
     
 
  mMNJIG0z6TLGgbjrhllmy 	 
    	  
    		   
   mmmC9tOGiLK6UaJr0E5vz 	 
    	    mhORIPgMIfN3Fn8aCQBuU 	 
 _12290826968547181107 mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  	_12315458030785690534  mOR5gj7K3yTraJVOrvmKy 	 
    _12315458030785690534 mbG1GEmOdh2dXkJZ42sXo 	 
    	  
   _12290829632982753066 mmCJ670wA_VHgip7JZ1dW 	   mhyL_M5gnmQzwyHW45MdA 	 mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
     
 
  	
            _3177069355788807654 mu_nOcTFwUo8r0uNE351R 	 
    	 -_3177068552486117874 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
            _3177069355788807468 myJHqW7fkn_72nVEhKeZ6 	 
 _3177068552486117874 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 
  	 
         mJOnXqKm3GBylSdRjpXAA 	 
    	  
   
         moT0JKxDJVSALTDfSRUYM 	 
     mUFzn4yJGA8c9qnEcb9dH 	  mReDuVelSknxaDAoDEmwT 	 
  mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
    _12290827085925694194 mqEAvVDOCXqrrwrTRByrM 	 
    	  
    	_12315458030785690534  mvW7MwxFgHE1jUFn6bpuP 	 
  _12315458030785690534 mYfYoOWdsOLTDCIBT7npX 	 
    	  
    	_12290826968547181107 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		    mmCJ670wA_VHgip7JZ1dW 	 
    	   mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		 
            _3177069355788807654 mif4ZCBkqdiqSYkR9AD0r 	 
_3177068552486117874 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
 
            _3177069355788807468 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
    _3177068552486117874 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 

         mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     
 
 
        _3175967376861678913 mFyKKLtdivGGDlk8sYzsf 	 
    	  _3176948340370061933 mUB1yrSrKOwldqxmCatN2 	 
.x mC7CcuPGpz81aizhogiZL 	 
    	  
    		   
     
 _3177069355788807654 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
   
        _3175967376861678913 mILaQGKCAmcKrYQNhgWUq 	 
 _3176948340370061933 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     
.y mC7CcuPGpz81aizhogiZL 	 
  _3177069355788807468 mriCvhMavpfheoLNc0eCD 	 
    
        _3175967376861678913 mTjppsgNpY1Pjyv5Z_zMr 	 
  _11941284328360913259 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
     
   .x mFKRUYDiDlNmwfGKdBg2S 	 
    	  
    _3177069355788807654 mPdHdcAZ6XJhwf8wLtULI 	
        _3175967376861678913 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
     
 
 _11941284328360913259 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
     
 .y mtL59O4fTIGPJKdcQHvhB 	 
    	  
    		   
  _3177069355788807468 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		  

     mnSkEvR4SbDwQxj23xB1M 	 
    	  
 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 
  	



 mihBlyb7pwidO496a5_p1 	 
    	  
    		   
 MarkerDetector_Impl mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 _13365150943186347431 mtbP4KQJdh36UGELfV2zq 	 
 cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   Size _10104164517741906567 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     const mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     
 
  	 
     mRzhpvoeHZK7yCqqzYDDp 	 
    	 mtbP4KQJdh36UGELfV2zq 	 
    	_18062104616271777338.minSize mnZ6t3BhMZ_1d7zzE72ah 	 
    -1  mbFGY3HJrKnP_L6H3dMsA 	 
    	  
    		   
     
     
 
 _18062104616271777338.minSize_pix maDn6NcmB5JPmBvJglMEd 	 
    	  
    		   
     
     
 
  	 -1 mlqM0snvYcrWCw2_QjhQi 	 
     mo03bPDhF7WKTf8ndM1Bk 	 
 0 mPdHdcAZ6XJhwf8wLtULI 	 
    	
    
     mSD7jHYN8mOif4_CBtIg6 	 
    	  
    		  _17126222192490468606 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
   std mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
    max mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  _10104164517741906567.width, _10104164517741906567.height msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
   mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
 
 
     mihBlyb7pwidO496a5_p1 	 
    	  
    		   
     _9531480675436973396  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
 
0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
 
     mEwOO8zzJcEkF96gfFa1e 	 
    	  
    		   
     
     
 
  	 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
  	 _18062104616271777338.minSize mWUoD50tT9HFGBNQCsjUC 	 
    	-1 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
  _9531480675436973396  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
  	 static_cast mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
 mlkEZnzYCXAgDnYDi5up3 	 
    	  
    		   mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
  mtbP4KQJdh36UGELfV2zq 	 
   _18062104616271777338.minSize mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
* static_cast mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
 mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
   mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   
     
   mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     
 
  _17126222192490468606 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
       mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		 
     mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		   
     
    mhxtTU7dvZHXCTSg8B8rx 	 
    	  
   _18062104616271777338.minSize_pix muOzaq9SXefX6wOasanyX 	 
    	  
    		   
     
   -1 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
      _9531480675436973396 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
  min mFlVjO0mLpwnCN5a1Quio 	_18062104616271777338.minSize_pix, _9531480675436973396  mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
    mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
  
     myYaYWcsrnLoe6SxorDYt 	 
    	  
    		   
  _9531480675436973396  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
     
 


 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   


 mU8SToe5QpPWgY0z9QAcm 	 
    	  MarkerDetector_Impl mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 warp miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
 Mat& _16232574195069562409, Mat& _5268605234504081842, Size _3176948226119365859, vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
    Point2f mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
 _3225820074026295014 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   

 mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     
 
  	 
     mMNJIG0z6TLGgbjrhllmy 	 
    	  
    		   
     
  miAECMSxGwjxrcOKk0DII 	 
    _3225820074026295014.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
      mZk2lUQMDVDhOLQdg9s92 	 
    	  
    		   
     
   4 mzf4ZxeZY8wF2XnrdYK61 	 
    
        throw cv mYGfQUZmV9IjKAPVrLhZl 	 
    Exception mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
9001, "\x5c\x78\x37\x30\x5c\x78\x36\x66\x5c\x78\x36\x39\x5c\x78\x36\x65\x5c\x78\x37\x34\x5c\x78\x32\x65\x5c\x78\x37\x33\x5c\x78\x36\x39\x5c\x78\x37\x61\x5c\x78\x36\x35\x5c\x78\x32\x38\x5c\x78\x32\x39\x5c\x78\x32\x31\x5c\x78\x33\x64\x5c\x78\x33\x34", "\x5c\x78\x34\x64\x5c\x78\x36\x31\x5c\x78\x37\x32\x5c\x78\x36\x62\x5c\x78\x36\x35\x5c\x78\x37\x32\x5c\x78\x34\x34\x5c\x78\x36\x35\x5c\x78\x37\x34\x5c\x78\x36\x35\x5c\x78\x36\x33\x5c\x78\x37\x34\x5c\x78\x36\x66\x5c\x78\x37\x32\x5c\x78\x35\x66\x5c\x78\x34\x39\x5c\x78\x36\x64\x5c\x78\x37\x30\x5c\x78\x36\x63\x5c\x78\x33\x61\x5c\x78\x33\x61\x5c\x78\x37\x37\x5c\x78\x36\x31\x5c\x78\x37\x32\x5c\x78\x37\x30", __FILE__, __LINE__ mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
      mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		  
    
    Point2f _10473289206739293354 mZnfmoDANjVLDjZfzM5MR 	 
    	  
    		 4 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    , _9482907070712177146 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
     
 
  	 4 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
     
    mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 
 
     m_BNZbnU2Y1bOBnnPOF0b 	 
    	  
     mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	 mSD7jHYN8mOif4_CBtIg6 	 
    	  
    _13303058356268144138  mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
  0 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
   _13303058356268144138  mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
     
 
  	  4 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
 _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 
    	  
    		   
    mgkSwnYHQivQIpeAwgr20 	 
    	 
        _9482907070712177146 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
  _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
      ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   _3225820074026295014 mGYpOkNIG_qSvYXBOU9Vf 	 
    	  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
     mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  	
    _10473289206739293354 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
0 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
     
     
  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		  mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
 Point2f mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
0, 0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
    _10473289206739293354 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
  1 msdqcdg5NNrdQnc_PT1Ee 	 
  muQdV4OJL6V6gVxW6AdRy 	 
    	 Point2f mhxtTU7dvZHXCTSg8B8rx 	 
    	  
   static_cast mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		 mnECjbnhLknZie3Z5iHP2 	 
    	  
    		   
     
 m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
 mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
     
 
  	 _3176948226119365859.width - 1 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		 , 0.f mycwFs63h7Mi3ggRkMEVm 	 
    mJTScPpWt8plE9Cz9fDU6 	 
    	
    _10473289206739293354 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   2 mUB1yrSrKOwldqxmCatN2 	 
   mCm219F3DHVwNe_CsrCeK 	 
    	  
 Point2f mSa4WnWih0z4lSo9RYUGU 	 
    	  
    static_cast mYI2nkSxgJHf1pY1PttV1 	 
    	  
   mWokjWH0MHqyBOx4j0Oac 	 
    	  
   mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
     
 
 mFlVjO0mLpwnCN5a1Quio 	 
    _3176948226119365859.width - 1 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 
 , static_cast mK5OxIt23gZzSiTA8trU8 	 
   mYKwa_OYBeVXzRPMa_mz6 	 
    	  mE4_Vrik0lveh4HNJUk1B 	 
    	  
    mSa4WnWih0z4lSo9RYUGU 	 
    	  
    	_3176948226119365859.height - 1 mAnDeXfeHaujEzGBbrjil 	 
   mlqM0snvYcrWCw2_QjhQi 	 
    	 mxdAvfSsdzliezc0uyUMk 	 
    	 
    _10473289206739293354 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
    3 mIkhxhgSNMt_JUZR7ce1U 	 
  mKcKHr_bTagXAK_pf8btG 	 
    	  
    	 Point2f mmmC9tOGiLK6UaJr0E5vz 	 
   0.f, static_cast mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   mYKwa_OYBeVXzRPMa_mz6 	 
    	  
    		   
     
  mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   
     
     
 miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
_3176948226119365859.height - 1 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
      mINcNsH05D0QZDej9wl4h 	 
    	  
    	
    Mat _13303058356268144331  myJHqW7fkn_72nVEhKeZ6 	 
    	  
  getPerspectiveTransform mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
     
 _9482907070712177146, _10473289206739293354 mycwFs63h7Mi3ggRkMEVm 	  mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
    cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
   warpPerspective mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
_16232574195069562409, _5268605234504081842, _13303058356268144331, _3176948226119365859, cv mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
INTER_LINEAR mycwFs63h7Mi3ggRkMEVm 	 
    	  
   mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
   
  
   mLfKYVMLDthbyvvLerNPJ 	 
    	  
    		  mRrVhT0WkQauAZEUJHKOK 	 
    	  
    		 mriCvhMavpfheoLNc0eCD 	 

 mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   
     




 mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		   
     
  MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
     
 _16109434691388891984 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     const vector mK5OxIt23gZzSiTA8trU8 	 
    Point2f mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
    & _13303058356268144201 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
 
  
 mypSy3lS4LRIjRYTxVxzg 	 
    	  

     mCujczJix6jMpJcynoBiA 	 
  _5268611907573087124  mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
  0 mxdAvfSsdzliezc0uyUMk 	
     m_owRLEm0gIJ4StPRwTkZ 	 
   mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
 unsigned  mCujczJix6jMpJcynoBiA 	 
    	  
    		   
     
     
 
  	_13303058356268144138  mKcKHr_bTagXAK_pf8btG 	 
    	  
   0 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
 _13303058356268144138  mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
    _13303058356268144201.size maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
 _13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
   muiDYQbmwLxL3PGrwWGeP 	 

     mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
   
         mG7mr0Iq8BCEeADSwrCoW 	 
    	  
    		 _16232574195069558079  mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
  mSa4WnWih0z4lSo9RYUGU 	 
    	_13303058356268144138 + 1 mycwFs63h7Mi3ggRkMEVm 	 
    	  
   % _13303058356268144201.size mFwk30320retpLBiICndp 	 
    	  
    		   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
        _5268611907573087124  mhMsdnRaOV1FZ69nEgvbs 	 
    	  
    		   static_cast mqEAvVDOCXqrrwrTRByrM 	 
    	  
    	 meWm4MhzbcJwavtoh469w 	 
    	  
mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   
     
     
 mp3H4249LtCVDCYFqQqz4 	 sqrt miAECMSxGwjxrcOKk0DII 	 
    	  
    	 mFsSEF_3_iD2mT6nZG9QR 	 _13303058356268144201 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
_13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
.x - _13303058356268144201 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     _16232574195069558079 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
.x mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 
   *  mSa4WnWih0z4lSo9RYUGU 	 
    	  
_13303058356268144201 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  _13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    	.x - _13303058356268144201 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		  _16232574195069558079 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
 
  	 .x mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		    +
                                       mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
  _13303058356268144201 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     .y - _13303058356268144201 mZnfmoDANjVLDjZfzM5MR 	 
    	 _16232574195069558079 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   .y mXAYJa6osZ6HNTIEEBnr0 	 
     *  mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
  _13303058356268144201 mA4oXllup8K3T5dxkluRR 	 
    	 _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    .y - _13303058356268144201 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 
  	 _16232574195069558079 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
.y mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
   mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
  mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     mPdHdcAZ6XJhwf8wLtULI 	 
    	  

     mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		   
     
     mLfKYVMLDthbyvvLerNPJ 	 
 _5268611907573087124 mINcNsH05D0QZDej9wl4h 	 
    	  
    		 
 mnSkEvR4SbDwQxj23xB1M 	 
    	 



 mc6SGgM2Uzvo_wy5KTima 	 
MarkerDetector_Impl mBBHVSlvDGP5NVUfEuhuf 	 
 _5589556639929121196 mSa4WnWih0z4lSo9RYUGU 	 
    	const std mfx1fLYDWN4YRZNnQEsJN 	 
    vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
   cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   Point2f mW1YUos9eL_9NmgJuSDH7 	 
    & _14067181347882760969, cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
  Point3f& _15087904812230018442 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
   
 mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
     
 
  	 
     mOcs0qqtJYmueMnfTyCFx 	 
    	  
_3176948348563158707, _3257891898253592020, _3176948348563158706, _3257891898253592021 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   

    _3176948348563158707  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
 
 _3257891898253592020  mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     _14067181347882760969 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
     
 
  	 0 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
.x mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
  	 
    _3176948348563158706  mif4ZCBkqdiqSYkR9AD0r 	 
    	   _3257891898253592021  mif4ZCBkqdiqSYkR9AD0r 	 
    	   _14067181347882760969 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
0 mrpQVzv6u8gxvho1qUlil 	 
    	 .y mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     

     m_owRLEm0gIJ4StPRwTkZ 	 
    	  
    		   
     
  mFsSEF_3_iD2mT6nZG9QR 	 unsigned  meWm4MhzbcJwavtoh469w 	 
    	  
    		   
     
     
 
  	_13303058356268144138  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		  1 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 _13303058356268144138  mCALzjQ0bwpDnngl_oSsi 	 _14067181347882760969.size mFwk30320retpLBiICndp 	 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
 _13303058356268144138 mcstdE8Wwpam6tUMM45Sa 	 
    	   mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
 
     mnU2hwoI16_nZ7reLKJTr 	 
    	  
    		   
     
         mJvv2tbrel2xOYjvgipUL 	 
    	  
    		   
    miAECMSxGwjxrcOKk0DII 	 
    	  
  _14067181347882760969 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
  _13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
.x  mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
     _3176948348563158707 mAnDeXfeHaujEzGBbrjil 	 
    	  
            _3176948348563158707  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
   _14067181347882760969 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    _13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
  .x mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		
         mRzhpvoeHZK7yCqqzYDDp 	 
    	  
    		   
    miAECMSxGwjxrcOKk0DII 	 
    	  
  _14067181347882760969 mFyKKLtdivGGDlk8sYzsf 	 _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
   .x  mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		   
 _3257891898253592020 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
   
            _3257891898253592020  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
  _14067181347882760969 mTjppsgNpY1Pjyv5Z_zMr 	 
  _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
     
 
  .x mxdAvfSsdzliezc0uyUMk 	 
         mRzhpvoeHZK7yCqqzYDDp 	 
    	   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		 _14067181347882760969 mdF98bHO7yrxGJn0aQZVK 	 
    	  _13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		  .y  mYfYoOWdsOLTDCIBT7npX 	 
    _3176948348563158706 muiDYQbmwLxL3PGrwWGeP 	 
    	  
   
            _3176948348563158706  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     _14067181347882760969 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
_13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
  .y mftnbgRvzOIVyL93HyyWt 	 

         mNhNSN2gx5KERe8tfdmgu 	 
    	  
    		    mhORIPgMIfN3Fn8aCQBuU 	_14067181347882760969 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   
     
     
 _13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
 .y  m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
     _3257891898253592021 mmCJ670wA_VHgip7JZ1dW 	 
 
            _3257891898253592021  ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   _14067181347882760969 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
 _13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	.y mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		
     mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
  

    
    const  mMGij61UZUIIYyztVz9vN 	 
    	  
    	_16643961442089568442  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
 
  	 static_cast mqEAvVDOCXqrrwrTRByrM 	 
    	  
    		 mP8l6554fUQhsCw2PetD2 	 
    	  
    		   
mE4_Vrik0lveh4HNJUk1B 	 
    	  
    mFlVjO0mLpwnCN5a1Quio 	 
    	_14067181347882760969.size mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
     
 
   msubWq7nTVSPilWqmTzkx 	 
   mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
    Mat _13303058356268142351 mp3H4249LtCVDCYFqQqz4 	 
_16643961442089568442, 2, CV_32FC1, Scalar mSa4WnWih0z4lSo9RYUGU 	 
    	  0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
   mmCJ670wA_VHgip7JZ1dW 	 
    	  mlqoNTA3LQoUJF6i5YDFc 	 
    	  

    Mat _13303058356268142348 mhxtTU7dvZHXCTSg8B8rx 	 
_16643961442089568442, 1, CV_32FC1, Scalar mFlVjO0mLpwnCN5a1Quio 	 
    	 0 mXAYJa6osZ6HNTIEEBnr0 	  mzf4ZxeZY8wF2XnrdYK61 	 
    	   mxdAvfSsdzliezc0uyUMk 	 
    
    Mat _13303058356268144267 mriCvhMavpfheoLNc0eCD 	 
    	  
 

     mJvv2tbrel2xOYjvgipUL 	 
    	 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
   _3257891898253592020 - _3176948348563158707  mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
     
 _3257891898253592021 - _3176948348563158706 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
 
     mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   

        
         mLBxgVrVeq7bTUcDGJqNH 	 
    	  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
 mMGij61UZUIIYyztVz9vN 	 
    	  
    	_13303058356268144138  mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
  0 mJTScPpWt8plE9Cz9fDU6 	 
    _13303058356268144138  mca1GaR7Rv9qOZsisqKBB 	 
    	  
  _16643961442089568442 mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
     
 _13303058356268144138 mi940TUip6nLdi0tWD33F 	 
    	  
    		   
     
   mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
    
         mnU2hwoI16_nZ7reLKJTr 	 
    	 
            _13303058356268142351.at mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     mOcs0qqtJYmueMnfTyCFx 	mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   
     
     
 
  	  mhxtTU7dvZHXCTSg8B8rx 	_13303058356268144138, 0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
   mif4ZCBkqdiqSYkR9AD0r 	 
 _14067181347882760969 mNDJrNgMXB1tBoFNaJO0d 	 
    	_13303058356268144138 mrpQVzv6u8gxvho1qUlil 	 
    	  
    		   
     
     .x mJTScPpWt8plE9Cz9fDU6 	 
            _13303058356268142351.at mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
      mI_QuD605u2H3qQFyuTju 	 
    	  
    		   
     
 mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    _13303058356268144138, 1 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
  	  muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     
     
  1. mJTScPpWt8plE9Cz9fDU6 	 
    	  
            _13303058356268142348.at mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
      mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		  mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     mFsSEF_3_iD2mT6nZG9QR 	 
    	  
_13303058356268144138, 0 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
      mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
   _14067181347882760969 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 
 _13303058356268144138 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
    .y mlqoNTA3LQoUJF6i5YDFc 	 
    	  
    		   
     
  
         mCvAz6nTbqhvwRULRgKe4 	 
    	  


        
        solve mSa4WnWih0z4lSo9RYUGU 	_13303058356268142351, _13303058356268142348, _13303058356268144267, DECOMP_SVD mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
        
        _15087904812230018442  ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     Point3f miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
_13303058356268144267.at mca1GaR7Rv9qOZsisqKBB 	 
  mI_QuD605u2H3qQFyuTju 	 
    	  
    		   
     
     
 
 mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
     
 
 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
 0, 0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
 , -1., _13303058356268144267.at mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		    mglDNKH5ah89GptW6H4Cu 	 
    	  
    mRHNkLPwUSnx20pmLgrTq 	 
    	  
    		   
     
    mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		  1, 0 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
  mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
  	 
     muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		
    else
     mMRNM5hfPBWFjYCspldu3 	 

        
         mA9OyoOle98msK0BnFc8I 	 
    	  
    		   
     
   mReDuVelSknxaDAoDEmwT 	 
    	  
    		    mP8l6554fUQhsCw2PetD2 	 
    	  
    		   
     
     
 _13303058356268144138  mKcKHr_bTagXAK_pf8btG 	 
    	  0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 
  	  _13303058356268144138  mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   
     
     
 
   _16643961442089568442 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
  	 _13303058356268144138 mkGHGzUDDVqHIjIdYGe6S 	 
    	  
    		   
     
     
 
  	 mhyL_M5gnmQzwyHW45MdA 	 
    	  
  
         mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
     
 
 
            _13303058356268142351.at mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
    mglDNKH5ah89GptW6H4Cu 	 
    	  
    		m_j6ZkbEfLCgUqtaolYTp 	 
    	  
    		   
     
   mhxtTU7dvZHXCTSg8B8rx 	 
_13303058356268144138, 0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
  	  mif4ZCBkqdiqSYkR9AD0r 	 
     _14067181347882760969 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
 _13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    	  
  .y mVOlbMaOu1U0SC2oeKIzP 	 
    	
            _13303058356268142351.at mYI2nkSxgJHf1pY1PttV1 	 
    	  
    		    mlkEZnzYCXAgDnYDi5up3 	 
    	  
    		   
     
    mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		 mFsSEF_3_iD2mT6nZG9QR 	 _13303058356268144138, 1 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
       mKcKHr_bTagXAK_pf8btG 	 
    	  
    	 1. mftnbgRvzOIVyL93HyyWt 	 
   
            _13303058356268142348.at mqEAvVDOCXqrrwrTRByrM 	 
   mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
mE4_Vrik0lveh4HNJUk1B 	 
    	 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     _13303058356268144138, 0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
    myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     _14067181347882760969 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
     
 
  	_13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
     
 
 .x mriCvhMavpfheoLNc0eCD 	 
    	  
    		   

         mICILgDpdCTDSJqQAn06L 	 
    

        
        solve mSa4WnWih0z4lSo9RYUGU 	 
_13303058356268142351, _13303058356268142348, _13303058356268144267, DECOMP_SVD mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   mftnbgRvzOIVyL93HyyWt 	 
 
        
        _15087904812230018442  mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 
   Point3f mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     -1., _13303058356268144267.at mca1GaR7Rv9qOZsisqKBB 	 
   maOczvhF_v9OTsK70ZZut 	 
    	  
 mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
     
     
  mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
  0, 0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
 , _13303058356268144267.at mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     mOcs0qqtJYmueMnfTyCFx 	mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
  mhxtTU7dvZHXCTSg8B8rx 	 
  1, 0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
    mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		 
     maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 
 mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     
 
 


Point2f MarkerDetector_Impl myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		  _8396213235373312360 mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   const cv mdssZV6TB06aiisDwN1cX 	Point3f& _17129155073204649235, const cv mYGfQUZmV9IjKAPVrLhZl 	 
    	Point3f& _17129155073204649234 mXAYJa6osZ6HNTIEEBnr0 	 
 
 mJkMyi0NbVRDgE__LMR_m 	 
   
    
    Mat _13303058356268142351 mReDuVelSknxaDAoDEmwT 	 
   2, 2, CV_32FC1, Scalar mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
   0 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
 
 mXAYJa6osZ6HNTIEEBnr0 	 
     mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
  
    Mat _13303058356268142348 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
 2, 1, CV_32FC1, Scalar mhORIPgMIfN3Fn8aCQBuU 	 
    	  
   0 mzf4ZxeZY8wF2XnrdYK61 	 
     mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
 mdmuaUz9iCkCckSUhcEv1 	 
  
    Mat _13303058356268144267 mPdHdcAZ6XJhwf8wLtULI 	 
    	  

    _13303058356268142351.at mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
     
     
 
 mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		   
     
     
 
mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
     
 
  	  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
   0, 0 mzf4ZxeZY8wF2XnrdYK61 	 
    	   myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 
   _17129155073204649235.x mftnbgRvzOIVyL93HyyWt 	
    _13303058356268142351.at mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
   maISPbNJKXWB2QqsuuExM 	 
    	  
   mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		 mtbP4KQJdh36UGELfV2zq 	 
    	  
    	0, 1 mgkSwnYHQivQIpeAwgr20 	 
    	  
    mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
   _17129155073204649235.y mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     

    _13303058356268142348.at mqEAvVDOCXqrrwrTRByrM 	 
   mnqZGwZqTTi1dekKxujAE 	 
    	  
    		   
     
mW1YUos9eL_9NmgJuSDH7 	 
    	  
    		   
     
     
 mFlVjO0mLpwnCN5a1Quio 	 
    	0, 0 msubWq7nTVSPilWqmTzkx 	 
    	    mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
 -_17129155073204649235.z mlqoNTA3LQoUJF6i5YDFc 	 
    

    _13303058356268142351.at mYI2nkSxgJHf1pY1PttV1 	 
    	  
     maOczvhF_v9OTsK70ZZut 	 
    	  
    		   
  mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		   
      mhxtTU7dvZHXCTSg8B8rx 	 
    	  1, 0 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
    mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		 _17129155073204649234.x mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
    _13303058356268142351.at mK5OxIt23gZzSiTA8trU8 	 mYKwa_OYBeVXzRPMa_mz6 	mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
  mp3H4249LtCVDCYFqQqz4 	 
1, 1 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
   mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    		   
     
     
 
   _17129155073204649234.y mINcNsH05D0QZDej9wl4h 	 
    	  
    		   

    _13303058356268142348.at mbG1GEmOdh2dXkJZ42sXo 	 
    mglDNKH5ah89GptW6H4Cu 	 
    	mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
    1, 0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		    mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   -_17129155073204649234.z mdmuaUz9iCkCckSUhcEv1 	 
    	  
    

    
    solve mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
 
 _13303058356268142351, _13303058356268142348, _13303058356268144267, DECOMP_SVD muiDYQbmwLxL3PGrwWGeP 	 
    	  
 mftnbgRvzOIVyL93HyyWt 	 
    	  
   
     mGbN63kjoGx6fvYq0oiYN 	 
    	Point2f mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
     
 
  	_13303058356268144267.at mlP1m6taP4mQVYA_j8Oxe 	 
    	  
   mWokjWH0MHqyBOx4j0Oac 	 
    	  
    		  mE4_Vrik0lveh4HNJUk1B 	 
    mhORIPgMIfN3Fn8aCQBuU 	0, 0 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		  , _13303058356268144267.at mca1GaR7Rv9qOZsisqKBB 	 
    	  maOczvhF_v9OTsK70ZZut 	 
    	  
    mW1YUos9eL_9NmgJuSDH7 	 
  mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   1, 0 mXAYJa6osZ6HNTIEEBnr0 	 
    mycwFs63h7Mi3ggRkMEVm 	 mPdHdcAZ6XJhwf8wLtULI 	 

 mnSkEvR4SbDwQxj23xB1M 	 
    	  
    		   
     
     
 
  	








 mKmIjE1RujJ5RSETUjqwW 	 
    	  
    		   
     
     
 
  	MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
     
 
_10815521206485692603 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  Mat _17276638435886805939, std mdssZV6TB06aiisDwN1cX 	 
 vector mbG1GEmOdh2dXkJZ42sXo 	 
    	std mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    vector mW1ds9XwNwevT5B2b3j8B 	 
    cv mEMN2sRTwHcTUl7SNSw0d 	 
    Point migVyykpmr2io3DNlFdHK 	 
    	  
    		   
     
     
 
  	& _10998538416191004035 msubWq7nTVSPilWqmTzkx 	 
 
 mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
     
 
  	
    drawContours mp3H4249LtCVDCYFqQqz4 	 
 _17276638435886805939, _10998538416191004035, -1, Scalar mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
 255, 0, 255 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   mXAYJa6osZ6HNTIEEBnr0 	 
    mriCvhMavpfheoLNc0eCD 	 
    	  
    	
 mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
 


 mKqJtaKtNNFCDA9awnods 	 
    	  
    		   
     
     
 
  	 MarkerDetector_Impl mpJt2kGThF7wb3VNzG38b 	 
    _13747571233701806900 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		  Mat& _16232574195069562409, vector mCALzjQ0bwpDnngl_oSsi 	 
    	  
    		   Point mE4_Vrik0lveh4HNJUk1B 	 
  & _14091102513355313451, Scalar _12505068097757366359 mmCJ670wA_VHgip7JZ1dW 	
 mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		  
     maB_pNl4zuODt3oqXg9EB 	 
    	  
    		   
     
     
  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
    unsigned  mP8l6554fUQhsCw2PetD2 	 
_13303058356268144138  myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
  0 mdmuaUz9iCkCckSUhcEv1 	 
    	   _13303058356268144138  mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     
 
  _14091102513355313451.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
   mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 
  _13303058356268144138 mEZrtAN7pSZl5y4oEHd38 	 
   mAnDeXfeHaujEzGBbrjil 	 
    	  
    		 
     mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     
        cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    rectangle mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     
_16232574195069562409, _14091102513355313451 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		_13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
  , _14091102513355313451 mA4oXllup8K3T5dxkluRR 	 
    	  
 _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
, _12505068097757366359 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
 mxdAvfSsdzliezc0uyUMk 	 
  
     mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
 
 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		  

 myqrAJLu9GRcs5sFEN1xM 	 
    	  
    		   
     
    MarkerDetector_Impl myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     _10891860653827325848 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
   Mat& _16232574195069562409, vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
     
 
  	Point m_j6ZkbEfLCgUqtaolYTp 	 
    	  
 & _14091102513355313451, Scalar _12505068097757366359, moI11mwtxiOXpqDxK_aQL 	 
 _11719114631568207584 mgkSwnYHQivQIpeAwgr20 	 
 mfKhTg3wpiK_YhdQzWWcS 	 
    	  
 
     mA9OyoOle98msK0BnFc8I 	 
     mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
  unsigned  moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     _13303058356268144138  ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		    0 mINcNsH05D0QZDej9wl4h 	 
     _13303058356268144138  mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
     
 
  _14091102513355313451.size mwTQhkbVNQHd2Xw4EA4fj 	 
     mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
  _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 
    mAnDeXfeHaujEzGBbrjil 	 
    	 
     mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
    
        cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		line mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    	_16232574195069562409, _14091102513355313451 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		_13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   
 , _14091102513355313451 mFyKKLtdivGGDlk8sYzsf 	 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
     
     
 
  	 _13303058356268144138 + 1 mlqM0snvYcrWCw2_QjhQi 	 
    % _14091102513355313451.size mKpq3GwvJxRduE5RsGgGP 	 
    	 mwTp2D1d4PfxNNOzzUfhS 	 
    	  
    		   
     
     , _12505068097757366359,_11719114631568207584 msubWq7nTVSPilWqmTzkx 	 
   mhGXMe8LHJXydR9dMisHj 	 
    	  
    		
     mDUyr1RAsHMG7u1BeTW3F 	 
   
 mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   
     
     
 
  	 


 mKmIjE1RujJ5RSETUjqwW 	 
    	  
    		   
 MarkerDetector_Impl myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     
 
  	 _5695532306146282654 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   Mat _5268605234504081842, const vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		 Marker mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		  & _14642194608118973580 mycwFs63h7Mi3ggRkMEVm 	 
    	  
 mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
   
     maB_pNl4zuODt3oqXg9EB 	 
    	  miAECMSxGwjxrcOKk0DII 	 
unsigned  mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		   
     
     
 
  	 _13303058356268144138  muQdV4OJL6V6gVxW6AdRy 	 
    	  
 0 mJTScPpWt8plE9Cz9fDU6 	 
    	  
     _13303058356268144138  mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
   _14642194608118973580.size mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
 mhGXMe8LHJXydR9dMisHj 	  _13303058356268144138 mwwJvnj2j3yLmklxxOEJQ 	  mgkSwnYHQivQIpeAwgr20 	 
 
     mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     
 
  	 
        cv mU808frSKQDZnEEU3Q3s9 	 
   line mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
_5268605234504081842, _14642194608118973580 mY2nz8M_6jpSxQZL8EYgU 	 
    	_13303058356268144138 mwTp2D1d4PfxNNOzzUfhS 	 
     mNDJrNgMXB1tBoFNaJO0d 	 
   0 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
 
  	, _14642194608118973580 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
    _13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    		   
     
     
 
  1 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
     
 
 , cv mdssZV6TB06aiisDwN1cX 	 
    	  
    Scalar miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     255, 0, 0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
  , 2 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
     
  mINcNsH05D0QZDej9wl4h 	 
    	  
 
        cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
  line mFsSEF_3_iD2mT6nZG9QR 	 
    	  
  _5268605234504081842, _14642194608118973580 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
     
     
 _13303058356268144138 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
     
 
  	  mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
    1 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
     
 
 , _14642194608118973580 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     
 
_13303058356268144138 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		  mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
     
     
 
  2 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
   , cv maKLz6mCz5anFyVle_MtD 	Scalar mp3H4249LtCVDCYFqQqz4 	 
    	  
    		255, 0, 0 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     
 
  , 2 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
   mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
     
   
        cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
 line mp3H4249LtCVDCYFqQqz4 	 
    	 _5268605234504081842, _14642194608118973580 mA4oXllup8K3T5dxkluRR 	 
    	  
    		   
     
  _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   
     
 mILaQGKCAmcKrYQNhgWUq 	 
2 mJtGCV8zXQjnVDVBVdvFZ 	 
 , _14642194608118973580 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
 _13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		3 mEFd2D2UDF9SIoPfQtUv6 	 
 , cv mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
     
  Scalar mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
 255, 0, 0 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
 , 2 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
   mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
  
        cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
     
   line mmmC9tOGiLK6UaJr0E5vz 	 
    	  
   _5268605234504081842, _14642194608118973580 mFyKKLtdivGGDlk8sYzsf 	_13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
 3 mbViqhyIcr6lGWibuo3Im 	 
    	  , _14642194608118973580 mTjppsgNpY1Pjyv5Z_zMr 	 
    	  
    _13303058356268144138 mUB1yrSrKOwldqxmCatN2 	 
    	  
    		 mdF98bHO7yrxGJn0aQZVK 	 
    	  
    		   
     
     
 0 msdqcdg5NNrdQnc_PT1Ee 	 
    	  
    		   , cv mEMN2sRTwHcTUl7SNSw0d 	 
   Scalar mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
    255, 0, 0 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   , 2 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
   mPdHdcAZ6XJhwf8wLtULI 	 
    
     mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
     
     

 mgjPImSFwUcUKl9XTKqqB 	 
    	  
    


 mKqJtaKtNNFCDA9awnods 	MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
     
setMarkerLabeler miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
  cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
  Ptr mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     MarkerLabeler mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		 _13776510099302020409 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		  
 mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
  
    _4383831888714590158  mCm219F3DHVwNe_CsrCeK 	 
    	 _13776510099302020409 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    
 mhl3Z6oGBbP13ZxehUcg9 	 
    	 

 mfJA9NVd6FBgGhRSkkhhs 	MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    	setDictionary mhORIPgMIfN3Fn8aCQBuU 	 
  moI11mwtxiOXpqDxK_aQL 	 
    	  
    		   
     
     
 
_1265885183454069381,
                                    mlkEZnzYCXAgDnYDi5up3 	 
 _1582275183843417612 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     
 mLdYY4X2b7VOjtTSnd7Hj 	 
    
    _4383831888714590158  mM3tRrWbRPqPOU3G4ShKT 	 
    	   MarkerLabeler myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
    create mhxtTU7dvZHXCTSg8B8rx 	 
    miAECMSxGwjxrcOKk0DII 	Dictionary mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		DICT_TYPES mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
 _1265885183454069381, _1582275183843417612 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
   
    _18062104616271777338.error_correction_rate mKcKHr_bTagXAK_pf8btG 	 
    	  
  _1582275183843417612 mriCvhMavpfheoLNc0eCD 	
    _18062104616271777338.dictionary muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
     aruco mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   Dictionary maKLz6mCz5anFyVle_MtD 	 
    	  
    		   getTypeString mhxtTU7dvZHXCTSg8B8rx 	 
    	  
 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
Dictionary myuwTFtkH1L5Be2OVY9rt 	 
    	  DICT_TYPES mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 
 _1265885183454069381 mgkSwnYHQivQIpeAwgr20 	 
    	  
    		    mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     

 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
     
 





 myqrAJLu9GRcs5sFEN1xM 	 
 MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 
 setDictionary mSa4WnWih0z4lSo9RYUGU 	 
    	  
   string _1265885183454069381,  mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		   
     
     
 
  	 _1582275183843417612 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
 mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
  
		 moNuUrvhPRwgFBZS8fSa1 	 
    	  
    		   
 _4657944431535098742 muQdV4OJL6V6gVxW6AdRy 	  mNDJrNgMXB1tBoFNaJO0d 	 
    	  
    		   
  mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     
     
 
  miAECMSxGwjxrcOKk0DII 	 
    	  
  mWokjWH0MHqyBOx4j0Oac 	 
    	  
    	_13303058356268144138 muiDYQbmwLxL3PGrwWGeP 	 
  mT_x8cqp5t43PgqNMR8gO 	 
    	  
    		 
			std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    stringstream _5268611907574360399 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
     
 
  _5268611907574360399 mOk7NgrdfVmJx9axvYv9F 	 
    	  
    		 _13303058356268144138 mJTScPpWt8plE9Cz9fDU6 	 mLfKYVMLDthbyvvLerNPJ 	 
_5268611907574360399.str maHkatHu0Jap4oTaT5q4_ 	 
 mINcNsH05D0QZDej9wl4h 	 
    	  
    	
			 mgjPImSFwUcUKl9XTKqqB 	 
    	  
    		   
  mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 
        _18062104616271777338.dictionary mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     _1265885183454069381 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
 
    _4383831888714590158  mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
  MarkerLabeler mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
  create mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
   _1265885183454069381, _4657944431535098742 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  _1582275183843417612 mhyL_M5gnmQzwyHW45MdA 	 
    	  
     mXAYJa6osZ6HNTIEEBnr0 	 
 mxdAvfSsdzliezc0uyUMk 	 
    	  

    _18062104616271777338.error_correction_rate mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
_1582275183843417612 mINcNsH05D0QZDej9wl4h 	 
    
 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 
 


cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
Mat MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    	getThresholdedImage mReDuVelSknxaDAoDEmwT 	 
 mxNiL7NRse0iP2D2VgJvE 	 
    	  
    		   
     
     
 
 _5268611906072959276 msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
 

 mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     

     mwQUfI7G4pBH6IJQiBjmU 	 
  mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
_16594497104544919971.size mH1xQMRmYb0Y4RDp2hARz 	 
    	  
    		   
     
     
 
   mnZ6t3BhMZ_1d7zzE72ah 	 
    	  
    		   
     
    0 msubWq7nTVSPilWqmTzkx 	 
    	  
     mTAavMivNX5WuUrRQXoEf 	 
    	  
   cv mYGfQUZmV9IjKAPVrLhZl 	 
    	Mat mdWkXjuaPd4Se0r0SdY1e 	 
    	  
 mhGXMe8LHJXydR9dMisHj 	 
   
     mMNJIG0z6TLGgbjrhllmy 	 
    	  
    	 mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
    _5268611906072959276 moE42zHNBVjnlCdllZAkS 	 
    	  
    	_16594497104544919971.size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     
     
 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
      _5268611906072959276 mif4ZCBkqdiqSYkR9AD0r 	 
    	  
    	_16594497104544919971.size mKpq3GwvJxRduE5RsGgGP 	 
    	  
   -1 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
     
  
     maoHwm5lyecyelmN95sur 	 
    	  _16594497104544919971 mNDJrNgMXB1tBoFNaJO0d 	 
    	  
 _5268611906072959276 mDd5IIsnjfLI1lcygRsW3 	 
    	  
    		   
     
     mftnbgRvzOIVyL93HyyWt 	 
    	  
    	
 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   




 mc6SGgM2Uzvo_wy5KTima 	 
   MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    		 _8160328761135174279 mmmC9tOGiLK6UaJr0E5vz 	 
    vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
      cv mdssZV6TB06aiisDwN1cX 	 
Point2f  m_j6ZkbEfLCgUqtaolYTp 	 _16232574195069562409, vector mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
    cv mpJt2kGThF7wb3VNzG38b 	 
    	  Point2f  mRHNkLPwUSnx20pmLgrTq 	 
    	 &_5268605234504081842, const Mat &_2920695669964880276, const Mat &_14932605280544191270 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     mMRNM5hfPBWFjYCspldu3 	 
    	  
    		   
     
     
 
  	 
    
    cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    	Mat _3257878217983167715  mdKhcOUXVqyCMdccisL_a 	 
 cv mU808frSKQDZnEEU3Q3s9 	 
    	 Mat mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
 3, 1, CV_32FC1, cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 
  Scalar mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
  all mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
 
  	 0 mzf4ZxeZY8wF2XnrdYK61 	 
    	   mAnDeXfeHaujEzGBbrjil 	 
    	  
  mINcNsH05D0QZDej9wl4h 	 
    	  
    		   

    cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
     
 
  Mat _3175884290294458214  mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
     
 
   _3257878217983167715.clone mcznTYeCGOAygtXXAPYS_ 	 
    	  
    		   
     
  mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 
  	 
    
    vector mW1ds9XwNwevT5B2b3j8B 	 
    	  
    		   
     
  cv mpJt2kGThF7wb3VNzG38b 	 Point3f  mtJAThUzPUAnb_DMXiQOL 	 
  _15604885210959594850 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
 
  	 
     m_BNZbnU2Y1bOBnnPOF0b 	 
    	  
    		   
     
     
 
 mhORIPgMIfN3Fn8aCQBuU 	 
unsigned  mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
   _13303058356268144138  mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
   0 mlqoNTA3LQoUJF6i5YDFc 	 
   _13303058356268144138  mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   _16232574195069562409.size mzeHK1hG1SYQMISNMWMB8 	 
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
  _13303058356268144138 mo7mKuzaX2h9vw2rEj5qh 	 
    	  
    		   
     
     
 
  	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
 
        _15604885210959594850.push_back mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
     
 
cv maKLz6mCz5anFyVle_MtD 	 Point3f mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
   mSa4WnWih0z4lSo9RYUGU 	 
    	  _16232574195069562409 mGYpOkNIG_qSvYXBOU9Vf 	 
    	 _13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	 
.x - _2920695669964880276.at mqEAvVDOCXqrrwrTRByrM 	   mnECjbnhLknZie3Z5iHP2 	 
    	  
     mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   
     
   mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
     
   0, 2 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		    mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
 / _2920695669964880276.at mK5OxIt23gZzSiTA8trU8 	 
    	  
    		   
     
     mnqZGwZqTTi1dekKxujAE 	 
    	  
 mW1YUos9eL_9NmgJuSDH7 	  mmmC9tOGiLK6UaJr0E5vz 	 
    	  
0, 0 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    , 
                                               mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     _16232574195069562409 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   _13303058356268144138 mIkhxhgSNMt_JUZR7ce1U 	 
    	  
    		   .y - _2920695669964880276.at mbG1GEmOdh2dXkJZ42sXo 	 
    	  
    		   
     
    mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		  mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
   mmmC9tOGiLK6UaJr0E5vz 	 
  1, 2 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   / _2920695669964880276.at mW1ds9XwNwevT5B2b3j8B 	 
    	  
     mI_QuD605u2H3qQFyuTju 	 
    	  
    		    mtJAThUzPUAnb_DMXiQOL 	 
     mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
  1, 1 mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
    , 
                                              1 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		  mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
     
     
 
  mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
  
    cv mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
projectPoints mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     _15604885210959594850, _3257878217983167715, _3175884290294458214, _2920695669964880276, _14932605280544191270, _5268605234504081842 mlqM0snvYcrWCw2_QjhQi 	  mJTScPpWt8plE9Cz9fDU6 	 
 
 mnSkEvR4SbDwQxj23xB1M 	



 mc6SGgM2Uzvo_wy5KTima 	 
    	  
MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
  saveParamsToFile mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
   const std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
   string &_3257891857586418487 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    const mN0TszoCQmyzxmobsgV2H 	 
    	  
    		   
     

    cv mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
 FileStorage _16232574195041746640 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     _3257891857586418487, cv mUCEzhGWrU8OYqcHVPlVW 	 
    	  
    		   
     
     
 
 FileStorage mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 
  WRITE mgkSwnYHQivQIpeAwgr20 	 
    	  
    		   
 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
 
     mikiSyOnVry6pvQ1Ds28H 	 
     mxD0ASUiBIk9J4KLYW_eX 	 
    	  
    		   
     
     
 
  _16232574195041746640.isOpened maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
 mgkSwnYHQivQIpeAwgr20 	 
  throw std mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
 runtime_error mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
    "\x5c\x78\x34\x33\x5c\x78\x36\x66\x5c\x78\x37\x35\x5c\x78\x36\x63\x5c\x78\x36\x34\x5c\x78\x32\x30\x5c\x78\x36\x65\x5c\x78\x36\x66\x5c\x78\x37\x34\x5c\x78\x32\x30\x5c\x78\x36\x66\x5c\x78\x37\x30\x5c\x78\x36\x35\x5c\x78\x36\x65\x5c\x78\x32\x30"+_3257891857586418487 mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
     
     
 
  mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
    _18062104616271777338.save mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		 _16232574195041746640 mycwFs63h7Mi3ggRkMEVm 	 
    	  
 mJTScPpWt8plE9Cz9fDU6 	 
    	  
 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     


 mwu5s8ye7pYEdPIYXjU5h 	 
    	  
    		   
     
   MarkerDetector_Impl maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
    loadParamsFromFile mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
    const std mdssZV6TB06aiisDwN1cX 	 
    	string &_3257891857586418487 mycwFs63h7Mi3ggRkMEVm 	 
    	  mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		 
    cv mYGfQUZmV9IjKAPVrLhZl 	 
 FileStorage _16232574195041746640 mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
_3257891857586418487, cv mpJt2kGThF7wb3VNzG38b 	 
  FileStorage mdssZV6TB06aiisDwN1cX 	 
    	  
READ msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
 
 mINcNsH05D0QZDej9wl4h 	 
  
     mX_x9bVx2zqKO8c2FxqgZ 	 
    	  
    		   
     
     
 
   mnswinmeXuam57kXH7myI 	 
    	  
    		   
     
  _16232574195041746640.isOpened mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
      mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     
     
 
  	 throw std maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
  runtime_error miAECMSxGwjxrcOKk0DII 	"\x5c\x78\x34\x33\x5c\x78\x36\x66\x5c\x78\x37\x35\x5c\x78\x36\x63\x5c\x78\x36\x34\x5c\x78\x32\x30\x5c\x78\x36\x65\x5c\x78\x36\x66\x5c\x78\x37\x34\x5c\x78\x32\x30\x5c\x78\x36\x66\x5c\x78\x37\x30\x5c\x78\x36\x35\x5c\x78\x36\x65\x5c\x78\x32\x30"+_3257891857586418487 mAnDeXfeHaujEzGBbrjil 	 
    	   mftnbgRvzOIVyL93HyyWt 	 
    	  
    		
    _18062104616271777338.load mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		  _16232574195041746640 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
     
     
 mdmuaUz9iCkCckSUhcEv1 	 
 
    setDictionary mhORIPgMIfN3Fn8aCQBuU 	 
    	  
   _18062104616271777338.dictionary,_18062104616271777338.error_correction_rate msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
  mlqoNTA3LQoUJF6i5YDFc 	 
    
 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
     
 
 

 mKmIjE1RujJ5RSETUjqwW 	 
    	  
    		   
     
    MarkerDetector_Impl mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
toStream miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
std mpJt2kGThF7wb3VNzG38b 	 
    	  
    		   
    ostream &_5268611907574360399 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		  const
 mN0TszoCQmyzxmobsgV2H 	
    uint64_t _5268611907573361194 mKcKHr_bTagXAK_pf8btG 	 
    	  
    		   
     
     13213 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
    
    _5268611907574360399.write mhxtTU7dvZHXCTSg8B8rx 	 
    	  
    		   
   mhORIPgMIfN3Fn8aCQBuU 	char* mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
     
     
 
&_5268611907573361194,sizeof mSa4WnWih0z4lSo9RYUGU 	 
    _5268611907573361194 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
   mmCJ670wA_VHgip7JZ1dW 	 
    	  
     mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
 
    _18062104616271777338.toStream mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
_5268611907574360399 muiDYQbmwLxL3PGrwWGeP 	 
 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
 
 mDUyr1RAsHMG7u1BeTW3F 	 
    	  
    		   
     
     
 
  	

 mKqJtaKtNNFCDA9awnods 	 
    	  
    		   
 MarkerDetector_Impl mYGfQUZmV9IjKAPVrLhZl 	 
    	  
    		   
 fromStream mhORIPgMIfN3Fn8aCQBuU 	 
    	std mU808frSKQDZnEEU3Q3s9 	 
    	  
   istream &_5268611907574360399 mmCJ670wA_VHgip7JZ1dW 	 
 mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
 
    uint64_t _5268611907573361194 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
     
     
 
 13213 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
    
    _5268611907574360399.read mtbP4KQJdh36UGELfV2zq 	 
    	  
   miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
 char* mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		  &_5268611907573361194,sizeof miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
    _5268611907573361194 mXAYJa6osZ6HNTIEEBnr0 	 mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
     
     mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
   
     mEwOO8zzJcEkF96gfFa1e 	 
   miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
     
     
 
  _5268611907573361194 mtDHooAMb6ubWraYLa7pj 	 
    	  
 13213 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
      throw std mfx1fLYDWN4YRZNnQEsJN 	 
    	 runtime_error mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     
    "\x5c\x78\x34\x64\x5c\x78\x36\x31\x5c\x78\x37\x32\x5c\x78\x36\x62\x5c\x78\x36\x35\x5c\x78\x37\x32\x5c\x78\x34\x34\x5c\x78\x36\x35\x5c\x78\x37\x34\x5c\x78\x36\x35\x5c\x78\x36\x33\x5c\x78\x37\x34\x5c\x78\x36\x66\x5c\x78\x37\x32\x5c\x78\x35\x66\x5c\x78\x34\x39\x5c\x78\x36\x64\x5c\x78\x37\x30\x5c\x78\x36\x63\x5c\x78\x33\x61\x5c\x78\x33\x61\x5c\x78\x36\x36\x5c\x78\x37\x32\x5c\x78\x36\x66\x5c\x78\x36\x64\x5c\x78\x35\x33\x5c\x78\x37\x34\x5c\x78\x37\x32\x5c\x78\x36\x35\x5c\x78\x36\x31\x5c\x78\x36\x64\x5c\x78\x32\x30\x5c\x78\x36\x39\x5c\x78\x36\x65\x5c\x78\x37\x36\x5c\x78\x36\x31\x5c\x78\x36\x63\x5c\x78\x36\x39\x5c\x78\x36\x34\x5c\x78\x32\x30\x5c\x78\x37\x33\x5c\x78\x36\x39\x5c\x78\x36\x37\x5c\x78\x36\x65\x5c\x78\x36\x31\x5c\x78\x37\x34\x5c\x78\x37\x35\x5c\x78\x37\x32\x5c\x78\x36\x35" muiDYQbmwLxL3PGrwWGeP 	 
    	  
  mJTScPpWt8plE9Cz9fDU6 	 
    	
    _18062104616271777338.fromStream mhORIPgMIfN3Fn8aCQBuU 	 
    	  
   _5268611907574360399 mhyL_M5gnmQzwyHW45MdA 	 
    mlqoNTA3LQoUJF6i5YDFc 	 
  
    setDictionary mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
    _18062104616271777338.dictionary,_18062104616271777338.error_correction_rate msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
   mlqoNTA3LQoUJF6i5YDFc 	 
  

 mDUyr1RAsHMG7u1BeTW3F 	



 mc6SGgM2Uzvo_wy5KTima 	 
    	  
    		   
     
     MarkerDetector_Impl mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   _18048540700028965067 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
   std mYGfQUZmV9IjKAPVrLhZl 	 
    	  vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   cv mYGfQUZmV9IjKAPVrLhZl 	DMatch mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
      &_14641992596943690144  mmCJ670wA_VHgip7JZ1dW 	 mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     
 
  	 
     mabeHDqoCFUg5Mty5oLni 	 
    	  
    		   
     
 miAECMSxGwjxrcOKk0DII 	 _14641992596943690144.size mzeHK1hG1SYQMISNMWMB8 	 
    	  
    		   
     
   mnZ6t3BhMZ_1d7zzE72ah 	 
    	  
    		   
  0 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     
     
 
  mGbN63kjoGx6fvYq0oiYN 	 
    	  
    		   
  mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
  
    
     mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    _3257891898253592016 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   
     
     
 -1 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
     ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		   
     
   moNuUrvhPRwgFBZS8fSa1 	 
    	  
    		   
   _13303058356268144134:_14641992596943690144 mXAYJa6osZ6HNTIEEBnr0 	 
    _3257891898253592016 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
     
 
 std mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     max mtbP4KQJdh36UGELfV2zq 	 
 _3257891898253592016,_13303058356268144134.queryIdx mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
    

    
    vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
     
 
  	  moI11mwtxiOXpqDxK_aQL 	 
    	  
mBpPKNB5wfuTOV223BA2r 	 
    	  
    		    _3175890141660034698 mmmC9tOGiLK6UaJr0E5vz 	_3257891898253592016+1,-1 muiDYQbmwLxL3PGrwWGeP 	 
    	   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
   
    vector mca1GaR7Rv9qOZsisqKBB 	 
    	  
    		   
     
     
 
  cv mU808frSKQDZnEEU3Q3s9 	 
    	  
    		 DMatch mBpPKNB5wfuTOV223BA2r 	 _2844604575892364742 mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
     
_3257891898253592016 muiDYQbmwLxL3PGrwWGeP 	 
    	  
   mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
     
 
 
     mdEzmAkZNQkKD1HrLnSSo 	 
    	  
    		   
     
     _5268611906072959276 mu_nOcTFwUo8r0uNE351R 	 
    	  
    		   
 0 mhGXMe8LHJXydR9dMisHj 	 
    	  

     mYA_OUCZSQycbIZ5oB16m 	 
    	  
    		   _17308907134902915790 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		 mLEx8V9d9KOGX6TpfxDP_ 	 
    	  
    		   
mxdAvfSsdzliezc0uyUMk 	 
    	  


     mwkUVn0D8pUxgFq_rx20G 	 
     mclhRCo4dM7MadZp5V8m6 	 
    	  
    		   
     
     
 
 &_15915593883518787333:_14641992596943690144  mycwFs63h7Mi3ggRkMEVm 	 
    mypSy3lS4LRIjRYTxVxzg 	 
    	  
    		   
     
     
 
  	
         mJvv2tbrel2xOYjvgipUL 	 
   mSa4WnWih0z4lSo9RYUGU 	 
    	  
    	_3175890141660034698 mFyKKLtdivGGDlk8sYzsf 	 
    	  
    		   
     
     _15915593883518787333.queryIdx mwTp2D1d4PfxNNOzzUfhS 	 maDn6NcmB5JPmBvJglMEd 	 
    	  
    		   
     -1 mAnDeXfeHaujEzGBbrjil 	 
   mjbtcSgN5ZQfkGDsoYG4l 	 
    	  
    		   
     
     
 
            _3175890141660034698 mY2nz8M_6jpSxQZL8EYgU 	 
    	  
    		   
 _15915593883518787333.queryIdx mUB1yrSrKOwldqxmCatN2 	 
    	  
    		   
     
   ma6VjqdfajK4BX9gkoGiD 	 
    	  
    	_5268611906072959276 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
     
  
         mJOnXqKm3GBylSdRjpXAA 	 
    	  
    		
         mHcxzZHoWX11H4xEjR59T 	 
    	  
    		   
     
     
 
 mT_x8cqp5t43PgqNMR8gO 	 

             mvw_MKiY3S1FcVNfJQCRT 	 
    	  
    	 mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
  _14641992596943690144 mILaQGKCAmcKrYQNhgWUq 	 
    	  
    		   _3175890141660034698 mILaQGKCAmcKrYQNhgWUq 	 
   _15915593883518787333.queryIdx mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
       mrpQVzv6u8gxvho1qUlil 	 
    	  
 .distance mtJAThUzPUAnb_DMXiQOL 	 
    	  
    		   _15915593883518787333.distance mhyL_M5gnmQzwyHW45MdA 	 
     mfKhTg3wpiK_YhdQzWWcS 	 
    	  
   
                _14641992596943690144 mNDJrNgMXB1tBoFNaJO0d 	 
    	   _3175890141660034698 mGYpOkNIG_qSvYXBOU9Vf 	 
   _15915593883518787333.queryIdx mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
     
 
    mDd5IIsnjfLI1lcygRsW3 	 
 .queryIdx muQdV4OJL6V6gVxW6AdRy 	 
   -1 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
  
                _3175890141660034698 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
     
     
 
_15915593883518787333.queryIdx mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
   muQdV4OJL6V6gVxW6AdRy 	 
  _5268611906072959276 mVOlbMaOu1U0SC2oeKIzP 	 
 
                _17308907134902915790 mif4ZCBkqdiqSYkR9AD0r 	 
    	   m_wyaFib5_cQG4j1HqokH 	 
    	  
   mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
   
             muuG2jhk4iNsA9KNmj6oA 	 
    	  
    		   
     
 
             moT0JKxDJVSALTDfSRUYM 	 
    	  
 mnU2hwoI16_nZ7reLKJTr 	 
    	  
 
                _15915593883518787333.queryIdx mu_nOcTFwUo8r0uNE351R 	 
    -1 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
                _17308907134902915790 mdKhcOUXVqyCMdccisL_a 	  m_wyaFib5_cQG4j1HqokH 	 
    	  
    		   
     
mdmuaUz9iCkCckSUhcEv1 	 
    	
             maCQ9r5fSln_CXgRXGFvO 	 
    	  
         maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 

        _5268611906072959276 mUq8qfNXjDE9FPlMHvjf4 	 
    	  
    		   
     
   mdmuaUz9iCkCckSUhcEv1 	 
     maCQ9r5fSln_CXgRXGFvO 	 
    	  


     mWHxIxEh8g9mg3Hyipn8D 	 
    	  
    		   
     
     
 
 mFsSEF_3_iD2mT6nZG9QR 	 
    	  
_17308907134902915790 msubWq7nTVSPilWqmTzkx 	 
    
        _14641992596943690144.erase mhORIPgMIfN3Fn8aCQBuU 	 
  std maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
  remove_if mFsSEF_3_iD2mT6nZG9QR 	 
    	  
    		   
     _14641992596943690144.begin maHkatHu0Jap4oTaT5q4_ 	 
    	  
,_14641992596943690144.end mwTQhkbVNQHd2Xw4EA4fj 	 
    	  
    		   
   ,  mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    	 mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     mReDuVelSknxaDAoDEmwT 	 
    	  
 const cv mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     DMatch &_13303058356268144134 mmCJ670wA_VHgip7JZ1dW 	 
    	  
   mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    miFyHzo07syL8tsy3JLAT 	 
    	  
    		  _13303058356268144134.trainIdx mHOvg7vOJH6ujsVsg3S5G 	 -1  mQfgxxEXCA984FTu8Jz8Q 	 
    	  
    		   
     
 _13303058356268144134.queryIdx mgAgf2KiVOzOHJDU4qKPI 	 
    	  
    		  -1 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
  mhl3Z6oGBbP13ZxehUcg9 	 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		, _14641992596943690144.end maHkatHu0Jap4oTaT5q4_ 	 
    	  
    		   
  muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
     mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
  


 mgjPImSFwUcUKl9XTKqqB 	 
    

 myqrAJLu9GRcs5sFEN1xM 	 
    	  
    		   
     
     
 MarkerDetector_Impl mUCEzhGWrU8OYqcHVPlVW 	 _14028278894506040778 mFlVjO0mLpwnCN5a1Quio 	 
    	  
    		   
     
     
 
 std mdssZV6TB06aiisDwN1cX 	 
    	  
    vector mlP1m6taP4mQVYA_j8Oxe 	 
  Marker mE4_Vrik0lveh4HNJUk1B 	 
    	  
    		   
& _6528263073538749848, cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		  Size _17190350386607761058  mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
  mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    
    std mEMN2sRTwHcTUl7SNSw0d 	 
    	  
    		   
     
    vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    	std mUCEzhGWrU8OYqcHVPlVW 	vector mca1GaR7Rv9qOZsisqKBB 	 
   cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		  Point2f mYxohqgekcJ8HhaDZvWcX 	 
    	  
    		  mW1YUos9eL_9NmgJuSDH7 	 
  _13891523452203630414 mINcNsH05D0QZDej9wl4h 	 
    	  
   
     ma9rnYFEs_TUiw_WyBflg 	const  moNuUrvhPRwgFBZS8fSa1 	 
    	  
    		   
 &_13303058356268144134:_6528263073538749848 mycwFs63h7Mi3ggRkMEVm 	 
    	 _13891523452203630414.push_back mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
  _13303058356268144134 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
 mdmuaUz9iCkCckSUhcEv1 	 
   
    _14028278894506040778 mReDuVelSknxaDAoDEmwT 	 
    	  
    		   
 _13891523452203630414,_17190350386607761058 mmCJ670wA_VHgip7JZ1dW 	 
    	  
    		   
 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
   
     mF9AQyKXtPTPy1zvAUpED 	 
    	  
   size_t _13303058356268144138 myJHqW7fkn_72nVEhKeZ6 	 
    	  
    		   0 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
_13303058356268144138 mHkLXuUOlyX2vZI7w3FQj 	_6528263073538749848.size mFwk30320retpLBiICndp 	 
    	  
    		   
     
     
 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
 _13303058356268144138 mBh4lc09qKYGXyU7FeqOv 	  msubWq7nTVSPilWqmTzkx 	 
    	  
    		   

        _6528263073538749848 mGYpOkNIG_qSvYXBOU9Vf 	 
_13303058356268144138 mbViqhyIcr6lGWibuo3Im 	 
    	  
    		   
     
 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    _13891523452203630414 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   _13303058356268144138 mo8MRbS3DUX_ZOlgmUSna 	 
    	  
    		   
     
     
 
 mftnbgRvzOIVyL93HyyWt 	 
    	  
   

 mCvAz6nTbqhvwRULRgKe4 	 
    	  
    		   
     
     
 
  	


 mQk9KGg1kmiZQnIZzbOuE 	 
    	  
  MarkerDetector_Impl mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     
     
 _14028278894506040778 mhORIPgMIfN3Fn8aCQBuU 	 
    	  
std mfx1fLYDWN4YRZNnQEsJN 	 
    	  
    		   
     
     
 
vector mlP1m6taP4mQVYA_j8Oxe 	 
    	  
    		   
     
   std myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
vector mHkLXuUOlyX2vZI7w3FQj 	 
    	  
    		   
     
     
 cv maKLz6mCz5anFyVle_MtD 	 
    	  
    		   
     
     
 
  Point2f mBpPKNB5wfuTOV223BA2r 	 
    	  
    		   
     
  mEc9zv3P8LW8haIvtztwe 	 
    	  
    		   
  & _6528263073538749848, cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
 Size _17190350386607761058  msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
 
  mJkMyi0NbVRDgE__LMR_m 	 
    	  
    		   
      mRzhpvoeHZK7yCqqzYDDp 	 
  mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		   
     _6528263073538749848.size mf_hJsy06Me1epT4PRx_l 	 
    	  
    		   
     
     mRuVXNtG32xpaNLi1hDLk 	 
    	  
    		   
   0 mmCJ670wA_VHgip7JZ1dW 	 
    	  
     mLfKYVMLDthbyvvLerNPJ 	 
    	  
    		   
     
     
 
  	 mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
     
     
 
 
     
      mCujczJix6jMpJcynoBiA 	 
_14793609818754720849 mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     0 mxdAvfSsdzliezc0uyUMk 	 
    	  


      moPdTa5HpJKbS1U6TqDjY 	 
    	  
    		   
     
    size_t _13303058356268144138 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
  0 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     _13303058356268144138 mHkLXuUOlyX2vZI7w3FQj 	 
    	  
   _14234691456098337398.size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
    		   
     
      mxdAvfSsdzliezc0uyUMk 	 
    	  
    		   
_13303058356268144138 mcstdE8Wwpam6tUMM45Sa 	 
    	  
   msubWq7nTVSPilWqmTzkx 	 
    	  
    		   
     
     
  mLdYY4X2b7VOjtTSnd7Hj 	 
    	  
    		   
    
          mWHxIxEh8g9mg3Hyipn8D 	 
    	 miAECMSxGwjxrcOKk0DII 	 
    	  
    		   
  _17190350386607761058.width  mYfYoOWdsOLTDCIBT7npX 	 
    	   _14234691456098337398 mZnfmoDANjVLDjZfzM5MR 	 
    	 _13303058356268144138 msdqcdg5NNrdQnc_PT1Ee 	.cols mzf4ZxeZY8wF2XnrdYK61 	 
    	  
    		   
      _14793609818754720849 ma6VjqdfajK4BX9gkoGiD 	 
    	  
    		   
     
     
_13303058356268144138 mftnbgRvzOIVyL93HyyWt 	 
    	  
    		   
     
     
 

          mZQqomBcB_Prq89ftbAiD 	 
    	  
  mTFkOkggRsxkeMv25hiJW 	 
    	  
    		   
     
     
 
  	mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
   
      mDUyr1RAsHMG7u1BeTW3F 	 
    	  
  
 

      cv mdssZV6TB06aiisDwN1cX 	 
    	  
    		   
     Size _1914080660989537839 mM3tRrWbRPqPOU3G4ShKT 	_17190350386607761058 mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
     
     
 
  	
      mhXXYzAVu3lDYyh7TkRWq 	 
    	  
  mMGij61UZUIIYyztVz9vN 	 
    	  
    		   
   _13044199310297575846 mM3tRrWbRPqPOU3G4ShKT 	 
    	  
    		   
     
    _14793609818754720849 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		 _13044199310297575846 msao8K6SR84Lu5ND7NCVt 	 
    	  
    		   
     
    0 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    		   
   _13044199310297575846 mEiOeyHRZlQujPqpgYY7u 	 mlqM0snvYcrWCw2_QjhQi 	 
     mfKhTg3wpiK_YhdQzWWcS 	 
    	  
    		   
     
     
 

          mOcs0qqtJYmueMnfTyCFx 	 
    	  
    		   
     
_6633594514234248811 mRwjoMr_aqph4iL4nu8NS 	 
    	  
    		   
     
       mYKwa_OYBeVXzRPMa_mz6 	 
    	mmmC9tOGiLK6UaJr0E5vz 	 
    	  
    		   
     
   _14234691456098337398 mA4oXllup8K3T5dxkluRR 	 
    	  
    	_13044199310297575846 mwTp2D1d4PfxNNOzzUfhS 	 
  .cols mlqM0snvYcrWCw2_QjhQi 	 
    	  
    		   
/float mtbP4KQJdh36UGELfV2zq 	 
    _1914080660989537839.width mAnDeXfeHaujEzGBbrjil 	 
    	  
    		   
  mftnbgRvzOIVyL93HyyWt 	 
   
         
          moPdTa5HpJKbS1U6TqDjY 	 
    	  
    		   
     
     
  mHXoMWKZSiZYUvqmVkLF5 	 
    	  
    		   
     
    &_13303058356268144134:_6528263073538749848 msubWq7nTVSPilWqmTzkx 	 
  
              mF9AQyKXtPTPy1zvAUpED 	 
    	  
 mHXoMWKZSiZYUvqmVkLF5 	 
    	  
    		   
     
     &_15913523031057945521:_13303058356268144134 mycwFs63h7Mi3ggRkMEVm 	 
    	  
    		   
     
   mN0TszoCQmyzxmobsgV2H 	 
   _15913523031057945521 mt6CTIKlbWyEq7tYJENOL 	 
    	  
    		   
     
     
_6633594514234248811 mriCvhMavpfheoLNc0eCD 	 
    	  
    		   
     
     
 maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
     
     
 
 
          moI11mwtxiOXpqDxK_aQL 	 
   _134566848691226369 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
      0.5+2.5*_6633594514234248811 mhGXMe8LHJXydR9dMisHj 	 
    	  
    		   
     
     
              std mdssZV6TB06aiisDwN1cX 	 
  vector mYfYoOWdsOLTDCIBT7npX 	 
    	  
    		   
     
     
 cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
    		   
     
     Point2f mel3l7ZRXwnAEsy0Wfxj_ 	 
    	  
    		   
     
     
 _5268611907161554282 mINcNsH05D0QZDej9wl4h 	 
    	  
    		   
     
     
              mwkUVn0D8pUxgFq_rx20G 	 
    	  
    		   
     
     
 
   mgxs4jaOm5WhsuDH7hsbo 	 
    	  &_13303058356268144134:_6528263073538749848 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
 
                  mwkUVn0D8pUxgFq_rx20G 	 
    	  
    		   
   myYAiLHDT3JvFKUJCC_FN 	 &_15913523031057945521:_13303058356268144134 mlqM0snvYcrWCw2_QjhQi 	 
    	    mDzQQrEx5Ki0C6uDHU2cy 	 
    	  
    		   
     
     
 
  _5268611907161554282.push_back mtbP4KQJdh36UGELfV2zq 	 
    	  
    		   
     
     
 
  _15913523031057945521 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
     
 mJTScPpWt8plE9Cz9fDU6 	 
    	  
    		   
    mJOnXqKm3GBylSdRjpXAA 	 
               cv mBBHVSlvDGP5NVUfEuhuf 	 
    	  
    		   
     
     cornerSubPix mhORIPgMIfN3Fn8aCQBuU 	 
    	  
    		 _14234691456098337398 mY2nz8M_6jpSxQZL8EYgU 	 _13044199310297575846 mDd5IIsnjfLI1lcygRsW3 	 
  ,_5268611907161554282,cv mpJt2kGThF7wb3VNzG38b 	 
  Size mmmC9tOGiLK6UaJr0E5vz 	 
    	  
 _134566848691226369,_134566848691226369 mXAYJa6osZ6HNTIEEBnr0 	 
    	  
    		   
     ,cv myuwTFtkH1L5Be2OVY9rt 	 
    	  
  Size mp3H4249LtCVDCYFqQqz4 	 
    	  
    		   
     
     
-1,-1 muiDYQbmwLxL3PGrwWGeP 	 
    	  
    		   
 ,cv maKLz6mCz5anFyVle_MtD 	 
    	  
TermCriteria mSa4WnWih0z4lSo9RYUGU 	 
    	  
    		   
     
 cv mpJt2kGThF7wb3VNzG38b 	 
  TermCriteria mEMN2sRTwHcTUl7SNSw0d 	 
   MAX_ITER , 4,0.5 mzf4ZxeZY8wF2XnrdYK61 	 
 muiDYQbmwLxL3PGrwWGeP 	 
    	  
     mdmuaUz9iCkCckSUhcEv1 	 
    	  
    		   
              mP8l6554fUQhsCw2PetD2 	 
    	  
    		   
     
_3175967589404451389 mCm219F3DHVwNe_CsrCeK 	 
    	  
    		   
     
     
 
  0 mVOlbMaOu1U0SC2oeKIzP 	 
    	  
    		   
   
              moPdTa5HpJKbS1U6TqDjY 	 
    	  
    		   
     
  mHXoMWKZSiZYUvqmVkLF5 	 
    	  
    		   
     &_13303058356268144134:_6528263073538749848 mhyL_M5gnmQzwyHW45MdA 	 
    	  
    		   
     
                  ms9iveRK8Fk_QtPMDvDcP 	 
    	  
    		 mgxs4jaOm5WhsuDH7hsbo 	 
    	  
&_15913523031057945521:_13303058356268144134 msubWq7nTVSPilWqmTzkx 	   mfKhTg3wpiK_YhdQzWWcS 	 
    	  
   _15913523031057945521  mdKhcOUXVqyCMdccisL_a 	 
    	  
    		   
     
  _5268611907161554282 mWkGo8xUdRIKgJ1DEUvvn 	 
    	  
    		   
  _3175967589404451389 mi940TUip6nLdi0tWD33F 	 
    	  
    		   
  mEFd2D2UDF9SIoPfQtUv6 	 
    	  
    		   
     mftnbgRvzOIVyL93HyyWt 	 
    	   muuG2jhk4iNsA9KNmj6oA 	 
  

         _1914080660989537839 muQdV4OJL6V6gVxW6AdRy 	 
    	  
    		   
_14234691456098337398 mGYpOkNIG_qSvYXBOU9Vf 	 
    	 _13044199310297575846 mJtGCV8zXQjnVDVBVdvFZ 	 
    	  
    		   
     
    .size mbHCSQc_uaLNP9Sf4Lz_n 	 
    	  
 mPdHdcAZ6XJhwf8wLtULI 	 
    	  
    	
      mCvAz6nTbqhvwRULRgKe4 	 
    	  
    	
  maCQ9r5fSln_CXgRXGFvO 	 
    	  
    		   
  
 mhl3Z6oGBbP13ZxehUcg9 	 
    	  
    		   
     
     
  mriCvhMavpfheoLNc0eCD 	 
   
#ifdef _3643599497981880515
#undef  mtDtuj5HWLyTAsK7Fmx4g 
#undef  mIM7YEc9Ba5XWDEr0m2YG 
#undef  miAr40ThvnnZei4PQ8nft 
#undef  mEc9zv3P8LW8haIvtztwe 
#undef mQj7wHAa1damVYwoD46UjZpPHvzvyA2
#undef mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y
#undef  mIyXpca78p_CKHmulak4e 
#undef  mAVrnO9aWNRf9b3dALx0J 
#undef  mI_QuD605u2H3qQFyuTju 
#undef  mhMsdnRaOV1FZ69nEgvbs 
#undef muRWS4RqXt1RDg1intuX3MkjrSgf2o4
#undef  mHOvg7vOJH6ujsVsg3S5G 
#undef  mfge932GrgApRFyCExy_M 
#undef  mIzujDpHjrUPsW3ssOAji 
#undef  mM0eyBFMShg9qdQPSMqiz 
#undef mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT
#undef  mC854TxsErP91YgtWBjLs 
#undef  mwxm9pz2KjGAhBIIfFMf4 
#undef  me9YsE5_K5dlCgWRVtztQ 
#undef  mCAzyIDtopeLXRxFfI0EK 
#undef  mabeHDqoCFUg5Mty5oLni 
#undef  m_owRLEm0gIJ4StPRwTkZ 
#undef  mBJ7M0ikk98KhD4Oi32wB 
#undef  mbtXL8AfsmYGQ1waevjwS 
#undef  moNuUrvhPRwgFBZS8fSa1 
#undef  mSD7jHYN8mOif4_CBtIg6 
#undef  mLhy8e0peljv3075Jx0N4 
#undef  mtDHooAMb6ubWraYLa7pj 
#undef  mAQWugjGggd1dm4Esoytv 
#undef  mOcs0qqtJYmueMnfTyCFx 
#undef  mhORIPgMIfN3Fn8aCQBuU 
#undef mPF9YW010VzHVkbdsdOMJgq7D81z3gH
#undef  mHIh6WyQKJh1ZKme1nslP 
#undef  mo03bPDhF7WKTf8ndM1Bk 
#undef  mFyKKLtdivGGDlk8sYzsf 
#undef mMinTurqhjOTBoJcyTuRpllwDXFTRab
#undef  mYxohqgekcJ8HhaDZvWcX 
#undef  mJkMyi0NbVRDgE__LMR_m 
#undef  mwBOm3LXJ8FMsqTgQKZ6O 
#undef m_Gim03zcA2esaeteCftKMhV2X3oFiR
#undef  mhl3Z6oGBbP13ZxehUcg9 
#undef  mdkQcL_ccA3dE51c_fq0e 
#undef  mv1ijGQAKacWqWAusY8nc 
#undef  mCqWliO9r5qeuU4xIw2kK 
#undef mZeHXgILeDH93lObH9TjZ9sjRzIIBMF
#undef  mF8CPQI5IssWjwlV2CXVE 
#undef  m_YnlLsKBlim0LDKxc0Xy 
#undef  moT0JKxDJVSALTDfSRUYM 
#undef  mOk7NgrdfVmJx9axvYv9F 
#undef  mfySD3GO3N8Vw4agWXnxR 
#undef  mwoUu824QThZXd8c3IKpk 
#undef  mCnIg_Afe_CAU6Bb6OxXH 
#undef  mFK5JCwqLjSVNjbuFv1Xz 
#undef  mTAavMivNX5WuUrRQXoEf 
#undef  mAtZroqlrY5Hmm_G3pFca 
#undef  mCQaCcJleVmF11nXRNijz 
#undef  mWHxIxEh8g9mg3Hyipn8D 
#undef  mCAk2bmH5F7oeetankJLO 
#undef mH52So0EeYsEZDduDH5e4qGZvbPX6fz
#undef  mA4oXllup8K3T5dxkluRR 
#undef  mXh8R2TW8u4BE0GHtpbVz 
#undef  mReDuVelSknxaDAoDEmwT 
#undef  mE_Ow4Xh61sHZuYT9u_vp 
#undef  mKqJtaKtNNFCDA9awnods 
#undef  mNAgAegAkh3aostDDex0p 
#undef  mjjNAUwZAzilKpyI1Dk6r 
#undef  mrYYGY_ATzXkS3kXEPpEg 
#undef  moE42zHNBVjnlCdllZAkS 
#undef  mJTScPpWt8plE9Cz9fDU6 
#undef  mFwk30320retpLBiICndp 
#undef  mPdHdcAZ6XJhwf8wLtULI 
#undef  mHAbGd4HvG2QvOxZcs3lT 
#undef  mc6SGgM2Uzvo_wy5KTima 
#undef  mvfKgFvXHh0Jqv_PZxbka 
#undef  mclhRCo4dM7MadZp5V8m6 
#undef  mUgRzGHHwu8B0HUYWcJfg 
#undef  mtL59O4fTIGPJKdcQHvhB 
#undef mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC
#undef mxD9VicPg3JzxB0Nq4Uo1xLfNkXirAD
#undef  muESrr63SaH81rmeBWzRi 
#undef  mE4_Vrik0lveh4HNJUk1B 
#undef  mCvAz6nTbqhvwRULRgKe4 
#undef  mm3iTU9Va924R0kb0bFj1 
#undef  mnSkEvR4SbDwQxj23xB1M 
#undef  mK02Cexqsx6vNaoTzun_D 
#undef  mlKtR21FV5abL2Mmi4l1T 
#undef mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU
#undef mhgllqTSj8yCumOJiOB_SNOZi1jZpHa
#undef  mce_8CnsU6ESSZfDxaV3C 
#undef  mINcNsH05D0QZDej9wl4h 
#undef  mSQwieae_zm87QxGSkqhw 
#undef  mlP1m6taP4mQVYA_j8Oxe 
#undef mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF
#undef  mlqoNTA3LQoUJF6i5YDFc 
#undef  mYM4ze6K0DiGvfExY0uu0 
#undef  mDd5IIsnjfLI1lcygRsW3 
#undef  msRrpu3bfxgN_CQlh5kGb 
#undef  maKLz6mCz5anFyVle_MtD 
#undef m_DXxPIyOoo082vGXUpjcjCP9GYwO5X
#undef  mbvotPuLfQMMkHkrWczyy 
#undef  mCpxQXTS3AV0wU8W7TGY0 
#undef  mCOuCt3mN6pV7VrSR351Y 
#undef  mnZ6t3BhMZ_1d7zzE72ah 
#undef  mnAk2iR9Su1JlXNU__70t 
#undef  mWUoD50tT9HFGBNQCsjUC 
#undef  mFrnvKb629IAbveEQOTJk 
#undef  mpHTdkvfapV5_Igrm_XSs 
#undef mjE2s1jSu76TqssWv5OkpQyTNcXDW0j
#undef m_7GcuKeh99wm21PzmE3XY0ABoZNB_w
#undef  mndAbF8Mhqs6wYK8Ew3E6 
#undef  mJSI8Lfa53eTFnQ8sZxQl 
#undef  mMGij61UZUIIYyztVz9vN 
#undef  mRrVhT0WkQauAZEUJHKOK 
#undef  mgfxr297Vj2D89efCcdCK 
#undef  mpJt2kGThF7wb3VNzG38b 
#undef  mZHJfF8VODcHrGq0YEwM_ 
#undef  mypSy3lS4LRIjRYTxVxzg 
#undef  mgN2NPegMIWZaSlArqSpX 
#undef  mHZ0KiNSj0hY4k5601_yW 
#undef  mTQiPILYbCv0nYwQtndF8 
#undef  mP8l6554fUQhsCw2PetD2 
#undef  mp3H4249LtCVDCYFqQqz4 
#undef  mMqLg7J_GrCMFwMZsIhbs 
#undef  mZnfmoDANjVLDjZfzM5MR 
#undef  mpDI48gcBVmyAktanjCOQ 
#undef  mfKhTg3wpiK_YhdQzWWcS 
#undef  mFKRUYDiDlNmwfGKdBg2S 
#undef  mjc_6rRmys9smvg_opA48 
#undef mKb2gquqaqcZhKKuABYQAQTKDfCzCv8
#undef  mVgd0sC5KIFeGa4mcMXm9 
#undef  msdqcdg5NNrdQnc_PT1Ee 
#undef  mu3VfwjYyEXmsa3FxHdyz 
#undef  mEUOZPFJPicZ9AQx6_FEx 
#undef meSFhtslMYeRECKXZrMQ8rKH8kdvfsC
#undef  mgQ_wngzoaArigUsebwJ5 
#undef  mnqZGwZqTTi1dekKxujAE 
#undef mexiex6yQ4W2cwOKYmh9Kok982mCBo0
#undef  msMfR3R5kzP8SqAQ3DWTq 
#undef  muxyK0XEbbiarSy_y8QSe 
#undef  mhxVrs8TRVT7m4DD0qJSy 
#undef  mLOAPVN3DUqvZfrHEsp7F 
#undef  mCALzjQ0bwpDnngl_oSsi 
#undef  mPjc1ei1txxv19TBbzbvk 
#undef  mf_hJsy06Me1epT4PRx_l 
#undef  m_NWV9acHYMEPlYLCkf5F 
#undef mCuBtAqzIu5X7282ZWyHMjsFupyWd7i
#undef  mVHGLK1C5RNdKdXzDgMZU 
#undef mhKXOgA6gWk8walTiLP2RlqyfDmKe1e
#undef mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a
#undef  mUvhkm5O6wWaFaksW3gGB 
#undef  mIwaKux_FnDqG9TKWI9sf 
#undef  miAECMSxGwjxrcOKk0DII 
#undef  myo_tabD5NOdQw_HDUeAl 
#undef  mj7rzLUFNjZZ8TQ9LzphN 
#undef  mXkfygpbRUCrOfJA4ktlP 
#undef mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u
#undef  mB3kG5fis1WUHfqjDpcgw 
#undef  mwnRQJQKy9VbzznJbM76_ 
#undef  myqrAJLu9GRcs5sFEN1xM 
#undef  mvW7MwxFgHE1jUFn6bpuP 
#undef  mjbtcSgN5ZQfkGDsoYG4l 
#undef  mJ9ZKhf2JTQ6b_phI67L4 
#undef  mRzhpvoeHZK7yCqqzYDDp 
#undef  mgWtxscBTuWBkK7X3fJ_M 
#undef  meOIEIGNtns3N9UkZHp_p 
#undef  mYB93ieg1KMHexoJXsKQO 
#undef  mnzbRa6WXDfLtEhMMu8uf 
#undef  mi940TUip6nLdi0tWD33F 
#undef  mN0TszoCQmyzxmobsgV2H 
#undef  mikiSyOnVry6pvQ1Ds28H 
#undef  mjVigZhPz5SJG76mcwBBH 
#undef  mh5Oneq9KX80ZFd7dCoKK 
#undef  mUh25fI232n1nZuNP2DcY 
#undef  mNMDyj9J1Nt8auTKwp8ze 
#undef  mfx1fLYDWN4YRZNnQEsJN 
#undef  mErel9ajJN1agpA_k4bOG 
#undef  mT_x8cqp5t43PgqNMR8gO 
#undef mzo2b_NWVHgZakDiMHmV12I4pTxTTDh
#undef  mZQqomBcB_Prq89ftbAiD 
#undef  mzqBtnG8Ja0w84lba1GCT 
#undef mYYWXe0GsOK9y3tuaI0XM8wApbmutU0
#undef mA7GovY8jPZMrXdPcttrfcvZCc5QYs1
#undef  msubWq7nTVSPilWqmTzkx 
#undef  muQdV4OJL6V6gVxW6AdRy 
#undef  mzeHK1hG1SYQMISNMWMB8 
#undef  mXyxJEKR2vQDAiXVkkZ96 
#undef  mTjppsgNpY1Pjyv5Z_zMr 
#undef mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW
#undef mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU
#undef  mdNWJa6f_e7wadzG60ejq 
#undef  mBuRRlPSkgfIqW4MkJEkn 
#undef  mel3l7ZRXwnAEsy0Wfxj_ 
#undef  mm9xpbYUQ152i_zNBGUZu 
#undef  mUB1yrSrKOwldqxmCatN2 
#undef  mxMl9vPEiIZkGZuxtm_RI 
#undef  mBBHVSlvDGP5NVUfEuhuf 
#undef  mP2fo6VtM4ySlx6m268_j 
#undef  mt6CTIKlbWyEq7tYJENOL 
#undef  mUrLXSL7g29oB1gxfN8O0 
#undef  mqHHu9OC8XdQm9Yh7V7x0 
#undef  mcqTciDcDgSbPPY9iuwhB 
#undef  muh3toWhBpay0OfyCHmRI 
#undef  ma9rnYFEs_TUiw_WyBflg 
#undef  mKui3FcBrQ5fUw3SS2JBl 
#undef  mIMikP4zsPvXTvXr7Rfnr 
#undef  mhyL_M5gnmQzwyHW45MdA 
#undef  mhgVj3QiKBmvoTbS8WYEn 
#undef  mdLKGc6TH1B4fmpMEcP4V 
#undef  mpMWr23OozoNFIk9M3JRl 
#undef  mNDJrNgMXB1tBoFNaJO0d 
#undef  mKcKHr_bTagXAK_pf8btG 
#undef  mnECjbnhLknZie3Z5iHP2 
#undef  mTFkOkggRsxkeMv25hiJW 
#undef  mSuHweZ8NLqp3TniIO9nc 
#undef  mCm219F3DHVwNe_CsrCeK 
#undef  mXUi6ZMBLLcoMCxEzieWB 
#undef  mrRUZLmQTdeC3HO0hVmGH 
#undef  mW1ds9XwNwevT5B2b3j8B 
#undef  mlJqcdUT0sl1_64qaqDwc 
#undef  mQk9KGg1kmiZQnIZzbOuE 
#undef  mVRbVdVjFvNmKzGv4WiNp 
#undef mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt
#undef  mbG1GEmOdh2dXkJZ42sXo 
#undef  mjxPa00ei9qkuuQmiGB3C 
#undef  mSDkw9ayb_9gGdMv3ViWL 
#undef mElbPhFy9PzMYpwK0rJM72HTzRPloIw
#undef  mgor9wB6mrVARR8vJt7rC 
#undef mH9ypXNXQET4Yi7K20Jh29E84Mwri1d
#undef  mrm8jC9SczExaamJBF8OL 
#undef  mYONm1FLAyaMuB1zKpzHD 
#undef  m_BNZbnU2Y1bOBnnPOF0b 
#undef  mWA_ETdQ9hsfQKo10V6Ed 
#undef  mMXwD61a3ZsfucFBja1D_ 
#undef  mep87jMrgQZcK1mXjlt_w 
#undef  mmCJ670wA_VHgip7JZ1dW 
#undef  mifrRvzkyTJgS5ZnlEWNT 
#undef mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj
#undef  mt0bWs8kxCzTnBdtR9vKu 
#undef  mfNhxMALMjy2jMKPPP3pN 
#undef mfi_VmSWr30C6e1Og_9nDolWgyPyTBP
#undef  mtPtbM6hNfOIkqlx661ci 
#undef  mbHCSQc_uaLNP9Sf4Lz_n 
#undef  mwkUVn0D8pUxgFq_rx20G 
#undef  mOEGA4b6sqebQZ8Uv15A2 
#undef  mKwBF6wdaXmwZg6eVpHR2 
#undef  mnkTvEdpCXelpIHLLqQno 
#undef  mLfKYVMLDthbyvvLerNPJ 
#undef  mDjDVHrQ1nua2LsKX9HSc 
#undef  maOczvhF_v9OTsK70ZZut 
#undef  mFlVjO0mLpwnCN5a1Quio 
#undef  mKmIjE1RujJ5RSETUjqwW 
#undef  mHbmZNNhradVwUtDZ5U7B 
#undef mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN
#undef  maCQ9r5fSln_CXgRXGFvO 
#undef  mqHOA0Vf8azkugKZoQT2g 
#undef  mIkhxhgSNMt_JUZR7ce1U 
#undef  mn7NaVKR8Eys8MRznQhqq 
#undef  mwTQhkbVNQHd2Xw4EA4fj 
#undef  mgAgf2KiVOzOHJDU4qKPI 
#undef  mUtcrfgjMX2yuzlJWU7ae 
#undef msFedzwaZ2kcbRyPxAwvYLedNBp9XR1
#undef  migVyykpmr2io3DNlFdHK 
#undef  mdF98bHO7yrxGJn0aQZVK 
#undef  mRawsH1LNxMcHXhyroWR7 
#undef  mqENAtmVRtspFcCyFxQkl 
#undef  msFQPbyubcQTkvTYpFFPL 
#undef  mGyGrvv4NjvJFmxY5zFqS 
#undef  mt0GBkUzL9v7leCB9JJCC 
#undef  mlqM0snvYcrWCw2_QjhQi 
#undef  mtggfblAKFVUli3PxtdvW 
#undef  mJke9dzVx7gMdakG5cgU_ 
#undef  meZ135JJTidHY5m2MSApS 
#undef  mhXXYzAVu3lDYyh7TkRWq 
#undef  mJOnXqKm3GBylSdRjpXAA 
#undef  mriCvhMavpfheoLNc0eCD 
#undef  mJWlrLOowGXzksrQ1iOpo 
#undef  mnt0Yxwh2kXjuvEydiY6Z 
#undef  mEz1qIDbyJp0Jb730lPO1 
#undef  mr45_AiDx2WPxM5kKJ73c 
#undef  mM7GnshIhlJuqxxDdvNQ9 
#undef  mDzQQrEx5Ki0C6uDHU2cy 
#undef  mukpDKZCMfw2TrxqBczvn 
#undef  muKP5B7qysoQRrYrwu_aG 
#undef mzcT8teQAcAtdQGMnR4j__bo0O7W6fh
#undef  mnU2hwoI16_nZ7reLKJTr 
#undef  mIqkiLoOdpjYrPavNSkO3 
#undef  moPdTa5HpJKbS1U6TqDjY 
#undef  mb7CDbA8OAKKL51zp5Kp2 
#undef  mPvJelqEXJke3tsTVDKaA 
#undef mArVNsRyxIBuRhpRuviXmuMgA4HFptj
#undef  mLdYY4X2b7VOjtTSnd7Hj 
#undef  mdssZV6TB06aiisDwN1cX 
#undef  mT1nRBXOOPTe1uInaQg48 
#undef  mQDLRy0PKsddZ3xq0mn3V 
#undef  mmhvewuTDMRQuh4yozZj0 
#undef  mwQUfI7G4pBH6IJQiBjmU 
#undef  mvAxy99EwaX0EkXFRf6SN 
#undef  mECamByxBqjGyTShbPlRQ 
#undef  mYwsOAvDOXneTzOST0d5c 
#undef  mgxs4jaOm5WhsuDH7hsbo 
#undef  mnlCUtQ6kn1Qc7HkEzE0c 
#undef  mThelntXiwCutIvyMhNsD 
#undef  mFMxB_7Xv8pds76G1KO8P 
#undef  mM3tRrWbRPqPOU3G4ShKT 
#undef  mwTp2D1d4PfxNNOzzUfhS 
#undef  mGYpOkNIG_qSvYXBOU9Vf 
#undef  maSZLm7xL0jGtxyrdwaul 
#undef  muOzaq9SXefX6wOasanyX 
#undef mevyCL_5kjUx7NbD67ju0rSs5KRucsR
#undef  mOwM0Kfjt44STnd1SP93u 
#undef  mVVBTZX2L35xKLlbqB8u4 
#undef mLC2F6mTDlCPm4Amdj66bcsfP08vka4
#undef  mpi20hzA7RnQ_cRlycwva 
#undef  mkyaUNysRlFi3wOJaaFye 
#undef  mdWkXjuaPd4Se0r0SdY1e 
#undef  mYA_OUCZSQycbIZ5oB16m 
#undef  mZVOYp2JAGvUM7UPbzd3Q 
#undef  mkGHGzUDDVqHIjIdYGe6S 
#undef  mPJvcMzH2GoPEPAArs6CO 
#undef  mQwlYb2fiOk1ogUVAZU22 
#undef  mPlk6hpBhStcHkX9pfoTY 
#undef mwuimZUNEQYuguDYpIp15llEoOqkXc0
#undef mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM
#undef  mDUyr1RAsHMG7u1BeTW3F 
#undef mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7
#undef  mGmn6AwhPqDzvkxFmEeXf 
#undef  mEFd2D2UDF9SIoPfQtUv6 
#undef mJRcV3UxOoHUziTla6CTItAztGL9WSZ
#undef mcvC2D_94pblXXCjjwhbKRwRZdXBrpg
#undef mQaMmAoZTrzB9rh95SV_SNzHqc0isDC
#undef mKAy3YZbvi464n5g9TLhbuXIqHPaeqv
#undef  mRltbJjpZ8AzImbP6r6M4 
#undef  mPrvhmoEgzU_ThNhPmGUb 
#undef  miGFoFUQX5urgUZ1Rewwt 
#undef  mBpPKNB5wfuTOV223BA2r 
#undef  mYPzKChOwisp1u2IoCgxk 
#undef  mxIhhpr2Lkr3NxxDHw1vq 
#undef  mglDNKH5ah89GptW6H4Cu 
#undef  mgkSwnYHQivQIpeAwgr20 
#undef  mCBPKKFCRSbvDkZsS_B45 
#undef  mcstdE8Wwpam6tUMM45Sa 
#undef  mC_m9rmwsKDO6tF3NGSKw 
#undef mr0l01irlQTHxEjA5eunteQkeoLuBQY
#undef mTTOC6Wz4GS45ua7oKbWEmBZpWCWLbr
#undef  mOR5gj7K3yTraJVOrvmKy 
#undef  mzf4ZxeZY8wF2XnrdYK61 
#undef  miTVnDZI0mihWq9STK4vZ 
#undef  mmAbmKM2jnErQzGL0hU87 
#undef  mYsjCP2nXqW2Jls3JAUkc 
#undef  mxQewHEnT8PTNQcVKCqL9 
#undef  mYfpOohym5jydVBxgDUop 
#undef  maoHwm5lyecyelmN95sur 
#undef  mMRNM5hfPBWFjYCspldu3 
#undef  mqwYu0y4oTPCnfXbylThX 
#undef  mG9O2bX6GrjZ7A14g4o0R 
#undef  mLplHCs9IECRrk3AL90fE 
#undef  mN1cOqoznikSSj4MMYyFX 
#undef  my42VNapWQSG36GDaLRZU 
#undef  mGxw9hY3riKhnwFZ5jcqN 
#undef mX2089XJEUghT4WdpeqIpdVl5urfw9e
#undef  mNHO_HqPPuJ0s1xmA3Hyp 
#undef  mBh4lc09qKYGXyU7FeqOv 
#undef  mtbP4KQJdh36UGELfV2zq 
#undef  mfurntceIvF3j4__Qp6L5 
#undef  mv50Xfpo4ITZHLXGtKNlu 
#undef  mEGd5SkTeDLeSnWPvzGk3 
#undef  miFyHzo07syL8tsy3JLAT 
#undef  mEMN2sRTwHcTUl7SNSw0d 
#undef mqm5corqEX8t35Uu6nBYm_yWWsarIow
#undef mmu72Hys1y28eLiXc2AAu_ewAGX_SGw
#undef  mC5oDJ0qE1gW_qsx3g1mu 
#undef mxL2jX9CFTtSnMCJoJ1anRskFISM7ye
#undef  mE51_Yx1e52Gg6LtJn8Ft 
#undef mlkXvCGjzNE_N7vszwePKcZNchffiZF
#undef  muuG2jhk4iNsA9KNmj6oA 
#undef  m_6hetAMDOSYN9CmiL4W7 
#undef  mgSkXUgcRjYGUB2o3shqJ 
#undef mufZyaMJ62rgFtcDkgqf_5OhhyLV_dz
#undef  mAnDeXfeHaujEzGBbrjil 
#undef  mrYTPN06XEG4I2Q8GwVal 
#undef  m_j6ZkbEfLCgUqtaolYTp 
#undef  md8eYFrUH5ZCVnYz5HXJs 
#undef  mq_LX9xWjqEZjC_8nIQQB 
#undef  mHkLXuUOlyX2vZI7w3FQj 
#undef  mIyKKzozGjE84ROdV4z79 
#undef  mca1GaR7Rv9qOZsisqKBB 
#undef  mTna5ZWhTRHGhmpdDhP8Q 
#undef muE9dUeTdzrXFfj8JjJHsYH_fISmi_r
#undef  mopvqiLosQusnLb5T1cPQ 
#undef  mfXSqvRpqFIhzf0yTtohv 
#undef mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa
#undef  mWB0Y3YknsbsRFnNAcGvV 
#undef  moRHJd8MnQc4OOt6sDvUk 
#undef  mqEAvVDOCXqrrwrTRByrM 
#undef  mbYMUxVFybbviIFqRhN2f 
#undef mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q
#undef  mftnbgRvzOIVyL93HyyWt 
#undef  mb_mniVMqcXJMFkJcXnTV 
#undef mnIgag5XDMc1HAJdYJSOnPrbWBffgTI
#undef  mILaQGKCAmcKrYQNhgWUq 
#undef  ms9iveRK8Fk_QtPMDvDcP 
#undef  mLx62v15Gc0EOGYi5W96J 
#undef  maISPbNJKXWB2QqsuuExM 
#undef  mYKwa_OYBeVXzRPMa_mz6 
#undef  myuwTFtkH1L5Be2OVY9rt 
#undef  mmmC9tOGiLK6UaJr0E5vz 
#undef maZplRnE_IUwmU_xzu3NekpUHRmaUSP
#undef mRpzyAUUkieNHbskgKP0AofElml4apw
#undef  mxdAvfSsdzliezc0uyUMk 
#undef  mICILgDpdCTDSJqQAn06L 
#undef  mdDEjFb9QPcGyAxk8oT5M 
#undef  mE5GmVndUe3w4VVob7TEw 
#undef  mNQatzTrxcdXGxcIUXU8h 
#undef  mILr1bxfFRdMH70QJkaPL 
#undef mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN
#undef mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz
#undef mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz
#undef  mu0qe2vnLpegnyYWkJiID 
#undef  mHcxzZHoWX11H4xEjR59T 
#undef  mX_x9bVx2zqKO8c2FxqgZ 
#undef  mKqJbq4fPTw28Ilr7bzpA 
#undef  mu5MgGYXZDetF61l00p1M 
#undef muKLilOLbFZ3yJM00gLINUymjA4CZq_
#undef  mlxKATcGFZZXuYzEVZko1 
#undef  mhnMl9nmNNK1ubSXXRkWs 
#undef  mAwnIBmzoGA1R_JK770kK 
#undef mwcRCcU6S0ahJKT269YrZSchpTbqC8A
#undef  mEiOeyHRZlQujPqpgYY7u 
#undef  mv4kxLDTrK8Y14srOeMs9 
#undef  mif4ZCBkqdiqSYkR9AD0r 
#undef mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E
#undef  mu_nOcTFwUo8r0uNE351R 
#undef mUPTRsc2WCtijDSKQungDsRrIFUGnz1
#undef mshTvqIeJnktjfxvTh_Q17geiWCXNRC
#undef  mquhIKppt3a65sc068Kvt 
#undef  mY2nz8M_6jpSxQZL8EYgU 
#undef  moejXze8_C6TCxb2bIzgq 
#undef  mSlNeIB2kCkOFZLLZbZvl 
#undef mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3
#undef  mH1xQMRmYb0Y4RDp2hARz 
#undef  mlujXFTq8HgFCDqLu7dpu 
#undef mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW
#undef  mwzVPTpaJAiRC6bZKMfQX 
#undef  mKpq3GwvJxRduE5RsGgGP 
#undef mkuXAnWhKAEZ7UQwHldfZw6MZuPCbu2
#undef  mvw_MKiY3S1FcVNfJQCRT 
#undef m_bMsemALspVgRNyYoh4QNv5h7J6TCa
#undef  mIYvQtGxrUTK9jCV0wgjB 
#undef mpoy16fiv_eugwBU4NxPwSY0pkiHptx
#undef  mGkUuomrp7ufvC8H_J8ZB 
#undef  mwu5s8ye7pYEdPIYXjU5h 
#undef  mbndM1iNeSBZryqPzzxpU 
#undef  mA9OyoOle98msK0BnFc8I 
#undef mLsmsKBxetQnHulsmKvKGZrZv3OKajL
#undef  mQu7TMP4YfBcqf0WCzN18 
#undef  mJvv2tbrel2xOYjvgipUL 
#undef  mNEkKASvjK_HgII9jzEu6 
#undef  mbFGY3HJrKnP_L6H3dMsA 
#undef  m_lICnZ0bJGmuMACmMVcA 
#undef  m_Bc574zvmsa5bmM8Ay7H 
#undef  mNhNSN2gx5KERe8tfdmgu 
#undef mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps
#undef  mhDkJpX31vSJRGCWwJgDF 
#undef mf4h8kYb28ybDtqub3aw3HtQXgCqXKS
#undef  mgjPImSFwUcUKl9XTKqqB 
#undef  myYAiLHDT3JvFKUJCC_FN 
#undef  myFE4ZIOynNe4GHuzkHmk 
#undef  mxD0ASUiBIk9J4KLYW_eX 
#undef  meWm4MhzbcJwavtoh469w 
#undef  mpaH8vob0MFQfWtEu0gpW 
#undef  mo8MRbS3DUX_ZOlgmUSna 
#undef  myYaYWcsrnLoe6SxorDYt 
#undef  mEDa32iTjVIlpXzu_8bXW 
#undef  mGbN63kjoGx6fvYq0oiYN 
#undef  mqQspPZKCoa6LP0Jj0qH2 
#undef  mzPPQ5Tm31T6ToJuCly5i 
#undef  mUFzn4yJGA8c9qnEcb9dH 
#undef  mMNJIG0z6TLGgbjrhllmy 
#undef  mwwJvnj2j3yLmklxxOEJQ 
#undef  mVOlbMaOu1U0SC2oeKIzP 
#undef  mHaUGkpJ3E2hPS8TahoVd 
#undef  mDWRa2VXHJyGtXnU3Z9De 
#undef  m_wyaFib5_cQG4j1HqokH 
#undef  mE0JnyzA4LAd5tJboIPVe 
#undef  mKzXNxKoc8d_JaqSCmnt5 
#undef mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY
#undef  myCKVyjNuW6E_Fp3y6x2x 
#undef  mdKhcOUXVqyCMdccisL_a 
#undef  mgRihfujs8Yyx1O6Z75ze 
#undef  mPBSejyyYBZX7KoLjIvqq 
#undef  mow1IjdflpN81ICD702rC 
#undef  mVPyhnVeODFpKcj5PAnUM 
#undef myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF
#undef  mEzFcmvX0IX3FOucgCcVF 
#undef  mbQuioGdvAG5jcbGdIlbv 
#undef  mi0dc2wlXgNoHf9VPli9f 
#undef  mnNakURRgCUtkCBzEeIbT 
#undef  mS2LGTpbZiAMEweak007k 
#undef  mZk2lUQMDVDhOLQdg9s92 
#undef mc03ciJcqzEcDCvFZREOoKestkbXulB
#undef  maHkatHu0Jap4oTaT5q4_ 
#undef  mcJvl68QD2UYT9DPOREOj 
#undef  mD8VAS4XY9Vf6fdJqnluZ 
#undef  mHgo4JTEAdFhAHz3buc5U 
#undef mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s
#undef  mGuK55c17XqU0IVL5INTz 
#undef  mUq8qfNXjDE9FPlMHvjf4 
#undef  mU8SToe5QpPWgY0z9QAcm 
#undef  mhGXMe8LHJXydR9dMisHj 
#undef  mlkEZnzYCXAgDnYDi5up3 
#undef  miFg9XqPeEmQjjY9dOISI 
#undef  mneGB1iZsOWGhJroSY5fV 
#undef  mrpQVzv6u8gxvho1qUlil 
#undef  mhlQDh1wF6VsRTHY9MXvo 
#undef  mEZrtAN7pSZl5y4oEHd38 
#undef  mUCEzhGWrU8OYqcHVPlVW 
#undef  mihBlyb7pwidO496a5_p1 
#undef  mw_6Ab4pR3RtOt7wvMnqF 
#undef mtnsDyAXJojPFvMiilyGbFo63qTJSV_
#undef  mrzvE9vOXIlwaUYsJynGX 
#undef mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI
#undef  mnswinmeXuam57kXH7myI 
#undef mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R
#undef  mF9AQyKXtPTPy1zvAUpED 
#undef  msao8K6SR84Lu5ND7NCVt 
#undef  mRwjoMr_aqph4iL4nu8NS 
#undef  mfFGohhJTv_x4m7UMdlWF 
#undef  mEmzu5ycY6iORBuT83fJe 
#undef  mt3VEObKOLfcodk2q6Hb4 
#undef  maDn6NcmB5JPmBvJglMEd 
#undef  mhpoAZakkKCTBIsnDg7v3 
#undef  mdEzmAkZNQkKD1HrLnSSo 
#undef  mKdH1o6rFuMJ1Fl0PA_sn 
#undef  mZiUSTfWjbMiMsmxNY2q9 
#undef  mWokjWH0MHqyBOx4j0Oac 
#undef  mO3OYAsYlFzrizsYt__9m 
#undef mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu
#undef  mtvEQgcnwdOR4zAMwLHDb 
#undef  mWkGo8xUdRIKgJ1DEUvvn 
#undef  maB_pNl4zuODt3oqXg9EB 
#undef  mCujczJix6jMpJcynoBiA 
#undef mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie
#undef mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF
#undef  mxNiL7NRse0iP2D2VgJvE 
#undef  mKcyQhGKewGQ8D80ltPKd 
#undef  mAcwJn9Fm7cgTYOF5KC6H 
#undef  mbViqhyIcr6lGWibuo3Im 
#undef  mW1YUos9eL_9NmgJuSDH7 
#undef mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH
#undef  mEwOO8zzJcEkF96gfFa1e 
#undef  mK5OxIt23gZzSiTA8trU8 
#undef  mSovB5T1QsQHo_5C08NNM 
#undef  mm3KIQTUMZkPidze1WHnH 
#undef  mYfYoOWdsOLTDCIBT7npX 
#undef  mLEx8V9d9KOGX6TpfxDP_ 
#undef  mfBNQ_3zW9r0ekYxjcYs6 
#undef  mIt7rZ26ebLuaPjnQsvmi 
#undef mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT
#undef  mfJA9NVd6FBgGhRSkkhhs 
#undef  mSx88YARryA674S7RpNKv 
#undef maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8
#undef  minXN1_7si2azFOae4puK 
#undef  mYGfQUZmV9IjKAPVrLhZl 
#undef  mG7mr0Iq8BCEeADSwrCoW 
#undef  mtFjgCt4NTpjOcEST1puq 
#undef  mRuVXNtG32xpaNLi1hDLk 
#undef  mYPq_LjN7ad6AVi4Iwwhx 
#undef  mSBH4REv5nn8iXIXWLqFa 
#undef mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr
#undef mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv
#undef  mbVacJ38Njfe_9kvqyl6v 
#undef mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj
#undef  muiDYQbmwLxL3PGrwWGeP 
#undef  mxjRBOqzfKYNpief2KWEu 
#undef  mC7CcuPGpz81aizhogiZL 
#undef  moI11mwtxiOXpqDxK_aQL 
#undef  mf3l8ay5y_EjkAsZg8mUs 
#undef  mDx7kMxPPgzO4EUIw_BnI 
#undef  myJHqW7fkn_72nVEhKeZ6 
#undef  mk9FUg_FZy9ugg8Rqf3jY 
#undef  mvvjvpVVXY9qkY9G6I2UZ 
#undef mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox
#undef  mJtGCV8zXQjnVDVBVdvFZ 
#undef mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2
#undef  mGXmXMs8LhHsVpd3vA7qq 
#undef  mRHNkLPwUSnx20pmLgrTq 
#undef  mQfgxxEXCA984FTu8Jz8Q 
#undef  mW0z8FqRbcMOOqrwq1TRC 
#undef mhGemuVhKwpkxrzvad1IFvExNIEs7Ak
#undef  mUwTrZwI1VfAXDN69k3UA 
#undef  mRrGWRfoKK0rGG_g5N_ah 
#undef  mndDt3huhmUYGZC1vQmOq 
#undef  mhxtTU7dvZHXCTSg8B8rx 
#undef  mdmuaUz9iCkCckSUhcEv1 
#undef  mOymGuaDUIEo4ESm5VpCR 
#undef  mo7mKuzaX2h9vw2rEj5qh 
#undef  mdbRZP7cWFYlUcaGRMsKc 
#undef  mtJAThUzPUAnb_DMXiQOL 
#undef  mYI2nkSxgJHf1pY1PttV1 
#undef  mLBxgVrVeq7bTUcDGJqNH 
#undef  mGDvPrxv8kCxNPwud9IqM 
#undef  miFbFMaHNYmE7ZhdtdD1I 
#undef  mMcZ82Suei3klnF_x2Lcx 
#undef  mFsSEF_3_iD2mT6nZG9QR 
#undef  mKbtq8OHrv8CI8FhvE4XG 
#undef  mkIOpFxp9pqNBAq8rhDn1 
#undef  ma84ph1Q5xfgaPalqi72x 
#undef mztFjkqY05BHqxhJraeJTl0p2s3heFu
#undef  mm2qioZxIvP_11cqVcoVX 
#undef  mSa4WnWih0z4lSo9RYUGU 
#undef  mXRH4Jm901JGMftiW3Yi4 
#undef  mtBaSZn4xtaMpMhvfebM_ 
#undef  mycwFs63h7Mi3ggRkMEVm 
#undef  mU808frSKQDZnEEU3Q3s9 
#undef  ma43zKzGwyDT5C3mNdj6s 
#undef  myyhXEjkyqbh66A1Qwu0O 
#undef  mXAYJa6osZ6HNTIEEBnr0 
#undef  ma6VjqdfajK4BX9gkoGiD 
#undef  mij4fDpzx7A1fAEkEKDEN 
#undef mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G
#undef mCytfckU7SmdEgj6kDXVCjNq_lj0sfn
#undef  mmB6x9VkGrq_qpFtMKL7A 
#undef  mfQTptx1DXC7MJP5Cfk8m 
#undef  mIwyzOHEkeXgErUDD0EEp 
#undef  m_e_PmiIjNUGQEwSJbBF8 
#undef  mgM8ScCmoJ3qXwMzVOzZc 
#undef mQnt4GgeXMPy1qcLwCadlcgZL0S7aML
#undef  mHXoMWKZSiZYUvqmVkLF5 
#undef  mcznTYeCGOAygtXXAPYS_ 
#undef  mECcJc0jrNRWKGTvkEzeA 
#endif

#ifdef _3643599497981880515
#undef  mECcJc0jrNRWKGTvkEzeA 
#undef  mdNWJa6f_e7wadzG60ejq 
#undef  mAVrnO9aWNRf9b3dALx0J 
#undef mwuimZUNEQYuguDYpIp15llEoOqkXc0
#undef  mFwk30320retpLBiICndp 
#undef  mqwYu0y4oTPCnfXbylThX 
#undef  m_Bc574zvmsa5bmM8Ay7H 
#undef  mm3iTU9Va924R0kb0bFj1 
#undef  mdssZV6TB06aiisDwN1cX 
#undef  mgQ_wngzoaArigUsebwJ5 
#undef  mJkMyi0NbVRDgE__LMR_m 
#undef  mgor9wB6mrVARR8vJt7rC 
#undef  mYB93ieg1KMHexoJXsKQO 
#undef  mCQaCcJleVmF11nXRNijz 
#undef  mjc_6rRmys9smvg_opA48 
#undef  mDd5IIsnjfLI1lcygRsW3 
#undef  mvvjvpVVXY9qkY9G6I2UZ 
#undef  mwkUVn0D8pUxgFq_rx20G 
#undef  mpDI48gcBVmyAktanjCOQ 
#undef  mifrRvzkyTJgS5ZnlEWNT 
#undef  mt0bWs8kxCzTnBdtR9vKu 
#undef  mW0z8FqRbcMOOqrwq1TRC 
#undef  mMGij61UZUIIYyztVz9vN 
#undef  mwwJvnj2j3yLmklxxOEJQ 
#undef  mndAbF8Mhqs6wYK8Ew3E6 
#undef  mt6CTIKlbWyEq7tYJENOL 
#undef  mm9xpbYUQ152i_zNBGUZu 
#undef  mlkEZnzYCXAgDnYDi5up3 
#undef meSFhtslMYeRECKXZrMQ8rKH8kdvfsC
#undef  mihBlyb7pwidO496a5_p1 
#undef  mX_x9bVx2zqKO8c2FxqgZ 
#undef mcvC2D_94pblXXCjjwhbKRwRZdXBrpg
#undef  md8eYFrUH5ZCVnYz5HXJs 
#undef  meZ135JJTidHY5m2MSApS 
#undef  mpi20hzA7RnQ_cRlycwva 
#undef  mnlCUtQ6kn1Qc7HkEzE0c 
#undef  mxD0ASUiBIk9J4KLYW_eX 
#undef  mndDt3huhmUYGZC1vQmOq 
#undef  mWB0Y3YknsbsRFnNAcGvV 
#undef  mdkQcL_ccA3dE51c_fq0e 
#undef  miFyHzo07syL8tsy3JLAT 
#undef  mGYpOkNIG_qSvYXBOU9Vf 
#undef  mEMN2sRTwHcTUl7SNSw0d 
#undef  miFbFMaHNYmE7ZhdtdD1I 
#undef  mPlk6hpBhStcHkX9pfoTY 
#undef  mkGHGzUDDVqHIjIdYGe6S 
#undef  mGDvPrxv8kCxNPwud9IqM 
#undef  mDzQQrEx5Ki0C6uDHU2cy 
#undef  my42VNapWQSG36GDaLRZU 
#undef  mglDNKH5ah89GptW6H4Cu 
#undef  mEDa32iTjVIlpXzu_8bXW 
#undef  mvW7MwxFgHE1jUFn6bpuP 
#undef  m_wyaFib5_cQG4j1HqokH 
#undef  mQk9KGg1kmiZQnIZzbOuE 
#undef  mZQqomBcB_Prq89ftbAiD 
#undef  mcznTYeCGOAygtXXAPYS_ 
#undef  mrpQVzv6u8gxvho1qUlil 
#undef  mhORIPgMIfN3Fn8aCQBuU 
#undef  mhgVj3QiKBmvoTbS8WYEn 
#undef  mxjRBOqzfKYNpief2KWEu 
#undef  mnswinmeXuam57kXH7myI 
#undef  mHAbGd4HvG2QvOxZcs3lT 
#undef mCuBtAqzIu5X7282ZWyHMjsFupyWd7i
#undef mX2089XJEUghT4WdpeqIpdVl5urfw9e
#undef  mKbtq8OHrv8CI8FhvE4XG 
#undef  me9YsE5_K5dlCgWRVtztQ 
#undef  myJHqW7fkn_72nVEhKeZ6 
#undef  mdKhcOUXVqyCMdccisL_a 
#undef  mReDuVelSknxaDAoDEmwT 
#undef  mmB6x9VkGrq_qpFtMKL7A 
#undef  mwxm9pz2KjGAhBIIfFMf4 
#undef  mB3kG5fis1WUHfqjDpcgw 
#undef  mA4oXllup8K3T5dxkluRR 
#undef  mxMl9vPEiIZkGZuxtm_RI 
#undef  mf_hJsy06Me1epT4PRx_l 
#undef  mMXwD61a3ZsfucFBja1D_ 
#undef  mLEx8V9d9KOGX6TpfxDP_ 
#undef  mSovB5T1QsQHo_5C08NNM 
#undef  mUFzn4yJGA8c9qnEcb9dH 
#undef  mfXSqvRpqFIhzf0yTtohv 
#undef  mlKtR21FV5abL2Mmi4l1T 
#undef  mF8CPQI5IssWjwlV2CXVE 
#undef  m_BNZbnU2Y1bOBnnPOF0b 
#undef  mdbRZP7cWFYlUcaGRMsKc 
#undef  mFMxB_7Xv8pds76G1KO8P 
#undef  mZVOYp2JAGvUM7UPbzd3Q 
#undef  mCm219F3DHVwNe_CsrCeK 
#undef  mGbN63kjoGx6fvYq0oiYN 
#undef  mUtcrfgjMX2yuzlJWU7ae 
#undef  mu5MgGYXZDetF61l00p1M 
#undef mpMBFPEerAbCZmlkKlVh_N5JqyDGaBN
#undef  mo7mKuzaX2h9vw2rEj5qh 
#undef mf4h8kYb28ybDtqub3aw3HtQXgCqXKS
#undef  mhXXYzAVu3lDYyh7TkRWq 
#undef  m_e_PmiIjNUGQEwSJbBF8 
#undef  mgxs4jaOm5WhsuDH7hsbo 
#undef  mnU2hwoI16_nZ7reLKJTr 
#undef  msMfR3R5kzP8SqAQ3DWTq 
#undef  mIYvQtGxrUTK9jCV0wgjB 
#undef mpK6pxKC4ZXHIzSanBPacwWmlP7OzCz
#undef  mjVigZhPz5SJG76mcwBBH 
#undef  mnkTvEdpCXelpIHLLqQno 
#undef  mftnbgRvzOIVyL93HyyWt 
#undef  mypSy3lS4LRIjRYTxVxzg 
#undef  mOEGA4b6sqebQZ8Uv15A2 
#undef  maKLz6mCz5anFyVle_MtD 
#undef  mwoUu824QThZXd8c3IKpk 
#undef mjZvNSly8dRBzZWtVgAvmKEoP5XXUaT
#undef  mkIOpFxp9pqNBAq8rhDn1 
#undef  mLx62v15Gc0EOGYi5W96J 
#undef  mDUyr1RAsHMG7u1BeTW3F 
#undef  mJvv2tbrel2xOYjvgipUL 
#undef mLUq8aGfwkTdnzQeNJ5jI_xlRY0CnTH
#undef  mK02Cexqsx6vNaoTzun_D 
#undef  muKP5B7qysoQRrYrwu_aG 
#undef mAj3V8fNuZa0zcT9SrcGtpUv4tleVbU
#undef  mY2nz8M_6jpSxQZL8EYgU 
#undef  mqQspPZKCoa6LP0Jj0qH2 
#undef  mAtZroqlrY5Hmm_G3pFca 
#undef mF143YfMMbFl_Z9MaIdMK0RKDi2Kttj
#undef mNaa6ujtHJ_ALdoCJCd9Rs9bJsl9CA2
#undef  mJOnXqKm3GBylSdRjpXAA 
#undef mTTOC6Wz4GS45ua7oKbWEmBZpWCWLbr
#undef  mdmuaUz9iCkCckSUhcEv1 
#undef mArVNsRyxIBuRhpRuviXmuMgA4HFptj
#undef  mjjNAUwZAzilKpyI1Dk6r 
#undef  mNHO_HqPPuJ0s1xmA3Hyp 
#undef  mHkLXuUOlyX2vZI7w3FQj 
#undef  mP2fo6VtM4ySlx6m268_j 
#undef  mtbP4KQJdh36UGELfV2zq 
#undef mt0J2cgGrQp2ucvKFkwuOILDyrA8QJM
#undef mvI29UffPi_yJdDV3Vdm6w3QHqlu4_u
#undef  mPBSejyyYBZX7KoLjIvqq 
#undef  mOcs0qqtJYmueMnfTyCFx 
#undef  mzqBtnG8Ja0w84lba1GCT 
#undef  mKqJbq4fPTw28Ilr7bzpA 
#undef  mUh25fI232n1nZuNP2DcY 
#undef mMinTurqhjOTBoJcyTuRpllwDXFTRab
#undef  mbFGY3HJrKnP_L6H3dMsA 
#undef  mikiSyOnVry6pvQ1Ds28H 
#undef  mKmIjE1RujJ5RSETUjqwW 
#undef mOUkN_e0mvAXFRqMX_1zcW7MgjGhp1y
#undef  mYPzKChOwisp1u2IoCgxk 
#undef  mWHxIxEh8g9mg3Hyipn8D 
#undef  maOczvhF_v9OTsK70ZZut 
#undef  m_6hetAMDOSYN9CmiL4W7 
#undef  mFKRUYDiDlNmwfGKdBg2S 
#undef  mCALzjQ0bwpDnngl_oSsi 
#undef mshTvqIeJnktjfxvTh_Q17geiWCXNRC
#undef  m_NWV9acHYMEPlYLCkf5F 
#undef  ms9iveRK8Fk_QtPMDvDcP 
#undef  mEGd5SkTeDLeSnWPvzGk3 
#undef  mFyKKLtdivGGDlk8sYzsf 
#undef mwB_tR_srO0AlQhW1UaDy4Mdgah73Ie
#undef  mG7mr0Iq8BCEeADSwrCoW 
#undef  mgWtxscBTuWBkK7X3fJ_M 
#undef  mfNhxMALMjy2jMKPPP3pN 
#undef mH9ypXNXQET4Yi7K20Jh29E84Mwri1d
#undef mfi_VmSWr30C6e1Og_9nDolWgyPyTBP
#undef  mbG1GEmOdh2dXkJZ42sXo 
#undef  mYwsOAvDOXneTzOST0d5c 
#undef  m_j6ZkbEfLCgUqtaolYTp 
#undef mJI2h44hAoDYrHnLdxJ9jbIgiWRiz8s
#undef  mrYTPN06XEG4I2Q8GwVal 
#undef  mw_6Ab4pR3RtOt7wvMnqF 
#undef  mlqoNTA3LQoUJF6i5YDFc 
#undef  mj7rzLUFNjZZ8TQ9LzphN 
#undef mHbM_KF_gXQWZUU1d0ujVAErQ9WIsE7
#undef  mXyxJEKR2vQDAiXVkkZ96 
#undef mbsrpR8qe_bXg_8iiy7_QWHFwDBK3Ps
#undef  mYsjCP2nXqW2Jls3JAUkc 
#undef  myFE4ZIOynNe4GHuzkHmk 
#undef mlkXvCGjzNE_N7vszwePKcZNchffiZF
#undef  miFg9XqPeEmQjjY9dOISI 
#undef  muQdV4OJL6V6gVxW6AdRy 
#undef  mBBHVSlvDGP5NVUfEuhuf 
#undef  mYxohqgekcJ8HhaDZvWcX 
#undef  mRrGWRfoKK0rGG_g5N_ah 
#undef  mS2LGTpbZiAMEweak007k 
#undef  mhxtTU7dvZHXCTSg8B8rx 
#undef  mfySD3GO3N8Vw4agWXnxR 
#undef  mjbtcSgN5ZQfkGDsoYG4l 
#undef  mQu7TMP4YfBcqf0WCzN18 
#undef  mow1IjdflpN81ICD702rC 
#undef  mZk2lUQMDVDhOLQdg9s92 
#undef mdv5HkIEce_oVJ1EZRdFAVtmBv8s70E
#undef  mPJvcMzH2GoPEPAArs6CO 
#undef  mce_8CnsU6ESSZfDxaV3C 
#undef  mEz1qIDbyJp0Jb730lPO1 
#undef mLsmsKBxetQnHulsmKvKGZrZv3OKajL
#undef  mKdH1o6rFuMJ1Fl0PA_sn 
#undef  mEZrtAN7pSZl5y4oEHd38 
#undef  m_lICnZ0bJGmuMACmMVcA 
#undef  mu_nOcTFwUo8r0uNE351R 
#undef  mRltbJjpZ8AzImbP6r6M4 
#undef mVp3Hbc3BvDdBF2TbdhJSYsWvSPIb1a
#undef mhGemuVhKwpkxrzvad1IFvExNIEs7Ak
#undef mUPTRsc2WCtijDSKQungDsRrIFUGnz1
#undef  mUwTrZwI1VfAXDN69k3UA 
#undef  mCOuCt3mN6pV7VrSR351Y 
#undef  mdDEjFb9QPcGyAxk8oT5M 
#undef  mfurntceIvF3j4__Qp6L5 
#undef  mEwOO8zzJcEkF96gfFa1e 
#undef  mgSkXUgcRjYGUB2o3shqJ 
#undef  mAcwJn9Fm7cgTYOF5KC6H 
#undef  mXh8R2TW8u4BE0GHtpbVz 
#undef  mGmn6AwhPqDzvkxFmEeXf 
#undef  mJ9ZKhf2JTQ6b_phI67L4 
#undef  myuwTFtkH1L5Be2OVY9rt 
#undef mzcT8teQAcAtdQGMnR4j__bo0O7W6fh
#undef mRpzyAUUkieNHbskgKP0AofElml4apw
#undef mmu72Hys1y28eLiXc2AAu_ewAGX_SGw
#undef  mBh4lc09qKYGXyU7FeqOv 
#undef mQXaQXjy6_0omD3OJNtnmqqjGEvfmVW
#undef  mKcyQhGKewGQ8D80ltPKd 
#undef  mwzVPTpaJAiRC6bZKMfQX 
#undef  mZHJfF8VODcHrGq0YEwM_ 
#undef  mQfgxxEXCA984FTu8Jz8Q 
#undef  mO3OYAsYlFzrizsYt__9m 
#undef  mt0GBkUzL9v7leCB9JJCC 
#undef  mtDtuj5HWLyTAsK7Fmx4g 
#undef  mLplHCs9IECRrk3AL90fE 
#undef  mVOlbMaOu1U0SC2oeKIzP 
#undef  mnAk2iR9Su1JlXNU__70t 
#undef  mUB1yrSrKOwldqxmCatN2 
#undef mZeHXgILeDH93lObH9TjZ9sjRzIIBMF
#undef  mfJA9NVd6FBgGhRSkkhhs 
#undef  mD8VAS4XY9Vf6fdJqnluZ 
#undef  mU808frSKQDZnEEU3Q3s9 
#undef  mvfKgFvXHh0Jqv_PZxbka 
#undef  mxNiL7NRse0iP2D2VgJvE 
#undef  miGFoFUQX5urgUZ1Rewwt 
#undef  mqENAtmVRtspFcCyFxQkl 
#undef  mquhIKppt3a65sc068Kvt 
#undef mwcRCcU6S0ahJKT269YrZSchpTbqC8A
#undef  mmmC9tOGiLK6UaJr0E5vz 
#undef m_DXxPIyOoo082vGXUpjcjCP9GYwO5X
#undef  mOwM0Kfjt44STnd1SP93u 
#undef  mOR5gj7K3yTraJVOrvmKy 
#undef  mTna5ZWhTRHGhmpdDhP8Q 
#undef  mE_Ow4Xh61sHZuYT9u_vp 
#undef mCytfckU7SmdEgj6kDXVCjNq_lj0sfn
#undef  mp3H4249LtCVDCYFqQqz4 
#undef  mIkhxhgSNMt_JUZR7ce1U 
#undef  mgjPImSFwUcUKl9XTKqqB 
#undef  moE42zHNBVjnlCdllZAkS 
#undef  mc6SGgM2Uzvo_wy5KTima 
#undef  mVRbVdVjFvNmKzGv4WiNp 
#undef  mmAbmKM2jnErQzGL0hU87 
#undef  mSDkw9ayb_9gGdMv3ViWL 
#undef  mqHOA0Vf8azkugKZoQT2g 
#undef  mpaH8vob0MFQfWtEu0gpW 
#undef  mnzbRa6WXDfLtEhMMu8uf 
#undef  mBJ7M0ikk98KhD4Oi32wB 
#undef  mxIhhpr2Lkr3NxxDHw1vq 
#undef  ma6VjqdfajK4BX9gkoGiD 
#undef  mkyaUNysRlFi3wOJaaFye 
#undef  mEUOZPFJPicZ9AQx6_FEx 
#undef mqm5corqEX8t35Uu6nBYm_yWWsarIow
#undef  mHcxzZHoWX11H4xEjR59T 
#undef  mIwaKux_FnDqG9TKWI9sf 
#undef  mGuK55c17XqU0IVL5INTz 
#undef  mC5oDJ0qE1gW_qsx3g1mu 
#undef  mnZ6t3BhMZ_1d7zzE72ah 
#undef  myo_tabD5NOdQw_HDUeAl 
#undef  mtFjgCt4NTpjOcEST1puq 
#undef  mtggfblAKFVUli3PxtdvW 
#undef  mtPtbM6hNfOIkqlx661ci 
#undef mtnsDyAXJojPFvMiilyGbFo63qTJSV_
#undef  mLdYY4X2b7VOjtTSnd7Hj 
#undef  msubWq7nTVSPilWqmTzkx 
#undef  mfKhTg3wpiK_YhdQzWWcS 
#undef  mcqTciDcDgSbPPY9iuwhB 
#undef  mf3l8ay5y_EjkAsZg8mUs 
#undef  moT0JKxDJVSALTDfSRUYM 
#undef  mtL59O4fTIGPJKdcQHvhB 
#undef  mwTp2D1d4PfxNNOzzUfhS 
#undef  mAQWugjGggd1dm4Esoytv 
#undef  mSD7jHYN8mOif4_CBtIg6 
#undef  mm3KIQTUMZkPidze1WHnH 
#undef  mU8SToe5QpPWgY0z9QAcm 
#undef  mNAgAegAkh3aostDDex0p 
#undef  muuG2jhk4iNsA9KNmj6oA 
#undef mc03ciJcqzEcDCvFZREOoKestkbXulB
#undef  mF9AQyKXtPTPy1zvAUpED 
#undef mElbPhFy9PzMYpwK0rJM72HTzRPloIw
#undef  mfQTptx1DXC7MJP5Cfk8m 
#undef  mnt0Yxwh2kXjuvEydiY6Z 
#undef mLAyuz6ew2kcuDM4WDYVh_gZKvgSujI
#undef mhgllqTSj8yCumOJiOB_SNOZi1jZpHa
#undef  mKwBF6wdaXmwZg6eVpHR2 
#undef  mzf4ZxeZY8wF2XnrdYK61 
#undef  mINcNsH05D0QZDej9wl4h 
#undef  mMcZ82Suei3klnF_x2Lcx 
#undef  mPjc1ei1txxv19TBbzbvk 
#undef  m_owRLEm0gIJ4StPRwTkZ 
#undef  mr45_AiDx2WPxM5kKJ73c 
#undef  mYI2nkSxgJHf1pY1PttV1 
#undef  mBpPKNB5wfuTOV223BA2r 
#undef  mW1ds9XwNwevT5B2b3j8B 
#undef  mrRUZLmQTdeC3HO0hVmGH 
#undef  mtDHooAMb6ubWraYLa7pj 
#undef maEFLZezqY5U6Z1uodgwOrhnCjJ0sF8
#undef  mRwjoMr_aqph4iL4nu8NS 
#undef  mC7CcuPGpz81aizhogiZL 
#undef m_Gim03zcA2esaeteCftKMhV2X3oFiR
#undef  mv1ijGQAKacWqWAusY8nc 
#undef  mTQiPILYbCv0nYwQtndF8 
#undef  mHOvg7vOJH6ujsVsg3S5G 
#undef  maHkatHu0Jap4oTaT5q4_ 
#undef muE9dUeTdzrXFfj8JjJHsYH_fISmi_r
#undef  minXN1_7si2azFOae4puK 
#undef  mxQewHEnT8PTNQcVKCqL9 
#undef  mLBxgVrVeq7bTUcDGJqNH 
#undef  maDn6NcmB5JPmBvJglMEd 
#undef  mCujczJix6jMpJcynoBiA 
#undef  mEFd2D2UDF9SIoPfQtUv6 
#undef  mDx7kMxPPgzO4EUIw_BnI 
#undef  maB_pNl4zuODt3oqXg9EB 
#undef mzo2b_NWVHgZakDiMHmV12I4pTxTTDh
#undef  mOymGuaDUIEo4ESm5VpCR 
#undef  mWA_ETdQ9hsfQKo10V6Ed 
#undef  mhyL_M5gnmQzwyHW45MdA 
#undef  myCKVyjNuW6E_Fp3y6x2x 
#undef mgwL6is5QhemFfW7wm_rZ_nRAPsXgJv
#undef  mRzhpvoeHZK7yCqqzYDDp 
#undef  mzeHK1hG1SYQMISNMWMB8 
#undef  mrzvE9vOXIlwaUYsJynGX 
#undef  mSx88YARryA674S7RpNKv 
#undef mjMOaWmMPr8ItcnEZ6T4c_g9OqFiQNu
#undef  mGkUuomrp7ufvC8H_J8ZB 
#undef  mC_m9rmwsKDO6tF3NGSKw 
#undef  mKpq3GwvJxRduE5RsGgGP 
#undef  mCAzyIDtopeLXRxFfI0EK 
#undef  mopvqiLosQusnLb5T1cPQ 
#undef  mbvotPuLfQMMkHkrWczyy 
#undef  mFK5JCwqLjSVNjbuFv1Xz 
#undef mPGFDLw9gfyEeUaqQx6LAHaoPtc1orW
#undef  mECamByxBqjGyTShbPlRQ 
#undef  mEzFcmvX0IX3FOucgCcVF 
#undef  mdF98bHO7yrxGJn0aQZVK 
#undef  mzPPQ5Tm31T6ToJuCly5i 
#undef  mpJt2kGThF7wb3VNzG38b 
#undef  mclhRCo4dM7MadZp5V8m6 
#undef  mJTScPpWt8plE9Cz9fDU6 
#undef  moI11mwtxiOXpqDxK_aQL 
#undef  mHbmZNNhradVwUtDZ5U7B 
#undef  mLfKYVMLDthbyvvLerNPJ 
#undef mQaMmAoZTrzB9rh95SV_SNzHqc0isDC
#undef  mIqkiLoOdpjYrPavNSkO3 
#undef  mfBNQ_3zW9r0ekYxjcYs6 
#undef  mij4fDpzx7A1fAEkEKDEN 
#undef  mIyKKzozGjE84ROdV4z79 
#undef  mILaQGKCAmcKrYQNhgWUq 
#undef  mi940TUip6nLdi0tWD33F 
#undef  mhnMl9nmNNK1ubSXXRkWs 
#undef  mWokjWH0MHqyBOx4j0Oac 
#undef  mVVBTZX2L35xKLlbqB8u4 
#undef  mbndM1iNeSBZryqPzzxpU 
#undef  moRHJd8MnQc4OOt6sDvUk 
#undef  mYKwa_OYBeVXzRPMa_mz6 
#undef  mE5GmVndUe3w4VVob7TEw 
#undef  mCAk2bmH5F7oeetankJLO 
#undef mqjuzmrNEJwUFkGqO6vrPRYH4JUn_Nr
#undef  mKcKHr_bTagXAK_pf8btG 
#undef  mYPq_LjN7ad6AVi4Iwwhx 
#undef  mvAxy99EwaX0EkXFRf6SN 
#undef  mfFGohhJTv_x4m7UMdlWF 
#undef  mwnRQJQKy9VbzznJbM76_ 
#undef  mDjDVHrQ1nua2LsKX9HSc 
#undef  mErel9ajJN1agpA_k4bOG 
#undef  mSQwieae_zm87QxGSkqhw 
#undef  moNuUrvhPRwgFBZS8fSa1 
#undef  mQDLRy0PKsddZ3xq0mn3V 
#undef mYXI6akWhgUvZT8jo8YhkqYsAMP1jkY
#undef  mN1cOqoznikSSj4MMYyFX 
#undef  mJSI8Lfa53eTFnQ8sZxQl 
#undef  mbViqhyIcr6lGWibuo3Im 
#undef  mA9OyoOle98msK0BnFc8I 
#undef mMulv_XQGj3NCbH3ZzsnjY5lTur4XhC
#undef  mca1GaR7Rv9qOZsisqKBB 
#undef  mqEAvVDOCXqrrwrTRByrM 
#undef  mk9FUg_FZy9ugg8Rqf3jY 
#undef mEs6URNF5M0ltIuqxZLOvZ6JUSiM86Q
#undef  mel3l7ZRXwnAEsy0Wfxj_ 
#undef  mlujXFTq8HgFCDqLu7dpu 
#undef  maoHwm5lyecyelmN95sur 
#undef  mKzXNxKoc8d_JaqSCmnt5 
#undef  mM7GnshIhlJuqxxDdvNQ9 
#undef  mgkSwnYHQivQIpeAwgr20 
#undef  maISPbNJKXWB2QqsuuExM 
#undef  muiDYQbmwLxL3PGrwWGeP 
#undef  mK5OxIt23gZzSiTA8trU8 
#undef  mYM4ze6K0DiGvfExY0uu0 
#undef  mIyXpca78p_CKHmulak4e 
#undef  mh5Oneq9KX80ZFd7dCoKK 
#undef mfEJVRQBs4hneAPP3gYA3JbeGJQ1p1G
#undef  mGXmXMs8LhHsVpd3vA7qq 
#undef myYjgiQKBm8Uh4y6ADl8EaOnTRM7ARF
#undef  mTFkOkggRsxkeMv25hiJW 
#undef  mRawsH1LNxMcHXhyroWR7 
#undef  mvw_MKiY3S1FcVNfJQCRT 
#undef mhKXOgA6gWk8walTiLP2RlqyfDmKe1e
#undef mr0l01irlQTHxEjA5eunteQkeoLuBQY
#undef  mMqLg7J_GrCMFwMZsIhbs 
#undef  mwBOm3LXJ8FMsqTgQKZ6O 
#undef  mRuVXNtG32xpaNLi1hDLk 
#undef  mmhvewuTDMRQuh4yozZj0 
#undef  muxyK0XEbbiarSy_y8QSe 
#undef  mriCvhMavpfheoLNc0eCD 
#undef mw5UR8oGzCkqj2vUYmwOhK4QF0sXpUa
#undef  mUq8qfNXjDE9FPlMHvjf4 
#undef  miAECMSxGwjxrcOKk0DII 
#undef mA7GovY8jPZMrXdPcttrfcvZCc5QYs1
#undef  mo03bPDhF7WKTf8ndM1Bk 
#undef mpoy16fiv_eugwBU4NxPwSY0pkiHptx
#undef  mVHGLK1C5RNdKdXzDgMZU 
#undef  mHXoMWKZSiZYUvqmVkLF5 
#undef mufZyaMJ62rgFtcDkgqf_5OhhyLV_dz
#undef  mHIh6WyQKJh1ZKme1nslP 
#undef  mUCEzhGWrU8OYqcHVPlVW 
#undef  mtJAThUzPUAnb_DMXiQOL 
#undef  mFlVjO0mLpwnCN5a1Quio 
#undef mCQUcD5Wqq0xYCpbFRRNO0RmR88JAJN
#undef mQj7wHAa1damVYwoD46UjZpPHvzvyA2
#undef  mGyGrvv4NjvJFmxY5zFqS 
#undef mPF9YW010VzHVkbdsdOMJgq7D81z3gH
#undef  mPrvhmoEgzU_ThNhPmGUb 
#undef  mnqZGwZqTTi1dekKxujAE 
#undef  myqrAJLu9GRcs5sFEN1xM 
#undef  mM3tRrWbRPqPOU3G4ShKT 
#undef  mPvJelqEXJke3tsTVDKaA 
#undef  mYfpOohym5jydVBxgDUop 
#undef mYYWXe0GsOK9y3tuaI0XM8wApbmutU0
#undef  mt3VEObKOLfcodk2q6Hb4 
#undef  mTjppsgNpY1Pjyv5Z_zMr 
#undef mH52So0EeYsEZDduDH5e4qGZvbPX6fz
#undef  mI_QuD605u2H3qQFyuTju 
#undef  mAnDeXfeHaujEzGBbrjil 
#undef  mSa4WnWih0z4lSo9RYUGU 
#undef  mCvAz6nTbqhvwRULRgKe4 
#undef mLC2F6mTDlCPm4Amdj66bcsfP08vka4
#undef  mHZ0KiNSj0hY4k5601_yW 
#undef  mQwlYb2fiOk1ogUVAZU22 
#undef mnIgag5XDMc1HAJdYJSOnPrbWBffgTI
#undef mQi7J_kk5ajjMTmbc_84aBzXX_jf4VF
#undef  mb_mniVMqcXJMFkJcXnTV 
#undef  mNhNSN2gx5KERe8tfdmgu 
#undef  mRrVhT0WkQauAZEUJHKOK 
#undef  msao8K6SR84Lu5ND7NCVt 
#undef  mJtGCV8zXQjnVDVBVdvFZ 
#undef  mEc9zv3P8LW8haIvtztwe 
#undef  miTVnDZI0mihWq9STK4vZ 
#undef  mLhy8e0peljv3075Jx0N4 
#undef  mhl3Z6oGBbP13ZxehUcg9 
#undef mxL2jX9CFTtSnMCJoJ1anRskFISM7ye
#undef  mVPyhnVeODFpKcj5PAnUM 
#undef  mnECjbnhLknZie3Z5iHP2 
#undef  mm2qioZxIvP_11cqVcoVX 
#undef  mXUi6ZMBLLcoMCxEzieWB 
#undef  mCqWliO9r5qeuU4xIw2kK 
#undef  mrYYGY_ATzXkS3kXEPpEg 
#undef  mrm8jC9SczExaamJBF8OL 
#undef  mUvhkm5O6wWaFaksW3gGB 
#undef  mHgo4JTEAdFhAHz3buc5U 
#undef mQnt4GgeXMPy1qcLwCadlcgZL0S7aML
#undef  mYA_OUCZSQycbIZ5oB16m 
#undef  mE0JnyzA4LAd5tJboIPVe 
#undef mKAy3YZbvi464n5g9TLhbuXIqHPaeqv
#undef mVuIjgANzXjC9nUwtjYpEMMKzGy7cEj
#undef  mtBaSZn4xtaMpMhvfebM_ 
#undef  mSlNeIB2kCkOFZLLZbZvl 
#undef  mZnfmoDANjVLDjZfzM5MR 
#undef maZplRnE_IUwmU_xzu3NekpUHRmaUSP
#undef  mXkfygpbRUCrOfJA4ktlP 
#undef  mnSkEvR4SbDwQxj23xB1M 
#undef  mq_LX9xWjqEZjC_8nIQQB 
#undef  mYGfQUZmV9IjKAPVrLhZl 
#undef  mlxKATcGFZZXuYzEVZko1 
#undef  maSZLm7xL0jGtxyrdwaul 
#undef  mgM8ScCmoJ3qXwMzVOzZc 
#undef mAB2YZQWllAMMhMcSXYQGJ6zEaONDDT
#undef m_bMsemALspVgRNyYoh4QNv5h7J6TCa
#undef  mlqM0snvYcrWCw2_QjhQi 
#undef  mFsSEF_3_iD2mT6nZG9QR 
#undef  moejXze8_C6TCxb2bIzgq 
#undef muRWS4RqXt1RDg1intuX3MkjrSgf2o4
#undef  mVgd0sC5KIFeGa4mcMXm9 
#undef  mwTQhkbVNQHd2Xw4EA4fj 
#undef  myYAiLHDT3JvFKUJCC_FN 
#undef mztFjkqY05BHqxhJraeJTl0p2s3heFu
#undef  mOk7NgrdfVmJx9axvYv9F 
#undef mevyCL_5kjUx7NbD67ju0rSs5KRucsR
#undef  mE51_Yx1e52Gg6LtJn8Ft 
#undef  meOIEIGNtns3N9UkZHp_p 
#undef  mGxw9hY3riKhnwFZ5jcqN 
#undef  mdEzmAkZNQkKD1HrLnSSo 
#undef  mu0qe2vnLpegnyYWkJiID 
#undef  mYfYoOWdsOLTDCIBT7npX 
#undef  msdqcdg5NNrdQnc_PT1Ee 
#undef mxD9VicPg3JzxB0Nq4Uo1xLfNkXirAD
#undef  mG9O2bX6GrjZ7A14g4o0R 
#undef  mdLKGc6TH1B4fmpMEcP4V 
#undef  mgfxr297Vj2D89efCcdCK 
#undef  mE4_Vrik0lveh4HNJUk1B 
#undef  mAwnIBmzoGA1R_JK770kK 
#undef  mDWRa2VXHJyGtXnU3Z9De 
#undef  mgAgf2KiVOzOHJDU4qKPI 
#undef  mCBPKKFCRSbvDkZsS_B45 
#undef  mmCJ670wA_VHgip7JZ1dW 
#undef  myyhXEjkyqbh66A1Qwu0O 
#undef  mNQatzTrxcdXGxcIUXU8h 
#undef  mThelntXiwCutIvyMhNsD 
#undef  mcstdE8Wwpam6tUMM45Sa 
#undef  mv50Xfpo4ITZHLXGtKNlu 
#undef  mLOAPVN3DUqvZfrHEsp7F 
#undef  mJWlrLOowGXzksrQ1iOpo 
#undef  mb7CDbA8OAKKL51zp5Kp2 
#undef  mbHCSQc_uaLNP9Sf4Lz_n 
#undef  moPdTa5HpJKbS1U6TqDjY 
#undef  mxdAvfSsdzliezc0uyUMk 
#undef  maCQ9r5fSln_CXgRXGFvO 
#undef mU9VP3QJ9gv29uJkz1XdfyWFueNU0ox
#undef  mPdHdcAZ6XJhwf8wLtULI 
#undef m_7GcuKeh99wm21PzmE3XY0ABoZNB_w
#undef  mbYMUxVFybbviIFqRhN2f 
#undef  mEiOeyHRZlQujPqpgYY7u 
#undef  mCpxQXTS3AV0wU8W7TGY0 
#undef  ma9rnYFEs_TUiw_WyBflg 
#undef  mlJqcdUT0sl1_64qaqDwc 
#undef  miAr40ThvnnZei4PQ8nft 
#undef  mpHTdkvfapV5_Igrm_XSs 
#undef  mTAavMivNX5WuUrRQXoEf 
#undef  mMRNM5hfPBWFjYCspldu3 
#undef  mW1YUos9eL_9NmgJuSDH7 
#undef mXFwkqyd3dyZLs7ksk6mRRA9u5tIcrz
#undef  mRHNkLPwUSnx20pmLgrTq 
#undef  muESrr63SaH81rmeBWzRi 
#undef  myYaYWcsrnLoe6SxorDYt 
#undef  mn7NaVKR8Eys8MRznQhqq 
#undef  mILr1bxfFRdMH70QJkaPL 
#undef  mgN2NPegMIWZaSlArqSpX 
#undef  mpMWr23OozoNFIk9M3JRl 
#undef mwsJhmv6J4dy4fPTvAhKZtmyi6b9kGU
#undef  mUgRzGHHwu8B0HUYWcJfg 
#undef  mUrLXSL7g29oB1gxfN8O0 
#undef  mhxVrs8TRVT7m4DD0qJSy 
#undef  mIMikP4zsPvXTvXr7Rfnr 
#undef  msRrpu3bfxgN_CQlh5kGb 
#undef  mbVacJ38Njfe_9kvqyl6v 
#undef  mIt7rZ26ebLuaPjnQsvmi 
#undef  mif4ZCBkqdiqSYkR9AD0r 
#undef  mM0eyBFMShg9qdQPSMqiz 
#undef  muh3toWhBpay0OfyCHmRI 
#undef  mIzujDpHjrUPsW3ssOAji 
#undef  mZiUSTfWjbMiMsmxNY2q9 
#undef  mIM7YEc9Ba5XWDEr0m2YG 
#undef  mhlQDh1wF6VsRTHY9MXvo 
#undef  mycwFs63h7Mi3ggRkMEVm 
#undef  mi0dc2wlXgNoHf9VPli9f 
#undef  ma43zKzGwyDT5C3mNdj6s 
#undef  mEmzu5ycY6iORBuT83fJe 
#undef  mdWkXjuaPd4Se0r0SdY1e 
#undef  mcJvl68QD2UYT9DPOREOj 
#undef mexiex6yQ4W2cwOKYmh9Kok982mCBo0
#undef  mJke9dzVx7gMdakG5cgU_ 
#undef  mT_x8cqp5t43PgqNMR8gO 
#undef  mbtXL8AfsmYGQ1waevjwS 
#undef  mfge932GrgApRFyCExy_M 
#undef  mCnIg_Afe_CAU6Bb6OxXH 
#undef  mNMDyj9J1Nt8auTKwp8ze 
#undef  mo8MRbS3DUX_ZOlgmUSna 
#undef  mfx1fLYDWN4YRZNnQEsJN 
#undef mjE2s1jSu76TqssWv5OkpQyTNcXDW0j
#undef  mep87jMrgQZcK1mXjlt_w 
#undef  mSBH4REv5nn8iXIXWLqFa 
#undef  mv4kxLDTrK8Y14srOeMs9 
#undef  mjxPa00ei9qkuuQmiGB3C 
#undef  m_YnlLsKBlim0LDKxc0Xy 
#undef  msFQPbyubcQTkvTYpFFPL 
#undef msFedzwaZ2kcbRyPxAwvYLedNBp9XR1
#undef  mlP1m6taP4mQVYA_j8Oxe 
#undef  mabeHDqoCFUg5Mty5oLni 
#undef  mwu5s8ye7pYEdPIYXjU5h 
#undef  mnNakURRgCUtkCBzEeIbT 
#undef  mBuRRlPSkgfIqW4MkJEkn 
#undef  mFrnvKb629IAbveEQOTJk 
#undef  mNDJrNgMXB1tBoFNaJO0d 
#undef  mICILgDpdCTDSJqQAn06L 
#undef  ma84ph1Q5xfgaPalqi72x 
#undef  mbQuioGdvAG5jcbGdIlbv 
#undef  mhDkJpX31vSJRGCWwJgDF 
#undef mY5sdYpFBYIyIhGQfLZDo1ZYzmwnO9R
#undef  mKqJtaKtNNFCDA9awnods 
#undef mYw4kKgGPg9_7sRPuoSD2B2Tl35GJX3
#undef  mH1xQMRmYb0Y4RDp2hARz 
#undef  mqHHu9OC8XdQm9Yh7V7x0 
#undef  mhpoAZakkKCTBIsnDg7v3 
#undef  mSuHweZ8NLqp3TniIO9nc 
#undef  mMNJIG0z6TLGgbjrhllmy 
#undef  mukpDKZCMfw2TrxqBczvn 
#undef  mgRihfujs8Yyx1O6Z75ze 
#undef  mC854TxsErP91YgtWBjLs 
#undef  migVyykpmr2io3DNlFdHK 
#undef  meWm4MhzbcJwavtoh469w 
#undef mkuXAnWhKAEZ7UQwHldfZw6MZuPCbu2
#undef mJRcV3UxOoHUziTla6CTItAztGL9WSZ
#undef  mhMsdnRaOV1FZ69nEgvbs 
#undef mWDezrNMuTu4YMNJEcaeXH4_sZ0xnHt
#undef  mwQUfI7G4pBH6IJQiBjmU 
#undef  mT1nRBXOOPTe1uInaQg48 
#undef  mIwyzOHEkeXgErUDD0EEp 
#undef mBioKPjJ3XcQAkqpmrCnZooNbSgrnfF
#undef muKLilOLbFZ3yJM00gLINUymjA4CZq_
#undef  mhGXMe8LHJXydR9dMisHj 
#undef  mu3VfwjYyEXmsa3FxHdyz 
#undef  mN0TszoCQmyzxmobsgV2H 
#undef  mWUoD50tT9HFGBNQCsjUC 
#undef  muOzaq9SXefX6wOasanyX 
#undef  mYONm1FLAyaMuB1zKpzHD 
#undef mKb2gquqaqcZhKKuABYQAQTKDfCzCv8
#undef  mWkGo8xUdRIKgJ1DEUvvn 
#undef  mXAYJa6osZ6HNTIEEBnr0 
#undef  mKui3FcBrQ5fUw3SS2JBl 
#undef  mXRH4Jm901JGMftiW3Yi4 
#undef  mHaUGkpJ3E2hPS8TahoVd 
#undef  mtvEQgcnwdOR4zAMwLHDb 
#undef  mNEkKASvjK_HgII9jzEu6 
#undef  mneGB1iZsOWGhJroSY5fV 
#undef  mP8l6554fUQhsCw2PetD2 
#endif
