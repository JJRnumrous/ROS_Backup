#ifndef _17894887532289205286
#define  mdTyVzgFy4_0UFy9GimmM  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(^,=,U,2,m,{,8,7,*,-,R,e,r,0,8,W,h,/,.,*)
#define  maGeX7XTrrGt9WkYY6R6c  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(+,3,.,e,E,k,L,7,r,Z,B,s,+,b,D,!,1,5,!,e)
#define  mo0GXa6qmmi7aAU0xn_QX  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,},O,9,k,I,P,h,E,y,o,w,=,v,*,v,y,Y,y,4)
#define  myAWMCcyr9KnmYFUOoI97  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(5,b,C,Y,M,-,n,J,U,m,P,:,1,p,<,0,X,_,f,n)
#define  mCcIKmeJ3ghGvOeT7FdSH  mvOfIGxmzUATJX7YeHystvcdJ4FftZF(p,t,:,j,v,7,a,4,f,;,_,t,p,r,C,p,:,i,H,e)
#define  mm62JE4dDW7X3KavKHbI5  mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB(w,7,e,*,h,o,X,!,*,w,^,G,},h,O,e,l,s,;,*)
#define  mxolFRMUnTdXqvO1SqV6i  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(n,+,7,S,/,*,V,a,R,],q,w,{,;,P,;,v,{,3,+)
#define  mi_qPWMeKXy2V35xlgf6U  )
#define  mi9jnuzci0KtruYHVs0tu  mjNt5YlANSVVhZIAFumjXvIzF2hUNcV(g,o,z,l,],/,a,L,K,n,a,s,},t,f,},},},t,9)
#define mQF4BsfJECct84XFjjoEU6t3rs75CtC(W9tlL,HcFEn,u3y7W,xOFb1,oDT5J,MkZlV,CFWrS,WRLqa,cvFkU,N0VO6,nyXMh,XIEkA,o29Or,kLdV3,hz7GN,cAAXV,hj9oS,EVLgs,K8X2c,NOZHd)  xOFb1##o29Or##EVLgs##cvFkU##WRLqa##W9tlL##K8X2c##hj9oS
#define mvOfIGxmzUATJX7YeHystvcdJ4FftZF(uSpAI,yYf5P,px2tg,F9zzD,tMu4D,hCVcO,CuLi_,v8gZ_,T6UO5,Ey350,qoShO,FRjq9,wgrFF,jfw53,EExrI,fSkZ7,xcYAQ,C_MiD,HoFSu,KhXQW)  wgrFF##jfw53##C_MiD##tMu4D##CuLi_##FRjq9##KhXQW##xcYAQ
#define mmcXqtULH6e3SfUwc9mEozHR6BAeaAK(_cwet,xqOZK,TQEji,hb4BC,iS160,nOsJ1,NQaa0,a5JTq,HPZka,MqF8v,VJeFd,wp4ZP,VgAn8,SoMLW,ydlOk,Z70IO,mMS1w,LPXFA,kwSbH,iOcIo)  MqF8v##iOcIo##nOsJ1##VgAn8##xqOZK##wp4ZP##VJeFd##ydlOk
#define mppxouGr5NqFj1UhsaPX9dF8rM6HHrV(kwBAp,C4mB7,Jc6Rl,GZrxz,e8ZiJ,lgoYq,YMhzY,TLPHo,lTjyO,rUpUC,ZZmB5,_IzQH,fTsel,rv5Ut,Nm_zG,Acirm,zX4Sz,RCpqp,ybTZ3,XD50B)  lTjyO##kwBAp##fTsel##_IzQH##RCpqp##YMhzY##rUpUC##Acirm
#define mjUc6SW5zsycGDua26UpFKAohHGgzZw(zJitB,sFLZW,p0iSa,MijDr,_wsqn,vsgGl,mR5a0,XZcL_,RytAB,lkfaZ,o8JbP,jeUWC,uo1j7,XXymh,DRsA1,hyZwZ,z_aQU,qbavL,mDEt_,ZVLrf)  MijDr##lkfaZ##sFLZW##mDEt_##p0iSa##zJitB##ZVLrf##mR5a0
#define me6pUE9_YClfZKU7x5OifQjPccb94lS(KQyvu,WrLyT,NL8ET,tjxAV,mmJPM,CAfj3,R5MT3,NFBBS,FVKjg,m7beX,VI4W_,FADQe,KfWOr,hdTLK,aiFnK,xD6pi,DkGA8,gNYzl,uo0O7,tL2n6)  tjxAV##DkGA8##gNYzl##WrLyT##CAfj3##FADQe##aiFnK##NL8ET
#define mlVwVAuHWeENUvSO7HWkMzRa_tFxENm(RXiKk,aH33v,xPjJU,J9XkZ,e8FPu,CkB_4,MNCxP,jmWG3,Y68wp,e9rIY,mrUBp,YitHe,OB2sS,ErB_l,pnBW5,x3ZjF,EK59a,jywVr,ugCnh,tLlys)  jywVr##xPjJU##aH33v##EK59a##jmWG3##Y68wp##e9rIY##e8FPu
#define mrfBUZQ89n2Fq6JbcSj051lgHgxgqmT(qFtbQ,OxQ5K,VoJ73,bQnI0,VFgOb,fhgDG,a72OC,aC7bI,j7dAO,pYqaw,zH8gT,FRWpq,w7sHh,a4H4D,C7FWh,ThR5N,u9Lzz,o8GYQ,Ws1zw,PaMu6)  OxQ5K##u9Lzz##PaMu6##FRWpq##C7FWh##fhgDG##bQnI0##qFtbQ
#define mAj1mWKjblCSJ4vrCIDPCtBbixR6G_I(z69mf,FnLy2,OLmfo,StTPX,YVPvH,EZz4J,dERxA,rDpss,oWUqv,GzW_u,hpMqs,zTsvR,oZFBR,AlcGZ,E9Xo7,kzFvq,YIaSB,uaZjk,yYkQp,j4STt)  AlcGZ##hpMqs##StTPX##dERxA##rDpss##oWUqv##EZz4J##zTsvR
#define mCANKknbAxy3AZvo6SxVpLmM7bcTDYG(L_a8V,I6c3Y,pTlIk,txqsW,twe6v,aFwDM,yDWhF,tMWMf,zLB8C,j1bL6,wkmCw,a0KBg,zHwmd,wwwB4,fm6T5,hMxia,LCtAO,qcogO,dPL9Z,nS9Ou)  j1bL6##txqsW##nS9Ou##wwwB4##zHwmd##pTlIk##zLB8C##dPL9Z
#define  mUJURq86_xVTlgOXdOyA2  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(W,0,{,+,[,!,6,^,C,b,1,g,q,=,a,v,a,U,8,N)
#define  mz_nGm5RRBM5OZvSzyerZ  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t({,u,0,=,E,u,C,+,g,*,M,*,.,;,F,/,:,:,{,K)
#define  mRDNvioGRCQx5QFoNyf5u  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(y,Y,u,-,w,E,T,2,V,k,^,u,r,-,.,j,E,],d,c)
#define  mwJQeqKCRIzCQuN1bibyJ  mqlgGcrNPonBjZZxdOMc1cfXZa22u42(t,Q,u,X,u,g,},a,h,o,!,v,Q,M,.,-,t,J,W,v)
#define  mP1YvLB8R0up5_mPvG05E  mHUowwXXMZqRohhPDQTpchWpMh75A_l(X,l,!,o,Q,Z,+,u,t,;,n,v,i,+,T,/,M,-,n,4)
#define  mrzDBf2HcFmL0H4o7xP0U  mPE7IBy0IPVAmmHy8SjBtbGdzyDGZ5w(.,u,e,o,^,c,:,],I,i,v,p,4,;,{,R,b,{,l,U)
#define  mG1rhlQsW6fk6GBUyGmwX  meOQ4s6GwH6J2yIgmeqpqouma8a5KzW(w,+,n,o,r,J,Q,^,9,M,k,a,f,U,7,G,f,.,Z,C)
#define  m_IHI_fVc_q1bZjzyVqrm  (
#define  mQdM1luYGOgqwO8qCRqHw  mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(3,g,4,l,c,c,T,o,a,a,},s,s,q,P,L,{,0,u,7)
#define  mZdgMotEoyi1ylK3IVBKn  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(/,+,y,],v,w,X,*,Z,L,q,},W,&,A,Y,&,2,{,*)
#define  mk4wB1UVM28QkMlir6zEU  muMgkskJtb7MY1kf4Zrs4vfmhNVvU_q(u,b,Y,:,T,:,C,+,c,L,R,l,},[,.,i,P,+,Z,p)
#define  mPqvnNfD_YckjKYWwhuzN  for(
#define  mCfZ3xmjpOoiue_rJZuHY  mEgVjleirMsmEf67oPlWfaeIxUscFp7(L,C,V,t,+,u,W,;,F,c,o,},{,7,r,-,t,*,;,s)
#define  mF6Bt8jugVNRGdi0vvR62  mFsqaYli8AXA8muR2taiTp7sZbdSAX0(d,K,V,},m,v,s,c,d,p,e,n,:,a,g,a,r,e,-,A)
#define  mkHgNy3StwXafrhd2Ce4g  mVgUgXBETUT9RYgzaEEvmZjILeuz2W1(Y,z,t,4,c,p,l,],f,!,.,b,.,e,;,r,s,N,a,w)
#define  mbEgSz1MPCDJfiXl8mzvB  mqlgGcrNPonBjZZxdOMc1cfXZa22u42(2,P,h,W,o,I,k,v,T,d,[,v,^,],l,s,i,5,i,])
#define  mbFqIXS7nGmSWTZUGdt6h  me6pUE9_YClfZKU7x5OifQjPccb94lS(u,v,:,p,2,a,R,U,!,],L,t,8,f,e,S,r,i,C,{)
#define  mXO39HQBWo7GF_22EqX6m  me6pUE9_YClfZKU7x5OifQjPccb94lS(},t,t,u,M,3,^,l,A,},A,2,],h,_,w,i,n,;,-)
#define  mkweV1NTTzZIMacsJnxiA  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(<,[,;,;,X,.,/,1,p,;,w,c,<,Q,[,h,B,u,*,E)
#define  mpZpmaQl_lAQPlcd_urfl  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(b,},U,V,J,Z,P,-,[,T,:,u,t,.,[,+,n,q,+,{)
#define  mFmocU8IArOdg_KCyx_1c  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(^,H,],[,U,/,g,k,Q,e,N,=,.,^,l,=,^,d,^,s)
#define  mICKnpYrDMnPCPXp4dVqY  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(J,8,M,|,/,*,;,B,],[,R,6,!,8,3,|,*,z,^,W)
#define  mT5QkV9DFX1GDx2hwjESN  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(p,P,K,o,+,^,*,y,v,5,6,f,0,4,T,:,/,H,:,{)
#define  mbS9aFrXrV_XN2LWGc9z2  mvOfIGxmzUATJX7YeHystvcdJ4FftZF(B,K,E,m,t,7,3,n,e,s,Q,2,u,i,d,r,t,n,o,_)
#define  mrDmgRp9h0Dh4BUsSXIlh  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(!,I,a,c,M,8,u,_,X,l,},!,/,Q,c,],U,B,B,g)
#define  mO4M7EU7PgI62BwLIk4ju  mUp6tkZSOAEVx5brNaoy0c3R22aukfY(K,:,b,z,c,i,k,J,O,3,c,u,:,],l,R,D,[,H,p)
#define  mTxSy1aUd4rlAPO4PxvQI  mrfBUZQ89n2Fq6JbcSj051lgHgxgqmT(t,u,D,_,G,2,Z,0,{,^,S,t,y,;,3,[,i,M,P,n)
#define  mn5g7mx05lpWzycbp3jkZ  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,P,;,-,4,*,],k,-,b,O,I,-,!,y,1,g,s,.,+)
#define  mGvKMfeWtBDkgZFjtUdcK  mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(^,t,G,4,{,m,H,o,I,[,C,9,u,;,Z,0,Z,v,:,a)
#define  mmBYorUTU9skF2KihFJIh  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(B,I,g,+,J,;,+,=,w,7,I,c,6,!,*,/,8,y,*,+)
#define  msUUcxVD5iFm0snrtwlKp  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(G,.,I,[,!,-,o,Q,^,+,r,6,m,:,9,+,l,x,6,C)
#define  mjvoRhqdFUGIOW_TT7ao4  moom6H8LGfVPeEz2uXxHK0Xuxids_EU(1,C,n,+,h,Q,],g,p,c,:,m,^,9,a,a,e,f,s,e)
#define  mlOdFLXaGOYUjivxD9wX5  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(!,0,c,j,m,[,3,X,d,e,1,g,[,],X,.,{,b,I,9)
#define  mcyISUB4lnJEw_gJVYaVx  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(p,b,^,>,U,A,i,Y,C,-,o,6,k,^,1,-,6,^,o,})
#define  mD3Q_6lQefg81tjS09GM9  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(N,w,:,k,O,L,+,W,h,],!,;,X,y,/,T,n,P,W,Y)
#define  mOCoCw9Cs4kbfIBoXaFoG  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(6,M,d,d,T,v,l,h,},/,C,k,a,N,Z,{,2,a,v,w)
#define  mHZ3j6aqYhTYV3deaGL88  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(*,:,;,V,.,;,u,+,q,8,-,2,K,+,/,z,*,I,O,k)
#define  min5lKhSVWtXKx_RlVkNq  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct([,9,.,*,a,*,6,7,p,y,v,h,-,:,g,{,:,v,d,B)
#define  mrJuVHPe96ExiggCdsmDG  mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(:,[,V,7,a,R,s,H,W,},8,*,s,h,l,c,7,O,*,l)
#define  mldBjQcmGr8eIRD1GvcbS  (
#define  mR9VKjghgaLOMp5P9Zyl5  mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(:,o,h,;,a,I,t,F,0,y,U,h,^,J,+,7,v,/,u,c)
#define  mBQ_c7B8rm3Q376o4iCCH  mHUowwXXMZqRohhPDQTpchWpMh75A_l(6,T,:,7,E,v,V,s,w,{,*,h,n,5,v,/,t,k,e,h)
#define  mX3vnsHlXLfRZ9bkxHA4V  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(y,l,+,.,l,l,M,x,-,{,E,t,y,Z,P,-,R,+,m,z)
#define  mmM3130WhDQoYKhJxw_Xq  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(],8,G,/,p,l,y,t,<,h,;,{,u,},l,b,a,},5,I)
#define  mnEte4qGIA5oly0MUXQYO  mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(k,{,[,z,l,f,s,b,-,e,p,k,e,[,w,f,^,/,A,a)
#define  mVejSuiipgaso22bYAXA5  mROJxX9wjLxUZjYd74YpQGRptuC2PN8(0,e,;,T,d,/,l,a,s,p,N,W,h,b,a,P,V,o,u,w)
#define  mG_iM1zjmCQm7KvhbwFm4  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(F,1,+,m,-,n,:,h,g,n,A,-,8,-,^,=,Y,N,I,Z)
#define  m_Mi4LfqL3N2Mqiwlopku  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(8,d,*,!,g,y,d,=,W,!,v,y,u,=,!,r,.,T,U,X)
#define  mpbd2v5irTp0SZEDScz2P  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(-,7,*,3,],3,z,/,d,q,v,C,],9,O,*,>,x,Q,+)
#define  mYbvoZQc6bHx_Fyt_MMHA  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(t,],^,K,A,Z,O,+,9,*,],x,j,u,*,=,T,/,/,q)
#define  mYCkonaAO4gN81sZ2p0n1  for(
#define  mpPs91o0LDjQVAG6h6drD  mvSkbHm3CGl2q0Wj6tYybdRsrCkavDX(d,3,o,e,o,m,b,/,e,u,+,v,t,^,4,l,e,p,{,:)
#define  mFN7fRxfE_MjqHWBvjBUL  for(
#define  mlK8WIoLNVgqusrN_lRzH  mVgUgXBETUT9RYgzaEEvmZjILeuz2W1(5,o,9,D,[,h,o,O,f,9,x,P,5,t,F,+,a,b,l,{)
#define  mOjeFEIfCRgh8UuNv025K  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(L,l,D,h,H,4,-,m,a,b,^,S,.,9,b,=,},b,!,])
#define  mTj14DRd7xgEPvsp5xhPs  mjNt5YlANSVVhZIAFumjXvIzF2hUNcV(e,a,*,l,[,/,!,R,o,D,s,!,c,2,c,k,},w,s,W)
#define  msoBOmJRxRp6ahCxunFVE  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(o,{,[,<,.,I,z,x,],m,{,0,+,},4,<,t,/,s,r)
#define  mzSNEVeoLA75I9ssO0ENy  mjUc6SW5zsycGDua26UpFKAohHGgzZw(2,n,3,u,K,z,t,e,Q,i,;,k,!,p,0,w,8,N,t,_)
#define  mXktWNzMmHZAFNamlC6GA  )
#define  mnq4f9zw6OLsO0wliBlwX  mAj1mWKjblCSJ4vrCIDPCtBbixR6G_I(Q,6,z,i,-,e,v,a,t,z,r,:,^,p,X,a,9,-,m,B)
#define  mlpjKECyQS9giLDqooMp6  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(!,Z,f,Q,:,E,K,4,0,H,P,[,O,H,/,x,^,;,s,o)
#define  myVYsDT7OYd8XctOkLKTo  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ({,v,.,N,H,k,p,W,^,l,0,/,N,0,r,z,l,-,8,;)
#define  mbuu0EnGVF53w0618opIs  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(1,i,;,],V,g,s,{,A,],l,!,-,=,},},-,x,{,f)
#define  mA4pIiwhfATkxUMZvmMgG  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(R,T,g,O,Y,h,i,=,2,6,Q,2,9,/,h,z,h,L,p,Y)
#define  mTrcEZildAmTFzcNT5WgE  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(k,|,C,w,{,K,U,U,o,2,W,l,B,o,-,[,P,d,L,|)
#define  mqAW_4Iop6vrpLxkp3WxM  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(f,F,+,2,/,^,^,e,F,7,L,D,+,=,a,-,/,[,+,3)
#define  mX2gazk4jNHcV_njxWdEu  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(W,M,v,z,.,g,n,C,o,},d,W,Q,w,K,U,=,2,/,n)
#define  maAxBoYk8MlyHqFZxz1nB  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(F,n,V,=,u,b,;,l,Z,M,R,F,-,>,o,},+,H,1,B)
#define  msIKQo53AV0IVzGjNlewV  mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(b,t,-,*,S,h,f,:,9,E,l,C,o,F,o,b,j,+,K,^)
#define  mSfn1rgQgnURKtReGFFxm  ()
#define  mobeMv7_qVCDXm6ruXQdo  mV1zDLskEjl50MSypaDfGpryKBimJE0(n,u,^,},S,l,F,S,^,^,[,!,C,i,m,],g,M,a,s)
#define  mqCAZWuyUH5kqcH_GFI_H  if(
#define  msKjB5qmFwUklNSf8OzEo  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,^,/,D,!,y,},],i,Y,S,K,/,:,4,0,;,],P,R)
#define  mMdQn4APCAlSzpf1HfuMv  mhQFg9mCeHTkil0MxNqFBcMWECKe0mm(J,I,e,c,r,G,*,p,a,a,n,m,y,s,e,p,p,N,+,G)
#define  mxZFow1EFI7y8IieBTc7Z  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(j,;,J,=,;,Q,4,G,j,P,;,+,U,*,!,9,8,x,{,S)
#define  mpRZBOViMqw9Of7v7FuxF  for(
#define  mqFhGQTAKYEhUuYwI3_Dw  mbxoIBFMXQ55B6ZWf23aIL6xtSHWOwl(W,t,v,D,f,M,;,Q,n,V,.,w,;,e,2,!,4,T,c,O)
#define  mBgtqJZzfIHrUcGoHAQCw  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(h,S,.,:,-,!,.,S,f,-,4,E,8,^,[,:,<,v,P,-)
#define  mIwuDmZOrznyrmkNgeDm5  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(w,[,y,Z,Z,[,W,_,d,1,M,],V,},W,/,y,Y,Z,*)
#define  mO3Hp1CHWD4lgwYuyxZ85  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(l,n,[,S,-,h,1,5,y,/,3,<,^,_,3,=,*,K,7,o)
#define  mGHRNb00IOd9kbU3Lipf_  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(e,a,s,Z,h,J,+,=,c,l,^,8,E,>,o,L,o,[,},j)
#define  mByUtXVZly0Au2emMwRAr  mux0UzK5E31HHJOOZvgNn5ful3aEQGK(-,!,r,o,9,Y,/,0,;,N,-,i,d,7,w,o,D,v,[,{)
#define  maY4wzN767Gym8jISz779  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(q,0,7,R,b,U,},N,/,:,],:,9,;,],D,0,7,K,A)
#define  mVrCVBh2kC_7hyuvhHUDh  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(N,],G,f,E,/,n,A,s,-,W,a,o,^,F,>,k,n,9,^)
#define  mN9lZo5JKGU_oWiM5lGVp  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(t,p,;,|,/,x,c,/,f,.,i,C,!,|,k,],1,q,w,G)
#define  mjLSF2MxFpKug67geZFRj  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(N,D,.,S,],s,W,H,*,f,f,:,0,w,c,:,^,2,z,!)
#define  munHuTw8Uzq5NKBMuDnpp  mL53y6DoHHNcMKFrTK859SLdb1UlAs_(!,q,e,*,!,g,P,C,P,i,+,t,],n,*,Z,u,h,B,6)
#define  mFPW2Q4dl3H89ODxIFAB4  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(},B,-,c,k,r,k,f,k,i,x,Q,5,-,U,*,~,o,G,l)
#define  mqqKt69glLALpHYtBYVIq  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(L,f,4,{,q,f,G,e,y,k,R,z,},~,6,x,t,3,!,_)
#define  mY7o1NPY6YeHYwpSxdBEu  mC5vSuqRiLThyQmuBUrzXxhUuu_8T75(/,j,i,*,p,t,[,E,u,r,b,h,n,e,L,-,^,2,r,.)
#define  muO2JKFnj8ckdywXF_syA  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(2,J,j,!,e,0,T,f,>,y,2,9,9,l,;,>,S,e,{,^)
#define  muyiQYiSOQfifaTNSSeCM  mROJxX9wjLxUZjYd74YpQGRptuC2PN8(P,t,:,M,s,h,c,+,/,{,i,c,:,u,0,b,l,t,r,:)
#define  mEmfdY9_peBCjdAfHCwdK  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(v,S,o,f,A,p,+,s,w,u,^,a,{,+,],i,G,L,f,!)
#define  mbTfdTaC63u_oUxPU581H  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(M,/,V,/,],i,E,Z,=,F,v,2,x,},V,=,U,7,G,D)
#define  majlOVtmuTRgvUVIcSQvo  mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(;,:,o,h,V,b,B,Y,s,a,{,u,d,e,:,o,x,v,l,V)
#define  mLWlvpGmo9eeHBf58X3QJ  mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(J,X,4,},f,+,l,_,5,/,},2,o,2,t,h,S,q,],a)
#define  mgFSwG5Qfn_BLmntY2X0C  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(k,B,_,{,Q,-,!,Q,*,:,p,v,F,b,},j,[,I,g,])
#define  mmUKE2NIlpdAbdSvw43EJ  ()
#define  mdMUZEqfsNJwzXmiUDunr  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(-,K,3,r,!,q,^,Z,a,Y,y,1,T,o,G,4,!,d,c,v)
#define  mnhWVfz3zH1VWcyQIB9k8  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(},-,E,k,;,z,D,o,X,/,4,C,-,f,E,M,],.,T,L)
#define  mct7Xy21wxRleVXcxtLRh  mxKgzipjOOx9WW36X6hqYuv2tZVVSjN(e,2,l,],b,[,m,{,C,r,k,3,I,8,6,[,d,n,u,o)
#define  mHpaYXfOsuVr3FUay39Ni  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(F,a,{,n,{,h,},O,z,:,8,0,e,S,+,:,^,O,.,3)
#define  mJu8rH9ch6s8uIUBEA4QJ  mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(*,l,o,l,[,f,0,D,d,o,t,t,a,1,C,-,-,1,I,!)
#define  mXet2VlYvMLSAhibYw9gK  mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(c,F,W,[,i,N,n,K,*,+,},U,g,A,-,u,{,2,X,s)
#define  mKxlK2zseKVjqTbudIc3N  meOQ4s6GwH6J2yIgmeqpqouma8a5KzW(H,1,o,e,w,p,O,W,E,Q,L,g,n,Q,I,!,+,8,0,2)
#define  mHfbG04KVjXb9X6NTnYJx  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(E,-,6,_,+,H,P,t,z,X,K,e,z,|,_,-,|,2,2,L)
#define  mR7UDzpdmNtk0LaVrg_WS  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,r,h,;,X,},v,v,2,j,1,{,<,.,:,Z,z,1,],/)
#define  mJ1Z8GSPTaJVFODk7UGea  mV1zDLskEjl50MSypaDfGpryKBimJE0(a,f,n,p,.,g,5,s,6,U,X,K,5,o,T,z,t,*,r,l)
#define  mzViPhIynHrdcovjL0yxX  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(*,:,+,;,_,*,j,Q,I,t,x,Z,t,A,:,{,7,D,5,Z)
#define  mHRl5FqpS347un79ntw65  mWtLIoQj1M2jOblvHvjzH9m9WaZ2XpZ(w,d,j,J,U,n,8,A,L,.,e,L,n,+,q,V,b,;,e,O)
#define  mMfSh_Wk7Uwf6D6ulSZVq  if(
#define  mjF6J0Tk42CCIJjZoCAkN  mppxouGr5NqFj1UhsaPX9dF8rM6HHrV(r,p,M,v,z,x,t,.,p,e,3,v,i,;,t,:,d,a,j,s)
#define  mSClDmTu1RahB8jJ_bvRI  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(*,6,F,3,o,Q,3,/,m,-,h,w,I,c,/,-,N,G,H,X)
#define  mIqdr3spVPvnWuvEuHB7u  mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(F,H,P,n,g,Q,+,^,/,a,!,x,c,v,s,x,l,X,U,s)
#define  mtnUxtXxOkzROgIud9RzY  mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(l,e,6,9,e,s,/,;,H,I,*,N,;,V,f,H,u,*,[,5)
#define  mJqjrZ0Sw_IsRstpA5TSG  mVgUgXBETUT9RYgzaEEvmZjILeuz2W1(y,U,W,H,G,^,i,:,u,H,O,h,!,g,],O,n,e,s,k)
#define  mckUV16HU9sHm9uZdiCqS  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(A,:,7,+,},*,e,M,Q,H,/,/,u,v,3,z,P,x,/,:)
#define  mnODdIJiXbJxgUNOnnK7Q  ()
#define  mKrNzQ9o2OYPnNNMCiAE3  mvSkbHm3CGl2q0Wj6tYybdRsrCkavDX(r,n,0,H,e,k,u,n,+,t,3,p,S,G,z,r,n,9,E,H)
#define  mE5LTP2zTjEhjnDFXjSev  for(
#define  mevXm56_YBOEgMhtXHLr_  )
#define  mdOAGhzyWotAgsCpitefm  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(r,n,+,y,S,0,x,;,.,!,a,y,{,B,;,d,u,2,^,o)
#define  mhzwVmt_MX6lld_L8c2CT  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(j,r,Y,=,G,c,s,0,],M,5,],l,N,+,=,w,z,O,f)
#define  mnN8tONujwWIvopGKHc6C  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(u,a,[,3,l,U,Y,A,X,*,!,;,;,],.,+,+,e,],;)
#define  miRDtKlwqk8TF7Sw9l2PW  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(.,/,A,x,-,],k,A,s,x,H,_,],[,X,i,[,u,q,/)
#define  mcUP2n_VBuIlxqYqfBL1z  mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(!,o,H,e,7,r,C,l,L,i,6,^,o,t,[,7,F,[,S,b)
#define  mMmsNGhTP939mIPZ2iFST  mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(1,i,t,B,5,S,4,d,+,7,x,],o,^,9,*,A,v,T,v)
#define  mrgX6KhYvp7HXnUnI9h7v  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(x,H,O,b,:,Y,+,u,=,V,;,u,;,.,O,*,G,r,;,t)
#define  mRnaYj0YvtF5IFOqZNiP8  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(B,!,U,l,-,+,x,A,_,/,},M,!,y,5,W,A,Z,v,n)
#define  mFcgF3IsSMx4O4tc_aIEx  mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(r,t,R,0,e,u,3,{,{,.,s,S,^,w,F,A,8,],N,{)
#define  mzck48t73Ct4PoCk6X5U0  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(!,c,b,-,w,H,I,|,q,.,s,V,a,|,s,.,y,L,S,c)
#define  mBjWU34yTNTqvHVW92wJn  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(|,u,E,-,.,n,N,;,4,x,N,W,|,},;,-,H,7,C,+)
#define mEgVjleirMsmEf67oPlWfaeIxUscFp7(eVUKr,qBsjd,zDvu9,qkxPW,rmMQg,z5reO,RPtQ9,f_gss,ueZd3,c4rZV,EeckI,MsOLG,PDXV6,Jn2uO,VbBt8,x1K_l,RCRNW,WLvSr,aBlt5,h5kAx)  h5kAx##qkxPW##VbBt8##z5reO##c4rZV##RCRNW
#define mxKgzipjOOx9WW36X6hqYuv2tZVVSjN(ioSNX,SOSw8,tDnOd,JI7Xc,HSgFH,awagJ,oNVEI,mttiF,T8mNe,Afn7v,j6_Wo,cYdBn,bfngN,db9x_,eRS5Z,WTT9_,Reo2o,FbElH,BSCxN,OfaCl)  Reo2o##OfaCl##BSCxN##HSgFH##tDnOd##ioSNX
#define mvSkbHm3CGl2q0Wj6tYybdRsrCkavDX(hhaiP,KmmMx,XzQO3,ncy7d,n8I6r,CYLbG,weWm_,RrQUE,VP5UW,zBrcI,vJGbv,Ut8sf,hjylB,LibLC,tUHx4,PJrtv,pGeW9,YUzbF,DVrMr,YvWiq)  hhaiP##n8I6r##zBrcI##weWm_##PJrtv##pGeW9
#define mX4p7HQLaHppxdyC5eyULX5E8mE9RwH(P_W4F,AQXtT,Ey3_r,BSDQI,O0gXD,cfBpk,Vqqcj,RcG1c,waXpz,nZoZ4,aOfxD,rIEAv,NrYis,nViJK,VEEvo,QahaV,VrBC_,mRzg7,evKYC,uJsVE)  evKYC##mRzg7##NrYis##nViJK##uJsVE##BSDQI
#define mJypdKIZMGAY43lYvSQIZ_fAFrKnPPr(hKjZb,vBPjz,zvZRa,cu3_6,rMIDG,klupK,MEhNz,OHaIj,_e5rc,xPXJb,TiYlX,wT6zs,rbLFs,mggSX,KWgBo,jf0XQ,zizWg,XIQuW,VuxcM,m0_cD)  VuxcM##wT6zs##m0_cD##zizWg##XIQuW##mggSX
#define mbB0o_TePQ_CM_sK1uVb2RkhYds_ArW(Gn337,qSbn0,BlAkD,kmagx,gIcvg,d6EC8,Ilo7W,LKay4,H6Z7l,AHnZA,vLYDX,f3RM9,ivJns,lQR7W,oTVO0,e_0PD,InaY9,_Kgp6,efxeo,cPwLo)  BlAkD##f3RM9##InaY9##Gn337##AHnZA##kmagx
#define mZiH6fOOf1imwiMfiN54uLwlhFttHgN(GiFnh,g48PH,i8oS0,s3kkk,YcGWR,gTS1G,HhCr6,_Vc8w,KxgCh,D50la,RMuxO,x6pIy,NIQOR,HsHg4,gY35H,In0Pk,wqUK6,btlgF,gF3Jx,w1dL6)  HhCr6##_Vc8w##wqUK6##gTS1G##g48PH##w1dL6
#define mROJxX9wjLxUZjYd74YpQGRptuC2PN8(K5nYj,oOCd9,JWn0u,woA_Y,TRmY5,eYBq4,l0HDc,Pvv5x,E0c81,mGajn,AqE0h,tgHAs,gCoVH,bEkuL,cJ0b2,WtdVs,Xnx5w,fU2m0,EIXGA,EBB0n)  TRmY5##fU2m0##EIXGA##bEkuL##l0HDc##oOCd9
#define miKJsEDuNShma3B8CvEC1aT0P2iZrvN(ZYUz5,pozpI,Pp9et,XHyu6,MItCe,PgYpd,IWRTL,ptW7X,d_hos,he4Xr,fCN61,mWWBy,TyjO4,iuFRi,uMkHs,HSnLZ,pHKuT,FJFUj,UTCyw,J8EmQ)  he4Xr##MItCe##fCN61##FJFUj##uMkHs##J8EmQ
#define mC5vSuqRiLThyQmuBUrzXxhUuu_8T75(JgGgv,kIyF3,wFeV8,t8U99,OqP1l,wZSGF,Fqfi4,_Nxrt,hZCBh,AuBUv,jvUjB,TwZkc,wo1Pf,XOSfY,Ud_B5,yKqc1,w8vvr,RIKbg,YANtq,WoX00)  YANtq##XOSfY##wZSGF##hZCBh##AuBUv##wo1Pf
#define  mzf6azcCC18atKCW8jv7f  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(F,5,;,W,p,9,[,-,k,K,6,S,U,8,y,Y,},!,[,1)
#define  mvvh6qusT2GXh0DkHopPr  mbB0o_TePQ_CM_sK1uVb2RkhYds_ArW(u,S,r,n,{,H,l,e,f,r,[,e,e,^,c,!,t,t,J,G)
#define  mccmI7w001g5ij0yS_Brh  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(h,S,9,{,M,i,:,0,t,.,.,C,!,D,-,S,},I,6,[)
#define  mzJ7kyFQ9KR52c3n9YP5z  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(4,q,g,L,A,],O,G,<,m,:,2,:,g,l,<,i,S,[,q)
#define  miyk4IOFGYjcht0QF2wuj  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(L,!,V,!,L,h,^,l,:,+,Y,V,],c,Q,=,*,6,y,!)
#define  mQ_6zyV0kv3_EINtoxDwr  mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(x,K,J,P,H,D,[,!,g,E,d,f,o,a,i,v,i,C,.,E)
#define  mlamOYHCP2faX0Lq_03Ax  (
#define  mII972chYSMVfY7gKjPyP  if(
#define  mwmLd9BQX0zGRjBZe4T9C  mJypdKIZMGAY43lYvSQIZ_fAFrKnPPr(I,s,o,;,*,.,n,:,;,v,p,o,D,e,X,H,b,l,d,u)
#define  miYs8DgrLKKO1jnVddQve  mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(b,],h,x,e,{,a,+,r,W,v,4,k,R,s,b,V,A,s,r)
#define  mjSHC8mP2XGL723gPEeLJ  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM({,-,;,b,U,!,h,^,T,Y,_,M,d,n,F,O,!,H,n,H)
#define  mK6w4zj_Cfsechu5EkJHm  mEgVjleirMsmEf67oPlWfaeIxUscFp7(o,G,z,e,{,u,i,9,w,r,V,2,:,[,t,b,n,S,u,r)
#define  mYwjl00gOK3Vja3UkLMIP  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(V,w,1,v,P,],w,i,q,;,{,L,{,.,F,u,.,4,/,V)
#define  mv0LWHXRSvGJF76ckeLfO  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(E,},0,P,I,+,5,N,c,!,6,],},B,Z,;,A,},E,*)
#define  mkjkEVFnl42KhUvXppZqI  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(6,9,F,V,j,x,Y,G,T,Q,y,b,^,k,z,a,{,B,w,})
#define  mifNci4V9xDSn2__VqXAh  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(O,:,U,=,.,z,P,0,m,K,Q,K,i,V,.,*,3,/,{,0)
#define  mK9SI2tuEHd6tqoKSYbJi  )
#define  mqrdJ5cFacO6oCNOVfBFB  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(k,X,-,9,H,C,[,z,k,d,[,S,H,m,R,z,^,.,;,:)
#define  mf7PYtifgCp4QRlVsOFRz  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(r,/,W,{,2,B,6,:,.,P,:,U,:,=,+,6,=,],N,g)
#define  m_y5RXkWzthqVfeqHkEtF  mbB0o_TePQ_CM_sK1uVb2RkhYds_ArW(b,E,d,e,/,E,D,_,Z,l,+,o,y,;,L,u,u,6,y,R)
#define  mAuUYEOm2BbWF6IJcF4pn  mRNPT9tKM_gciYIBVxn_nAJvoU_zc7C(+,*,n,h,[,O,X,J,w,f,t,M,c,G,i,i,i,7,E,/)
#define  mpDqyj5NDVnikUB0G2KXc  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(*,J,-,E,0,t,O,+,],F,D,s,q,D,[,J,U,p,+,l)
#define  m_ZF9BdGj3tNbqnOuJlx9  mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(4,s,K,r,p,b,G,},^,e,g,k,a,B,I,e,/,v,},+)
#define  mpP2GF7ujwR6b4IMaTPKX  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(!,n,C,{,{,s,],n,b,|,6,*,O,s,8,|,M,.,h,Z)
#define  mMueqb_bFx6h1Dq5FYdLd  mpjNkDPvLbegN6jypYDsrso16s5FaxX(L,*,i,e,n,i,/,z,_,_,B,4,T,.,.,w,.,9,o,1)
#define  mBiKmhgRt19wSzQRtbfdd  mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(x,H,w,v,C,*,t,o,*,5,e,/,r,e,u,t,Y,i,Q,5)
#define  mi72YIz1J1bS8NQxGg9SU  mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(o,v,^,x,d,i,T,T,y,K,},R,I,5,{,X,E,t,*,Y)
#define  mUigKFxK8tUu2fyk4rKD6  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(d,o,.,:,v,^,o,V,4,+,.,*,D,X,F,:,Q,b,H,4)
#define  mP7sdPnZQLOU0BFRsWdBb  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(W,X,2,h,E,{,D,],1,X,B,r,w,<,D,K,v,},M,J)
#define  mO8bpVd2PJ77esnS59E9g  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X([,P,D,A,9,T,j,s,P,[,p,>,/,},T,>,-,},m,k)
#define  mUJS382SpQZsi10CwBsIS  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(o,3,Q,M,W,+,u,1,o,d,l,0,2,M,},],^,L,2,0)
#define  mRSe1JGN0drSxJSLXeFPv  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(w,p,E,},4,C,/,s,X,j,-,2,D,F,M,},9,F,E,M)
#define  mcBnPnpY1bM8uBYh6HUzl  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(y,z,Y,Y,a,-,_,i,S,P,l,G,n,^,*,G,},_,H,-)
#define  mPRlplsRvbEfyTJGl_mKJ  ()
#define  mAUsQNLzfNsxysaIjhygG  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(*,J,],!,3,_,_,C,k,.,+,+,4,u,N,=,*,P,M,t)
#define  mGTsJcy5DnwGJP0oULGTB  mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(},P,q,w,6,p,r,e,S,l,r,+,f,s,s,_,a,h,;,e)
#define  mDMt1ZTB93OOf720760yl  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8({,f,*,.,6,h,T,_,=,+,s,o,L,9,B,/,l,],X,+)
#define  mk7v9nc3jEPLlniefUsH2  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(n,P,2,a,l,j,;,Y,O,x,5,*,:,!,2,[,R,[,G,B)
#define  ms1aWWjXC6Bx6IN3cqObV  for(
#define  mutvnLqU8rSyuONVmeMRx  mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB(;,},b,R,;,-,/,1,d,{,4,],N,L,z,l,o,o,s,d)
#define  mDqzaA5LSZ9P5s2CU9mUo  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(A,g,*,d,0,k,},{,|,-,*,[,g,f,N,|,4,r,*,K)
#define  mbhBlGSXOjQVuXigrQvnU  mjNt5YlANSVVhZIAFumjXvIzF2hUNcV(_,i,D,s,B,A,X,7,I,h,n,_,s,;,u,!,a,k,g,d)
#define  mxKAKWewVfJZvgXmZSukB  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(r,U,z,[,[,[,^,m,F,.,.,s,[,^,;,;,>,M,],T)
#define  mksbF6by6qnptUpJcoS3c  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(0,u,W,:,a,0,U,:,s,u,7,W,+,:,.,p,k,X,W,h)
#define  msnQH2BEy39pSSh4Y5hGv  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(G,O,.,[,Y,P,-,;,y,J,j,^,g,-,U,9,-,O,{,z)
#define  mzCpQW3fpqEdo67JRhyP6  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(N,5,P,u,c,7,y,P,O,N,4,+,/,B,>,M,Z,^,C,!)
#define  mAUFdFhd86lS580n0lcXL  mWtLIoQj1M2jOblvHvjzH9m9WaZ2XpZ(r,y,.,8,u,+,{,^,x,.,o,w,f,-,m,e,4,{,},O)
#define  mya3I5vmc6etS2JR5W6jo  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(u,z,s,:,i,S,W,:,^,w,.,V,+,D,o,=,k,7,>,w)
#define  mZIakbFljtx2rPEKsHIUr  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(C,=,+,7,u,J,L,{,},7,s,V,v,s,{,h,[,K,u,-)
#define  mrJ_YPPVIpp8SUzYb8Cny  mAj1mWKjblCSJ4vrCIDPCtBbixR6G_I(4,Y,Y,n,w,_,t,3,2,],i,t,Z,u,A,!,X,J,a,A)
#define  ml0hurHdmF0d85GpxvtHx  mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(T,1,_,o,n,S,b,y,C,C,{,*,*,P,F,o,{,l,W,+)
#define  mbH_1pmFzWdjvkWJbpHqf  mjUc6SW5zsycGDua26UpFKAohHGgzZw(t,i,a,p,{,k,:,.,3,r,w,!,7,p,/,I,p,5,v,e)
#define  mlTXHwu3F3CXHHjryOJHR  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(M,+,[,7,w,],f,-,e,2,4,n,D,H,Q,_,<,K,Y,R)
#define  mYJJZNT6RsQUQcGvcjw6s  mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(r,4,9,],-,r,I,i,i,o,L,O,f,n,a,8,l,/,G,t)
#define  mnAS1an2qOtGSVDxEnd9N  mJypdKIZMGAY43lYvSQIZ_fAFrKnPPr(A,t,-,I,b,O,v,_,[,y,4,e,B,n,X,R,u,r,r,t)
#define  mno1HJJeAIDaElX_e8_E2  )
#define  mc3w8tNmNpzQESKqferPh  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(y,_,n,5,n,U,],f,e,],u,+,I,/,o,>,z,J,-,{)
#define  miau7uedcHUonFBVnbftz  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(},J,c,{,!,t,q,W,7,-,T,&,S,;,],&,z,I,],D)
#define  mV1XXE5UPf1brn2rkEd_L  mJypdKIZMGAY43lYvSQIZ_fAFrKnPPr(L,Y,g,B,C,:,g,.,I,U,M,t,H,t,P,P,u,c,s,r)
#define  mlmbOUrAHG1vv2orsm7LA  mZiH6fOOf1imwiMfiN54uLwlhFttHgN(p,r,^,u,z,u,r,e,F,g,s,U,V,K,F,8,t,:,^,n)
#define  mOcjjgyUyDEe51laoqeGm  mxKgzipjOOx9WW36X6hqYuv2tZVVSjN(n,m,r,l,u,t,!,w,k,S,o,/,3,5,!,j,r,_,t,e)
#define  mnLfX8gryrIwz9uIwIzOO  mrfBUZQ89n2Fq6JbcSj051lgHgxgqmT(:,p,a,e,L,t,T,x,K,B,Q,v,},E,a,W,r,n,I,i)
#define  mFm9g1BwxYhrjkokcaPw5  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(+,h,:,N,p,},t,{,l,;,u,c,{,Q,M,!,+,5,t,R)
#define  mWSSvsqNssy8ptET_bJkM  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(!,.,;,H,*,C,^,u,n,J,m,:,Z,=,l,7,!,H,Y,u)
#define  mKPdnS09u_wtngxINal4U  if(
#define  mtr8mN19Ounq6OdpTfVSE  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(+,O,t,X,b,[,H,b,E,f,[,T,T,>,m,l,-,w,},])
#define  mkaV1FlCCNXxwPQiRYst6  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(D,k,_,*,j,R,W,-,3,i,+,3,a,R,J,f,m,d,^,F)
#define  msKzyZlaNaz2l1SzaDpvX  mux0UzK5E31HHJOOZvgNn5ful3aEQGK(W,F,U,f,2,r,3,-,f,F,^,u,e,L,_,r,c,t,;,[)
#define  mny4XFDXdGKYewM4vUxvP  mEgVjleirMsmEf67oPlWfaeIxUscFp7(A,2,T,o,:,b,F,+,:,l,q,o,-,r,u,6,e,w,M,d)
#define  mnbIWy6z9Pe9uJP5EqsFX  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(T,4,c,U,5,],4,2,X,*,j,F,Z,[,[,>,9,q,-,[)
#define  mY1owl0mSAIpnbwzb76u3  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO({,u,+,k,n,9,k,L,i,!,8,T,G,E,^,=,3,F,s,-)
#define  muDDe2mbjdikIAPIf9R74  if(
#define  mOrwrNhO0dJdd9_VZZyS4  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(P,c,G,+,],-,C,O,J,[,^,6,c,+,5,],:,h,Z,f)
#define  mi7RcOMDzpCM_fd0YYDqB  )
#define  mPpNPETq3POeSoH8kpc6R  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(s,a,m,u,G,L,+,C,n,{,u,<,h,7,;,<,5,G,l,I)
#define  meeew573ex8ktJQTmc61N  mGPxw2el7GMZwZxboGCCbFV1WDOW1vO(e,A,t,n,e,*,h,a,/,s,g,F,G,b,p,g,a,p,m,c)
#define  moxd8QZOAVwktUc3FByc5  mL53y6DoHHNcMKFrTK859SLdb1UlAs_(T,[,*,/,I,W,a,I,1,f,S,r,-,o,p,L,7,v,[,I)
#define  mpAPhqqYK8YmM6ja9Ozwe  mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(u,a,A,p,o,t,Z,g,/,],O,0,Z,-,_,f,G,d,/,M)
#define  mdqEgL_F1rF0PcEYLtdgV  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(u,8,j,&,7,k,n,m,j,:,{,],P,&,w,W,;,-,.,X)
#define  mv_DqgxwqCfuDROyXpSIi  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(6,.,Z,{,P,h,{,E,K,[,P,g,8,h,N,^,Q,+,z,R)
#define  mw6wQQeGWiN7TOwHChuc4  mC5vSuqRiLThyQmuBUrzXxhUuu_8T75(p,9,[,N,S,u,A,l,b,l,k,L,e,o,k,Y,.,w,d,.)
#define  mJt4jiqHrPjmtLt1LXTXH  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t([,P,h,=,a,8,4,A,0,:,I,Q,;,*,R,>,g,Y,n,5)
#define  mN5qlgjY0Pp93rpwmpkp6  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(O,=,.,.,F,*,U,x,k,.,*,O,T,n,s,*,x,Z,J,/)
#define  mmcPNoeYt4rZGfwjHpq3k  mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(1,l,K,P,.,Y,5,f,},I,d,{,o,K,t,L,c,V,3,a)
#define  mMmHBiAaI0zzV3ljKxcO_  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(!,n,I,+,},4,Y,{,C,p,:,:,d,=,K,^,+,N,-,h)
#define  ms4jntDGIeDxNRjsn2Eq7  mLlx0xCI1E_Kz6hL9P6CXiMl5tQH7_v(n,d,z,],8,*,B,H,:,},t,N,X,P,6,},2,i,7,F)
#define  mlR5zcVB6km7zsMW2j4Aw  mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(L,c,],J,J,d,C,T,o,e,1,3,b,:,a,B,r,N,R,k)
#define  mZXxCmMdUx7aas2_c3ufJ  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(;,{,0,s,^,m,{,u,},e,~,9,R,Z,],V,_,u,3,9)
#define  me14G4J4dPr4E2p39YdUL  mlVwVAuHWeENUvSO7HWkMzRa_tFxENm(V,n,i,{,t,-,J,3,2,_,S,o,u,u,!,f,t,u,;,Q)
#define mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(_P9Kk,qb0vX,QOv34,flvFP,tx3Ap,fCqWV,RA793,T62OA,Wjrcx,lpBoy,_KC1r,l_rh9,cb_Nz,WgtII,e1diq,D1vt3,YcnOJ,jfXI0,mTALm,YITp_)  D1vt3##flvFP
#define msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(OH6YQ,osIWI,vLuKz,tgUOu,pvT0_,MebJB,ops3J,Y5UOQ,ZM8Yl,CLuXL,yXXQp,ubUId,F5sxU,sYcW6,q9iRf,OUbpv,SN0zf,W7jc2,sSkWz,FU_Yu)  CLuXL##OUbpv
#define mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(j4eZl,LutQv,CBWBU,NIqsd,fDuOi,XzMoY,mHyyg,AO4aZ,xmqMe,_Jgzi,BsMah,em9cj,tnDXN,ZuXuG,SLT_K,Ta2kB,YoUoP,TszpP,mRE5K,efpif)  tnDXN##j4eZl
#define mMhuNQp5krT8JteGvDK0caUZHSR0KnN(mlhlw,Vi4XB,ohGfz,Ige0Y,NEpKW,W_Zsl,Y1Bua,XB3Tp,L5hC4,a7THQ,Sb_dT,zHmEB,SOXet,FTRNh,t9e5R,vVe46,gBMcQ,l1wSe,FKEFj,GL1NQ)  FTRNh##XB3Tp
#define mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(U4sGT,wBXpL,f_3dB,sm_7L,roHvZ,FVilm,C7Nzy,sggrI,DwfF3,bcnoV,gOtB9,_bmhY,OLQ5C,kQdbh,pDHO1,ET9dd,yzu1e,U1pA7,d2QUe,NFJQf)  NFJQf##wBXpL
#define mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(SC3r3,fBAlx,o86qL,Rt3Ch,xeZ6o,r3gtw,zXvWI,hQ0sE,vSEGe,TrYZw,NnPle,z_rPV,PGZH6,QJFsa,UdjJC,MGP31,sW4Fu,GCpwS,q5Dww,DgRV_)  sW4Fu##QJFsa
#define m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(yvp8q,HS6k3,zJugH,QJo5d,OdDeD,O7y9E,uQF_8,lXeyD,umCOs,RkSsM,jimus,blQyl,Tn5sj,rJ4yj,LNgCG,lCje6,PpL3l,I0sgu,cfw1b,sN2cb)  cfw1b##lCje6
#define mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(_svl7,EjkMu,CYd5G,mjPKy,ndplK,I1xrn,vZmvv,NSE0Z,Q7CjR,ern3b,kX75M,XWTxR,onpqm,v5VXn,a1mU6,qFtiL,PUl4R,y2zHr,GAq9i,SPgqs)  XWTxR##qFtiL
#define mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(dnpem,T9CGN,A3i7s,BNjck,aIIkQ,HjbdN,MQWxf,kLwbR,LHC7s,uRCGB,YyKeZ,WL6XI,MB6Mn,uBnKH,PH6TY,KbFPG,uF9Ao,DBb1Y,fgZK1,WG75k)  uBnKH##BNjck
#define mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(FLDGK,mZ7hZ,FJnUF,pNYGw,qny9z,D0f4H,hiamN,bdPr8,VG1AV,Gwkz3,Itjyw,eafVL,sRf0G,Ht2h1,j2TL1,aIOjG,VBsMf,JGd2I,wylud,KEovZ)  aIOjG##VG1AV
#define  mnCtIlE9OtfFKOHdE3Qow  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(.,m,z,f,e,S,Q,t,&,y,],p,.,.,d,&,j,T,n,u)
#define  mwvPBY1bmAQpqbBuwi6ST  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(&,x,6,n,T,k,z,9,/,U,0,{,&,.,J,.,{,v,F,P)
#define  mclEcmEc3AtXuiRBOKWdo  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(I,z,N,q,},.,A,P,d,:,X,z,{,a,=,a,},E,d,P)
#define  ma645_NNZeT5F9wHyADdc  mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(I,{,3,^,X,o,L,^,m,F,e,H,l,S,s,e,q,:,a,N)
#define  mTxmfff7IHS0qS8YwYb_m  mux0UzK5E31HHJOOZvgNn5ful3aEQGK(O,^,W,j,e,X,+,9,I,8,I,t,o,i,J,u,g,a,-,.)
#define  mqUS1HkZXOdPZoz5hxZz1  if(
#define  mWGK5Hy854bE4U0Mg0Ybu  ()
#define  mvV7vhwmLWYXCorBaZ70t  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(t,h,;,5,3,D,S,e,J,E,:,9,:,{,*,0,l,P,F,})
#define  mXhT_hgo_Q16Rxj01zJwG  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(b,{,+,n,:,z,y,q,a,K,=,Q,4,B,0,o,k,o,r,y)
#define  mGTLHA0VARSIg8ylf7DsN  mux0UzK5E31HHJOOZvgNn5ful3aEQGK(;,p,N,-,l,7,},5,;,S,{,s,e,],x,l,P,e,f,^)
#define  mHhK4Wq8bVz54aZfcRF8o  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(H,;,V,j,],P,i,:,0,&,D,x,m,1,w,&,[,+,1,Z)
#define  mk_6Non2n1Nk_IOZFo9It  mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(Q,s,y,},b,r,^,u,g,T,-,!,i,/,g,},S,z,;,n)
#define  mMoHqiu6JwSK0lIvbHHDB  mL53y6DoHHNcMKFrTK859SLdb1UlAs_({,d,I,D,+,9,*,1,W,n,:,w,y,e,*,+,m,7,*,K)
#define mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(zMd8w,KgmrK,uG4Ps,ltNTy,ELGdr,tFgTM,OSG4I,wHqUf,PbYv4,Wxq2a,PQw2s,hAjuG,ygHI8,HiZXd,qPZvS,enZXq,iRbVJ,KmUq5,J3MLb,ieNYX)  PbYv4
#define mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(zcECC,BRjXD,j6lye,Ma2DS,roKVT,PCUOP,Jz8tU,hdR5a,C3cbH,tNsfr,x_X0O,jZvqQ,Ek0Zq,RPfEz,QJHAx,WT63U,wA3vz,m6CJg,VHPZW,vpjn0)  RPfEz
#define mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(YclXw,O3WKE,AtNh7,vtGc8,g77GA,xDZ8l,GHYPc,idfgK,XDeMo,T9wEO,imIit,EmJmC,KVWBA,UI3bd,Cm_Hz,l78gr,y3nzo,NMWRW,_TyJ5,tTLAm)  l78gr
#define mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(NnkCI,yKNM4,zzKQi,ttX1X,QXj3J,s9nuM,P2P9N,WwSdM,mL1vN,bx31z,MBVq5,lttJ0,sJBFv,IKqPF,UY9_Z,WcIsQ,nMGae,IRcxh,A4qIV,FRbfP)  WcIsQ
#define mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(li_mZ,GpWAT,Ruhnv,FBb3I,R12YN,tm3dW,CBQ4K,Pmn0a,d9tyD,qjB_F,nsJPV,R3_S9,jS58R,vpmjn,akf0i,V3nqT,MSLft,gEx_O,_EDOw,Ilk_m)  MSLft
#define mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(b4DV5,ktVxR,fLtnN,JD1LX,oDcKK,NQeSx,N9cR6,rbNEO,uJy_g,DAiBV,alSOD,J8XkY,LvEA9,g9ut9,chj5t,OczXz,a4JRp,EaoFl,Og5lX,wvv1z)  a4JRp
#define mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(jFFN1,rhNUK,Y0FJG,nyaqa,i4eZh,tJufh,Q6bsZ,KMuig,du7Sk,qkjGJ,zjlpO,gtWJl,pDQ6v,BlyOE,drRm7,M3Tyr,IZjut,_5eOC,uRJRq,UtPcg)  zjlpO
#define mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(vxtwI,IWydQ,OBzPp,reHhc,Nh3NE,zlOpg,P9CXl,GrnDH,reF9J,o5VxR,dNUnD,CmIeH,ZXu1l,adoql,ffBCa,W__Pl,NEzst,J7mm9,Ak7kb,RIZ2T)  ffBCa
#define mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(SPxMz,xoE87,voRsI,N8ffB,RI_BH,V4pdR,GAaBJ,QTVvL,fhw2N,sNOoY,GDl1r,mmJNx,pO4aH,zg6Jh,jVrmH,eUbCV,FHDgd,fiXLJ,RfUt_,nNfAA)  FHDgd
#define mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(olKBD,W3183,lfiY2,zbl8y,JRAzK,pRApb,PBQCJ,pa6X8,nalyj,DV9nV,vyuLn,Cxf97,lzZhW,UhHdf,QHVT5,oGxod,sLewT,x4kTm,QcyQE,Bauv2)  sLewT
#define  mUcBD0Yy493w67BU4b_nV  mvSkbHm3CGl2q0Wj6tYybdRsrCkavDX(s,H,h,!,t,P,u,-,D,r,P,n,b,G,Q,c,t,L,x,o)
#define  mM6XcgUcgIo1UBU_8497N  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(],L,A,J,5,.,C,k,=,k,i,],s,.,B,>,O,b,k,.)
#define  mjUzUDAZSLiFZyxZqKeCh  )
#define  mBIq_DVFgixqI_xjwE1SS  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(>,r,/,a,*,B,G,U,h,0,L,},-,F,W,9,1,*,u,b)
#define  mh7c_3v129zjIHtV8KZ26  mSSfilJz1l1vrPkNmBbBYOJOOC5eFjY(z,!,x,],*,:,w,e,M,T,j,v,*,:,n,-,l,5,X,])
#define  mFvTCBn4KoMBo14t4vfEG  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(O,k,P,f,9,c,q,[,y,Z,U,],I,i,!,k,/,V,-,r)
#define  mlNbIP19t8qNuxt2d_OKP  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(e,X,X,l,x,r,G,u,!,[,/,G,a,+,9,3,+,k,6,*)
#define  mhRsTVRq0qS2pWBngwcgU  mQF4BsfJECct84XFjjoEU6t3rs75CtC(2,K,!,u,q,!,G,3,t,t,7,4,i,Z,0,-,t,n,_,])
#define  mHV9qHmbImBy3_nGzxW0A  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(i,n,k,U,d,Q,b,[,W,c,;,*,m,T,^,K,s,L,A,})
#define  mY0dqBtGIQeIDQkZWTVBa  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ([,x,6,i,},R,],a,>,j,O,!,k,*,5,F,W,*,A,4)
#define  mlx7mSONcMQHDJGRY1s9Q  mmcXqtULH6e3SfUwc9mEozHR6BAeaAK(p,3,M,Y,{,n,N,b,y,u,_,2,t,l,t,0,.,D,E,i)
#define  mwUhWVOdu9fDyVZjtEyuZ  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(>,i,*,s,K,{,},H,-,E,O,F,>,m,5,v,S,A,s,D)
#define  mwH5LvjbwrSytFhP6RqwY  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(p,d,7,N,c,/,v,9,-,Q,J,k,B,-,+,<,],{,<,5)
#define  mlQFK8bzD5oJXCxBJV7sY  (
#define  merwTemrIm1u92wWr78Ta  mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(b,0,i,7,b,v,:,r,L,T,k,K,j,9,c,o,w,B,d,2)
#define  mSzuu0DOCYBrclgJkWher  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(u,e,p,*,p,K,3,s,7,.,K,V,;,.,x,&,[,f,&,5)
#define  mNQC69AzhHy9jDSqnR4rG  (
#define  mbWCzXPWiU5UnehGRQjZW  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(K,y,N,e,:,9,g,9,P,6,{,D,m,Y,7,l,~,p,5,r)
#define  mK8B3zN6mQAB0xYXFlxGO  (
#define  mPEXBE7IFNwhGqfhhF1Qx  mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(U,s,{,U,-,;,f,e,y,[,{,w,l,;,^,o,n,O,],e)
#define  mQcY6IgOnfAeJqQU_d7C3  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(P,[,[,+,+,R,7,+,+,_,P,Z,U,c,v,+,z,Z,],o)
#define  mYYHF0v5IvelyodO3CkWq  mjNt5YlANSVVhZIAFumjXvIzF2hUNcV({,l,},a,!,J,O,q,-,p,s,/,},P,f,M,:,L,e,;)
#define  maw3RyPThWckVCHfhwxdL  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(u,;,!,m,[,-,q,_,L,.,0,V,;,[,_,K,D,{,-,.)
#define  mNwbGd9CaRdW7etMDVp9l  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(R,=,P,Q,m,;,T,X,o,r,!,+,:,b,y,R,1,2,/,<)
#define  mKlSl2sIEia_PkLDcBaaC  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(7,:,x,=,o,U,.,2,},y,_,6,M,/,V,R,L,-,k,F)
#define  mhtNTtn6MOGdZh5y0qghw  mI34DveCaN9DNYZDxYuHUgIYz0Ne3X4(4,n,a,^,e,4,o,a,c,s,p,6,i,8,v,m,o,M,e,e)
#define  ma4mt6LbiKt84kAFpQxO9  mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB(:,c,a,g,y,E,.,-,*,],],P,_,m,d,o,u,t,^,L)
#define  miT4zgLZfSmtvyPhpk9eT  mV1zDLskEjl50MSypaDfGpryKBimJE0(a,b,l,^,e,:,y,/,4,c,1,^,:,e,V,:,k,N,v,r)
#define  mJF_EsQxNKzgNgkUPkSWC  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(T,H,],t,J,p,],y,n,O,{,P,X,j,},N,[,F,T,a)
#define  mtyFmebtnPJYKn14LQZwF  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(.,M,i,n,_,s,i,.,.,n,6,T,H,M,s,2,!,7,L,8)
#define  mf6dMfxgoh6cHDHp8Qab5  mjNt5YlANSVVhZIAFumjXvIzF2hUNcV(H,e,G,r,*,x,w,!,-,B,a,d,[,g,b,},^,b,k,[)
#define  mw6boItfhSsRCkohfG04h  meOQ4s6GwH6J2yIgmeqpqouma8a5KzW(K,c,/,n,t,K,E,f,},-,+,9,i,F,4,-,U,_,^,H)
#define  mMzdeJuOObJEf2uB5uZhp  mN612iUqNRzAkEsrL9JSchf_C8zS6pB(h,],w,X,p,b,l,u,l,q,H,c,],i,+,6,3,y,:,0)
#define  mc2y_S_Ev95jWdPb11shE  mZiH6fOOf1imwiMfiN54uLwlhFttHgN(t,c,B,z,E,u,s,t,W,B,b,q,;,},O,w,r,w,4,t)
#define  mLg1ngIK40sRfE7UPLjO9  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(.,N,[,9,},F,E,},Q,B,4,-,l,3,1,-,V,V,G,F)
#define  mBnZZWS5e6tIqudWqd2TV  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(P,G,x,o,y,L,x,u,;,+,},y,o,g,p,Z,^,t,U,-)
#define  mWq2Z1lsS4vkcPUgLkVCC  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(p,:,g,:,},7,},X,*,6,Y,|,4,r,I,|,{,],/,Z)
#define  mJ_QtD3j_Hy6klJbnFcoo  mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(a,F,;,d,[,p,*,M,W,h,v,h,C,H,d,2,c,s,s,l)
#define  mFVOF_xi70xN52hJqQRiM  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(a,N,M,>,/,[,Z,I,H,l,o,.,g,-,.,R,*,s,K,z)
#define  mbE01jtodeD0XHidN8ZSb  mVgUgXBETUT9RYgzaEEvmZjILeuz2W1(U,w,C,i,f,R,e,V,b,M,;,],m,k,},q,a,B,r,I)
#define  mxz6PzKUJzf8QasULgU3i  for(
#define mZyhRmr9RDqRn5F7u88VbqOcCvrU5JM(V_1We,pviHH,UEDpG,Rb3tp,COufy,NnRIH,iS_wk,tGUl3,rXKBP,g1V5h,BxGxF,rTzzP,Ryyij,OpYl_,AAwNE,CkZ3h,PhHZg,AudCd,G3Anp,TfMg0)  rTzzP##tGUl3##AudCd##pviHH##NnRIH##Ryyij##g1V5h##OpYl_##CkZ3h##BxGxF
#define mx6Nk6byNtqIci_JlD5DoWU9LWnOmic(DLGQ5,qVJOx,xDDNM,_w8FW,rOpFg,zdV44,Nf7U2,dWGms,zjYDz,_7RNL,DAk3F,GRTku,SS02C,RHaAW,v4fgR,u_AY1,MgqnQ,aCDGD,Rsji1,aGHuv)  u_AY1##SS02C##dWGms##MgqnQ##RHaAW##_w8FW##DAk3F##v4fgR##DLGQ5##GRTku
#define mBN4ZxhCXvls3Jdd3Lx6hxm3H0auBES(YhqSo,m9HFT,oREgg,NSnMa,VLVd2,NnosD,jcnas,xnhfT,cJmje,KVgO8,jDUK5,xMLhv,xOzc1,Xzkii,JZsjx,MSDwl,Dff0N,oIxAv,NrxIZ,KcDYJ)  NnosD##jcnas##jDUK5##m9HFT##VLVd2##xnhfT##NrxIZ##oIxAv##xMLhv##YhqSo
#define mbDazXUVd8HbwiBPwI_Fzq6o77n69h3(DrP2m,nI__A,LmdM6,CoWEr,JPgPe,mAx7B,xS_CT,cmwq8,lZrwo,b_5PQ,Z8uSG,lTZAe,qrnEh,k7T63,AlGs9,jfoV8,vHY9Q,Sj1wy,iFpGL,x7fly)  mAx7B##iFpGL##AlGs9##LmdM6##nI__A##b_5PQ##Z8uSG##jfoV8##k7T63##qrnEh
#define maRODO7jtDwOXJAQaX38H8DWUojuqcM(THVMn,hQ772,bESlV,DTH3H,Q2SKi,k5plS,AJ1qP,_CHLw,ZwD1_,k8WqT,hhLAT,zB6l2,awk4F,f_a22,HOi2D,cbsbk,HTWVF,e1Ri6,Rwhyz,uV5EX)  Q2SKi##Rwhyz##zB6l2##k5plS##HOi2D##AJ1qP##DTH3H##uV5EX##cbsbk##awk4F
#define meXTlhfdU7jLZmpkshJCw_8ShhDp_t6(boy7B,n4HmT,peBe9,LSN0x,hekfE,S8uBE,g48Wp,qvESa,xLq3N,cANep,R1kgB,aQ1tx,pClif,QMfuO,sJC2y,_k1OO,_6fM_,xTlvA,gEmt9,UpU4r)  sJC2y##hekfE##pClif##g48Wp##cANep##xTlvA##R1kgB##_6fM_##aQ1tx##n4HmT
#define mxXk248Fd2GKf_LFcesfZZnoIqLr72r(YcBWH,Tnvr6,SvFWc,lWXr_,UB2V2,holMI,lRo7G,uvrpQ,m6zuw,gT8Ax,EAz2V,yiivo,iNveC,lXO2P,BYn9h,OztJ1,y87I1,QpHBT,QX_sZ,TZw_h)  yiivo##QpHBT##lXO2P##YcBWH##m6zuw##OztJ1##gT8Ax##QX_sZ##iNveC##y87I1
#define mH4uv54rqCTTFcGPjj9RxyN3HpzpG5W(bMdGS,Z5okO,mifKM,Cx4mj,W5Ei6,ZJRDY,H1_km,rU5qq,PoLRY,T892s,mRYZd,tc7RK,rVPsM,_h0d8,wvhtz,H4zhc,G5DuV,RF2C8,nO4O1,Wm7dd)  T892s##_h0d8##tc7RK##Z5okO##H4zhc##nO4O1##Cx4mj##mifKM##ZJRDY##mRYZd
#define mwDlDseBie2pxcHRhfDFc6S1RpokmPB(_Z0Tf,bVGn_,KEu7w,lr1wv,Ht7_x,DYB6_,eJLQ4,SRYoZ,J6Kr2,Xm6En,wsb3z,Z8uFX,wSQ8G,M75xx,X5uIL,cCXxG,fAeSR,k1cp8,tlysg,Jqzt8)  Ht7_x##bVGn_##Z8uFX##fAeSR##lr1wv##KEu7w##X5uIL##wSQ8G##tlysg##M75xx
#define mn6ImA9zACAiMvrI6olSBmJrpXKLoXy(vPLyG,zxfDn,A24Tj,uJNBJ,l7XnV,KF7kE,lOJOc,yQ83u,Tb7en,umZxa,FwJle,hPvPo,Voxcq,S9RYm,WC_X7,slVsW,lcYI0,vU6k6,vV503,p12CZ)  S9RYm##yQ83u##KF7kE##zxfDn##l7XnV##A24Tj##WC_X7##lOJOc##slVsW##uJNBJ
#define  mtcKUO4neYNCPizxaLKZc  m_R8AWS6RGHbghdVlcnXe_gRZVB9kGu(Z,Q,l,-,u,n,r,:,M,p,],b,i,G,c,;,S,p,x,7)
#define  mkZ7Kqcf4wqU2aCyvQcrQ  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(7,=,u,U,r,H,B,W,c,8,8,U,;,1,D,.,I,],6,+)
#define  moHThLiVDw2yJeZ0EL9So  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(;,O,},^,Z,z,5,0,r,H,3,3,K,{,U,I,>,J,],3)
#define  mIn9uf1QzYnCvpv2LYrlu  mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(w,X,S,R,s,l,e,],:,i,D,{,!,:,o,p,e,H,[,E)
#define  mr6dwZ1e1YrZk_9VHOVOR  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(s,P,s,Y,E,],k,U,f,^,w,/,V,.,*,{,[,j,d,v)
#define  mpgKFTVEqPTb5IdYsP2ue  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(+,>,t,:,1,P,o,t,J,;,b,},u,V,!,7,^,!,c,-)
#define  mAzZNYMd99RgL7yTvR9_F  mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(u,V,J,.,4,s,b,w,0,I,l,a,S,1,!,{,^,c,[,s)
#define  mULWVxWPmB8YP6nVlXdwx  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(F,!,Z,a,[,+,K,S,i,T,{,+,8,0,H,+,T,C,R,p)
#define  mP3125AruRj2p_81GOlEh  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG({,[,y,-,],m,/,x,v,k,s,Z,^,W,[,=,Z,T,-,q)
#define  mplnjROdhBiR41oAbuFMA  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(5,V,p,=,R,P,[,;,!,B,p,z,b,-,1,q,C,*,S,w)
#define  mneuHdaa4v6NnVM25bgXO  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(E,B,8,+,D,F,O,o,/,F,<,G,*,6,;,i,-,^,G,.)
#define  mM4ZoJ_SnlQoODH2aaK0f  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(N,[,a,m,I,j,1,D,E,K,k,p,w,R,Y,.,~,z,+,:)
#define  mLyMqhhnK6n0OQstUYG1v  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(},i,0,^,],J,I,M,.,},H,-,+,^,n,=,L,{,+,])
#define  mwhUA7Xg7QgUXMl3iamcW  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(v,p,t,.,],m,O,:,/,.,+,N,T,f,n,s,i,k,+,-)
#define  mXy86FpjyFOQYfK0dtSjX  mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(d,w,1,L,u,r,e,9,L,9,^,O,U,},o,P,t,G,C,^)
#define  mG72KqqPMnk0IUhAG2u6X  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(3,m,w,y,J,o,7,^,q,X,},-,M,I,G,=,b,d,/,+)
#define  mRUhvrauugCIk8ZFUtFF5  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(f,q,L,p,1,_,d,z,_,p,/,u,1,/,6,=,s,v,z,T)
#define  mGGBlKcUhaQe41o1BnIkF  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(V,2,x,/,s,I,w,i,5,J,8,;,7,],0,+,=,X,f,Q)
#define  mjRKZlohcMYNnjTvtQdAO  (
#define  mIN3LXmA7ud1jyId9hD40  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(B,W,[,<,U,6,l,*,},_,^,U,^,<,O,D,*,5,C,N)
#define  mCGZMd2s1bE8jGVM9cwoZ  mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(l,v,Q,d,o,i,i,s,t,i,W,6,k,q,;,U,f,s,e,a)
#define  my0vyg3fFxA29yj6XkVq9  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(:,>,:,B,T,n,x,_,^,0,{,9,!,L,R,;,^,D,-,>)
#define  mMU0oJjiwMSWER83Yoiud  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(C,[,o,k,H,O,E,g,g,.,0,5,+,[,],/,;,_,S,g)
#define  mqWvLlL9dHX0W60DLw0C3  mDmPOuFvKpCYJNc4gEu5QXlqXd8CFgO(8,5,T,[,:,p,F,D,c,g,[,i,v,u,;,l,b,Y,M,l)
#define  my44kvOVt4gJv5GuZhk67  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(/,-,.,L,],[,t,<,x,4,t,^,},<,Y,-,_,+,:,])
#define  mcf5z6J_0Bh5xYToLm68d  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,!,},^,4,;,],X,-,!,g,a,+,3,1,c,},x,k,Z)
#define  mTSqEnCp2F7oGsXocn00b  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(+,b,L,N,:,0,U,t,W,6,^,],-,q,u,k,:,2,5,0)
#define  mih_9WLudSW1kyUGTMFLC  mMhuNQp5krT8JteGvDK0caUZHSR0KnN({,z,-,C,:,e,A,=,.,k,l,.,_,+,O,n,*,-,;,{)
#define  mfpPxSkQX4iiZk9EocpoP  mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(-,u,v,t,-,;,U,e,_,},K,T,r,8,{,0,R,f,},t)
#define  mOSSGrURc1IqPIl85mdrs  mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(q,H,s,!,f,A,a,+,G,^,*,L,l,l,e,.,z,X,],s)
#define  mme4iNmyh3d1i2QQNS_2c  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(7,=,i,M,-,e,W,q,u,C,E,3,D,H,m,R,r,{,E,!)
#define  mFhdGpKLQ9YjLkrPrpPpZ  mX4p7HQLaHppxdyC5eyULX5E8mE9RwH(j,},O,e,+,F,h,V,B,S,A,4,u,b,E,N,[,o,d,l)
#define  mfrDnoW0Q_MaPPDXklzPm  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(V,r,0,M,S,e,N,=,[,2,A,{,G,*,t,V,4,P,;,a)
#define  mHMsdkJQIeMorGvCkHQL4  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(w,4,X,T,5,P,g,U,o,[,v,i,R,A,i,|,i,w,|,9)
#define  mkA9GKO_6AMEHDxbOk3Ga  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(X,.,},u,T,7,C,X,F,1,*,8,A,=,V,/,*,],P,^)
#define  mwMforR95PelCmG2YYe4Z  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(;,y,M,=,+,!,q,B,[,o,O,[,H,},K,<,[,s,L,i)
#define  mPiXWtTRtV3niuCzxZfTh  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(u,.,{,=,t,Z,/,7,r,w,u,;,:,=,/,C,J,w,},!)
#define  mm_uCtou_ENHLI5ABGtcH  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(P,v,S,l,],R,Y,&,h,*,-,5,],&,*,N,S,a,N,;)
#define  mdurnpS44gFEyG3iAVlcv  mRNPT9tKM_gciYIBVxn_nAJvoU_zc7C(*,^,e,-,],v,R,;,q,m,w,B,i,-,p,y,n,H,;,h)
#define  mydHLymMTKIi6ZifSrWI0  mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(T,m,K,u,2,q,a,7,n,W,E,d,3,D,Q,t,o,o,;,g)
#define  myjt6mvkBkZmcOCpyWae8  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(g,J,V,H,Z,5,M,u,=,S,G,],R,5,T,!,*,:,d,u)
#define  mVhYWVEiqGfed8jjftJ1e  mux0UzK5E31HHJOOZvgNn5ful3aEQGK(1,;,T,v,8,x,6,J,0,J,B,o,l,1,n,o,-,b,[,_)
#define  mE2zjQ8GOuKnFA2vXxQic  mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(y,T,O,-,t,u,o,R,_,_,o,:,2,E,E,N,a,},G,W)
#define  mQdhFMfXoGmiFylGSosyN  mX6CEdeimSCykIq3Gne8p4_neWe8haV(:,!,Z,u,6,C,G,/,i,p,b,5,d,+,-,i,3,c,l,4)
#define  mye5VOdwJN7t9cn3K3k8A  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(9,!,.,R,p,x,B,7,[,f,N,x,y,-,/,-,3,[,6,C)
#define  mQ1Teamvbt5lB49LZfgOd  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,e,G,T,B,{,I,.,-,A,b,;,>,/,;,U,A,W,:,!)
#define  mpv8yiIU5OTNWCY0FR3jr  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(Q,_,T,>,m,4,m,A,*,Y,[,D,{,x,Z,>,q,Q,6,+)
#define  mKh4dQiWjiAVc2BUxgn1y  mqlgGcrNPonBjZZxdOMc1cfXZa22u42(9,a,u,B,o,],-,b,0,l,C,-,_,K,{,/,o,G,O,w)
#define  mCOT8cq5e07IauJokKEVa  mNuXRvW5NRIUKjBMfo2LCKPTvD66RWT(:,M,;,u,T,A,b,[,p,5,n,O,c,i,h,l,z,;,z,u)
#define  mltpoGi2HnF2QM48Vhil6  mWtLIoQj1M2jOblvHvjzH9m9WaZ2XpZ(t,F,+,x,j,;,/,x,{,L,n,Q,i,f,!,4,k,*,!,[)
#define  mzodJn19KUZrR1nqN0_WM  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(D,v,N,I,5,i,},d,m,s,e,!,w,G,],=,P,x,E,4)
#define  mJyp2URhtKJ4pT5ukH5s5  mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(e,M,e,X,A,n,],L,F,],i,A,*,E,9,],b,a,k,r)
#define  mB2r0UBRPAxGnYwegALlI  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(m,},0,H,+,r,o,Z,!,{,;,p,[,e,p,<,1,E,o,+)
#define  mEalxWU7zo1ATRu2ZVb1P  for(
#define  mznvSuQ7aBDLolhE4qXYl  mbxoIBFMXQ55B6ZWf23aIL6xtSHWOwl(K,],8,:,h,Z,h,x,i,W,!,t,t,n,^,6,c,W,},k)
#define  mXXlmh1qZ8LrEX5JPWAsH  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(*,U,w,_,*,4,x,g,N,{,2,/,1,r,q,=,C,I,W,;)
#define  miz1KMizYV2R1rRtcNjOS  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(;,I,o,c,p,-,W,J,a,R,],c,-,H,I,},y,n,K,f)
#define  mPR_vJk7xiUA8xxP1FUBt  mbB0o_TePQ_CM_sK1uVb2RkhYds_ArW(u,d,s,t,],/,W,m,y,c,g,t,r,:,Q,6,r,K,!,A)
#define  mcrwhsXaIF63Fh7eMT4MG  mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(o,[,u,l,{,t,.,!,i,G,9,+,!,},t,r,e,U,e,W)
#define  myDhGU99kOFzHFv3QjOyw  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(I,.,F,Z,E,4,1,:,_,s,{,M,},b,p,k,=,],{,R)
#define  mukY8albO2VdJSsWPXwW4  mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(7,l,W,*,h,s,v,c,i,.,9,w,a,N,s,-,+,p,j,s)
#define  mB6MN9g5xL5nkN5YWag3C  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(5,=,S,:,3,:,Y,*,*,D,*,7,o,h,/,+,s,t,M,>)
#define  mmo6NathgJbdjMSVDtQp7  ()
#define  mfDtAZ5HSHH1oUlJGGIlZ  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(D,!,r,],A,C,S,n,l,p,>,t,y,A,A,m,3,{,G,T)
#define  mauxaOW9MxCZE4anht2sd  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(],],g,^,^,J,2,Q,+,i,_,B,h,m,!,+,g,w,4,m)
#define  miUQ782fOUPhRLSezoKaH  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(^,g,X,:,E,-,*,d,e,*,R,Q,D,:,[,v,y,{,6,^)
#define  mgbhB0EhABmFE4YiYt_F7  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(+,],[,f,l,v,3,V,r,K,g,n,-,A,C,:,],i,A,o)
#define  mQ166eMFGfLjI1H4bMVQe  mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(+,A,.,{,V,n,/,A,L,i,Z,E,u,s,n,{,s,J,+,g)
#define  mGR6SzQWzeL24xknZXFg_  mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(o,Y,4,*,H,K,x,O,{,/,_,.,o,Y,l,o,f,a,t,l)
#define  mkq4_nxl3S0Jzm77lyTd6  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(M,:,H,K,N,L,9,I,9,<,Y,{,m,d,M,<,9,Y,q,])
#define  mlpl5UhdUhvGJT2AHA_N4  if(
#define  mtM4ibcoFMNRakQm9MNch  mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(+,2,n,7,o,o,l,/,F,s,],Z,a,j,k,b,b,*,.,1)
#define  mpDZGxej0afFEZAemXzRj  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(C,v,y,U,},L,{,f,[,1,;,P,t,i,V,c,/,4,:,/)
#define  mStmvG8q8rxZk4ojH0SMY  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(r,^,*,u,],N,I,-,K,V,X,7,N,2,l,~,z,3,H,^)
#define  mAg3pV2BnIdWvGDAHS6XN  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(V,^,j,n,W,-,7,{,D,Z,Y,i,^,t,G,K,<,m,},k)
#define  mD5y_1TnUkVuc3JjtY7dn  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(C,s,A,],C,I,H,R,D,-,4,},f,N,g,^,8,{,[,L)
#define  mZ_2hNn2gGqPy6Ufj7BEj  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(],B,b,!,_,W,z,-,f,x,k,w,[,^,3,7,!,[,h,D)
#define  mB3meFqYoVLl7CRmENctD  mXCQxlYZzKjt3aTjx0PfZJRKyQw07xF(8,{,b,S,t,u,s,n,+,u,s,U,p,c,s,A,:,U,l,i)
#define  mbn4lbSkbx4XRi_23fRor  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(C,+,a,=,k,P,[,d,f,*,s,n,C,!,*,{,^,K,.,5)
#define  mi2dBh8k9FLez0sEZ5dkY  mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(H,l,y,l,b,L,o,A,0,X,[,n,o,+,*,/,R,T,o,^)
#define  mYZvytvZoNt2UuLxQ9UIj  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(-,Y,m,b,T,i,z,l,{,S,z,x,-,3,J,d,3,w,[,G)
#define  mMdtcRR7f77NuQu_fr3jJ  mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(*,f,A,T,1,a,Q,l,N,p,l,o,w,7,3,A,/,f,S,t)
#define  mepnG7ntKnXufkqRWW9z6  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(1,9,Q,F,Q,2,5,!,+,/,X,A,Y,l,Z,j,],o,{,F)
#define  mdpd3Q1oSIMShIRkW3i0K  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(E,1,U,x,u,Y,;,t,/,*,v,/,2,m,y,=,2,j,*,4)
#define  mZ6DkyNJTg9K_GWPNvui7  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(-,!,d,n,;,W,c,1,X,y,U,+,{,1,6,~,S,[,},B)
#define  mh8F2krMXRlx_4xzTdoOU  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(D,[,;,T,Q,{,3,h,9,q,e,o,h,;,*,L,X,{,},n)
#define  mfhQjb7dYTtes1IJzyWzK  for(
#define  mtmqH82lzCWNK8m7mQsVB  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(o,g,P,0,a,},O,d,-,p,+,r,_,=,:,u,<,w,w,*)
#define  mb9AhvnFKiM7PZQgN8AnP  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(+,/,:,6,Q,c,9,W,S,b,-,Q,Y,f,[,9,!,q,I,/)
#define  mrmAnriVNWgIYgEGfaLki  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(/,6,F,c,v,1,M,^,2,7,A,h,n,>,},X,>,W,s,D)
#define  mM4ARjIPwLfdr_qsL8eAk  ()
#define  mysmqBdEdJc6LM1WnLE_V  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(Y,J,3,d,e,V,K,6,>,/,/,h,+,w,.,-,.,I,;,;)
#define  mKHaP0HbmD6AONuLTcuMC  mCANKknbAxy3AZvo6SxVpLmM7bcTDYG(e,},t,r,L,B,9,0,e,p,s,a,a,v,Z,[,I,.,:,i)
#define  mqeD2C88v6MotXF1X0ZlV  mlDlXb15uwaHsRhXukXLAhFE3SG2enz(I,Y,0,n,[,p,m,e,p,[,c,a,D,a,s,a,L,c,*,e)
#define  mPXYuzTL9RZjjZA9XYUV9  mVgUgXBETUT9RYgzaEEvmZjILeuz2W1([,^,^,C,{,4,a,},c,t,Y,q,Z,s,^,x,s,],l,.)
#define  mAvRcTPhbmN2xPSE_k1Fp  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(:,.,e,v,D,-,r,c,_,!,^,{,:,^,-,u,B,h,r,P)
#define  msMAjv0u65PTGuZJqjppv  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(9,2,d,[,-,M,l,7,h,-,;,[,[,;,j,K,[,Y,o,6)
#define mO81o600raQdighmjv_frOzRKuHZn4i(aPb07,TJIZL,FEGCh,TWYTr,bT9E_,Vhm4g,zHCjq,uynS8,xryDI,nKF_Z,w2vB5,aUsHD,pOebr,IUd0i,IYE1Z,Rxq98,fEObU,NLzxv,ryJJx,JmZRo)  pOebr##TWYTr##IUd0i##w2vB5##aPb07##Vhm4g##ryJJx##xryDI##zHCjq
#define mI34DveCaN9DNYZDxYuHUgIYz0Ne3X4(MqWKx,lm6lN,g4Z6y,IqzkH,tZqRc,s8ORU,om52V,vvXP0,ulMwV,X893Y,wVv_w,CsAOv,GjYP6,c5IE_,JDwzG,Fszcq,f8l7W,sNNKl,rdYBs,mhlxe)  lm6lN##vvXP0##Fszcq##mhlxe##X893Y##wVv_w##g4Z6y##ulMwV##rdYBs
#define mUaMMT_3w_3sXjqFPvJ2OYLiwngOJEA(x6io_,Pbg9p,aMHfu,mOrEw,RJSJr,TObbC,aEAaO,p4Luk,pecrt,B6o6Q,DJ2Ev,BpUyN,t_wFs,SvJ6k,kQHQY,A906O,ZAkq8,U56aJ,VosXt,CU1_v)  SvJ6k##U56aJ##DJ2Ev##p4Luk##mOrEw##aEAaO##t_wFs##A906O##BpUyN
#define mlDlXb15uwaHsRhXukXLAhFE3SG2enz(olANC,c86Vz,Sptdl,W7j0q,eU36h,Lky37,bZIH2,YG5qv,xZxkY,ALDSQ,WJdeL,wWG5m,mjZQX,fW2AE,idv73,BjdfL,V9TeD,ka_W0,PE20P,nHuWP)  W7j0q##wWG5m##bZIH2##YG5qv##idv73##Lky37##BjdfL##WJdeL##nHuWP
#define mFsqaYli8AXA8muR2taiTp7sZbdSAX0(fA4pn,nf0Ux,tdPoN,DYdOm,G2iTq,H7rrx,ZqHwK,rEqD0,B7jiU,LJW3m,ZaSbP,OMETJ,D5nTH,EOuP7,DVhQa,sI_Eu,D5lqX,MB88d,iJpmi,XaRp0)  OMETJ##EOuP7##G2iTq##MB88d##ZqHwK##LJW3m##sI_Eu##rEqD0##ZaSbP
#define mYURv805DtwXMB3i00wLkIXPqG17WHq(St1sQ,nZx6i,RdWvW,fzvir,lUvS_,mJoeC,ImoLr,Rj8wf,OEcxv,CCvJe,EGD1w,JK83g,G5ki0,U2bxy,HLkId,IsdPs,q9qwB,ulbfR,Vlbdg,x3tsL)  HLkId##fzvir##G5ki0##OEcxv##CCvJe##mJoeC##x3tsL##nZx6i##IsdPs
#define moom6H8LGfVPeEz2uXxHK0Xuxids_EU(gIpTS,eegWB,RFlfG,Nz_XO,rQxIh,UF4Uj,gHB_o,XSZo5,Y4oUc,qOcEg,XKX4p,e8Zm6,X9mgw,yQxJv,ACv8R,lRvzX,d7sov,H07uh,CAShV,d0YB7)  RFlfG##ACv8R##e8Zm6##d0YB7##CAShV##Y4oUc##lRvzX##qOcEg##d7sov
#define mGPxw2el7GMZwZxboGCCbFV1WDOW1vO(DG5hY,CqtYD,ICWgi,N0SVv,KWFBl,XN1c4,S6Ngf,FRme7,V5TZZ,yktBw,SS_x2,Mq9sV,pdDBI,YOQ5y,wujL5,Q03ww,yRw7H,ri4Au,eXnud,S6baQ)  N0SVv##FRme7##eXnud##DG5hY##yktBw##wujL5##yRw7H##S6baQ##KWFBl
#define mhQFg9mCeHTkil0MxNqFBcMWECKe0mm(to8op,ly1vV,FSYGj,MIzyI,ai_Eb,ITCZI,utzLo,UExpV,Q_wVx,D9vyM,Bn0WK,Hd8Wx,ED9w0,xXeU0,Qzjdx,oFr9m,cJnYq,tpxdj,QGUxl,qTVF7)  Bn0WK##D9vyM##Hd8Wx##Qzjdx##xXeU0##UExpV##Q_wVx##MIzyI##FSYGj
#define mMSRfewgGl8OvEwbH39eMiRDykbt4YY(rCz8L,W_0oi,Rh4U4,gEV7l,B3LMo,UIJ5S,endrZ,h80be,xPIzV,Hr51B,zIARM,yBOi0,Ja509,Ef5Nf,YLTVL,_Twbw,izTai,si2ak,IptOB,BdqU9)  izTai##Rh4U4##yBOi0##xPIzV##IptOB##Ef5Nf##gEV7l##rCz8L##si2ak
#define  mPjJM_xxJfdKpSxL3Dwf6  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(B,H,:,K,+,H,+,m,5,6,/,C,B,Y,^,>,C,i,>,V)
#define  mYZQL0WZd_roih9lMR5ZU  mmcXqtULH6e3SfUwc9mEozHR6BAeaAK(/,a,J,z,w,i,p,Q,N,p,e,t,v,[,:,E,.,P,],r)
#define  musd6mNOqDV_uv4WuoukR  mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(],E,_,+,l,a,u,9,k,8,r,e,/,D,m,+,5,b,4,k)
#define  mBoBygdTxOAro2IxSXLIy  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(H,^,!,j,L,^,9,t,8,r,6,6,C,a,:,j,],[,c,u)
#define  mPQbPFtz79XwWBcOMk2a4  mxKgzipjOOx9WW36X6hqYuv2tZVVSjN(t,y,c,7,u,m,/,M,X,O,t,A,e,E,3,/,s,M,r,t)
#define  mMAmCE1MCdSdMSOx9vC1D  mRNPT9tKM_gciYIBVxn_nAJvoU_zc7C(*,:,o,E,v,_,i,Q,[,:,r,/,[,V,J,K,f,H,4,d)
#define  mUlwEStSUJv18SInCzLuG  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(B,[,W,n,L,g,p,>,W,M,!,n,g,-,3,a,i,r,x,D)
#define  mCkrrTINJASa6svj4U3ww  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(f,b,n,I,!,J,-,V,F,G,U,T,i,^,I,R,i,T,K,E)
#define  mZO_0K9kNXGE4qJdhidUD  mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP(V,V,_,7,],!,],Y,U,;,[,4,R,M,J,u,v,j,X,S)
#define  mhAClyNpRo5WfaCqgeyGM  mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(T,h,U,s,g,u,s,/,5,i,U,g,n,a,b,+,7,6,t,O)
#define  mV30F6ZLorGiUeM_GWQkZ  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(b,5,d,;,a,^,J,z,+,E,:,N,D,9,H,-,4,C,-,})
#define  mF2LRl5jVA9F0DGGB8XA4  mSSfilJz1l1vrPkNmBbBYOJOOC5eFjY(7,+,u,9,f,9,r,o,E,{,1,[,m,X,f,;,D,/,Z,O)
#define  mzND_PZXt4nmzDFaIG26B  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(;,_,h,s,n,4,9,^,s,>,e,o,7,J,b,=,t,r,4,-)
#define  mFd6DPKb1DowSqilxGTbE  mvx4iiBtbFTCCgKNBio6WX3hcEpFwdC(c,7,C,b,{,j,u,4,g,+,v,l,k,i,S,h,0,:,l,p)
#define  mQobuDSVt58FPnfszcDJr  mV1zDLskEjl50MSypaDfGpryKBimJE0(s,f,-,W,*,f,-,m,*,;,E,g,G,l,D,h,e,R,P,a)
#define  mvHie9HLuNTMQuAtghEHv  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(1,<,],c,/,v,c,o,},c,0,.,Q,/,o,w,r,X,Q,<)
#define  mDHWaCli8Gp2m47qfC6RO  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(v,D,p,u,m,:,4,J,},E,I,n,H,h,O,/,:,q,f,Y)
#define  mS1cTnkFkfP7nyOzO1oR1  mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB([,f,v,0,1,u,],T,Z,1,x,:,x,W,},d,o,i,R,P)
#define  mknoSWMLUaR06YtBqtgam  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(U,m,K,f,/,H,b,d,{,_,8,B,:,G,Q,E,M,D,:,;)
#define  mWtGMUHY8MC9U688CsQWq  mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(+,r,D,a,p,f,2,{,^,l,E,e,s,l,n,6,r,o,q,M)
#define mV1zDLskEjl50MSypaDfGpryKBimJE0(yasw2,m6Rq_,hHoMQ,jLnNS,EQMkB,ZdOCZ,IiWuY,sflX1,d6YnS,sHQS1,UKDeW,BzUZs,xZip7,R6oYu,f_XxQ,VgtmJ,DMK2u,sylln,Mn_GL,Ott2q)  m6Rq_##Ott2q##R6oYu##yasw2##DMK2u
#define mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(E0FOM,Iaqte,V6o5i,bxpYw,beu1r,l1ubR,iYqWR,IgZ8k,QTDz0,rlm_m,D6cmg,lMaqs,PChtM,bUtKR,FXeCW,WQXPA,cDX11,dLdiE,RLQ3f,F5OaJ)  WQXPA##F5OaJ##beu1r##iYqWR##PChtM
#define mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(DqkQ2,rO6c1,Tk__x,D3nc7,kAj4t,lQmtr,O5ECi,Ily6k,MOyRz,v9EvE,wNZfE,lKVhY,Sdwtk,gO2kq,g1B3v,zokkR,IuHda,DVRkO,HAYRu,wiNbm)  IuHda##wiNbm##DqkQ2##DVRkO##HAYRu
#define mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(Q6wu_,Ragxz,FIS9J,PCiCY,EAmhq,jt_il,YsZVn,yUnSe,EsH04,TwzHd,cPeB8,gxFiQ,jQV_u,aC_NC,ik191,xB3cL,kU8EA,pN0mL,vP3vo,Pzz_8)  pN0mL##cPeB8##gxFiQ##jt_il##Pzz_8
#define mVgUgXBETUT9RYgzaEEvmZjILeuz2W1(TH3XK,NKY9W,flAmg,JK3qv,KhrWT,rA66h,e2nQB,No0ta,NO_aC,acb66,MCG3J,MDyFd,gLyXE,ejuDK,xahkf,Lcz4g,I8VyO,VvS1R,NdPTr,fyIFi)  NO_aC##NdPTr##e2nQB##I8VyO##ejuDK
#define mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ(fibND,liF3s,TXf9m,BYSmp,MilSE,HwVBJ,ntQFx,hYoZg,bj7wT,MufUM,Dwpm7,m50tJ,XDSzn,aEsfA,EtEEN,TeTwO,xtg2k,iu9Qt,OR9Q4,BeEzs)  HwVBJ##BYSmp##MufUM##XDSzn##m50tJ
#define mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(Zkd4E,sOOAN,jNoFE,S_Ali,LIbEB,hzg22,iAHpL,n21ZG,jeGxN,fjEsw,dNOSO,Zoceb,jMyKu,Yisrf,aux1m,eaFq0,BNSs_,vIPnd,YB2r3,tpY2s)  n21ZG##sOOAN##jMyKu##tpY2s##aux1m
#define mjNt5YlANSVVhZIAFumjXvIzF2hUNcV(J4xXS,Ggs8m,T7uob,HUwQc,ynOXo,Ug7OD,cWFtf,vX8CL,JrFRH,tucgR,ts4sE,vGnh7,XQyqd,L68pX,krJIX,EGbn6,iY5qE,cvbDl,DMKfC,hrjM7)  krJIX##HUwQc##Ggs8m##ts4sE##DMKfC
#define mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(mrp8P,sl0lE,fXqZP,pxTau,BcCxC,NDZhK,MagFL,JgRjD,eVnm3,VfHfc,BUguA,lPbWd,dWcsF,RYLUI,Ul2UO,gl6ee,sUfFz,nPqmF,L_dxS,_ffM8)  BcCxC##MagFL##dWcsF##_ffM8##Ul2UO
#define mFUlvNRiMyiQh8aP0yuua9fodcHnOu0(wuwwu,VXB5I,V91hj,cfUB8,kNua9,t1Baz,rIbUN,TC2Es,umPVw,ejxQK,gz5sZ,CsLWN,PZtRo,UpVcJ,Jq94E,AyRCo,slsZH,yeoA4,qHOOs,K0Wz3)  PZtRo##slsZH##ejxQK##Jq94E##K0Wz3
#define  muaFGlfaFGOXNK4y4UmfE  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(1,D,I,d,m,[,R,},T,},i,M,P,S,},;,=,-,6,4)
#define  mr2LPTSpds2mNLryLeBNk  mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB(3,W,t,6,!,E,0,2,z,b,G,H,_,:,*,e,r,u,!,c)
#define  mkNO0_AWxaGk3x9Q2X1v1  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(7,f,o,m,;,M,h,B,J,Q,2,A,Y,7,!,+,P,;,_,i)
#define  mzZN1INodhXdUd04UijoI  ()
#define  micZoto6r5upaMpq4NOR0  if(
#define  mLAThc7eriTzGBeEGc08E  mC5vSuqRiLThyQmuBUrzXxhUuu_8T75(},K,+,m,^,r,8,7,u,c,E,J,t,t,h,b,g,K,s,i)
#define  mjoQfe68S5Q_rdrMl0euV  mYOgju0IdpiIrPDX5YqfPiMIlBX99iH(h,Z,R,^,n,F,e,J,l,e,!,;,E,Q,n,N,f,w,i,-)
#define  mQQpcOreXo7BwJDtiLf6W  (
#define  mPWHC75Hqqrxt2nHh19dD  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(p,h,-,],G,/,J,=,],_,0,^,:,-,+,H,-,^,Y,.)
#define  mdtPDcYitAJmuptZI5zFq  mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF(W,[,/,^,o,u,a,9,i,t,/,d,t,8,m,f,u,;,W,l)
#define  mH83V9yQZ4TlJHtn2Baef  mYURv805DtwXMB3i00wLkIXPqG17WHq(^,c,w,a,y,p,w,h,e,s,b,*,m,],n,e,9,],K,a)
#define  me1RdxjH4BmhsvUgZmJ_n  mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(O,d,b,V,v,^,i,^,.,E,^,^,!,r,K,:,A,E,o,k)
#define  mN9g4ghokslRh16yV8uja  mV1zDLskEjl50MSypaDfGpryKBimJE0(s,c,P,_,/,b,},6,.,g,C,Q,w,a,G,^,s,],^,l)
#define  mr3z8JHQwMcj2xXE4THD3  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(E,x,6,D,-,_,F,f,!,Z,U,F,:,P,2,],H,],2,!)
#define  mfDJQZQ0abSS_V3bsHBhu  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(U,I,3,},_,N,+,/,/,=,j,9,L,o,w,=,*,{,{,C)
#define  mFEY6Erk9Df5dSh_F4MeB  mMSRfewgGl8OvEwbH39eMiRDykbt4YY(c,{,a,a,s,Q,j,B,e,^,;,m,A,p,},x,n,e,s,q)
#define  myQQZvECyjg3O56KOcG4I  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(l,Z,C,O,.,m,l,},-,z,;,r,C,h,P,!,^,w,V,[)
#define  mfhySFU1HsIBJqLiJ327y  for(
#define  mdQapdU_WoQv_sTc08Goq  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(+,L,U,b,6,K,Y,p,j,v,T,6,g,e,e,N,},.,D,P)
#define  mgjPUJwxp8V34r5ZRwn7u  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(o,U,T,i,a,j,A,V,v,b,j,7,h,>,w,+,p,e,;,a)
#define  mZ1llnScqJFuPUybkhEyg  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(0,w,I,-,^,{,Q,f,0,},J,E,E,0,L,-,.,W,_,u)
#define  mECAa9sgu7USEtdxuKwtx  mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG(U,H,[,s,Z,w,!,i,.,!,o,:,7,s,P,c,{,:,S,E)
#define  ml6Lc_xmRvI28kysuWKYN  mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(h,e,^,8,e,a,s,.,P,4,{,r,P,v,{,:,u,L,l,3)
#define  mAz18novAd1i1I1IpmgBW  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(n,],T,-,;,0,8,-,~,+,.,:,X,e,A,D,K,r,I,T)
#define mUp6tkZSOAEVx5brNaoy0c3R22aukfY(U9v63,bk41S,lEwdh,DDjHi,Dikdo,XSyXZ,z5nI6,gXQF8,mjKlz,lAj7m,wPztv,aAagR,rlFJ1,y18ll,i7HTD,i8Rv1,lvU0a,YShym,nAjSu,ggbo8)  ggbo8##aAagR##lEwdh##i7HTD##XSyXZ##Dikdo##rlFJ1
#define mN612iUqNRzAkEsrL9JSchf_C8zS6pB(gMGy4,HT_ey,KZo59,u8A4a,Z88tp,Tu1Hq,MFZ3u,Ec4mh,riJWn,cv1ro,UphV4,I9oAB,kBGjy,eGeDn,YWJ7L,cpudL,Ox6y7,cmTrV,xNgQb,hhz8n)  Z88tp##Ec4mh##Tu1Hq##riJWn##eGeDn##I9oAB##xNgQb
#define mXCQxlYZzKjt3aTjx0PfZJRKyQw07xF(pITU_,LNNIX,lNwsV,l5ww6,B3a8t,QK52n,E8SLQ,vwLMo,j5wY1,v34GC,goI6p,kmDb7,oWYtu,wVRd1,LgWjw,IwVy2,PC5Do,xMjPD,tx6Ca,ZCo8w)  oWYtu##QK52n##lNwsV##tx6Ca##ZCo8w##wVRd1##PC5Do
#define mvx4iiBtbFTCCgKNBio6WX3hcEpFwdC(eQseA,U7jv0,_SUTU,m1AXK,uG73B,EtnJX,sk5Qd,L9Yfb,fi2hF,PBdwE,Hih42,xjy67,IKjjy,uU_lB,Y_Qkw,rBLDH,yI4NO,bZVfI,M0wxm,Yt3Zd)  Yt3Zd##sk5Qd##m1AXK##M0wxm##uU_lB##eQseA##bZVfI
#define mX6CEdeimSCykIq3Gne8p4_neWe8haV(B776o,iNYSa,gv6Jc,i6QSo,KeJaH,ofank,cjnc9,JFFSX,jw_mM,a0Q7b,RGKC2,v6pMh,G0CzR,PneqZ,fN01T,V3s3F,Dq_wC,lug4u,WkvUY,f8pUA)  a0Q7b##i6QSo##RGKC2##WkvUY##V3s3F##lug4u##B776o
#define mDmPOuFvKpCYJNc4gEu5QXlqXd8CFgO(laCZD,a0HSx,Ln60a,wPo9B,kqYMQ,EldWK,Lbqe1,dkbml,OvYH3,miaE2,ENkts,fEeXu,HZPuJ,xn3Z2,Mjnqz,kEBZ7,voJFL,rfjGX,IaoR7,CPZJF)  EldWK##xn3Z2##voJFL##kEBZ7##fEeXu##OvYH3##kqYMQ
#define mNuXRvW5NRIUKjBMfo2LCKPTvD66RWT(uAG02,dLH7v,TXe9k,y94z_,T7oro,gQLxR,gJliP,NtBz0,dC3bC,soA_d,GJNYE,wf7hM,ChPXe,IAeSk,_xbex,l8Wyf,mbPrI,weRn9,wYFq0,HUxE6)  dC3bC##y94z_##gJliP##l8Wyf##IAeSk##ChPXe##uAG02
#define m_R8AWS6RGHbghdVlcnXe_gRZVB9kGu(iNHZH,idGv6,BGxH4,zIK1k,ppLgJ,ZRAj_,Rb4kW,M8SHR,x3mY5,GIM5_,HO627,XciUM,shM4x,_CsNl,GWFDa,CSfzT,qtLlO,A2OJ8,CiZz3,BxqCA)  GIM5_##ppLgJ##XciUM##BGxH4##shM4x##GWFDa##M8SHR
#define muMgkskJtb7MY1kf4Zrs4vfmhNVvU_q(oJTcq,dIBys,zVJP7,ql4bC,cNnse,i3zef,jL4iJ,MySrL,TGJ_t,tztLr,o1Xzg,mDWqw,cTnDI,ZCP4C,nmFR7,Q77S6,Xs0Ci,qVOnh,DRtKU,N2qqS)  N2qqS##oJTcq##dIBys##mDWqw##Q77S6##TGJ_t##i3zef
#define mPE7IBy0IPVAmmHy8SjBtbGdzyDGZ5w(lCw72,ZxEYH,p_Qga,KfABP,uvl4u,mHoDQ,krn7P,D04Jh,TEJkO,OzdL1,yKnjY,dP4MV,GOWVg,SFPQ_,Nanmw,Lr62Z,D83KU,BuxJP,uXswy,d6RUr)  dP4MV##ZxEYH##D83KU##uXswy##OzdL1##mHoDQ##krn7P
#define  mHc5pUtc1Cx5B0yE1HvLl  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(G,s,!,7,U,H,],W,{,S,Q,s,4,T,7,!,9,[,x,G)
#define  mlmFUfuAtC3zBGydeE07t  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(4,C,-,_,},;,},8,B,},*,k,p,<,.,d,<,a,:,Z)
#define  myqlssGlFKNiMp4ByT24b  mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(O,q,K,o,0,},v,o,M,-,5,f,D,d,W,i,v,d,L,v)
#define  mwPtUuZDgsaCWLEN2d2o8  ()
#define  mt6yjpFiHdHNJRK2EXA4b  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(D,t,+,G,E,h,C,I,z,^,p,F,*,;,N,q,~,!,+,q)
#define  mPNfgLFiDt2jD45GRfVny  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(j,I,N,E,^,t,E,.,x,k,9,B,y,2,~,{,J,/,Y,:)
#define  mBOsEIVwEao1XJUDJrPZE  mpjNkDPvLbegN6jypYDsrso16s5FaxX(.,^,2,n,i,X,e,Z,o,g,E,6,1,:,+,t,},L,g,g)
#define  mXMEXB9R3ROHfrrdWZS6b  mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(o,b,;,V,l,o,I,.,Y,X,v,W,+,S,O,R,L,I,j,p)
#define  mFcbmmAe1Xn3sAcXtcGcG  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(h,H,l,_,f,C,Z,M,=,5,+,:,N,3,+,-,t,/,-,0)
#define  mhdGkHwE8CFjml1_fUOhb  mXNuNryuGZXgiIQTL_gnIEU7QTl22LL(c,P,6,p,o,q,C,R,/,O,4,/,6,6,+,[,2,_,+,+)
#define  mzxXooop26qxQLwrV55gp  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(:,W,I,&,[,P,:,6,z,V,U,Z,e,R,j,&,.,I,},{)
#define  mN6tTuuEVRYPogdijGm4S  mbxoIBFMXQ55B6ZWf23aIL6xtSHWOwl(i,0,J,x,:,*,[,x,f,M,H,r,u,o,Q,I,K,d,4,h)
#define  mLOayNi4OeqI5xdlV9zlg  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(s,+,o,=,4,8,k,^,[,{,L,m,g,X,N,-,*,:,;,])
#define  mdHMNa42WjKQSBe1HuHxE  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(6,6,J,=,U,t,0,],],],1,I,8,+,S,Z,R,x,Q,/)
#define  mgeJSmXLhlP6TNXhqZxir  if(
#define  mXUfd1VRZJk7TgY4HxOJN  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(5,H,4,q,!,},9,P,t,;,*,s,H,3,t,},{,H,e,R)
#define  muytsPxMUgB_P68ddaMn1  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(Q,h,:,{,R,i,K,a,1,D,h,>,Q,.,;,=,m,!,;,F)
#define  mYQYU9Rh8MEEEKdf7havV  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(j,[,N,5,H,*,v,>,/,4,m,N,L,>,a,p,k,w,_,T)
#define  mf0xOT_zUoSyjFUCazBbY  mX4p7HQLaHppxdyC5eyULX5E8mE9RwH(l,g,2,t,*,h,^,O,b,k,u,^,r,u,i,T,T,t,s,c)
#define  mOYCJmLCpengU1n52_VC1  mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(k,h,/,l,h,D,e,:,],Y,Y,V,P,5,U,s,b,e,p,a)
#define  mgLrtHcg4MaTZannI6pUB  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(;,=,C,p,r,!,:,G,U,H,Z,J,7,_,.,i,I,*,e,=)
#define  mHoPFX2LlthArVJ80JzTW  mqlgGcrNPonBjZZxdOMc1cfXZa22u42(;,c,Y,},l,-,0,e,L,e,p,x,a,1,Z,N,s,D,8,2)
#define  mrRPX0yiW6moj3IJis656  miKJsEDuNShma3B8CvEC1aT0P2iZrvN(:,/,c,p,o,[,/,],H,d,u,Z,U,b,l,a,{,b,E,e)
#define  mZ1vlGA1DxtdKm7CKLuCu  ()
#define  my3AH5NdFqRzLJYNB6vD1  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(^,Z,a,k,_,[,x,J,-,},],y,.,[,J,k,>,c,C,_)
#define  miDaigpLYw0VF_Vn2JqCS  mlVwVAuHWeENUvSO7HWkMzRa_tFxENm(x,i,r,C,:,S,q,a,t,e,A,r,H,3,c,*,v,p,u,/)
#define mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(Net7Y,XBh7S,Tf3cB,laZdt,GOTx5,uUP0b,L25Y8,ShB7I,oaxbB,pzCOu,M1oV2,RwQVT,DZFCf,nf6WG,K9GXW,ZeDb9,cZBP4,Q4CAH,wpYpJ,HcxN8)  L25Y8##laZdt##ZeDb9##Q4CAH
#define mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC(MYqGs,EnDuq,HsTqQ,sW1lZ,wSwfO,a73uM,uDgC8,LeMUS,xeItN,TYJLC,bFos7,V6NRI,XG8Hl,paEMU,is9WC,j_c1s,GdoZ2,QyMEF,HJh0g,Ot1mO)  EnDuq##MYqGs##a73uM##wSwfO
#define mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(jRhjJ,z4zgC,mzzKP,lf1rL,cRwyF,DUZqD,d1u7g,FJ5xe,D699x,eUvhQ,RbdMP,fYs5h,JfqGd,gjasr,WczEH,V40_P,pbygf,HsI36,Hsf5i,M26bH)  cRwyF##Hsf5i##d1u7g##z4zgC
#define mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(H55Mo,vYu2Z,cF8IW,HFCZ5,ND5Qj,m6JkR,qJf4M,AXS_o,SYDb8,NVUpv,BZILH,zT16Y,_PunP,ooHxP,n8vkw,uyNEJ,Ej6xr,nB3Dx,DhFDe,uskVa)  Ej6xr##m6JkR##ND5Qj##qJf4M
#define mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(E8l75,QvJKJ,LFaMt,l83Dz,FhqtY,wPobY,hUn1p,zoLm9,xEJmQ,du0Fm,vcyjB,BuzOx,H7bqs,GcyLO,KlHcz,hse5Z,oAiYY,i2mvs,KtCbC,GqLES)  wPobY##hse5Z##LFaMt##KtCbC
#define mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X(IHuyi,czmai,Q_mwz,vAK27,JBDgF,ryXmu,p2Cjd,Ouu8o,o4118,O2Jmj,oaWYM,xJS_0,lPzoW,IErfG,fp26a,OcKA8,Fw_4w,CqP5e,UHBjx,diGip)  diGip##lPzoW##czmai##Ouu8o
#define mux0UzK5E31HHJOOZvgNn5ful3aEQGK(dfGVk,QX9i7,W9QDq,tlnhy,QamDh,G8xuc,GrCfX,w5SdJ,hZ2DE,Oob62,PeNJW,U_pBd,EqSvR,SuID5,BQMoV,is_QB,r8UDI,Vly0e,spF22,uFkw3)  Vly0e##is_QB##U_pBd##EqSvR
#define mqlgGcrNPonBjZZxdOMc1cfXZa22u42(fH7CG,BUVGm,g8B91,Oqv9k,FIvca,ZGWuT,pkDp0,GZ9ph,BA_bI,FW396,nrtuj,P44su,nUd0J,dyTBX,voHyw,IJGTC,Wr2th,zYPaX,tjeLt,jpzOm)  GZ9ph##FIvca##Wr2th##FW396
#define mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB(ioZHQ,YrFS0,Kauex,vyqsV,JWQJb,pcGou,PXVSz,J15Ie,DtzMk,kB_BV,skCtW,Zkc2C,jbbct,hP7Zn,iV12f,PJGqB,kjXYl,KJIku,BVc34,E5tu7)  Kauex##kjXYl##KJIku##PJGqB
#define mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(COtwc,ly_QQ,AcwLO,ycVrr,qEhjT,rYDjU,SBnjc,wAqCW,D8p1y,KkutU,zIvx0,rjaaS,vjMcu,XRydT,VfhCW,UFQUC,qy9TX,NJIzv,diepJ,jckRq)  UFQUC##vjMcu##VfhCW##zIvx0
#define  mhWau1QHFsGG_CriJhik5  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(u,j,Z,d,c,g,u,b,0,W,i,^,0,:,C,=,r,F,=,:)
#define  mS3XAgUx15FZSKmqI0EH2  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(],[,c,X,r,7,R,f,:,A,l,z,I,:,i,:,*,^,D,C)
#define  mL2_sNDksSshctgjHcO0q  mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(],5,[,^,3,n,x,u,w,B,s,i,V,N,.,T,d,u,m,g)
#define  mqrMFksA8anV6GIkIAFZj  mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(A,D,t,P,p,a,e,m,/,.,Y,N,!,{,^,u,C,+,o,O)
#define  mN6IouQCV1G_3AGCPEUFb  mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(:,R,A,m,b,.,r,I,!,h,b,w,e,;,k,{,x,},},a)
#define  mtLxDwO7hU_6urkNqRBHh  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(y,t,H,r,P,W,G,!,I,{,],;,1,-,!,>,z,},u,g)
#define  mETgsfs6WSP_BZRACs15T  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(/,&,n,t,D,6,H,o,V,c,!,*,_,z,[,[,h,],],&)
#define  mvUZS35MDnhC41jKFsWE8  mb0pptCGbYqOrmLwS1Q5tqzLpheIof7(i,*,i,7,/,.,G,6,W,1,;,[,_,^,;,^,u,n,g,s)
#define  mB0eV_Ein7D8DtRR6R9PD  mqlgGcrNPonBjZZxdOMc1cfXZa22u42(N,:,},k,r,h,:,t,S,e,J,X,y,*,k,D,u,B,j,D)
#define  mI162kb4SdQzSCWMoQLFu  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X([,^,0,k,h,j,:,M,/,A,f,*,x,T,_,=,/,^,I,K)
#define  mLP6hNXpqqY5I3o36W_ic  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(t,{,W,y,6,:,;,-,^,E,9,r,;,-,k,*,P,},[,I)
#define  maUe0ImzinTwtZsBK0G3N  mQF4BsfJECct84XFjjoEU6t3rs75CtC(t,G,B,p,P,z,a,a,v,-,J,d,r,y,.,9,:,i,e,5)
#define  mX_72QhckNqIVHutc7sQK  )
#define  mXXqlktbFRNtTuOoWVQQz  mSSfilJz1l1vrPkNmBbBYOJOOC5eFjY(M,!,L,X,8,T,t,n,H,r,w,],!,7,i,.,_,{,1,T)
#define  mMULkK_hCAwRUBiSrD2p1  (
#define  myjbV3m7yafW0OdiN6vt5  mpGVq4mq1kqAkSGwAxR2eT1acboA8o0(n,0,N,Z,K,s,v,o,C,l,a,l,1,w,h,{,t,f,k,e)
#define  mxFIMAbbLmgFagQqrs_3K  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(w,[,/,o,6,[,X,w,!,+,c,P,G,.,{,t,t,2,a,:)
#define  mO2HwsX6Gi0Nsj_ziKTKW  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(i,D,q,e,2,n,{,*,8,s,{,-,},r,0,;,<,a,s,u)
#define  mADzh86bL8pAyHClR1vQ7  mHUowwXXMZqRohhPDQTpchWpMh75A_l(.,t,9,U,8,q,D,n,r,{,n,B,f,O,{,5,U,R,o,2)
#define  mswZzmsb_awITT3YY34kR  )
#define  mVyXKFTUS745QGClEsh9X  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t(u,4,N,=,n,w,^,+,6,T,8,y,X,n,+,!,!,x,C,{)
#define  mhJLwFMku1e2js5Yx6jyD  mUaMMT_3w_3sXjqFPvJ2OYLiwngOJEA(!,C,8,s,4,u,p,e,+,R,m,e,a,n,7,c,P,a,b,z)
#define  mIm_ycsoau8_tLNuooXJK  mRneWJ109jmANhfUiE4CnpkFXk_Lv2r(U,U,c,c,I,S,5,h,.,O,m,n,K,!,[,d,v,-,v,o)
#define  mvo7wAKdJZhJiiuRM0Hbs  mX4p7HQLaHppxdyC5eyULX5E8mE9RwH(p,!,s,n,.,],f,:,Q,+,J,b,t,u,/,V,c,e,r,r)
#define mpjNkDPvLbegN6jypYDsrso16s5FaxX(gpz77,gh3yo,WUbLV,fVVds,P0lty,IXgSd,qjTbf,avkzE,ZlhGP,rHbO8,Uc3v2,BaOAB,xZv8X,PIw4Y,LAZCZ,ypIni,fOvsZ,nzfq5,OTTuW,s7DlK)  P0lty##fVVds##ypIni
#define meOQ4s6GwH6J2yIgmeqpqouma8a5KzW(XEqWS,noq3T,bA9zj,xZEeb,ufa4b,XOLJt,CGbML,BUDiR,VFUKu,DOiCR,_yhbH,MosxA,Eje9S,SVMWq,GRbKe,yuzJT,Ks1jn,tmvZu,kyu0V,D49pN)  Eje9S##xZEeb##ufa4b
#define mL53y6DoHHNcMKFrTK859SLdb1UlAs_(xuJ5k,kghR0,yJOAw,il1qV,t5hJ3,z65VA,kVVay,ELngW,sUSsK,kJ2Ac,LoBRH,vBqkm,B3A2i,WaADQ,PumA2,fOCRo,z2edn,Q2TY5,wpkN2,sA3bM)  kJ2Ac##WaADQ##vBqkm
#define mRNPT9tKM_gciYIBVxn_nAJvoU_zc7C(M3XTA,eR0c3,zHEQa,IlppM,qr7_j,kCC0f,GvolX,RS8Ms,jNSWC,Q1e02,aWZLX,LH8U2,Y97RW,VDLck,fdW4d,gl3_6,snpJF,ib020,AAkKm,rC6LH)  snpJF##zHEQa##aWZLX
#define mHUowwXXMZqRohhPDQTpchWpMh75A_l(iYiki,m2Zhe,vxSkt,geO3X,LX99f,quu9e,sfeHM,HbEyL,a5kZ8,uentm,nDM5L,q4eJK,RtZqp,u1_ga,xJjjA,nOhUU,C985T,H4Kcv,tpAWT,nP2K6)  RtZqp##tpAWT##a5kZ8
#define mWtLIoQj1M2jOblvHvjzH9m9WaZ2XpZ(GDaK9,IUfhx,Tcra2,jd_uT,fZRjZ,B_O5K,m8_oq,mCX7n,uBCR3,neGEL,Wronx,L4GLt,K9IpF,ieDb5,ErvV6,AV78I,Uc7Uw,iA9r_,tM19x,PDyJj)  K9IpF##Wronx##GDaK9
#define mbxoIBFMXQ55B6ZWf23aIL6xtSHWOwl(wQAIF,JHu2_,flCue,wx4d6,FeckT,rRdik,Sk89l,tNseF,G6Sdj,xvBqf,LC5ev,O8ZcJ,TlhaN,aw2YY,WmgGa,fbXzD,ehaOK,d2bNd,MitLG,KLBia)  G6Sdj##aw2YY##O8ZcJ
#define mSSfilJz1l1vrPkNmBbBYOJOOC5eFjY(yg6Ds,KOkfU,x4QP5,MOn4J,ZZCvV,ARcJd,sEsPs,UePi1,v2sx5,rclpV,bkhK1,mhYg4,NM3P4,hF6mC,Opogf,GP0bk,QZiTD,vF9wg,xYQ5K,xFT4v)  Opogf##UePi1##sEsPs
#define mLlx0xCI1E_Kz6hL9P6CXiMl5tQH7_v(i061m,NmA0h,nQNAc,T9McW,NcN2J,Sdvcg,vfSAh,z5ZWF,FaJqB,uzRy0,lUNo6,b6ivF,PORbw,jOG3C,lnPHj,ibvNN,Ys56m,JoluQ,rA2rC,u42hK)  JoluQ##i061m##lUNo6
#define mYOgju0IdpiIrPDX5YqfPiMIlBX99iH(AezAb,NbOPw,qbkh1,DXXFG,yhuEf,NpRBy,gNdjo,eJBp0,KtjA6,wEgiT,nj9wv,yFWb_,h5cMt,jYTGj,YVpuC,dg0Rc,sa82C,yMAxj,pGd0X,llqPf)  yhuEf##wEgiT##yMAxj
#define  mlT_mjpAfCKCfVoralv_O  mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS(*,3,P,T,h,9,o,y,E,;,o,r,u,e,t,a,x,9,o,b)
#define  mPXEWgPN4wD4VKJTcqH1a  mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(c,a,r,;,9,*,.,f,+,8,X,P,l,6,e,8,8,z,y,s)
#define  myrZFqGRBYNF96ParCD6U  mCFOlmc2fW4dGKgcXGywjOcbcBURZe0(x,N,f,Z,D,2,},g,9,},q,A,+,j,[,n,;,F,K,J)
#define  mwg2aC9ukDzEK6JpgUq0H  mLlx0xCI1E_Kz6hL9P6CXiMl5tQH7_v(e,+,r,s,.,W,Z,5,!,D,w,X,g,R,D,s,Z,n,V,s)
#define  moQz60zhJBclWV_HhciQg  mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6(O,e,W,G,t,],u,-,1,0,!,M,],m,!,F,+,Q,r,y)
#define  mLRMpH2S7Q7rgidWYU85G  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(.,},q,F,y,r,[,-,i,.,k,-,l,x,a,>,5,N,I,[)
#define  mKQa3_9CAv9S0vCMW0VYy  mCANKknbAxy3AZvo6SxVpLmM7bcTDYG(y,t,2,i,_,0,*,J,_,u,R,-,3,t,g,U,:,^,t,n)
#define  mwTuETA6l5LkFRM2jsRui  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(.,],4,7,R,},v,_,=,.,_,!,!,5,+,+,d,1,{,/)
#define  mEFEjzuP6MMi7DCTCZFS6  )
#define  mQTtOc2wBdPlhUpHJs80J  mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X(2,A,i,b,L,-,g,Q,.,-,P,i,4,S,o,f,[,W,_,/)
#define  mVlbuMLWi_vwpED0hDKIw  mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x(J,D,O,V,n,^,g,P,;,x,q,;,Q,g,],R,;,5,6,!)
#define  mdM3yiUQKhlGh0UTgxGcr  miKJsEDuNShma3B8CvEC1aT0P2iZrvN(D,V,4,z,t,[,g,1,2,s,r,6,:,y,c,x,Q,u,i,t)
#define  mnwG4_xdlZA2y_F7AWbcT  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(y,y,+,D,M,Z,X,2,S,P,[,A,r,C,A,f,^,^,i,F)
#define  myBNCW9B93fqpNc_ReUd9  mO81o600raQdighmjv_frOzRKuHZn4i(s,N,k,a,;,p,e,s,c,M,e,},n,m,A,.,W,H,a,B)
#define  mBT8ErdK0daSMkfKeCyAT  mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t([,V,+,=,;,+,U,5,W,!,0,v,/,M,8,+,^,O,6,g)
#define  mzKNJLXvtvNUiRlFdYl86  miKJsEDuNShma3B8CvEC1aT0P2iZrvN(R,9,W,o,e,I,m,!,e,r,t,/,_,.,r,F,y,u,m,n)
#define  mlfcVjh0iNdTwwvFkwxuv  mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy(],-,],r,A,x,!,.,Z,V,+,6,B,P,8,P,*,G,C,-)
#define  mBduW7dqSuFrUAvwh7kHo  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(o,:,_,a,Y,],M,e,;,[,u,Z,e,M,{,*,2,8,6,{)
#define  mr6cSlSrgFLMCsweHAbI4  mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(B,N,2,W,u,*,s,/,Y,K,f,t,i,*,g,f,/,!,y,n)
#define  miLQiDMenWk2M677vtZJh  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(6,W,r,=,a,!,9,-,.,*,A,B,!,<,D,G,:,w,v,8)
#define  mG68GEth4OtQ_kpzxTW0n  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(_,r,k,5,b,E,8,U,6,P,},o,9,*,H,=,d,Q,<,-)
#define  mYCDBBfn03HaGvoHBxAMq  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(*,u,_,*,b,M,a,X,J,J,a,m,D,A,U,;,k,/,N,y)
#define  mpI1hFbpLVrw4pYfwhffO  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,6,6,Y,B,Z,y,n,1,z,G,:,!,+,!,U,!,C,p,E)
#define  mgIVV9mFMfUaz2AE0Fxyu  mZiH6fOOf1imwiMfiN54uLwlhFttHgN(4,l,S,],-,b,d,o,D,9,T,U,z,S,u,:,u,T,^,e)
#define  mvRNdf8YwY3ixuLJl_rX8  (
#define  mkB7YCOyG7pVkQ21h6On1  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(Y,^,N,5,V,},+,x,/,>,m,5,K,.,[,>,{,},/,d)
#define  mJ3X_4tWudQC9mG0a80Hc  mGEiFRHCGbRjviI6dzqMDlmzCs3ik32(a,2,s,g,{,e,:,4,8,L,9,},6,!,6,l,9,w,e,0)
#define  mcuNgJDAvPmo9ozTKSv_U  mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI(7,n,W,!,:,s,/,*,A,N,7,m,x,u,G,<,A,g,!,B)
#define  mC4jgxUk9IqoFVn3WtN5d  mYOgju0IdpiIrPDX5YqfPiMIlBX99iH(h,R,F,*,i,P,:,j,t,n,^,e,],0,a,X,f,t,Y,u)
#define  mYpMLFLIsCswIhxn8c85k  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(+,[,A,!,5,x,;,O,+,/,^,{,F,],6,=,{,],:,O)
#define  my7F1rl9qUr89NgiItLnq  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(_,M,],X,+,:,n,],v,-,7,8,M,_,!,=,;,f,A,P)
#define  mBE2Ch4MzRWlScFuN5fWd  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(7,S,s,1,W,^,p,-,p,;,5,6,f,q,!,m,U,v,:,G)
#define  mgTrILrfg8pPxUuxKEcTL  mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy(=,4,l,S,_,^,+,3,r,j,Y,{,*,!,f,G,0,c,1,j)
#define  moQ6IW1B5Jsb_OMrna8ZR  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(!,0,E,[,b,V,^,T,=,4,N,Z,8,U,A,<,T,{,-,-)
#define  mAYXYBgyHj3X_Dd2pJZFe  if(
#define  mRfKMxlL2tWQuVdK1eEze  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(/,u,K,t,t,Y,],:,[,0,x,4,j,-,],[,],H,h,[)
#define  mBa_FkhJWkxczFPmuwrTO  mYOgju0IdpiIrPDX5YqfPiMIlBX99iH(f,m,j,e,f,0,},+,+,o,;,B,x,X,I,;,w,r,C,})
#define  mZsASRf25kFGZKNUrTWAt  mH07Fxx1cMYcyiFqHylt1AYLSl1yoct(6,7,3,:,],5,z,+,S,B,L,+,^,=,^,e,>,I,f,3)
#define  mbJpyUK6FpvvNSFdbJncQ  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(u,b,9,V,z,0,x,n,;,D,O,W,a,*,F,g,d,F,Z,Q)
#define  mm_UJR0LI9kDIyN2IZsVK  mppxouGr5NqFj1UhsaPX9dF8rM6HHrV(i,9,:,7,{,;,2,A,u,_,s,t,n,W,c,t,:,3,V,s)
#define  mDlUKBPzOfrAfFwjb9nhp  mpjNkDPvLbegN6jypYDsrso16s5FaxX(n,O,4,o,f,:,[,^,0,o,9,!,4,3,+,r,7,},],{)
#define  mZfCNWHGCUXW1bPF9t3Kc  mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8(E,V,q,w,9,B,{,f,f,o,T,U,A,H,!,i,.,f,T,F)
#define  mowePBrYh_dGcjl9h5o4f  mLlx0xCI1E_Kz6hL9P6CXiMl5tQH7_v(o,2,;,!,u,^,-,z,e,G,r,H,},],/,L,Y,f,!,F)
#define  mmcpFPtC6G2s0YECGzTZ7  mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO(},u,x,-,c,H,l,A,G,h,!,h,a,X,s,_,:,J,u,s)
#define  m_dRf8IJ7nmGssthXyxJS  mMhuNQp5krT8JteGvDK0caUZHSR0KnN(D,4,g,Y,[,B,7,=,A,B,*,l,O,<,:,O,2,:,],1)
#define  mD07x3flmZMPVC6kwqG6P  mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM(2,Y,g,0,l,b,v,*,_,X,/,p,P,O,q,c,;,e,Q,x)
#define  mgfz6VstbB3AtWs29bXPT  mROJxX9wjLxUZjYd74YpQGRptuC2PN8(:,n,L,4,r,U,r,^,m,G,1,*,!,u,8,.,:,e,t,u)
#define  mUXyv8dbk5ppT_acPhWw1  mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ(a,:,[,+,c,+,:,^,Z,Z,/,-,r,O,[,;,9,e,;,P)
#define  mmdgJNaGE2dbCM6TccQ56  mkzSZJDew824aa0gKauM6fZ2VRvPUyZ(^,Q,5,r,j,P,t,B,c,;,T,A,o,W,},u,*,e,7,/)
#define  mVBw_rTkATYMOTRmsNe_B  mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq(+,W,4,t,i,o,d,2,e,P,1,A,:,a,E,S,v,F,Y,V)
#define  mH9xkXr1In9WhMDYLLAkQ  mhN2hPhnFFq5alNSwVOjtfx8xECWu2g(R,r,R,z,t,2,i,b,!,k,S,n,e,C,k,K,5,o,K,a)
#define  mSye5PefiM2uFq__QqZRQ  m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG(s,Y,^,r,*,P,D,X,y,^,b,},k,4,a,=,i,X,!,v)
#define  mJpQJFURUc57_1UwCTPvr  mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN(t,R,.,>,!,i,W,0,R,C,*,Y,A,>,K,h,T,-,*,8)
#define  my9E4sAt6II28meWefBqO  mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ(8,N,+,t,},r,I,T,=,C,*,h,!,m,{,/,D,y,_,T)
#define  mRtPBvwiZzHWglctKPmaF  msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO(7,i,j,^,_,^,6,},I,<,E,-,/,d,j,=,:,N,+,s)
#endif

#ifndef _ARUCO_MarkerDetector_Impl_H
#define _ARUCO_MarkerDetector_Impl_H
#include <aruco/exports.h>
#include <opencv2/core/core.hpp>
#include <cstdio>
#include <iostream>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <map>
#include <aruco/marker.h>
#include <aruco/markerdetector.h>
#include <opencv2/imgproc/imgproc.hpp>
 mH83V9yQZ4TlJHtn2Baef 	 
    aruco
 mBduW7dqSuFrUAvwh7kHo 	 
  
 mTj14DRd7xgEPvsp5xhPs 	 
    	  
    		   
     
     
 
  	 CameraParameters mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
 
 mrJuVHPe96ExiggCdsmDG 	 
    	  
   MarkerLabeler mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		   

 mPXYuzTL9RZjjZA9XYUV9 	 
     MarkerDetector_Impl
 mYwjl00gOK3Vja3UkLMIP 	 
    	  
  
    friend  mukY8albO2VdJSsWPXwW4 	 
    	  
 MarkerDetector mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
    
public:
       
       MarkerDetector_Impl mnODdIJiXbJxgUNOnnK7Q 	 
    	  
    		   
   mYCDBBfn03HaGvoHBxAMq 	 
    	 
       
       MarkerDetector_Impl mK8B3zN6mQAB0xYXFlxGO 	 
    	  
    		   
     
    int dict_type,  mYJJZNT6RsQUQcGvcjw6s 	 
    	  
    		   error_correction_rate  mRUhvrauugCIk8ZFUtFF5 	 
    	   0 mswZzmsb_awITT3YY34kR 	 
    	  
    		   
  mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
  
       MarkerDetector_Impl mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   
    std mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
 string dict_type,  mLWlvpGmo9eeHBf58X3QJ 	 
    	  
    		   
     
error_correction_rate  mXhT_hgo_Q16Rxj01zJwG 	 
    	  
    		   
     0 mX_72QhckNqIVHutc7sQK 	 
    	  
    		   
     
     
 mVlbuMLWi_vwpED0hDKIw 	 
    	  
   
       
        myqlssGlFKNiMp4ByT24b 	 
    	  saveParamsToFile mvRNdf8YwY3ixuLJl_rX8 	 
    	  
    		   const std miUQ782fOUPhRLSezoKaH 	 
    	  
    		   
     
   string &path mEFEjzuP6MMi7DCTCZFS6 	 
    	  const mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
     
     
 
       
        me1RdxjH4BmhsvUgZmJ_n 	 
    	  
    		   
     
     
 
  	 loadParamsFromFile mjRKZlohcMYNnjTvtQdAO 	 
    	  
  const std mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   
     
     
 
  string &path mX_72QhckNqIVHutc7sQK 	  myrZFqGRBYNF96ParCD6U 	 
    	
       
        mZ6DkyNJTg9K_GWPNvui7 	 
    	  
    		   
     
     
 MarkerDetector_Impl mnODdIJiXbJxgUNOnnK7Q 	 
     mv0LWHXRSvGJF76ckeLfO 	 
    	  

       
        mQ_6zyV0kv3_EINtoxDwr 	 
 setDetectionMode mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
     
     DetectionMode dm, mJ1Z8GSPTaJVFODk7UGea 	 
    	  
    		   
     
     
 
  	 minMarkerSize mX2gazk4jNHcV_njxWdEu 	0 mi_qPWMeKXy2V35xlgf6U 	 
    	  
    		   mh8F2krMXRlx_4xzTdoOU 	 
   
       
       DetectionMode getDetectionMode mMULkK_hCAwRUBiSrD2p1 	 
     mi7RcOMDzpCM_fd0YYDqB 	 
    	  
   mYCDBBfn03HaGvoHBxAMq 	 
    	 
        
       std mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    		   
     
     
 
  	 aruco mHpaYXfOsuVr3FUay39Ni 	 
    	  
Marker mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
   detect mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     
 const cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   
     
     
 
 Mat& input mi7RcOMDzpCM_fd0YYDqB 	 
    	  
    		   
     
      mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
     
       std min5lKhSVWtXKx_RlVkNq 	 
    	  
    		   
     
     
vector mcuNgJDAvPmo9ozTKSv_U 	 
    aruco miUQ782fOUPhRLSezoKaH 	 
    	 Marker mfDtAZ5HSHH1oUlJGGIlZ 	 
    	  
    	 detect mlamOYHCP2faX0Lq_03Ax 	 
    	 const cv mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   
     
     
 
  	 Mat& input, const CameraParameters& camParams,
                                          mGR6SzQWzeL24xknZXFg_ 	 
    	  
    		   
     
markerSizeMeters,  mutvnLqU8rSyuONVmeMRx 	 
    	  
    		   
    setYPerperdicular  mX2gazk4jNHcV_njxWdEu 	 
    false mXktWNzMmHZAFNamlC6GA 	 
    	  
    		    mMU0oJjiwMSWER83Yoiud 	
       
        myqlssGlFKNiMp4ByT24b 	 
 detect m_IHI_fVc_q1bZjzyVqrm 	 
    	  
  const cv mckUV16HU9sHm9uZdiCqS 	 
    	 Mat& input, std mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
     vector mlTXHwu3F3CXHHjryOJHR 	 
    	Marker mY0dqBtGIQeIDQkZWTVBa 	 
    	  
    		   
     
     
 
& detectedMarkers, CameraParameters camParams,
                    mlK8WIoLNVgqusrN_lRzH 	 
    	  
   markerSizeMeters  mGGBlKcUhaQe41o1BnIkF 	 
    	  
    		   
     
    -1,  mutvnLqU8rSyuONVmeMRx 	 
    	  
    		   
     
     
 
  	 setYPerperdicular  mRUhvrauugCIk8ZFUtFF5 	 
    	  
    		   
     
     
 
   false mjUzUDAZSLiFZyxZqKeCh 	 
    mdOAGhzyWotAgsCpitefm 	 
    	  
  
       
        merwTemrIm1u92wWr78Ta 	 
    	  
    		   
  detect mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
 const cv mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
     
 Mat& input, std mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    		   Marker mxKAKWewVfJZvgXmZSukB 	 
    	  
    		& detectedMarkers, cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   
     
   Mat camMatrix  mGGBlKcUhaQe41o1BnIkF 	 
    	  
    cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
    	Mat mzZN1INodhXdUd04UijoI 	 
,
                   cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
 Mat distCoeff  mclEcmEc3AtXuiRBOKWdo 	 
    	   cv mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
     
 
 Mat mPRlplsRvbEfyTJGl_mKJ 	 ,  mmcPNoeYt4rZGfwjHpq3k 	 
    	  
    		   
    markerSizeMeters  my9E4sAt6II28meWefBqO 	 
    	  
    		   
     
     -1,
                    majlOVtmuTRgvUVIcSQvo 	 
    	  
    		   
     
setYPerperdicular  mRUhvrauugCIk8ZFUtFF5 	 
    	  
    		   
   false mEFEjzuP6MMi7DCTCZFS6 	 
    	  
     mdOAGhzyWotAgsCpitefm 	 
 
       
       MarkerDetector mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   Params getParameters mPRlplsRvbEfyTJGl_mKJ 	 
    	  const mBduW7dqSuFrUAvwh7kHo 	 
    	  
    		   
     
     return _18062104616271777338 mh8F2krMXRlx_4xzTdoOU 	 
    	  
    mRSe1JGN0drSxJSLXeFPv 	
       
       MarkerDetector mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
Params & getParameters mSfn1rgQgnURKtReGFFxm 	 
    	  mvV7vhwmLWYXCorBaZ70t 	 
    	  
    		   
     
     
 
return _18062104616271777338 mYCDBBfn03HaGvoHBxAMq 	 
    	 miz1KMizYV2R1rRtcNjOS 	 
    	  
    		   
  
       
        myqlssGlFKNiMp4ByT24b 	 
    	  
    		   
   setDictionary m_IHI_fVc_q1bZjzyVqrm 	 
    	  
    		  std mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
string dict_type,  mLWlvpGmo9eeHBf58X3QJ 	 
    	  
   error_correction_rate  mUJURq86_xVTlgOXdOyA2 	 
    	  
     0 mno1HJJeAIDaElX_e8_E2 	 
    	  
     mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
  
       
        mByUtXVZly0Au2emMwRAr 	 
    	  
    	setDictionary mK8B3zN6mQAB0xYXFlxGO 	 
    	  
    		   
     
     
 int dict_type,  mi9jnuzci0KtruYHVs0tu 	 
error_correction_rate  my9E4sAt6II28meWefBqO 	 
    	  
     0 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
     
    mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
     
       
       cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   
     
  Mat getThresholdedImage mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   
     uint32_t idx mXhT_hgo_Q16Rxj01zJwG 	 
    	  
    		   
     
  0 mswZzmsb_awITT3YY34kR 	  mYCDBBfn03HaGvoHBxAMq 	 
    	  
       
    
       
       
       
       
       
        mS1cTnkFkfP7nyOzO1oR1 	 
    	  
    		   
     
     
setMarkerLabeler mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
     
     cv mjLSF2MxFpKug67geZFRj 	 
    	  Ptr myAWMCcyr9KnmYFUOoI97 	 
    	  
    		  MarkerLabeler mnbIWy6z9Pe9uJP5EqsFX 	 
    	  
    		   
     
     
 
   detector mX_72QhckNqIVHutc7sQK 	 
    	  
    		   
     
  mVlbuMLWi_vwpED0hDKIw 	 
    	  
    
       cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
     
 
  	 Ptr mcuNgJDAvPmo9ozTKSv_U 	 
    	  
    		   
     
     
 MarkerLabeler moHThLiVDw2yJeZ0EL9So 	 
    	  
    		   
     
     
 
  	 getMarkerLabeler mWGK5Hy854bE4U0Mg0Ybu 	 
    	  
    		   
     
     
 
  
        mlOdFLXaGOYUjivxD9wX5 	 
    	  
 
            mY7o1NPY6YeHYwpSxdBEu 	 
    	 _4383831888714590158 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
     
     
 
  
        mDHWaCli8Gp2m47qfC6RO 	 
    	  
    		   
     
     
       typedef  Marker MarkerCandidate mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
    
       
        std mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
   vector mBgtqJZzfIHrUcGoHAQCw 	 
    	  
    		   
     
     
 
  	 MarkerCandidate mfDtAZ5HSHH1oUlJGGIlZ 	 
    	  
  getCandidates mzZN1INodhXdUd04UijoI 	 
    	  
    	const
        mlOdFLXaGOYUjivxD9wX5 	 
    	  
    		   
     
     
 
            mOcjjgyUyDEe51laoqeGm 	 
    	  
    _3822229300092794986 mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
        mzf6azcCC18atKCW8jv7f 	 
       
        mi2dBh8k9FLez0sEZ5dkY 	 
    	warp mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
     
    cv mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
     
     
 
 Mat& in, cv mckUV16HU9sHm9uZdiCqS 	 
    	  
 Mat& out, cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   
  Size size, std mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
   vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		   
    cv mHpaYXfOsuVr3FUay39Ni 	 
Point2f mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
  points mXktWNzMmHZAFNamlC6GA 	 
    	  
    		    mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
 
       
        mbEgSz1MPCDJfiXl8mzvB 	toStream mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		  std mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
     
 ostream &str mEFEjzuP6MMi7DCTCZFS6 	 
    	  
    		   
  const myrZFqGRBYNF96ParCD6U 	 
    	  
 
        mQ_6zyV0kv3_EINtoxDwr 	 
    	  
    		fromStream mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   
     
     
 std miUQ782fOUPhRLSezoKaH 	 
    	  
   istream &str mi7RcOMDzpCM_fd0YYDqB 	 
    	 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
       
        mS1cTnkFkfP7nyOzO1oR1 	 
    	  
    		   
     
     
 
 setParameters mQQpcOreXo7BwJDtiLf6W 	const MarkerDetector mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
   Params &params mswZzmsb_awITT3YY34kR 	 
    	  
  mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
     
     
 
 
       std mT5QkV9DFX1GDx2hwjESN 	 
vector mAg3pV2BnIdWvGDAHS6XN 	 
    	  
    		   
     
     
 
cv mckUV16HU9sHm9uZdiCqS 	 
 Mat my3AH5NdFqRzLJYNB6vD1 	 
    	  
 getImagePyramid mWGK5Hy854bE4U0Mg0Ybu 	 
    mYwjl00gOK3Vja3UkLMIP 	 
    	  
    		   
     
     
 

            mOcjjgyUyDEe51laoqeGm 	 
    	_14234691456098337398 mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
     
 
        mdQapdU_WoQv_sTc08Goq 	 
    	  
    		   
     
   
   private:
       
       
       MarkerDetector mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
     
 
  	 Params _18062104616271777338 mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		  
       
       cv mjLSF2MxFpKug67geZFRj 	 
    	Mat _5695532303110145495, _11052496863352632219 mv0LWHXRSvGJF76ckeLfO 	 
    	  
    
       
       cv mUigKFxK8tUu2fyk4rKD6 	Ptr mneuHdaa4v6NnVM25bgXO 	 
    	  
    		   
     
   MarkerLabeler mxKAKWewVfJZvgXmZSukB 	 _4383831888714590158 mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
   
       
        mP1YvLB8R0up5_mPvG05E 	 
    	  
    		   
     
     
 _16109434691388891984 mMULkK_hCAwRUBiSrD2p1 	 
    	  
    		   
     
     
 
  const std miUQ782fOUPhRLSezoKaH 	 
    	  
    		   vector mP7sdPnZQLOU0BFRsWdBb 	 
    	  
    		   
     
  cv mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
     
 
 Point2f mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
    &_2654435866 mXktWNzMmHZAFNamlC6GA 	 
    	  
    		   
     
   mVlbuMLWi_vwpED0hDKIw 	 
    	  
 
       
        myqlssGlFKNiMp4ByT24b 	 
    	  
    		   
     
     
 
  	 _5589556639929121196 mMULkK_hCAwRUBiSrD2p1 	 
    	  
    const std mHpaYXfOsuVr3FUay39Ni 	 
    	vector mAg3pV2BnIdWvGDAHS6XN 	 
    	 cv mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
Point2f my3AH5NdFqRzLJYNB6vD1 	 
    	  
    		   
     
  & _16998118202926652486, cv mksbF6by6qnptUpJcoS3c 	 
    	  
    		  Point3f& _6807035520661505487 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
     
      myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
 
       cv mHpaYXfOsuVr3FUay39Ni 	 
  Point2f _8396213235373312360 mMULkK_hCAwRUBiSrD2p1 	 
    	  const cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
     
 
  Point3f& _46082543365551796, const cv mT5QkV9DFX1GDx2hwjESN 	 
    Point3f& _46082543365551795 mjUzUDAZSLiFZyxZqKeCh 	 
     msMAjv0u65PTGuZJqjppv 	 
    	  
    		   
     
     
 
  
        me1RdxjH4BmhsvUgZmJ_n 	 
    	  
    		_8160328761135174279 mNQC69AzhHy9jDSqnR4rG 	std mjLSF2MxFpKug67geZFRj 	 
   vector mneuHdaa4v6NnVM25bgXO 	 
    	  
    		   
 cv min5lKhSVWtXKx_RlVkNq 	 
 Point2f mpbd2v5irTp0SZEDScz2P 	 
    	  
    		   
      _175247760141, std mksbF6by6qnptUpJcoS3c 	 
    	vector mmM3130WhDQoYKhJxw_Xq 	 
    	  
    		   
     
   cv mckUV16HU9sHm9uZdiCqS 	 
    	  
 Point2f mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
     
& _11093822299329, const cv mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
     
 
  Mat& _16987817484368171524,
                          const cv mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    	Mat& _16988745799786462721 mno1HJJeAIDaElX_e8_E2 	 
    	  
    		   
     
     
 
  	 mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		   
       
        ms4jntDGIeDxNRjsn2Eq7 	 
    	  
 _13365150943186347431 mldBjQcmGr8eIRD1GvcbS 	 
    	  
   cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    		   
  Size _4339048708451217590 mno1HJJeAIDaElX_e8_E2 	 
    const mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		   
 
       
        mP1YvLB8R0up5_mPvG05E 	 
    	  
    		  _2048331705952164624 mSfn1rgQgnURKtReGFFxm 	 
    	  
    		   
     
     
 
  	  msMAjv0u65PTGuZJqjppv 	 
    	  
  
       
       template  mAg3pV2BnIdWvGDAHS6XN 	typename T mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
     
 
        mS1cTnkFkfP7nyOzO1oR1 	 
   _17229649132943359639 mvRNdf8YwY3ixuLJl_rX8 	 std mksbF6by6qnptUpJcoS3c 	 
    	  
    		 vector mAg3pV2BnIdWvGDAHS6XN 	 
T mY0dqBtGIQeIDQkZWTVBa 	 
    	  
    		   
     & _3005399811171241833, const std miUQ782fOUPhRLSezoKaH 	 
    	  
    		   
     
     
 
vector mAg3pV2BnIdWvGDAHS6XN 	 
    	  
    		   
     
     
 
  	bool moHThLiVDw2yJeZ0EL9So 	& _16997208802817240490 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		 
        mlOdFLXaGOYUjivxD9wX5 	 

           
           size_t _18140367232096151754  mOjeFEIfCRgh8UuNv025K 	 
    	  
    	 0 mYCDBBfn03HaGvoHBxAMq 	 
    	  
    		   
     
     
 
  	
            mAUFdFhd86lS580n0lcXL 	 
    	  
    		   
     
     
 
  	  m_IHI_fVc_q1bZjzyVqrm 	 
    	  
    		   
 size_t _2654435874  mX2gazk4jNHcV_njxWdEu 	 
    	  
 0 mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
     
     
 
 _2654435874  mBgtqJZzfIHrUcGoHAQCw 	 
    	  
    		   
     
   _16997208802817240490.size mM4ARjIPwLfdr_qsL8eAk 	 
     myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
   _2654435874 mlNbIP19t8qNuxt2d_OKP 	  mevXm56_YBOEgMhtXHLr_ 	 
    	  
  
            mvV7vhwmLWYXCorBaZ70t 	 
    	  
    		   
                mCkrrTINJASa6svj4U3ww 	 
    	  
    		   
  m_IHI_fVc_q1bZjzyVqrm 	 
    	  
    		 mD3Q_6lQefg81tjS09GM9 	 
    	  
    		   
     
     _16997208802817240490 mye5VOdwJN7t9cn3K3k8A 	 
    	_2654435874 mrDmgRp9h0Dh4BUsSXIlh 	 
    	  
    		   
     
     
 
  	  mEFEjzuP6MMi7DCTCZFS6 	 
    	  
    		   

                mknoSWMLUaR06YtBqtgam 	 
    	  
    		   
     
     

                    mQTtOc2wBdPlhUpHJs80J 	 
    	  
     mNQC69AzhHy9jDSqnR4rG 	 
  _18140367232096151754  mWSSvsqNssy8ptET_bJkM 	 
    	  
     _2654435874 mi7RcOMDzpCM_fd0YYDqB 	 
    	  
    		   
     
     
 
 
                       _3005399811171241833 mgFSwG5Qfn_BLmntY2X0C 	 
    	  
  _18140367232096151754 mRfKMxlL2tWQuVdK1eEze 	 
      mGGBlKcUhaQe41o1BnIkF 	 
    	  
 _3005399811171241833 mUXyv8dbk5ppT_acPhWw1 	 
    _2654435874 mepnG7ntKnXufkqRWW9z6 	 
    	  
    	 mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
     
     

                   _18140367232096151754 mlNbIP19t8qNuxt2d_OKP 	 
    	  mbJpyUK6FpvvNSFdbJncQ 	
                mRSe1JGN0drSxJSLXeFPv 	 
    	  
    		   
     
     
 

            miz1KMizYV2R1rRtcNjOS 	 
    	  
    
           _3005399811171241833.resize mjRKZlohcMYNnjTvtQdAO 	 
_18140367232096151754 mEFEjzuP6MMi7DCTCZFS6 	 
    	  
    		   
  mbJpyUK6FpvvNSFdbJncQ 	 

        mdQapdU_WoQv_sTc08Goq 	 
    	  

       template  mneuHdaa4v6NnVM25bgXO 	 
    	typename T mgjPUJwxp8V34r5ZRwn7u 	 
    
        mByUtXVZly0Au2emMwRAr 	_9674227328620005286 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
   std mHpaYXfOsuVr3FUay39Ni 	 
   vector mAg3pV2BnIdWvGDAHS6XN 	 
    	  
    		   
   std mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
     
 
  	 vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		   
     
     
 
  T mwUhWVOdu9fDyVZjtEyuZ 	 
    	  
    		   
     
     
 & _175247760981, std mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
 vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    		   
     
     
T mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
 & _2654435887,  mVhYWVEiqGfed8jjftJ1e 	 
    	  
    	_3005399601921486099  mUJURq86_xVTlgOXdOyA2 	 
    	  
    		   
     
     
 
   false mno1HJJeAIDaElX_e8_E2 	 
    	  
    		   
     
     
 
        mkjkEVFnl42KhUvXppZqI 	 
    	  
    		   
   
            mwhUA7Xg7QgUXMl3iamcW 	 
    	  
  m_IHI_fVc_q1bZjzyVqrm 	_3005399601921486099 mi_qPWMeKXy2V35xlgf6U 	 

               _2654435887.clear mmo6NathgJbdjMSVDtQp7 	 mdOAGhzyWotAgsCpitefm 	 

            mDlUKBPzOfrAfFwjb9nhp 	 
    	  
    		 m_IHI_fVc_q1bZjzyVqrm 	 
    size_t _2654435874  myDhGU99kOFzHFv3QjOyw 	 
    	  
    		   
   0 mdOAGhzyWotAgsCpitefm 	 
    	  
 _2654435874  mmM3130WhDQoYKhJxw_Xq 	 
    	  _175247760981.size mmo6NathgJbdjMSVDtQp7 	 
    	  
    		   
     
      msMAjv0u65PTGuZJqjppv 	 _2654435874 msUUcxVD5iFm0snrtwlKp 	 
   mswZzmsb_awITT3YY34kR 	 
    	  
    		   
     
     
 
  	 
                mG1rhlQsW6fk6GBUyGmwX 	 
    	  
  mK8B3zN6mQAB0xYXFlxGO 	 
  size_t _2654435875  mOjeFEIfCRgh8UuNv025K 	 
    	  
    		   
   0 mYCDBBfn03HaGvoHBxAMq 	 _2654435875  mP7sdPnZQLOU0BFRsWdBb 	 
    	  
    		 _175247760981 maw3RyPThWckVCHfhwxdL 	 
    	  
    		   
     
     
 
  	_2654435874 mRfKMxlL2tWQuVdK1eEze 	 .size mSfn1rgQgnURKtReGFFxm 	 
    	  
    		   
     
     
 
  	 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
     
     
  _2654435875 mxolFRMUnTdXqvO1SqV6i 	 mi7RcOMDzpCM_fd0YYDqB 	 
 
                   _2654435887.push_back mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     _175247760981 miRDtKlwqk8TF7Sw9l2PW 	 
    	  
    		   
     
  _2654435874 mRfKMxlL2tWQuVdK1eEze 	 
    	  
    		   
     
     
 
 mUXyv8dbk5ppT_acPhWw1 	 
_2654435875 maY4wzN767Gym8jISz779 	 
    	  
    		   
     mswZzmsb_awITT3YY34kR 	 
    	  
    		   
     
     
  mdOAGhzyWotAgsCpitefm 	 
    	  
  
        mccmI7w001g5ij0yS_Brh 	 
    	  
    		   
     
 
        std mS3XAgUx15FZSKmqI0EH2 	 
    	vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    		   
 cv mT5QkV9DFX1GDx2hwjESN 	 
    Mat mY0dqBtGIQeIDQkZWTVBa 	 
    	  
    		   _14234691456098337398 msMAjv0u65PTGuZJqjppv 	 
    	  
    		  
         mbEgSz1MPCDJfiXl8mzvB 	 
    	   _1548619269531313217 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     
MarkerCandidate &_706246351566300,  munHuTw8Uzq5NKBMuDnpp 	 
    	  
_706246308256699 mclEcmEc3AtXuiRBOKWdo 	 
    	  
    1 mevXm56_YBOEgMhtXHLr_ 	 
    	  
   mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
    
         mi72YIz1J1bS8NQxGg9SU 	 
    	  
     _14028278894506040778 mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
     std mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
   vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		   
     
     
 
  std miUQ782fOUPhRLSezoKaH 	vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    		cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
  Point2f mzCpQW3fpqEdo67JRhyP6 	  mpbd2v5irTp0SZEDScz2P 	 
    	  
    & _11306931217450568291, cv mUigKFxK8tUu2fyk4rKD6 	 
  Size _13071343076011237770  mi_qPWMeKXy2V35xlgf6U 	 
    	 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
   
         myqlssGlFKNiMp4ByT24b 	 
    	  
    		   
     
     
 
  	 _14028278894506040778 mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   std mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
 vector mP7sdPnZQLOU0BFRsWdBb 	Marker my3AH5NdFqRzLJYNB6vD1 	 
    	  
  & _11306931217450568291, cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
Size _13071343076011237770  mi_qPWMeKXy2V35xlgf6U 	 
    	  
     mMU0oJjiwMSWER83Yoiud 	 

        mQ_6zyV0kv3_EINtoxDwr 	 
    	  
  _11672520815028075718 mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   
     
std miUQ782fOUPhRLSezoKaH 	 
    	  
    		   
     
   vector mneuHdaa4v6NnVM25bgXO 	 
    	  
    		   
     
     
 
  cv mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
     
 
  	Mat mxKAKWewVfJZvgXmZSukB 	  &_3654758241385509439,const cv min5lKhSVWtXKx_RlVkNq 	 Mat &_706246308194599, mw6boItfhSsRCkohfG04h 	 
_6807036689599407548 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
   mYCDBBfn03HaGvoHBxAMq 	
       std mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
  vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		   
  aruco miUQ782fOUPhRLSezoKaH 	 
 MarkerCandidate moHThLiVDw2yJeZ0EL9So 	 
    	  
    		   
    _11288135742209909849 mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
const cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
     
 
  Mat  & _46082544221278757,  mXXqlktbFRNtTuOoWVQQz 	 
    	  
_15719809291399335005,  mXXqlktbFRNtTuOoWVQQz 	 
 _15719809291399335002, mVhYWVEiqGfed8jjftJ1e 	 
    	  
    		   
     
_46082543269539599,cv mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   
     
     
 
 Mat &_17600033834179186607 mX_72QhckNqIVHutc7sQK 	 
    mD07x3flmZMPVC6kwqG6P 	 
    	  
    		   
     
     
 

       std mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
 vector mBgtqJZzfIHrUcGoHAQCw 	 
    	  
    		   
aruco mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
  MarkerCandidate my3AH5NdFqRzLJYNB6vD1 	 
     _11288135742209909849 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
 const cv mjLSF2MxFpKug67geZFRj 	 
    	  
    		  Mat &_46082544231248938 mi7RcOMDzpCM_fd0YYDqB 	 
    	  
    		   
     
     
  myrZFqGRBYNF96ParCD6U 	 
    	  
   
       std mjLSF2MxFpKug67geZFRj 	 
    	  
vector mP7sdPnZQLOU0BFRsWdBb 	 
    	  
    		 aruco mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
     
     
 MarkerCandidate mtLxDwO7hU_6urkNqRBHh 	 
    	  
    		   
     
     
  _17990657514663812703 mlamOYHCP2faX0Lq_03Ax 	      std mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
     
 
 vector mcuNgJDAvPmo9ozTKSv_U 	 
    	  
    		   
     
     
 
  	  MarkerCandidate mpbd2v5irTp0SZEDScz2P 	 
    	  
    		   
     &_13899933296976059300,cv mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		 Size _4138612494050387097 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
     
   mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
    
       std mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		  cv mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
   Mat mtLxDwO7hU_6urkNqRBHh 	 
    	  
    		   
     
    _16594497104544919971 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
       std mHpaYXfOsuVr3FUay39Ni 	 
    	vector mlTXHwu3F3CXHHjryOJHR 	 std mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   
     
   vector mneuHdaa4v6NnVM25bgXO 	MarkerCandidate moHThLiVDw2yJeZ0EL9So 	 
    	  
    		   
     
     
 
  	   mpbd2v5irTp0SZEDScz2P 	 
    	  
   _8381292230366782771 myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
     
 
       
       std mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		vector mneuHdaa4v6NnVM25bgXO 	 
    	  
    		   
     
     
 
  	 MarkerCandidate mgjPUJwxp8V34r5ZRwn7u 	 
    	  
    		   
     
  _3822229300092794986 mVlbuMLWi_vwpED0hDKIw 	
       std mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		  vector mP7sdPnZQLOU0BFRsWdBb 	 
    	  
    		   
     Marker mnbIWy6z9Pe9uJP5EqsFX 	 
    	  
    		  _6872264293741719360 mMU0oJjiwMSWER83Yoiud 	 
   
       std miUQ782fOUPhRLSezoKaH 	 
    	  
    		   
map mP7sdPnZQLOU0BFRsWdBb 	 
    	  int,int mfDtAZ5HSHH1oUlJGGIlZ 	 
   _10242768842256594623 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
       
        mVBw_rTkATYMOTRmsNe_B 	 
    	  
    		   
     
     _10891860653827325848 mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
     
     
 
  cv mAvRcTPhbmN2xPSE_k1Fp 	 
    	  Mat& _175247760141, std mT5QkV9DFX1GDx2hwjESN 	 
    	vector mlTXHwu3F3CXHHjryOJHR 	cv mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   Point mfDtAZ5HSHH1oUlJGGIlZ 	 
& _18431075518103406877, cv mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
Scalar _46082574599890393,  mP1YvLB8R0up5_mPvG05E 	 
    	  
    		   
 _15593361063139481920 mX2gazk4jNHcV_njxWdEu 	 
    	  
    		   
     
     
 
  	1 mno1HJJeAIDaElX_e8_E2 	 
    	  
    		   
     
     
 
 msMAjv0u65PTGuZJqjppv 	 
    	  
    		   
     

        mQ_6zyV0kv3_EINtoxDwr 	 
    	  
 _13747571233701806900 mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
 Mat& _175247760141, std mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
 vector mmM3130WhDQoYKhJxw_Xq 	 
    	  
    		   
     cv mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
  Point my3AH5NdFqRzLJYNB6vD1 	 
    	  
    		   
     
     
 
  	& _6806985045552225970, cv mUigKFxK8tUu2fyk4rKD6 	 
    	 Scalar mi7RcOMDzpCM_fd0YYDqB 	 
   mdOAGhzyWotAgsCpitefm 	 
    	  

        mVBw_rTkATYMOTRmsNe_B 	 
  _10815521206485692603 mlamOYHCP2faX0Lq_03Ax 	 
    	  
    		   
     
 cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
 Mat _46082544221278757, std mUigKFxK8tUu2fyk4rKD6 	 
    	 vector mB2r0UBRPAxGnYwegALlI 	 
    	  
    		   
     
std mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
     
  vector mAg3pV2BnIdWvGDAHS6XN 	 
    	  
    		   
     cv mS3XAgUx15FZSKmqI0EH2 	 
    	  Point mJpQJFURUc57_1UwCTPvr 	 
    	  & _16940362843683299562 mXktWNzMmHZAFNamlC6GA 	 
    	  
    		   
     
     
 msMAjv0u65PTGuZJqjppv 	 
    	  
  
        mVBw_rTkATYMOTRmsNe_B 	 
    _5695532306146282654 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
 cv mksbF6by6qnptUpJcoS3c 	 
    	  
    		   
     
 Mat _11093822299329, const std mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
    vector mneuHdaa4v6NnVM25bgXO 	 
    	  
Marker mgjPUJwxp8V34r5ZRwn7u 	 
    	  
    		   
     
  & _6807036698426592110 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
     
 
       enum ThreadTasks  mECAa9sgu7USEtdxuKwtx 	 
    	  
    		   
     
     THRESHOLD_TASK,ENCLOSE_TASK,EXIT_TASK miz1KMizYV2R1rRtcNjOS 	 
    	  
    		   
     
   mh8F2krMXRlx_4xzTdoOU 	 
 
            muyiQYiSOQfifaTNSSeCM 	 
    	  
    		   
   _15785113844694797795 mzViPhIynHrdcovjL0yxX 	 
    	  
    		   
     
    
                mAuUYEOm2BbWF6IJcF4pn 	 
    	  
    		   
     
     
 _9830224992155182763,_13074680784567168978 mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
     
 
  	 
                mXXqlktbFRNtTuOoWVQQz 	_13074680779112612408,_13074680779112612409 mMU0oJjiwMSWER83Yoiud 	
               ThreadTasks _1012033135676957631 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
     
     
 

            mUJS382SpQZsi10CwBsIS 	 
    	  
    		   mh8F2krMXRlx_4xzTdoOU 	 
  
            me1RdxjH4BmhsvUgZmJ_n 	 
 _1434268935998653744 mzZN1INodhXdUd04UijoI 	 
    	 myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
    
           
           template  myAWMCcyr9KnmYFUOoI97 	 
    	  
    		  typename T mxKAKWewVfJZvgXmZSukB 	 
    	  
    		   
     
     
 
  	 
            mAzZNYMd99RgL7yTvR9_F 	 
    	  
    		   
     
     
 
  	_11052497071100241849
            mkjkEVFnl42KhUvXppZqI 	
           public:
               T _3970747861761939044 mmo6NathgJbdjMSVDtQp7 	 
    	
                mzViPhIynHrdcovjL0yxX 	 
    	  
    		
                   std mAvRcTPhbmN2xPSE_k1Fp 	unique_lock mO2HwsX6Gi0Nsj_ziKTKW 	 
    	  
    		   
     
     
 std miUQ782fOUPhRLSezoKaH 	 
    	 mutex mnbIWy6z9Pe9uJP5EqsFX 	 
    	   _46082575883046243 mMULkK_hCAwRUBiSrD2p1 	 
  _11363171807939138622 mi_qPWMeKXy2V35xlgf6U 	 
    msMAjv0u65PTGuZJqjppv 	 
    	 
                   while  mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
     
     
 
  	_11363171959283351776.empty mmUKE2NIlpdAbdSvw43EJ 	 
    	  
 mno1HJJeAIDaElX_e8_E2 	 
  
                    mYwjl00gOK3Vja3UkLMIP 	 
    	  
    		   
     
     
 

                       _18196901513633830848.wait mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     
 _46082575883046243 mswZzmsb_awITT3YY34kR 	 
    	  
    		    mh8F2krMXRlx_4xzTdoOU 	
                    miz1KMizYV2R1rRtcNjOS 	 
  
                    ma4mt6LbiKt84kAFpQxO9 	 
  _706246308731687  mXhT_hgo_Q16Rxj01zJwG 	 
    	  
    		   
   _11363171959283351776.front mZ1vlGA1DxtdKm7CKLuCu 	 
    	  
    		   
      myrZFqGRBYNF96ParCD6U 	
                   _11363171959283351776.pop mZ1vlGA1DxtdKm7CKLuCu 	 
    	  
    		  mbJpyUK6FpvvNSFdbJncQ 	 
    	  
  
                    mvvh6qusT2GXh0DkHopPr 	 
    	  
    		 _706246308731687 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
     
     
 

                mcBnPnpY1bM8uBYh6HUzl 	 
    	  
    		   
   
                mVBw_rTkATYMOTRmsNe_B 	 
    	  
    		 _16400045516394125907 mvRNdf8YwY3ixuLJl_rX8 	 
    	  
    		   
     
     const T& _706246308731687 mX_72QhckNqIVHutc7sQK 	 
    	  
    		   
     
  
                mvV7vhwmLWYXCorBaZ70t 	 
    	  
    		   
     
    
                   std mT5QkV9DFX1GDx2hwjESN 	 
    	  
   unique_lock mcuNgJDAvPmo9ozTKSv_U 	 
  std mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
     
  mutex mpbd2v5irTp0SZEDScz2P 	 
    	  
    		   
    _46082575883046243 mlQFK8bzD5oJXCxBJV7sY 	 
    	 _11363171807939138622 mno1HJJeAIDaElX_e8_E2 	  msMAjv0u65PTGuZJqjppv 	 
    	  
    		   

                   _11363171959283351776.push mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
_706246308731687 mXktWNzMmHZAFNamlC6GA 	 
    	  
    		   mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
     

                   _46082575883046243.unlock mSfn1rgQgnURKtReGFFxm 	 
    	  
    		   mdOAGhzyWotAgsCpitefm 	
                   _18196901513633830848.notify_one mWGK5Hy854bE4U0Mg0Ybu 	 
    	  
    		   
     
     mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
     
 
                mzf6azcCC18atKCW8jv7f 	 
    	  
    		   
   
               size_t _16400045516395142620 mZ1vlGA1DxtdKm7CKLuCu 	 
    	  
                mlOdFLXaGOYUjivxD9wX5 	 
    	  
                   std mHpaYXfOsuVr3FUay39Ni 	 
    	  unique_lock myAWMCcyr9KnmYFUOoI97 	 
    	  
   std mckUV16HU9sHm9uZdiCqS 	 
    	 mutex mY0dqBtGIQeIDQkZWTVBa 	 
    	   _46082575883046243 mQQpcOreXo7BwJDtiLf6W 	 
 _11363171807939138622 mK9SI2tuEHd6tqoKSYbJi 	 
    	  
    		   
    mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
     
 
 
                   size_t _2654435884 mX2gazk4jNHcV_njxWdEu 	 
_11363171959283351776.size mwPtUuZDgsaCWLEN2d2o8 	 
    	  
    		   mMU0oJjiwMSWER83Yoiud 	 
   
                    mvvh6qusT2GXh0DkHopPr 	 
    	  
    		   
     
_2654435884 mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
 
                mRSe1JGN0drSxJSLXeFPv 	 
    	  
  
           private:
               std mckUV16HU9sHm9uZdiCqS 	 
    	  
    		   
     
    queue mB2r0UBRPAxGnYwegALlI 	 
    T moHThLiVDw2yJeZ0EL9So 	 
 _11363171959283351776 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
     
     
 
  
               std mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     mutex _11363171807939138622 mYCDBBfn03HaGvoHBxAMq 	 

               std mUigKFxK8tUu2fyk4rKD6 	 
    	  
 condition_variable _18196901513633830848 myrZFqGRBYNF96ParCD6U 	
            mdQapdU_WoQv_sTc08Goq 	 
    	  
    		   
     
 msMAjv0u65PTGuZJqjppv 	 
    	  
    		   
     
     
 
  
           _11052497071100241849 mmM3130WhDQoYKhJxw_Xq 	 
    	  
    		   
     
     
 
 _15785113844694797795 mfDtAZ5HSHH1oUlJGGIlZ 	 
    	  
    		   
     _16684997543815802068 mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		   
     
     
 
  
            mMmsNGhTP939mIPZ2iFST 	 
    	  
 _10874168409609149361 mK8B3zN6mQAB0xYXFlxGO 	 
    	  
    		   
     
 aruco mAvRcTPhbmN2xPSE_k1Fp 	 Marker &_3005399795337363304,cv min5lKhSVWtXKx_RlVkNq 	 
  Mat _16130258770755438296 mOjeFEIfCRgh8UuNv025K 	 
    	  
    		   
  cv mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
    Mat mwPtUuZDgsaCWLEN2d2o8 	 
    	  
    		   
     
 ,cv min5lKhSVWtXKx_RlVkNq 	 
    	  
    		 Mat _16940388568071981096 myDhGU99kOFzHFv3QjOyw 	 
    	  
    		   
     
 cv mjLSF2MxFpKug67geZFRj 	 
    	 Mat mSfn1rgQgnURKtReGFFxm 	 
    	  
    		   
  mi7RcOMDzpCM_fd0YYDqB 	 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
 
           inline  mJu8rH9ch6s8uIUBEA4QJ 	 
    	  
    		   _16717062465605327948 mvRNdf8YwY3ixuLJl_rX8 	 
    	  
    		 cv miUQ782fOUPhRLSezoKaH 	 
    	  
    		   
     
 Point &_2654435881,cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
    Point2f&_175247759516 mX_72QhckNqIVHutc7sQK 	 
    	  
    		   
     
 mvV7vhwmLWYXCorBaZ70t 	 
    
                mJ1Z8GSPTaJVFODk7UGea 	 
    	  
    		   
     
_175247762917 mGGBlKcUhaQe41o1BnIkF 	 
    	  
    		   
 _2654435881.x-_175247759516.x mbJpyUK6FpvvNSFdbJncQ 	
                mJ1Z8GSPTaJVFODk7UGea 	 
    	  
    		   _175247762916 mX2gazk4jNHcV_njxWdEu 	 
    	  
    		   
 _2654435881.y-_175247759516.y mYCDBBfn03HaGvoHBxAMq 	 
    	  
    		   
 
                mOcjjgyUyDEe51laoqeGm 	 
 _175247762917*_175247762917+_175247762916*_175247762916 myrZFqGRBYNF96ParCD6U 	 
    	  
    
            miz1KMizYV2R1rRtcNjOS 	 
    	  
    		   
    
            mYJJZNT6RsQUQcGvcjw6s 	 
    	  
    		   
     
  _11754215234869264027 mclEcmEc3AtXuiRBOKWdo 	 
    	  
    		   
     
-1 mD07x3flmZMPVC6kwqG6P 	 
    
    mV1XXE5UPf1brn2rkEd_L 	_4191776636076832364 mBduW7dqSuFrUAvwh7kHo 	 
    	  
    		   
     
  
        myqlssGlFKNiMp4ByT24b 	 
    	  
    		   
     
 _2329825236964917351 mQQpcOreXo7BwJDtiLf6W 	 
    	  
     const std mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
     
     vector mAg3pV2BnIdWvGDAHS6XN 	 
    	  
    		   
 cv mjLSF2MxFpKug67geZFRj 	 Point2f mxKAKWewVfJZvgXmZSukB 	  &_2654435878 mXktWNzMmHZAFNamlC6GA 	 
    	   mknoSWMLUaR06YtBqtgam 	 
    	  
    		   
     
     
 

            _2462542741146301388 mXhT_hgo_Q16Rxj01zJwG 	 
    	  
   _2654435878 mdOAGhzyWotAgsCpitefm 	 
    	  
    		   
     
   
           _16317296749090388849  mUJURq86_xVTlgOXdOyA2 	 
     _2654435878 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   1 mnN8tONujwWIvopGKHc6C 	 
    	.x - _2654435878 mye5VOdwJN7t9cn3K3k8A 	 
    	  
    		   
0 mnN8tONujwWIvopGKHc6C 	 
    	  
    		   .x mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
     
     

           _16317296749090388848  mX2gazk4jNHcV_njxWdEu 	 
    	  
    		   _2654435878 maw3RyPThWckVCHfhwxdL 	 
    	  
    		   
     
     1 mRfKMxlL2tWQuVdK1eEze 	 
    	  
    		   
     
     
 
  	 .y - _2654435878 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   
     
0 maY4wzN767Gym8jISz779 	 
    	  
    		   
     
.y mYCDBBfn03HaGvoHBxAMq 	 
    	  
    		   
     
 
           _16317296749090380307  mX2gazk4jNHcV_njxWdEu 	 
    	  
  _2654435878 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   
     
     
 
  	 2 mnN8tONujwWIvopGKHc6C 	 
    	  
    		   
     
    .x - _2654435878 maw3RyPThWckVCHfhwxdL 	 
    	  
    		   0 mpDqyj5NDVnikUB0G2KXc 	 
    	  
    		  .x mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
           _16317296749090380306  mclEcmEc3AtXuiRBOKWdo 	 
    	  
    		  _2654435878 mye5VOdwJN7t9cn3K3k8A 	 
    	  
    		 2 mBoBygdTxOAro2IxSXLIy 	 
    	  
    		   
.y - _2654435878 mr6dwZ1e1YrZk_9VHOVOR 	 
    	  
    		   
     
     
 
  	 0 mRfKMxlL2tWQuVdK1eEze 	 
  .y mMU0oJjiwMSWER83Yoiud 	 
    	  

           _10148430786700162661 mRUhvrauugCIk8ZFUtFF5 	 
    	  
_2654435878 mr6dwZ1e1YrZk_9VHOVOR 	 
    0 mgbhB0EhABmFE4YiYt_F7 	 
    	  
     mD07x3flmZMPVC6kwqG6P 	 
    _10148430786700162660 mXhT_hgo_Q16Rxj01zJwG 	 
    	  
    		   
  _2654435878 mZO_0K9kNXGE4qJdhidUD 	 
    	  
    		   
     
     1 mpDqyj5NDVnikUB0G2KXc 	 
    	  mbJpyUK6FpvvNSFdbJncQ 	 
    	 _10148430786700162662 mRUhvrauugCIk8ZFUtFF5 	 
    _2654435878 mJF_EsQxNKzgNgkUPkSWC 	 
    	  
    		   
     2 mBoBygdTxOAro2IxSXLIy 	 
    	  
   myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
     
           _3979714351743309560 myDhGU99kOFzHFv3QjOyw 	 
    	  
    		   
     
     
 
 _12796226555186336887 mwPtUuZDgsaCWLEN2d2o8 	 
    	  
    		   
     
     
 
  myrZFqGRBYNF96ParCD6U 	 
           _14033480492370290249 mGGBlKcUhaQe41o1BnIkF 	 
    	  
    		   
     
     
 
  cv mS3XAgUx15FZSKmqI0EH2 	 
   Point2f mNQC69AzhHy9jDSqnR4rG 	 
    	  
    		   
     
     
 
 0,0 mK9SI2tuEHd6tqoKSYbJi 	 
    	  
    		   
     
    mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
  
            ms1aWWjXC6Bx6IN3cqObV 	 
    	  
   auto &_2654435881:_2462542741146301388 mno1HJJeAIDaElX_e8_E2 	 
    	  
    		   
     
     
 
 
               _14033480492370290249 mLyMqhhnK6n0OQstUYG1v 	 
    	  
    	_2654435881 mh8F2krMXRlx_4xzTdoOU 	
           _14033480492370290249 mkA9GKO_6AMEHDxbOk3Ga 	 
    	  
    		   
1./4. mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
 
        miz1KMizYV2R1rRtcNjOS 	 
   
        ml0hurHdmF0d85GpxvtHx 	 
    	 _14033480569961022451 mldBjQcmGr8eIRD1GvcbS 	 
    	  
    		   
     
  const cv mckUV16HU9sHm9uZdiCqS 	 
 Point2f &_2654435881 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
     
     
 
  	 const mBduW7dqSuFrUAvwh7kHo 	 
    	 
            mKPdnS09u_wtngxINal4U 	 
   _16985942626542851460 mldBjQcmGr8eIRD1GvcbS 	 
    	  
    _2462542741146301388 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    0 maY4wzN767Gym8jISz779 	 
    	  
    		   
     
     
 
  	 ,_2462542741146301388 miRDtKlwqk8TF7Sw9l2PW 	 
    	  
    		   
 1 mrDmgRp9h0Dh4BUsSXIlh 	 ,_2654435881 mEFEjzuP6MMi7DCTCZFS6 	 
    mlTXHwu3F3CXHHjryOJHR 	 
    	  
    		   
     
     
 
 0 mXktWNzMmHZAFNamlC6GA 	return  false mYCDBBfn03HaGvoHBxAMq 	 
    	  
            mAYXYBgyHj3X_Dd2pJZFe 	 
    	  
    		   
   _16985942626542851460 mMULkK_hCAwRUBiSrD2p1 	 
    	  _2462542741146301388 mgFSwG5Qfn_BLmntY2X0C 	 
    	  
    		1 mgbhB0EhABmFE4YiYt_F7 	 
    	 ,_2462542741146301388 mZO_0K9kNXGE4qJdhidUD 	 
    	2 mgbhB0EhABmFE4YiYt_F7 	,_2654435881 mi7RcOMDzpCM_fd0YYDqB 	 
    	  
    		    mlTXHwu3F3CXHHjryOJHR 	 
    	  
    		   
     
 0 mno1HJJeAIDaElX_e8_E2 	return  false myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
            mKPdnS09u_wtngxINal4U 	 
    	  
    		  _16985942626542851460 m_IHI_fVc_q1bZjzyVqrm 	 
    	  
  _2462542741146301388 mJF_EsQxNKzgNgkUPkSWC 	 
    	  
    		   
     
     
 2 mr3z8JHQwMcj2xXE4THD3 	 
,_2462542741146301388 mr6dwZ1e1YrZk_9VHOVOR 	 
    	  
    		   
     
  3 mrDmgRp9h0Dh4BUsSXIlh 	 
    	  
    		   
     
     
 
  	 ,_2654435881 mswZzmsb_awITT3YY34kR 	 
    	  
    		   
      mO2HwsX6Gi0Nsj_ziKTKW 	 
    	  
    		   
     
    0 mi_qPWMeKXy2V35xlgf6U 	 
    	  
    	return  false mYCDBBfn03HaGvoHBxAMq 	 
    	  
    	
            mgeJSmXLhlP6TNXhqZxir 	 
 _16985942626542851460 mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
     
     
 
  	 _2462542741146301388 mr6dwZ1e1YrZk_9VHOVOR 	 
   3 mrDmgRp9h0Dh4BUsSXIlh 	 
    	  
    		   
     
  ,_2462542741146301388 mye5VOdwJN7t9cn3K3k8A 	 
    	  
    		   
    0 mRfKMxlL2tWQuVdK1eEze 	 
    	  
   ,_2654435881 mevXm56_YBOEgMhtXHLr_ 	 
    	  
    mBgtqJZzfIHrUcGoHAQCw 	 
    	  
    		   
     
     
0 mK9SI2tuEHd6tqoKSYbJi 	 
    	  
    return  false mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
     
            mzKNJLXvtvNUiRlFdYl86 	 
    	  
    		   
 true myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
     
 
  	
        mdQapdU_WoQv_sTc08Goq 	 
  
       cv miUQ782fOUPhRLSezoKaH 	 
    	  
Point2f _2320218127778479373 mWGK5Hy854bE4U0Mg0Ybu 	 
    	  
    		   
     
     
 
const mBduW7dqSuFrUAvwh7kHo 	 
    	  
    		   
     
  return _14033480492370290249 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
     
 miz1KMizYV2R1rRtcNjOS 	 
    	  
    		   
     
 
        mmcPNoeYt4rZGfwjHpq3k 	 
    	_2462547792112398716 mZ1vlGA1DxtdKm7CKLuCu 	 
    	  
    		   
     
     const mYwjl00gOK3Vja3UkLMIP 	 
    	  
    		   
     
 return _3979714351743309560 mVlbuMLWi_vwpED0hDKIw 	 
    	  
    		   
     
     
 
  	  mcBnPnpY1bM8uBYh6HUzl 	 
    	  
    		   
     
     
 
 
        mMdtcRR7f77NuQu_fr3jJ 	 
    	 _12796226555186336887 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
   mX_72QhckNqIVHutc7sQK 	 
    	  
  const
        mYwjl00gOK3Vja3UkLMIP 	 
    	  
 
           
           cv mAvRcTPhbmN2xPSE_k1Fp 	 
    	  
    		   
     
     
 Point2f _11093821929003  mGGBlKcUhaQe41o1BnIkF 	 
 _2462542741146301388 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   
     
     
 1 mgbhB0EhABmFE4YiYt_F7 	 
    	  
   - _2462542741146301388 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   
   0 mr3z8JHQwMcj2xXE4THD3 	 
    	  
    		   
     
   mh8F2krMXRlx_4xzTdoOU 	 

           cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
 Point2f _11093821929001  mOjeFEIfCRgh8UuNv025K 	 
    	  
    		   
     _2462542741146301388 mye5VOdwJN7t9cn3K3k8A 	 
    	  
 3 mnhWVfz3zH1VWcyQIB9k8 	 - _2462542741146301388 maw3RyPThWckVCHfhwxdL 	 
    	  
    		   
     
     
 0 mepnG7ntKnXufkqRWW9z6 	  msMAjv0u65PTGuZJqjppv 	 
    	  
    		   
     
     
 
  	
            mYJJZNT6RsQUQcGvcjw6s 	 
    	  
    		   
   _46082576164771657  myDhGU99kOFzHFv3QjOyw 	 
    	  
    		   
     
      fabs m_IHI_fVc_q1bZjzyVqrm 	 
_11093821929003.x * _11093821929001.y - _11093821929003.y * _11093821929001.x mX_72QhckNqIVHutc7sQK 	 
    	  
    		   
     
     mYCDBBfn03HaGvoHBxAMq 	 
    	  
    		   

           cv mT5QkV9DFX1GDx2hwjESN 	Point2f _11093821929897  mX2gazk4jNHcV_njxWdEu 	 _2462542741146301388 mUXyv8dbk5ppT_acPhWw1 	 
    1 mRfKMxlL2tWQuVdK1eEze 	 
    	  
    		   
     
     
 - _2462542741146301388 maw3RyPThWckVCHfhwxdL 	 
    	  
    		   
     
     2 mBoBygdTxOAro2IxSXLIy 	 
    	  msMAjv0u65PTGuZJqjppv 	 
    	  
    		   
           cv min5lKhSVWtXKx_RlVkNq 	 
    	  
    		   
     
Point2f _11093821929899  myDhGU99kOFzHFv3QjOyw 	 
    _2462542741146301388 mUXyv8dbk5ppT_acPhWw1 	 
    	  
    		   
     
     
3 mBoBygdTxOAro2IxSXLIy 	 
    	  
    		 - _2462542741146301388 mZO_0K9kNXGE4qJdhidUD 	 
    	  2 mBoBygdTxOAro2IxSXLIy 	 
    	  
  myrZFqGRBYNF96ParCD6U 	 
    	  
    		   

            mdtPDcYitAJmuptZI5zFq 	 
    	  
    		   
     
   _46082576164771656  mRUhvrauugCIk8ZFUtFF5 	 
    	  
    		   
     
     
 
  fabs mMULkK_hCAwRUBiSrD2p1 	 
    	  
    		   
     
     _11093821929897.x * _11093821929899.y - _11093821929897.y * _11093821929899.x mXktWNzMmHZAFNamlC6GA 	 
    	  mv0LWHXRSvGJF76ckeLfO 	 
    	  
    		   
     
     
            mvvh6qusT2GXh0DkHopPr 	 
    	  
    	 mNQC69AzhHy9jDSqnR4rG 	 
_46082576164771656 + _46082576164771657 mjUzUDAZSLiFZyxZqKeCh 	 
    	  
    		   
     
     
 
 / 2.f myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
 
        mDHWaCli8Gp2m47qfC6RO 	 
    	  
    		   

        mdtPDcYitAJmuptZI5zFq 	 
    	  
    		   
     
     
 
_16317296749090388849, _16317296749090388848 , _16317296749090380307  ,_16317296749090380306 myrZFqGRBYNF96ParCD6U 	 
    	  
    		   
     
     
 
  	
       cv mUigKFxK8tUu2fyk4rKD6 	 
    	  
  Point2f _10148430786700162661,_10148430786700162660,_10148430786700162662 mbJpyUK6FpvvNSFdbJncQ 	 
  
        mdtPDcYitAJmuptZI5zFq 	 
    	  
    		   
     
     
 
  	_3979714351743309560 mMU0oJjiwMSWER83Yoiud 	 
       cv miUQ782fOUPhRLSezoKaH 	 
 Point2f _14033480492370290249 mYCDBBfn03HaGvoHBxAMq 	 
    	  
    		  
       std mT5QkV9DFX1GDx2hwjESN 	 
    vector myAWMCcyr9KnmYFUOoI97 	 
    	  
    cv mjLSF2MxFpKug67geZFRj 	 
    	  
    		   
Point2f mxKAKWewVfJZvgXmZSukB 	 
 _2462542741146301388 mMU0oJjiwMSWER83Yoiud 	 
   
       inline  mJ1Z8GSPTaJVFODk7UGea 	 
  _16985942626542851460 mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     
 cv miUQ782fOUPhRLSezoKaH 	Point2f _175247759514,cv miUQ782fOUPhRLSezoKaH 	 
    	  
Point2f _175247759517,cv miUQ782fOUPhRLSezoKaH 	 
Point2f _2654435881 mX_72QhckNqIVHutc7sQK 	 
    	const mXUfd1VRZJk7TgY4HxOJN 	 
    	  
    		   
     

            mKrNzQ9o2OYPnNNMCiAE3 	 
    	  
      mMULkK_hCAwRUBiSrD2p1 	 
     mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
     
    _175247759514.y-_175247759517.y mK9SI2tuEHd6tqoKSYbJi 	 
    	  
    		   *_2654435881.x +  mlamOYHCP2faX0Lq_03Ax 	 
    	  
 _175247759517.x-_175247759514.x mK9SI2tuEHd6tqoKSYbJi 	 
    	  
    		   
     
     
 *_2654435881.y +  mMULkK_hCAwRUBiSrD2p1 	 
    	  
    		 _175247759514.x*_175247759517.y-_175247759517.x*_175247759514.y mX_72QhckNqIVHutc7sQK 	 
    	 mi7RcOMDzpCM_fd0YYDqB 	 
    	  
    		   
     
     
 
  	  /  sqrt mlQFK8bzD5oJXCxBJV7sY 	 
    	  
    		   
     
     
 
    mjRKZlohcMYNnjTvtQdAO 	 
    	  
    		   
     
     
 
  	 _175247759517.x-_175247759514.x mK9SI2tuEHd6tqoKSYbJi 	* mQQpcOreXo7BwJDtiLf6W 	 
    	  
    		   
     
 _175247759517.x-_175247759514.x mXktWNzMmHZAFNamlC6GA 	 
    	  
    		  + mMULkK_hCAwRUBiSrD2p1 	 
    	  
    		   
   _175247759517.y-_175247759514.y mevXm56_YBOEgMhtXHLr_ 	 
    	  
    		   
   * mQQpcOreXo7BwJDtiLf6W 	 
_175247759517.y-_175247759514.y mjUzUDAZSLiFZyxZqKeCh 	 
    	  
    		  mno1HJJeAIDaElX_e8_E2 	 
    mv0LWHXRSvGJF76ckeLfO 	 
    	  
    
        mccmI7w001g5ij0yS_Brh 	 
    	  
    
    mUJS382SpQZsi10CwBsIS 	 
    	  
    		   
     
   mVlbuMLWi_vwpED0hDKIw 	 
   
    merwTemrIm1u92wWr78Ta 	 
    	  
 _6617398332792794799 m_IHI_fVc_q1bZjzyVqrm 	 
  cv mT5QkV9DFX1GDx2hwjESN 	 
    	  
    		   
     
     
 
Mat &_175247760140,std mS3XAgUx15FZSKmqI0EH2 	 
    	  
    		   
     
vector mneuHdaa4v6NnVM25bgXO 	 
    float mgjPUJwxp8V34r5ZRwn7u 	 &_706246330550423 mi_qPWMeKXy2V35xlgf6U 	 
    	  
    		   
     
   mh8F2krMXRlx_4xzTdoOU 	 
    	  
   
    ms4jntDGIeDxNRjsn2Eq7 	 
    	  
    		   
     
     
 
 _5695532316837479313 mK8B3zN6mQAB0xYXFlxGO 	 
  std mckUV16HU9sHm9uZdiCqS 	 
    	  vector mcuNgJDAvPmo9ozTKSv_U 	 
    	  
    		   
 float mnbIWy6z9Pe9uJP5EqsFX 	 
    	 &_706246330550423 mK9SI2tuEHd6tqoKSYbJi 	 
    	 mbJpyUK6FpvvNSFdbJncQ 	 
    	  
    		   
     
     
 
  	
    mS1cTnkFkfP7nyOzO1oR1 	 
  _18048540700028965067 mMULkK_hCAwRUBiSrD2p1 	 
    	  
    		   
     
     
 
  std mHpaYXfOsuVr3FUay39Ni 	 
  vector myAWMCcyr9KnmYFUOoI97 	cv mHpaYXfOsuVr3FUay39Ni 	 
    	  
    		   
 DMatch moHThLiVDw2yJeZ0EL9So 	 
    	  
  &_6807036698572949990  mXktWNzMmHZAFNamlC6GA 	 
    	  
    		   
      mh8F2krMXRlx_4xzTdoOU 	 
    	  
    		   
     
 
   
    mRnaYj0YvtF5IFOqZNiP8 	 
    	   mv0LWHXRSvGJF76ckeLfO 	
 mDHWaCli8Gp2m47qfC6RO 	 
    	  
    		   
     
     
 
 mMU0oJjiwMSWER83Yoiud 	 
    	  
    		   
    
#endif

#ifdef _17894887532289205286
#undef  myjt6mvkBkZmcOCpyWae8 
#undef  mQ166eMFGfLjI1H4bMVQe 
#undef  miyk4IOFGYjcht0QF2wuj 
#undef  mL2_sNDksSshctgjHcO0q 
#undef  micZoto6r5upaMpq4NOR0 
#undef  mVBw_rTkATYMOTRmsNe_B 
#undef  mksbF6by6qnptUpJcoS3c 
#undef mHUowwXXMZqRohhPDQTpchWpMh75A_l
#undef  mkB7YCOyG7pVkQ21h6On1 
#undef  mX3vnsHlXLfRZ9bkxHA4V 
#undef  mBQ_c7B8rm3Q376o4iCCH 
#undef  mFmocU8IArOdg_KCyx_1c 
#undef  mkweV1NTTzZIMacsJnxiA 
#undef  mGHRNb00IOd9kbU3Lipf_ 
#undef  mFN7fRxfE_MjqHWBvjBUL 
#undef  mXhT_hgo_Q16Rxj01zJwG 
#undef  mqFhGQTAKYEhUuYwI3_Dw 
#undef  mc3w8tNmNpzQESKqferPh 
#undef mUp6tkZSOAEVx5brNaoy0c3R22aukfY
#undef  my3AH5NdFqRzLJYNB6vD1 
#undef  mY1owl0mSAIpnbwzb76u3 
#undef  mG_iM1zjmCQm7KvhbwFm4 
#undef  moQ6IW1B5Jsb_OMrna8ZR 
#undef mvOfIGxmzUATJX7YeHystvcdJ4FftZF
#undef  mc2y_S_Ev95jWdPb11shE 
#undef  mlmbOUrAHG1vv2orsm7LA 
#undef  mjLSF2MxFpKug67geZFRj 
#undef  mG68GEth4OtQ_kpzxTW0n 
#undef mbxoIBFMXQ55B6ZWf23aIL6xtSHWOwl
#undef mFUlvNRiMyiQh8aP0yuua9fodcHnOu0
#undef  mlpl5UhdUhvGJT2AHA_N4 
#undef  maUe0ImzinTwtZsBK0G3N 
#undef  mTrcEZildAmTFzcNT5WgE 
#undef  mWSSvsqNssy8ptET_bJkM 
#undef  mHc5pUtc1Cx5B0yE1HvLl 
#undef  msUUcxVD5iFm0snrtwlKp 
#undef  mv0LWHXRSvGJF76ckeLfO 
#undef  mM4ARjIPwLfdr_qsL8eAk 
#undef  mGTsJcy5DnwGJP0oULGTB 
#undef  mB2r0UBRPAxGnYwegALlI 
#undef  mwvPBY1bmAQpqbBuwi6ST 
#undef  mMmsNGhTP939mIPZ2iFST 
#undef  mFVOF_xi70xN52hJqQRiM 
#undef  mccmI7w001g5ij0yS_Brh 
#undef mMSRfewgGl8OvEwbH39eMiRDykbt4YY
#undef  mFhdGpKLQ9YjLkrPrpPpZ 
#undef  mAzZNYMd99RgL7yTvR9_F 
#undef  ms1aWWjXC6Bx6IN3cqObV 
#undef  mVyXKFTUS745QGClEsh9X 
#undef  mZfCNWHGCUXW1bPF9t3Kc 
#undef mx6Nk6byNtqIci_JlD5DoWU9LWnOmic
#undef  mN6tTuuEVRYPogdijGm4S 
#undef  mm_uCtou_ENHLI5ABGtcH 
#undef  mlmFUfuAtC3zBGydeE07t 
#undef  mP1YvLB8R0up5_mPvG05E 
#undef  mXy86FpjyFOQYfK0dtSjX 
#undef  mjUzUDAZSLiFZyxZqKeCh 
#undef  mCkrrTINJASa6svj4U3ww 
#undef  mvUZS35MDnhC41jKFsWE8 
#undef  mhJLwFMku1e2js5Yx6jyD 
#undef  mCcIKmeJ3ghGvOeT7FdSH 
#undef  miau7uedcHUonFBVnbftz 
#undef  mqrMFksA8anV6GIkIAFZj 
#undef  mxZFow1EFI7y8IieBTc7Z 
#undef  mf0xOT_zUoSyjFUCazBbY 
#undef  mJF_EsQxNKzgNgkUPkSWC 
#undef  mgfz6VstbB3AtWs29bXPT 
#undef  mWq2Z1lsS4vkcPUgLkVCC 
#undef  mUigKFxK8tUu2fyk4rKD6 
#undef  mmdgJNaGE2dbCM6TccQ56 
#undef  mEmfdY9_peBCjdAfHCwdK 
#undef  m_dRf8IJ7nmGssthXyxJS 
#undef mKEVUtf4lfr9tym6iQC8HtOfdk7IPoC
#undef  mlamOYHCP2faX0Lq_03Ax 
#undef  mRnaYj0YvtF5IFOqZNiP8 
#undef mN612iUqNRzAkEsrL9JSchf_C8zS6pB
#undef  mr6dwZ1e1YrZk_9VHOVOR 
#undef  mTj14DRd7xgEPvsp5xhPs 
#undef  mZO_0K9kNXGE4qJdhidUD 
#undef mLlx0xCI1E_Kz6hL9P6CXiMl5tQH7_v
#undef  mzJ7kyFQ9KR52c3n9YP5z 
#undef mGPxw2el7GMZwZxboGCCbFV1WDOW1vO
#undef mO81o600raQdighmjv_frOzRKuHZn4i
#undef  moQz60zhJBclWV_HhciQg 
#undef  mZ_2hNn2gGqPy6Ufj7BEj 
#undef  m_Mi4LfqL3N2Mqiwlopku 
#undef mMhuNQp5krT8JteGvDK0caUZHSR0KnN
#undef  mN9g4ghokslRh16yV8uja 
#undef  mF2LRl5jVA9F0DGGB8XA4 
#undef  mzodJn19KUZrR1nqN0_WM 
#undef  mYZvytvZoNt2UuLxQ9UIj 
#undef  mZ6DkyNJTg9K_GWPNvui7 
#undef mpjNkDPvLbegN6jypYDsrso16s5FaxX
#undef  mYQYU9Rh8MEEEKdf7havV 
#undef mg9u34KlnZTaOu3rehQ2vwSDNrcdg6X
#undef  muO2JKFnj8ckdywXF_syA 
#undef  mMULkK_hCAwRUBiSrD2p1 
#undef  mS3XAgUx15FZSKmqI0EH2 
#undef  mnODdIJiXbJxgUNOnnK7Q 
#undef  mr2LPTSpds2mNLryLeBNk 
#undef  mi72YIz1J1bS8NQxGg9SU 
#undef  mi_qPWMeKXy2V35xlgf6U 
#undef  mrmAnriVNWgIYgEGfaLki 
#undef  mk7v9nc3jEPLlniefUsH2 
#undef  mQQpcOreXo7BwJDtiLf6W 
#undef  myjbV3m7yafW0OdiN6vt5 
#undef  msoBOmJRxRp6ahCxunFVE 
#undef  mDlUKBPzOfrAfFwjb9nhp 
#undef  mVrCVBh2kC_7hyuvhHUDh 
#undef  my0vyg3fFxA29yj6XkVq9 
#undef  mauxaOW9MxCZE4anht2sd 
#undef  mHRl5FqpS347un79ntw65 
#undef  mrJ_YPPVIpp8SUzYb8Cny 
#undef mXNuNryuGZXgiIQTL_gnIEU7QTl22LL
#undef  mcyISUB4lnJEw_gJVYaVx 
#undef  me14G4J4dPr4E2p39YdUL 
#undef m_R8AWS6RGHbghdVlcnXe_gRZVB9kGu
#undef  mSzuu0DOCYBrclgJkWher 
#undef  mWtGMUHY8MC9U688CsQWq 
#undef  mPQbPFtz79XwWBcOMk2a4 
#undef  mKQa3_9CAv9S0vCMW0VYy 
#undef  mQdhFMfXoGmiFylGSosyN 
#undef  mwUhWVOdu9fDyVZjtEyuZ 
#undef  myqlssGlFKNiMp4ByT24b 
#undef  mqWvLlL9dHX0W60DLw0C3 
#undef mNuXRvW5NRIUKjBMfo2LCKPTvD66RWT
#undef  mD3Q_6lQefg81tjS09GM9 
#undef  mtLxDwO7hU_6urkNqRBHh 
#undef mlDlXb15uwaHsRhXukXLAhFE3SG2enz
#undef mUaMMT_3w_3sXjqFPvJ2OYLiwngOJEA
#undef  mI162kb4SdQzSCWMoQLFu 
#undef  mQTtOc2wBdPlhUpHJs80J 
#undef  mvV7vhwmLWYXCorBaZ70t 
#undef  mlpjKECyQS9giLDqooMp6 
#undef  mH83V9yQZ4TlJHtn2Baef 
#undef  mgIVV9mFMfUaz2AE0Fxyu 
#undef  mhdGkHwE8CFjml1_fUOhb 
#undef  me1RdxjH4BmhsvUgZmJ_n 
#undef  mr6cSlSrgFLMCsweHAbI4 
#undef  mMAmCE1MCdSdMSOx9vC1D 
#undef  mBgtqJZzfIHrUcGoHAQCw 
#undef  mWGK5Hy854bE4U0Mg0Ybu 
#undef  mfDJQZQ0abSS_V3bsHBhu 
#undef  mw6boItfhSsRCkohfG04h 
#undef  mnEte4qGIA5oly0MUXQYO 
#undef  my44kvOVt4gJv5GuZhk67 
#undef  mdTyVzgFy4_0UFy9GimmM 
#undef  mV1XXE5UPf1brn2rkEd_L 
#undef  mZIakbFljtx2rPEKsHIUr 
#undef meOQ4s6GwH6J2yIgmeqpqouma8a5KzW
#undef  mOYCJmLCpengU1n52_VC1 
#undef  mAUsQNLzfNsxysaIjhygG 
#undef  mBnZZWS5e6tIqudWqd2TV 
#undef  mzck48t73Ct4PoCk6X5U0 
#undef  mY0dqBtGIQeIDQkZWTVBa 
#undef mFsqaYli8AXA8muR2taiTp7sZbdSAX0
#undef  mG72KqqPMnk0IUhAG2u6X 
#undef  ml0hurHdmF0d85GpxvtHx 
#undef  mMueqb_bFx6h1Dq5FYdLd 
#undef msiqIfe8Aci2FIHOTIR3qsdKyqc9jUO
#undef  mHfbG04KVjXb9X6NTnYJx 
#undef mYURv805DtwXMB3i00wLkIXPqG17WHq
#undef  mPqvnNfD_YckjKYWwhuzN 
#undef  mm62JE4dDW7X3KavKHbI5 
#undef  mV30F6ZLorGiUeM_GWQkZ 
#undef mcBmuF9mL0hTY7DOpmPHFAEGhxNVxEB
#undef  mD5y_1TnUkVuc3JjtY7dn 
#undef  mLP6hNXpqqY5I3o36W_ic 
#undef  mQdM1luYGOgqwO8qCRqHw 
#undef  mBE2Ch4MzRWlScFuN5fWd 
#undef mV1zDLskEjl50MSypaDfGpryKBimJE0
#undef  myDhGU99kOFzHFv3QjOyw 
#undef  mPpNPETq3POeSoH8kpc6R 
#undef  mrzDBf2HcFmL0H4o7xP0U 
#undef  mFcbmmAe1Xn3sAcXtcGcG 
#undef  miUQ782fOUPhRLSezoKaH 
#undef  mIwuDmZOrznyrmkNgeDm5 
#undef  mPEXBE7IFNwhGqfhhF1Qx 
#undef  mkq4_nxl3S0Jzm77lyTd6 
#undef  m_IHI_fVc_q1bZjzyVqrm 
#undef  mE2zjQ8GOuKnFA2vXxQic 
#undef  mi9jnuzci0KtruYHVs0tu 
#undef  mKHaP0HbmD6AONuLTcuMC 
#undef muMgkskJtb7MY1kf4Zrs4vfmhNVvU_q
#undef  mYCDBBfn03HaGvoHBxAMq 
#undef  m_ZF9BdGj3tNbqnOuJlx9 
#undef  mXXqlktbFRNtTuOoWVQQz 
#undef  mhWau1QHFsGG_CriJhik5 
#undef  mUJS382SpQZsi10CwBsIS 
#undef  mMU0oJjiwMSWER83Yoiud 
#undef  mbH_1pmFzWdjvkWJbpHqf 
#undef mC5vSuqRiLThyQmuBUrzXxhUuu_8T75
#undef  mKh4dQiWjiAVc2BUxgn1y 
#undef mRNPT9tKM_gciYIBVxn_nAJvoU_zc7C
#undef  mckUV16HU9sHm9uZdiCqS 
#undef  mny4XFDXdGKYewM4vUxvP 
#undef  mk4wB1UVM28QkMlir6zEU 
#undef  mIN3LXmA7ud1jyId9hD40 
#undef  mswZzmsb_awITT3YY34kR 
#undef  msnQH2BEy39pSSh4Y5hGv 
#undef  mtyFmebtnPJYKn14LQZwF 
#undef  mya3I5vmc6etS2JR5W6jo 
#undef  mo0GXa6qmmi7aAU0xn_QX 
#undef  mPWHC75Hqqrxt2nHh19dD 
#undef  m_y5RXkWzthqVfeqHkEtF 
#undef  mBT8ErdK0daSMkfKeCyAT 
#undef  mdpd3Q1oSIMShIRkW3i0K 
#undef  mZdgMotEoyi1ylK3IVBKn 
#undef  mobeMv7_qVCDXm6ruXQdo 
#undef  mHoPFX2LlthArVJ80JzTW 
#undef  mB0eV_Ein7D8DtRR6R9PD 
#undef  mtM4ibcoFMNRakQm9MNch 
#undef  mBiKmhgRt19wSzQRtbfdd 
#undef  mzKNJLXvtvNUiRlFdYl86 
#undef  mTSqEnCp2F7oGsXocn00b 
#undef  mJpQJFURUc57_1UwCTPvr 
#undef  mmM3130WhDQoYKhJxw_Xq 
#undef  myQQZvECyjg3O56KOcG4I 
#undef  mQ_6zyV0kv3_EINtoxDwr 
#undef  mgjPUJwxp8V34r5ZRwn7u 
#undef  moxd8QZOAVwktUc3FByc5 
#undef  mkZ7Kqcf4wqU2aCyvQcrQ 
#undef  mnbIWy6z9Pe9uJP5EqsFX 
#undef  mmo6NathgJbdjMSVDtQp7 
#undef mPE7IBy0IPVAmmHy8SjBtbGdzyDGZ5w
#undef mkzSZJDew824aa0gKauM6fZ2VRvPUyZ
#undef  mE5LTP2zTjEhjnDFXjSev 
#undef  mDMt1ZTB93OOf720760yl 
#undef  mGGBlKcUhaQe41o1BnIkF 
#undef  mYwjl00gOK3Vja3UkLMIP 
#undef  mfhySFU1HsIBJqLiJ327y 
#undef  mdMUZEqfsNJwzXmiUDunr 
#undef  mvvh6qusT2GXh0DkHopPr 
#undef mwDlDseBie2pxcHRhfDFc6S1RpokmPB
#undef mByXC_NAGVGzCcmUEv_c9mAYK8t5jBN
#undef  mECAa9sgu7USEtdxuKwtx 
#undef  mQobuDSVt58FPnfszcDJr 
#undef mxXk248Fd2GKf_LFcesfZZnoIqLr72r
#undef  mAg3pV2BnIdWvGDAHS6XN 
#undef  mPiXWtTRtV3niuCzxZfTh 
#undef  myVYsDT7OYd8XctOkLKTo 
#undef mGEiFRHCGbRjviI6dzqMDlmzCs3ik32
#undef  mpPs91o0LDjQVAG6h6drD 
#undef  mLOayNi4OeqI5xdlV9zlg 
#undef  mkaV1FlCCNXxwPQiRYst6 
#undef  mHZ3j6aqYhTYV3deaGL88 
#undef  mAuUYEOm2BbWF6IJcF4pn 
#undef  mukY8albO2VdJSsWPXwW4 
#undef  mBduW7dqSuFrUAvwh7kHo 
#undef  mIn9uf1QzYnCvpv2LYrlu 
#undef  mT5QkV9DFX1GDx2hwjESN 
#undef mxppI9IWo6ETE7Xy0HpdgXksc2hcHJy
#undef mG7JUSOE49gtRFHxIAfjvLJ8YSx2vnS
#undef  mjvoRhqdFUGIOW_TT7ao4 
#undef  mXXlmh1qZ8LrEX5JPWAsH 
#undef  mwmLd9BQX0zGRjBZe4T9C 
#undef  mgLrtHcg4MaTZannI6pUB 
#undef  miYs8DgrLKKO1jnVddQve 
#undef  mMdQn4APCAlSzpf1HfuMv 
#undef  mhtNTtn6MOGdZh5y0qghw 
#undef mTiMXJ8zZxs8kJip50BA1j8OuF8N0w8
#undef mEgVjleirMsmEf67oPlWfaeIxUscFp7
#undef mBPuuAO5RqtP8G4TYdodjmRE3B0xQ6t
#undef  mysmqBdEdJc6LM1WnLE_V 
#undef  mUJURq86_xVTlgOXdOyA2 
#undef  miT4zgLZfSmtvyPhpk9eT 
#undef  mwTuETA6l5LkFRM2jsRui 
#undef  mC4jgxUk9IqoFVn3WtN5d 
#undef  mQ1Teamvbt5lB49LZfgOd 
#undef  mcrwhsXaIF63Fh7eMT4MG 
#undef  mpAPhqqYK8YmM6ja9Ozwe 
#undef mbB0o_TePQ_CM_sK1uVb2RkhYds_ArW
#undef mvx4iiBtbFTCCgKNBio6WX3hcEpFwdC
#undef  mJ1Z8GSPTaJVFODk7UGea 
#undef  mVhYWVEiqGfed8jjftJ1e 
#undef  msMAjv0u65PTGuZJqjppv 
#undef mH4uv54rqCTTFcGPjj9RxyN3HpzpG5W
#undef  mQcY6IgOnfAeJqQU_d7C3 
#undef  mlTXHwu3F3CXHHjryOJHR 
#undef  ms4jntDGIeDxNRjsn2Eq7 
#undef  mSye5PefiM2uFq__QqZRQ 
#undef mWtLIoQj1M2jOblvHvjzH9m9WaZ2XpZ
#undef  mlOdFLXaGOYUjivxD9wX5 
#undef mppxouGr5NqFj1UhsaPX9dF8rM6HHrV
#undef  mHhK4Wq8bVz54aZfcRF8o 
#undef  mi7RcOMDzpCM_fd0YYDqB 
#undef  mfDtAZ5HSHH1oUlJGGIlZ 
#undef  mowePBrYh_dGcjl9h5o4f 
#undef  mBIq_DVFgixqI_xjwE1SS 
#undef mvSkbHm3CGl2q0Wj6tYybdRsrCkavDX
#undef  mxolFRMUnTdXqvO1SqV6i 
#undef  mUlwEStSUJv18SInCzLuG 
#undef  mXet2VlYvMLSAhibYw9gK 
#undef  mwPtUuZDgsaCWLEN2d2o8 
#undef  mBjWU34yTNTqvHVW92wJn 
#undef  mlQFK8bzD5oJXCxBJV7sY 
#undef  mqUS1HkZXOdPZoz5hxZz1 
#undef  mMdtcRR7f77NuQu_fr3jJ 
#undef mGJoExPsp9LQpgvTNdOhH4AqaFjFPrq
#undef  muytsPxMUgB_P68ddaMn1 
#undef  mepnG7ntKnXufkqRWW9z6 
#undef  mSClDmTu1RahB8jJ_bvRI 
#undef  mrJuVHPe96ExiggCdsmDG 
#undef  mmBYorUTU9skF2KihFJIh 
#undef mlVwVAuHWeENUvSO7HWkMzRa_tFxENm
#undef mI34DveCaN9DNYZDxYuHUgIYz0Ne3X4
#undef  mMmHBiAaI0zzV3ljKxcO_ 
#undef  mzND_PZXt4nmzDFaIG26B 
#undef  mJ3X_4tWudQC9mG0a80Hc 
#undef  mPXEWgPN4wD4VKJTcqH1a 
#undef  mIqdr3spVPvnWuvEuHB7u 
#undef  msIKQo53AV0IVzGjNlewV 
#undef mAj1mWKjblCSJ4vrCIDPCtBbixR6G_I
#undef mH0rzhLZkT82t7fN6IGVkmpqxn9y3U6
#undef  mzxXooop26qxQLwrV55gp 
#undef mX4p7HQLaHppxdyC5eyULX5E8mE9RwH
#undef  mXMEXB9R3ROHfrrdWZS6b 
#undef  mcf5z6J_0Bh5xYToLm68d 
#undef  mK9SI2tuEHd6tqoKSYbJi 
#undef mDmPOuFvKpCYJNc4gEu5QXlqXd8CFgO
#undef  mdurnpS44gFEyG3iAVlcv 
#undef  mpv8yiIU5OTNWCY0FR3jr 
#undef  mMoHqiu6JwSK0lIvbHHDB 
#undef mqlgGcrNPonBjZZxdOMc1cfXZa22u42
#undef  mi2dBh8k9FLez0sEZ5dkY 
#undef mROJxX9wjLxUZjYd74YpQGRptuC2PN8
#undef  mvRNdf8YwY3ixuLJl_rX8 
#undef  mno1HJJeAIDaElX_e8_E2 
#undef mpGVq4mq1kqAkSGwAxR2eT1acboA8o0
#undef  mIm_ycsoau8_tLNuooXJK 
#undef  mNwbGd9CaRdW7etMDVp9l 
#undef  mbuu0EnGVF53w0618opIs 
#undef  mETgsfs6WSP_BZRACs15T 
#undef  mZXxCmMdUx7aas2_c3ufJ 
#undef  mnLfX8gryrIwz9uIwIzOO 
#undef mpEJbtQk7kAn4LAsjEHOWfzqi0wouBy
#undef  mLg1ngIK40sRfE7UPLjO9 
#undef  mqCAZWuyUH5kqcH_GFI_H 
#undef  mdOAGhzyWotAgsCpitefm 
#undef  mkjkEVFnl42KhUvXppZqI 
#undef  mDqzaA5LSZ9P5s2CU9mUo 
#undef  mZsASRf25kFGZKNUrTWAt 
#undef  mwH5LvjbwrSytFhP6RqwY 
#undef  meeew573ex8ktJQTmc61N 
#undef mUUq4U1Oqga0d8b3HPyuX8hMxfSRAvG
#undef  mK8B3zN6mQAB0xYXFlxGO 
#undef  maY4wzN767Gym8jISz779 
#undef  mAYXYBgyHj3X_Dd2pJZFe 
#undef mRneWJ109jmANhfUiE4CnpkFXk_Lv2r
#undef  mPNfgLFiDt2jD45GRfVny 
#undef  mX_72QhckNqIVHutc7sQK 
#undef  mB3meFqYoVLl7CRmENctD 
#undef  mnCtIlE9OtfFKOHdE3Qow 
#undef  miDaigpLYw0VF_Vn2JqCS 
#undef  mvHie9HLuNTMQuAtghEHv 
#undef miKJsEDuNShma3B8CvEC1aT0P2iZrvN
#undef mJypdKIZMGAY43lYvSQIZ_fAFrKnPPr
#undef  mLAThc7eriTzGBeEGc08E 
#undef mQF4BsfJECct84XFjjoEU6t3rs75CtC
#undef  mnAS1an2qOtGSVDxEnd9N 
#undef  mK6w4zj_Cfsechu5EkJHm 
#undef  mLRMpH2S7Q7rgidWYU85G 
#undef maRODO7jtDwOXJAQaX38H8DWUojuqcM
#undef mFzTZaNOrvPJ32i9gU3Wr9J28M8DBzQ
#undef  mpgKFTVEqPTb5IdYsP2ue 
#undef  my7F1rl9qUr89NgiItLnq 
#undef  mye5VOdwJN7t9cn3K3k8A 
#undef  mgbhB0EhABmFE4YiYt_F7 
#undef  mhzwVmt_MX6lld_L8c2CT 
#undef mVgUgXBETUT9RYgzaEEvmZjILeuz2W1
#undef  mbJpyUK6FpvvNSFdbJncQ 
#undef  mO8bpVd2PJ77esnS59E9g 
#undef  mpZpmaQl_lAQPlcd_urfl 
#undef  mFm9g1BwxYhrjkokcaPw5 
#undef  mN9lZo5JKGU_oWiM5lGVp 
#undef  min5lKhSVWtXKx_RlVkNq 
#undef mrfBUZQ89n2Fq6JbcSj051lgHgxgqmT
#undef  mb9AhvnFKiM7PZQgN8AnP 
#undef  mYCkonaAO4gN81sZ2p0n1 
#undef mmcXqtULH6e3SfUwc9mEozHR6BAeaAK
#undef  mRDNvioGRCQx5QFoNyf5u 
#undef  mZ1vlGA1DxtdKm7CKLuCu 
#undef  mB6MN9g5xL5nkN5YWag3C 
#undef  mEalxWU7zo1ATRu2ZVb1P 
#undef  mcBnPnpY1bM8uBYh6HUzl 
#undef  mlT_mjpAfCKCfVoralv_O 
#undef  mlx7mSONcMQHDJGRY1s9Q 
#undef  mR7UDzpdmNtk0LaVrg_WS 
#undef  mBoBygdTxOAro2IxSXLIy 
#undef mbDazXUVd8HbwiBPwI_Fzq6o77n69h3
#undef  mHMsdkJQIeMorGvCkHQL4 
#undef  maAxBoYk8MlyHqFZxz1nB 
#undef mo6JP2Hjo1hYSbtxG1tBsHQIY9i4q6x
#undef mWQRJWn48_10aX_qZsR8nxNi9ZbHwvJ
#undef  myAWMCcyr9KnmYFUOoI97 
#undef  mxFIMAbbLmgFagQqrs_3K 
#undef  mA4pIiwhfATkxUMZvmMgG 
#undef  mYbvoZQc6bHx_Fyt_MMHA 
#undef  moHThLiVDw2yJeZ0EL9So 
#undef  mk_6Non2n1Nk_IOZFo9It 
#undef mjUc6SW5zsycGDua26UpFKAohHGgzZw
#undef  mqAW_4Iop6vrpLxkp3WxM 
#undef  mRfKMxlL2tWQuVdK1eEze 
#undef mhN2hPhnFFq5alNSwVOjtfx8xECWu2g
#undef  mwhUA7Xg7QgUXMl3iamcW 
#undef  mRUhvrauugCIk8ZFUtFF5 
#undef  mM6XcgUcgIo1UBU_8497N 
#undef  mbTfdTaC63u_oUxPU581H 
#undef  musd6mNOqDV_uv4WuoukR 
#undef  mfhQjb7dYTtes1IJzyWzK 
#undef  myBNCW9B93fqpNc_ReUd9 
#undef  mJqjrZ0Sw_IsRstpA5TSG 
#undef  mYpMLFLIsCswIhxn8c85k 
#undef  mRtPBvwiZzHWglctKPmaF 
#undef  mHV9qHmbImBy3_nGzxW0A 
#undef  mCfZ3xmjpOoiue_rJZuHY 
#undef  mAvRcTPhbmN2xPSE_k1Fp 
#undef  mz_nGm5RRBM5OZvSzyerZ 
#undef mH07Fxx1cMYcyiFqHylt1AYLSl1yoct
#undef mu1aRcYPGwwmkdvLrXjWyYkshrNbQfZ
#undef  mydHLymMTKIi6ZifSrWI0 
#undef  mZ1llnScqJFuPUybkhEyg 
#undef  mnhWVfz3zH1VWcyQIB9k8 
#undef  mnwG4_xdlZA2y_F7AWbcT 
#undef  miz1KMizYV2R1rRtcNjOS 
#undef  mEFEjzuP6MMi7DCTCZFS6 
#undef  mD07x3flmZMPVC6kwqG6P 
#undef  mBOsEIVwEao1XJUDJrPZE 
#undef  mOrwrNhO0dJdd9_VZZyS4 
#undef  mGR6SzQWzeL24xknZXFg_ 
#undef mnHlLzNOM1EFnPgmTo6jXwnLA_aQ96X
#undef  mevXm56_YBOEgMhtXHLr_ 
#undef  mHpaYXfOsuVr3FUay39Ni 
#undef  mbWCzXPWiU5UnehGRQjZW 
#undef  msKjB5qmFwUklNSf8OzEo 
#undef  mjRKZlohcMYNnjTvtQdAO 
#undef  mgeJSmXLhlP6TNXhqZxir 
#undef  mplnjROdhBiR41oAbuFMA 
#undef  mStmvG8q8rxZk4ojH0SMY 
#undef  mpbd2v5irTp0SZEDScz2P 
#undef  mtcKUO4neYNCPizxaLKZc 
#undef m_dk3EP_dRaChCeAYkjUT4mGB6eHLjG
#undef  mBa_FkhJWkxczFPmuwrTO 
#undef  mjF6J0Tk42CCIJjZoCAkN 
#undef  mdM3yiUQKhlGh0UTgxGcr 
#undef  mCOT8cq5e07IauJokKEVa 
#undef  mbE01jtodeD0XHidN8ZSb 
#undef  mrRPX0yiW6moj3IJis656 
#undef  mbn4lbSkbx4XRi_23fRor 
#undef  mKxlK2zseKVjqTbudIc3N 
#undef  mAz18novAd1i1I1IpmgBW 
#undef  mrDmgRp9h0Dh4BUsSXIlh 
#undef mnbetEUpLtQdoPk5xCZf8Fw4xc2_skF
#undef  ml6Lc_xmRvI28kysuWKYN 
#undef  mXktWNzMmHZAFNamlC6GA 
#undef  mYJJZNT6RsQUQcGvcjw6s 
#undef  mP3125AruRj2p_81GOlEh 
#undef mZiH6fOOf1imwiMfiN54uLwlhFttHgN
#undef  mgTrILrfg8pPxUuxKEcTL 
#undef  mM4ZoJ_SnlQoODH2aaK0f 
#undef  muyiQYiSOQfifaTNSSeCM 
#undef  mct7Xy21wxRleVXcxtLRh 
#undef  mO2HwsX6Gi0Nsj_ziKTKW 
#undef  mt6yjpFiHdHNJRK2EXA4b 
#undef mxKgzipjOOx9WW36X6hqYuv2tZVVSjN
#undef  mme4iNmyh3d1i2QQNS_2c 
#undef  mbS9aFrXrV_XN2LWGc9z2 
#undef  mifNci4V9xDSn2__VqXAh 
#undef  mX2gazk4jNHcV_njxWdEu 
#undef  mrgX6KhYvp7HXnUnI9h7v 
#undef  mN6IouQCV1G_3AGCPEUFb 
#undef  mPRlplsRvbEfyTJGl_mKJ 
#undef mSSfilJz1l1vrPkNmBbBYOJOOC5eFjY
#undef  mpRZBOViMqw9Of7v7FuxF 
#undef  mtmqH82lzCWNK8m7mQsVB 
#undef  mhRsTVRq0qS2pWBngwcgU 
#undef  mGTLHA0VARSIg8ylf7DsN 
#undef  mfpPxSkQX4iiZk9EocpoP 
#undef  mTxmfff7IHS0qS8YwYb_m 
#undef  mnq4f9zw6OLsO0wliBlwX 
#undef  mMzdeJuOObJEf2uB5uZhp 
#undef  mw6wQQeGWiN7TOwHChuc4 
#undef  mdHMNa42WjKQSBe1HuHxE 
#undef  mmcpFPtC6G2s0YECGzTZ7 
#undef  mltpoGi2HnF2QM48Vhil6 
#undef mX6CEdeimSCykIq3Gne8p4_neWe8haV
#undef  mxz6PzKUJzf8QasULgU3i 
#undef  mAUFdFhd86lS580n0lcXL 
#undef  mwJQeqKCRIzCQuN1bibyJ 
#undef  mn5g7mx05lpWzycbp3jkZ 
#undef mL53y6DoHHNcMKFrTK859SLdb1UlAs_
#undef  mh8F2krMXRlx_4xzTdoOU 
#undef  mdQapdU_WoQv_sTc08Goq 
#undef  mxKAKWewVfJZvgXmZSukB 
#undef  mY7o1NPY6YeHYwpSxdBEu 
#undef  mmUKE2NIlpdAbdSvw43EJ 
#undef  mP7sdPnZQLOU0BFRsWdBb 
#undef mgTaMXBV1VgmmBwBtiSZCm3esY_KVoI
#undef  mbFqIXS7nGmSWTZUGdt6h 
#undef  mjoQfe68S5Q_rdrMl0euV 
#undef  mJu8rH9ch6s8uIUBEA4QJ 
#undef  maGeX7XTrrGt9WkYY6R6c 
#undef  mnN8tONujwWIvopGKHc6C 
#undef  mLWlvpGmo9eeHBf58X3QJ 
#undef mb0pptCGbYqOrmLwS1Q5tqzLpheIof7
#undef  mICKnpYrDMnPCPXp4dVqY 
#undef  mKPdnS09u_wtngxINal4U 
#undef  mzSNEVeoLA75I9ssO0ENy 
#undef  mPjJM_xxJfdKpSxL3Dwf6 
#undef  muDDe2mbjdikIAPIf9R74 
#undef  mLyMqhhnK6n0OQstUYG1v 
#undef mI4uvJUMtOHwM9tZ_fQVibhgDcYwIsM
#undef  mH9xkXr1In9WhMDYLLAkQ 
#undef  muaFGlfaFGOXNK4y4UmfE 
#undef  mneuHdaa4v6NnVM25bgXO 
#undef  mh7c_3v129zjIHtV8KZ26 
#undef  msKzyZlaNaz2l1SzaDpvX 
#undef  mR9VKjghgaLOMp5P9Zyl5 
#undef  mpDqyj5NDVnikUB0G2KXc 
#undef  mzf6azcCC18atKCW8jv7f 
#undef  mkNO0_AWxaGk3x9Q2X1v1 
#undef  mzViPhIynHrdcovjL0yxX 
#undef  mJyp2URhtKJ4pT5ukH5s5 
#undef meXTlhfdU7jLZmpkshJCw_8ShhDp_t6
#undef mCFOlmc2fW4dGKgcXGywjOcbcBURZe0
#undef mYOgju0IdpiIrPDX5YqfPiMIlBX99iH
#undef mSXKPLrYFE9ulUmIJdgyrdKyR63LaZP
#undef  mOSSGrURc1IqPIl85mdrs 
#undef me6pUE9_YClfZKU7x5OifQjPccb94lS
#undef  mADzh86bL8pAyHClR1vQ7 
#undef  mO4M7EU7PgI62BwLIk4ju 
#undef mn6ImA9zACAiMvrI6olSBmJrpXKLoXy
#undef  maw3RyPThWckVCHfhwxdL 
#undef  mKlSl2sIEia_PkLDcBaaC 
#undef  mih_9WLudSW1kyUGTMFLC 
#undef  mPXYuzTL9RZjjZA9XYUV9 
#undef  mf7PYtifgCp4QRlVsOFRz 
#undef  mcuNgJDAvPmo9ozTKSv_U 
#undef  mJ_QtD3j_Hy6klJbnFcoo 
#undef  mO3Hp1CHWD4lgwYuyxZ85 
#undef  myrZFqGRBYNF96ParCD6U 
#undef  mXO39HQBWo7GF_22EqX6m 
#undef  mtr8mN19Ounq6OdpTfVSE 
#undef  mzCpQW3fpqEdo67JRhyP6 
#undef moom6H8LGfVPeEz2uXxHK0Xuxids_EU
#undef  mFcgF3IsSMx4O4tc_aIEx 
#undef  mYYHF0v5IvelyodO3CkWq 
#undef mhQFg9mCeHTkil0MxNqFBcMWECKe0mm
#undef  merwTemrIm1u92wWr78Ta 
#undef  miLQiDMenWk2M677vtZJh 
#undef  mRSe1JGN0drSxJSLXeFPv 
#undef  mdqEgL_F1rF0PcEYLtdgV 
#undef  mCGZMd2s1bE8jGVM9cwoZ 
#undef  mqrdJ5cFacO6oCNOVfBFB 
#undef  mpI1hFbpLVrw4pYfwhffO 
#undef  mkHgNy3StwXafrhd2Ce4g 
#undef  mhAClyNpRo5WfaCqgeyGM 
#undef  mlNbIP19t8qNuxt2d_OKP 
#undef  ma4mt6LbiKt84kAFpQxO9 
#undef  mlfcVjh0iNdTwwvFkwxuv 
#undef  mOcjjgyUyDEe51laoqeGm 
#undef  mNQC69AzhHy9jDSqnR4rG 
#undef  mKrNzQ9o2OYPnNNMCiAE3 
#undef  my9E4sAt6II28meWefBqO 
#undef  mzZN1INodhXdUd04UijoI 
#undef  mpP2GF7ujwR6b4IMaTPKX 
#undef  mN5qlgjY0Pp93rpwmpkp6 
#undef  mtnUxtXxOkzROgIud9RzY 
#undef  mwMforR95PelCmG2YYe4Z 
#undef  munHuTw8Uzq5NKBMuDnpp 
#undef  mlK8WIoLNVgqusrN_lRzH 
#undef  majlOVtmuTRgvUVIcSQvo 
#undef  mOCoCw9Cs4kbfIBoXaFoG 
#undef  mclEcmEc3AtXuiRBOKWdo 
#undef  mSfn1rgQgnURKtReGFFxm 
#undef  mfrDnoW0Q_MaPPDXklzPm 
#undef  mFEY6Erk9Df5dSh_F4MeB 
#undef  mv_DqgxwqCfuDROyXpSIi 
#undef  ma645_NNZeT5F9wHyADdc 
#undef  mOjeFEIfCRgh8UuNv025K 
#undef  mr3z8JHQwMcj2xXE4THD3 
#undef  mF6Bt8jugVNRGdi0vvR62 
#undef  mlR5zcVB6km7zsMW2j4Aw 
#undef  mmcPNoeYt4rZGfwjHpq3k 
#undef mjNt5YlANSVVhZIAFumjXvIzF2hUNcV
#undef  mPR_vJk7xiUA8xxP1FUBt 
#undef  mvo7wAKdJZhJiiuRM0Hbs 
#undef  mMfSh_Wk7Uwf6D6ulSZVq 
#undef  miRDtKlwqk8TF7Sw9l2PW 
#undef  mqeD2C88v6MotXF1X0ZlV 
#undef  mgFSwG5Qfn_BLmntY2X0C 
#undef  mjSHC8mP2XGL723gPEeLJ 
#undef  mUXyv8dbk5ppT_acPhWw1 
#undef  mdtPDcYitAJmuptZI5zFq 
#undef mJWt3_nPdSmmWlrKrZnDvgIVZcFsnmO
#undef mXCQxlYZzKjt3aTjx0PfZJRKyQw07xF
#undef  mcUP2n_VBuIlxqYqfBL1z 
#undef  mG1rhlQsW6fk6GBUyGmwX 
#undef  mTxSy1aUd4rlAPO4PxvQI 
#undef mBN4ZxhCXvls3Jdd3Lx6hxm3H0auBES
#undef  mUcBD0Yy493w67BU4b_nV 
#undef mux0UzK5E31HHJOOZvgNn5ful3aEQGK
#undef mZyhRmr9RDqRn5F7u88VbqOcCvrU5JM
#undef  mULWVxWPmB8YP6nVlXdwx 
#undef  mS1cTnkFkfP7nyOzO1oR1 
#undef  mldBjQcmGr8eIRD1GvcbS 
#undef  mVejSuiipgaso22bYAXA5 
#undef  mFvTCBn4KoMBo14t4vfEG 
#undef mCANKknbAxy3AZvo6SxVpLmM7bcTDYG
#undef  mf6dMfxgoh6cHDHp8Qab5 
#undef  mFPW2Q4dl3H89ODxIFAB4 
#undef  mByUtXVZly0Au2emMwRAr 
#undef  mm_UJR0LI9kDIyN2IZsVK 
#undef  mJt4jiqHrPjmtLt1LXTXH 
#undef  mYZQL0WZd_roih9lMR5ZU 
#undef  mbhBlGSXOjQVuXigrQvnU 
#undef  mVlbuMLWi_vwpED0hDKIw 
#undef  mbEgSz1MPCDJfiXl8mzvB 
#undef  mwg2aC9ukDzEK6JpgUq0H 
#undef  mpDZGxej0afFEZAemXzRj 
#undef  mII972chYSMVfY7gKjPyP 
#undef  mGvKMfeWtBDkgZFjtUdcK 
#undef  mqqKt69glLALpHYtBYVIq 
#undef  mDHWaCli8Gp2m47qfC6RO 
#undef  mXUfd1VRZJk7TgY4HxOJN 
#undef  mFd6DPKb1DowSqilxGTbE 
#undef  mutvnLqU8rSyuONVmeMRx 
#undef  mznvSuQ7aBDLolhE4qXYl 
#undef  mkA9GKO_6AMEHDxbOk3Ga 
#undef  mknoSWMLUaR06YtBqtgam 
#endif
